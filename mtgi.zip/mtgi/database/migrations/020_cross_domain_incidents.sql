-- 020_cross_domain_incidents.sql
-- ONE incident architecture for every domain.
--
-- rescue_incidents keeps its existing rows and shape. This adds the domain and
-- the typed context columns so a truck incident, a private emergency, a VIP
-- rescue request and a Smart Bus incident are all the same kind of row - the
-- Control Center, dispatch and audit need no per-domain branch.

CREATE TABLE incident_domains (
    code VARCHAR(24) NOT NULL,
    label VARCHAR(80) NOT NULL,
    description VARCHAR(255) NULL,
    PRIMARY KEY (code)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO incident_domains (code, label, description) VALUES
    ('SMART_BUS', 'Smart Bus', 'Passenger coach incidents'),
    ('TRUCK_CARGO', 'Truck and cargo', 'Freight movement incidents'),
    ('PRIVATE_VEHICLE', 'Private vehicle', 'Subscriber private vehicle emergencies'),
    ('VIP', 'VIP', 'Priority subscriber rescue requests'),
    ('OTHER', 'Other', 'Everything else');

CREATE TABLE incident_types (
    code VARCHAR(32) NOT NULL,
    label VARCHAR(120) NOT NULL,
    domain VARCHAR(24) NULL,
    default_severity VARCHAR(16) NOT NULL DEFAULT 'MEDIUM',
    requires_capability VARCHAR(32) NULL,
    is_actionable BOOLEAN NOT NULL DEFAULT TRUE,
    PRIMARY KEY (code),
    CONSTRAINT fk_incident_types_domain FOREIGN KEY (domain) REFERENCES incident_domains (code),
    CONSTRAINT ck_incident_types_severity CHECK (default_severity IN ('LOW', 'MEDIUM', 'HIGH', 'CRITICAL'))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- The catalogue the brief asks for. Truck types carry the capability a response
-- needs, so dispatch can filter on capability before distance.
INSERT INTO incident_types (code, label, domain, default_severity, requires_capability) VALUES
    ('BREAKDOWN', 'Vehicle breakdown', NULL, 'HIGH', 'MECHANICAL'),
    ('ACCIDENT', 'Road accident', NULL, 'HIGH', 'MECHANICAL'),
    ('ROLLOVER', 'Rollover', NULL, 'CRITICAL', 'HEAVY_TOWING'),
    ('FIRE', 'Fire', NULL, 'CRITICAL', 'FIRE'),
    ('TIRE_FAILURE', 'Tire failure', 'TRUCK_CARGO', 'MEDIUM', 'MECHANICAL'),
    ('ENGINE_FAILURE', 'Engine failure', 'TRUCK_CARGO', 'HIGH', 'MECHANICAL'),
    ('ELECTRICAL_FAILURE', 'Electrical failure', 'TRUCK_CARGO', 'MEDIUM', 'MECHANICAL'),
    ('CARGO_DAMAGE', 'Cargo damage', 'TRUCK_CARGO', 'MEDIUM', NULL),
    ('CARGO_SHIFT', 'Cargo shifted', 'TRUCK_CARGO', 'MEDIUM', 'CARGO_RECOVERY'),
    ('CARGO_SPILL', 'Hazardous cargo spill', 'TRUCK_CARGO', 'CRITICAL', 'CARGO_RECOVERY'),
    ('SECURITY_EVENT', 'Security event', NULL, 'HIGH', 'SECURITY_SUPPORT'),
    ('DRIVER_MEDICAL', 'Driver medical emergency', NULL, 'CRITICAL', 'MEDICAL'),
    ('ROAD_BLOCK', 'Road block', NULL, 'LOW', NULL),
    ('FUEL_SHORTAGE', 'Fuel shortage', 'TRUCK_CARGO', 'MEDIUM', NULL),
    ('TRAILER_DISCONNECTED', 'Trailer disconnected', 'TRUCK_CARGO', 'CRITICAL', 'HEAVY_TOWING'),
    ('PASSENGER_MEDICAL', 'Passenger medical emergency', 'SMART_BUS', 'CRITICAL', 'MEDICAL'),
    ('BUS_BREAKDOWN', 'Bus breakdown', 'SMART_BUS', 'HIGH', 'MECHANICAL'),
    ('PRIVATE_EMERGENCY', 'Private vehicle emergency', 'PRIVATE_VEHICLE', 'CRITICAL', 'MEDICAL'),
    ('VIP_RESCUE', 'VIP rescue request', 'VIP', 'HIGH', NULL),
    ('OTHER', 'Other', NULL, 'MEDIUM', NULL);

CREATE TABLE rescue_capabilities (
    code VARCHAR(32) NOT NULL,
    label VARCHAR(80) NOT NULL,
    description VARCHAR(255) NULL,
    PRIMARY KEY (code)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO rescue_capabilities (code, label) VALUES
    ('MEDICAL', 'Medical'), ('AMBULANCE', 'Ambulance'), ('TOWING', 'Towing'),
    ('HEAVY_TOWING', 'Heavy towing'), ('MECHANICAL', 'Mechanical'), ('FIRE', 'Fire'),
    ('CARGO_RECOVERY', 'Cargo recovery'), ('ROAD_ASSISTANCE', 'Road assistance'),
    ('SECURITY_SUPPORT', 'Security support');

CREATE TABLE rescue_unit_capabilities (
    rescue_unit_id CHAR(36) NOT NULL,
    capability_code VARCHAR(32) NOT NULL,
    created_at TIMESTAMP(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
    PRIMARY KEY (rescue_unit_id, capability_code),
    CONSTRAINT fk_unit_capabilities_unit FOREIGN KEY (rescue_unit_id) REFERENCES rescue_units (id) ON DELETE CASCADE,
    CONSTRAINT fk_unit_capabilities_capability FOREIGN KEY (capability_code) REFERENCES rescue_capabilities (code)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- The seeded units advertise what they can do, so dispatch can match capability
-- before distance. An operator adds more rows; nothing is hard-coded in a
-- controller.
INSERT INTO rescue_unit_capabilities (rescue_unit_id, capability_code)
SELECT u.id, c.code
FROM rescue_units u
JOIN (SELECT 'MR-B0' AS unit_code UNION ALL SELECT 'MR-S1' UNION ALL SELECT 'MR-S2'
      UNION ALL SELECT 'MR-S4' UNION ALL SELECT 'MR-R5') seed ON seed.unit_code = u.code
JOIN (SELECT 'ROAD_ASSISTANCE' AS code UNION ALL SELECT 'MECHANICAL' UNION ALL SELECT 'TOWING'
      UNION ALL SELECT 'AMBULANCE' UNION ALL SELECT 'MEDICAL' UNION ALL SELECT 'HEAVY_TOWING') c
WHERE 1 = 1
  AND NOT EXISTS (
      SELECT 1 FROM rescue_unit_capabilities existing
      WHERE existing.rescue_unit_id = u.id AND existing.capability_code = c.code);

ALTER TABLE rescue_incidents
    ADD COLUMN domain VARCHAR(24) NOT NULL DEFAULT 'OTHER' AFTER source,
    ADD COLUMN incident_type VARCHAR(32) NULL AFTER domain,
    ADD COLUMN severity VARCHAR(16) NOT NULL DEFAULT 'MEDIUM' AFTER priority,
    ADD COLUMN subscriber_id CHAR(36) NULL AFTER vip_passenger_count,
    ADD COLUMN vehicle_id CHAR(36) NULL AFTER subscriber_id,
    ADD COLUMN tracked_asset_id CHAR(36) NULL AFTER vehicle_id,
    ADD COLUMN journey_id CHAR(36) NULL AFTER tracked_asset_id,
    ADD COLUMN consignment_id CHAR(36) NULL AFTER journey_id,
    ADD COLUMN rescue_code_id CHAR(36) NULL AFTER consignment_id,
    ADD COLUMN cargo_weight_kg DECIMAL(12,2) NULL AFTER rescue_code_id,
    ADD COLUMN cargo_hazardous BOOLEAN NOT NULL DEFAULT FALSE AFTER cargo_weight_kg,
    ADD COLUMN response_notes VARCHAR(500) NULL,
    ADD COLUMN distance_basis VARCHAR(16) NULL,
    ADD KEY ix_rescue_incidents_domain_status (domain, status, reported_at DESC),
    ADD KEY ix_rescue_incidents_subscriber (subscriber_id, status),
    ADD KEY ix_rescue_incidents_vehicle (vehicle_id, status),
    ADD KEY ix_rescue_incidents_asset (tracked_asset_id),
    ADD KEY ix_rescue_incidents_journey (journey_id),
    ADD KEY ix_rescue_incidents_severity (severity, status),
    ADD CONSTRAINT fk_rescue_incidents_domain FOREIGN KEY (domain) REFERENCES incident_domains (code),
    ADD CONSTRAINT fk_rescue_incidents_type FOREIGN KEY (incident_type) REFERENCES incident_types (code),
    ADD CONSTRAINT fk_rescue_incidents_subscriber FOREIGN KEY (subscriber_id) REFERENCES subscribers (id) ON DELETE SET NULL,
    ADD CONSTRAINT fk_rescue_incidents_canonical_vehicle FOREIGN KEY (vehicle_id) REFERENCES vehicles (id) ON DELETE SET NULL,
    ADD CONSTRAINT fk_rescue_incidents_asset FOREIGN KEY (tracked_asset_id) REFERENCES tracked_assets (id) ON DELETE SET NULL,
    ADD CONSTRAINT fk_rescue_incidents_code FOREIGN KEY (rescue_code_id) REFERENCES rescue_codes (id) ON DELETE SET NULL,
    ADD CONSTRAINT ck_rescue_incidents_severity CHECK (severity IN ('LOW', 'MEDIUM', 'HIGH', 'CRITICAL'));

-- The consignment foreign key is added by the Truck & Cargo migration, where the
-- consignments table actually exists; the column is here so every domain can
-- attach cargo context the same way.

-- Existing incidents are classified from the source they already carry, so no
-- historical row is left as "Other" when we know better.
UPDATE rescue_incidents SET domain = 'SMART_BUS' WHERE smartbus_trip_id IS NOT NULL AND domain = 'OTHER';
UPDATE rescue_incidents SET domain = 'PRIVATE_VEHICLE' WHERE source = 'PANIC_DEVICE' AND domain = 'OTHER';
UPDATE rescue_incidents SET severity = 'CRITICAL' WHERE source = 'PANIC_DEVICE' AND severity = 'MEDIUM';
UPDATE rescue_incidents SET severity = 'HIGH' WHERE priority = 'HIGH' AND severity = 'MEDIUM';
UPDATE rescue_incidents SET severity = 'CRITICAL' WHERE priority = 'CRITICAL' AND severity <> 'CRITICAL';
