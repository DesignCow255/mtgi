-- 015_vehicles_canonical.sql
-- The canonical vehicle registry, and the link from the three existing vehicle
-- stores to it. Additive: each domain table keeps its own id forever and gains a
-- vehicle_id pointing at the one canonical row.

CREATE TABLE vehicles (
    id CHAR(36) NOT NULL,
    vehicle_type VARCHAR(24) NOT NULL,
    registration_number VARCHAR(40) NOT NULL,
    country_of_registration CHAR(2) NOT NULL DEFAULT 'CD',
    chassis_number VARCHAR(64) NULL,
    vin VARCHAR(64) NULL,
    engine_number VARCHAR(64) NULL,
    make VARCHAR(80) NULL,
    model VARCHAR(80) NULL,
    year SMALLINT UNSIGNED NULL,
    color VARCHAR(40) NULL,
    fuel_type VARCHAR(24) NULL,
    ownership_type VARCHAR(24) NOT NULL DEFAULT 'UNKNOWN',
    owner_person_id CHAR(36) NULL,
    owner_organization_id CHAR(36) NULL,
    tracking_enabled BOOLEAN NOT NULL DEFAULT FALSE,
    verified_status VARCHAR(16) NOT NULL DEFAULT 'UNVERIFIED',
    status VARCHAR(24) NOT NULL DEFAULT 'ACTIVE',
    created_at TIMESTAMP(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
    updated_at TIMESTAMP(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6) ON UPDATE CURRENT_TIMESTAMP(6),
    deleted_at TIMESTAMP(6) NULL,
    PRIMARY KEY (id),
    -- A registration is unique per country, enforced in the database so no
    -- domain can quietly create the same plate twice.
    UNIQUE KEY uq_vehicles_registration (country_of_registration, registration_number),
    UNIQUE KEY uq_vehicles_chassis (chassis_number),
    UNIQUE KEY uq_vehicles_vin (vin),
    UNIQUE KEY uq_vehicles_engine (engine_number),
    KEY ix_vehicles_type (vehicle_type, status),
    KEY ix_vehicles_owner_person (owner_person_id),
    KEY ix_vehicles_owner_organization (owner_organization_id),
    KEY ix_vehicles_tracking (tracking_enabled, status),
    CONSTRAINT fk_vehicles_owner_person FOREIGN KEY (owner_person_id) REFERENCES persons (id) ON DELETE SET NULL,
    CONSTRAINT fk_vehicles_owner_organization FOREIGN KEY (owner_organization_id) REFERENCES organizations (id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Backfill: one canonical vehicle per existing Smart Bus vehicle.
INSERT INTO vehicles (id, vehicle_type, registration_number, country_of_registration, chassis_number,
                      engine_number, make, model, year, tracking_enabled, status, created_at)
SELECT v.id, 'BUS', v.registration_number, 'CD',
       (SELECT sv.chassis_no FROM subscriber_vehicles sv WHERE sv.plate_number = v.registration_number ORDER BY sv.created_at LIMIT 1),
       (SELECT sv.engine_no FROM subscriber_vehicles sv WHERE sv.plate_number = v.registration_number ORDER BY sv.created_at LIMIT 1),
       v.make, v.model, v.year, v.gps_enabled, v.status, v.created_at
FROM smartbus_vehicles v
WHERE NOT EXISTS (SELECT 1 FROM vehicles c WHERE c.id = v.id);

-- Backfill: one canonical vehicle per existing rescue unit.
INSERT INTO vehicles (id, vehicle_type, registration_number, country_of_registration, make, model,
                      tracking_enabled, status, created_at)
SELECT u.id, 'RESCUE_VEHICLE',
       COALESCE(NULLIF(u.code, ''), CONCAT('RU-', SUBSTRING(REPLACE(u.id, '-', ''), 1, 10))),
       'CD', u.base_name, u.unit_type, TRUE, u.status, u.created_at
FROM rescue_units u
WHERE NOT EXISTS (SELECT 1 FROM vehicles c WHERE c.id = u.id)
  AND NOT EXISTS (SELECT 1 FROM vehicles c WHERE c.registration_number = u.code);

-- Backfill: one canonical vehicle per existing subscriber vehicle.
INSERT INTO vehicles (id, vehicle_type, registration_number, country_of_registration, chassis_number,
                      engine_number, make, model, year, owner_person_id, status, created_at)
SELECT sv.id, 'PRIVATE_CAR', sv.plate_number, 'CD', sv.chassis_no, sv.engine_no, sv.vehicle_make,
       sv.vehicle_model, sv.vehicle_year, COALESCE(u.id, s.id), 'ACTIVE', sv.created_at
FROM subscriber_vehicles sv
JOIN subscribers s ON s.id = sv.subscriber_id
LEFT JOIN users u ON u.subscriber_id = s.id
WHERE NOT EXISTS (SELECT 1 FROM vehicles c WHERE c.id = sv.id);

-- Link columns: the domain rows keep their ids and gain a canonical pointer.
ALTER TABLE smartbus_vehicles
    ADD COLUMN vehicle_id CHAR(36) NULL AFTER id,
    ADD UNIQUE KEY uq_smartbus_vehicles_vehicle (vehicle_id),
    ADD CONSTRAINT fk_smartbus_vehicles_vehicle FOREIGN KEY (vehicle_id) REFERENCES vehicles (id) ON DELETE SET NULL;
UPDATE smartbus_vehicles SET vehicle_id = id WHERE vehicle_id IS NULL;

ALTER TABLE rescue_units
    ADD COLUMN vehicle_id CHAR(36) NULL AFTER id,
    ADD UNIQUE KEY uq_rescue_units_vehicle (vehicle_id),
    ADD CONSTRAINT fk_rescue_units_vehicle FOREIGN KEY (vehicle_id) REFERENCES vehicles (id) ON DELETE SET NULL;
UPDATE rescue_units SET vehicle_id = id WHERE vehicle_id IS NULL;

ALTER TABLE subscriber_vehicles
    ADD COLUMN vehicle_id CHAR(36) NULL AFTER id,
    ADD UNIQUE KEY uq_subscriber_vehicles_vehicle (vehicle_id),
    ADD CONSTRAINT fk_subscriber_vehicles_vehicle FOREIGN KEY (vehicle_id) REFERENCES vehicles (id) ON DELETE SET NULL;
UPDATE subscriber_vehicles SET vehicle_id = id WHERE vehicle_id IS NULL
  AND EXISTS (SELECT 1 FROM vehicles c WHERE c.id = subscriber_vehicles.id);

-- A person and an organization on the account, so domain scoping has an anchor.
ALTER TABLE users
    ADD COLUMN person_id CHAR(36) NULL AFTER subscriber_id,
    ADD COLUMN organization_id CHAR(36) NULL AFTER operator_id,
    ADD KEY ix_users_person (person_id),
    ADD KEY ix_users_organization (organization_id),
    ADD CONSTRAINT fk_users_person FOREIGN KEY (person_id) REFERENCES persons (id) ON DELETE SET NULL,
    ADD CONSTRAINT fk_users_organization FOREIGN KEY (organization_id) REFERENCES organizations (id) ON DELETE SET NULL;
UPDATE users SET person_id = id WHERE person_id IS NULL;

-- Subscribers and operators now point at the canonical person/organization too.
ALTER TABLE subscribers
    ADD COLUMN person_id CHAR(36) NULL AFTER id,
    ADD COLUMN organization_id CHAR(36) NULL AFTER company_registration,
    ADD KEY ix_subscribers_person (person_id),
    ADD KEY ix_subscribers_organization (organization_id),
    ADD CONSTRAINT fk_subscribers_person FOREIGN KEY (person_id) REFERENCES persons (id) ON DELETE SET NULL,
    ADD CONSTRAINT fk_subscribers_organization FOREIGN KEY (organization_id) REFERENCES organizations (id) ON DELETE SET NULL;
UPDATE subscribers SET person_id = id WHERE person_id IS NULL;

ALTER TABLE smartbus_operators
    ADD COLUMN organization_id CHAR(36) NULL AFTER id,
    ADD KEY ix_smartbus_operators_organization (organization_id),
    ADD CONSTRAINT fk_smartbus_operators_organization FOREIGN KEY (organization_id) REFERENCES organizations (id) ON DELETE SET NULL;
UPDATE smartbus_operators SET organization_id = id WHERE organization_id IS NULL;
