-- 007_subscriptions_receipts.sql
-- Canonical subscription domain: rescue products (fee engine catalog),
-- subscribers, subscriptions + fee lines, subscription payments with
-- allocations, ledger postings, government tax records and receipts.
--
-- Money is DECIMAL(14,2) USD, timestamps TIMESTAMP(6) UTC, UUID CHAR(36).
-- Fee amounts are seeded from the same canonical catalog that
-- app/Support/FeeEngine.php exposes; tests/fee-catalog-parity.php fails if the
-- seeded amounts ever drift from the engine.

CREATE TABLE rescue_products (
    id CHAR(36) NOT NULL,
    legacy_postgres_id VARCHAR(64) NULL,
    code VARCHAR(64) NOT NULL,
    name VARCHAR(160) NOT NULL,
    product_type VARCHAR(32) NOT NULL,
    vehicle_type VARCHAR(32) NOT NULL,
    billing_frequency VARCHAR(16) NOT NULL,
    base_fee DECIMAL(14,2) NOT NULL,
    total_fee DECIMAL(14,2) NOT NULL,
    currency CHAR(3) NOT NULL DEFAULT 'USD',
    applicable_provinces JSON NOT NULL,
    status VARCHAR(24) NOT NULL DEFAULT 'ACTIVE',
    created_at TIMESTAMP(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
    updated_at TIMESTAMP(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6) ON UPDATE CURRENT_TIMESTAMP(6),
    PRIMARY KEY (id),
    UNIQUE KEY uq_rescue_products_code (code),
    UNIQUE KEY uq_rescue_products_legacy_postgres_id (legacy_postgres_id),
    CONSTRAINT ck_rescue_products_type CHECK (product_type IN ('TRUCK_RESCUE', 'PRIVATE_VEHICLE_RESCUE')),
    CONSTRAINT ck_rescue_products_vehicle CHECK (vehicle_type IN ('TRUCK', 'PRIVATE_VEHICLE')),
    CONSTRAINT ck_rescue_products_frequency CHECK (billing_frequency IN ('ONE_TIME', 'MONTHLY', 'ANNUAL')),
    CONSTRAINT ck_rescue_products_total CHECK (total_fee > 0 AND base_fee >= 0 AND total_fee >= base_fee),
    CONSTRAINT ck_rescue_products_currency CHECK (currency = 'USD'),
    CONSTRAINT ck_rescue_products_status CHECK (status IN ('ACTIVE', 'RETIRED'))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Rule rows carry BOTH the chargeable lines (allocation_role = CHARGEABLE) that
-- reconcile to the product total and the informational sub-allocations of a
-- taxable container (allocation_role = SUBSET). Subsets are reported on
-- receipts and stored on the subscription, but are NEVER added to the total.
CREATE TABLE rescue_product_rules (
    id CHAR(36) NOT NULL,
    product_id CHAR(36) NOT NULL,
    component_key VARCHAR(48) NOT NULL,
    component_name VARCHAR(160) NOT NULL,
    component_type VARCHAR(48) NOT NULL,
    category VARCHAR(24) NOT NULL,
    allocation_role VARCHAR(16) NOT NULL,
    ledger_account VARCHAR(32) NOT NULL,
    amount DECIMAL(14,2) NOT NULL,
    is_taxable BOOLEAN NOT NULL DEFAULT FALSE,
    province VARCHAR(80) NULL,
    display_order SMALLINT UNSIGNED NOT NULL DEFAULT 0,
    created_at TIMESTAMP(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
    PRIMARY KEY (id),
    UNIQUE KEY uq_rescue_product_rules_component (product_id, component_key),
    KEY ix_rescue_product_rules_role (product_id, allocation_role, display_order),
    CONSTRAINT fk_rescue_product_rules_product FOREIGN KEY (product_id) REFERENCES rescue_products (id) ON DELETE CASCADE,
    CONSTRAINT ck_rescue_product_rules_role CHECK (allocation_role IN ('CHARGEABLE', 'SUBSET')),
    CONSTRAINT ck_rescue_product_rules_amount CHECK (amount > 0),
    CONSTRAINT ck_rescue_product_rules_province CHECK (province IS NULL OR province IN ('HAUT_KATANGA', 'LUALABA')),
    CONSTRAINT ck_rescue_product_rules_category CHECK (category IN ('BASE_FEE', 'TAXABLE', 'OPERATING_COST', 'TAX', 'PDC', 'PROFIT', 'RESERVE', 'OTHER', 'UNALLOCATED'))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE subscribers (
    id CHAR(36) NOT NULL,
    legacy_postgres_id VARCHAR(64) NULL,
    membership_number VARCHAR(40) NOT NULL,
    first_name VARCHAR(100) NULL,
    last_name VARCHAR(100) NULL,
    company_name VARCHAR(160) NULL,
    email VARCHAR(190) NULL,
    phone VARCHAR(32) NULL,
    alternative_phone VARCHAR(32) NULL,
    national_id VARCHAR(64) NULL,
    passport_number VARCHAR(64) NULL,
    company_registration VARCHAR(64) NULL,
    emergency_contact VARCHAR(140) NULL,
    emergency_phone VARCHAR(32) NULL,
    photo_url VARCHAR(500) NULL,
    digital_signature VARCHAR(500) NULL,
    gps_latitude DECIMAL(10,7) NULL,
    gps_longitude DECIMAL(10,7) NULL,
    notes TEXT NULL,
    is_active BOOLEAN NOT NULL DEFAULT TRUE,
    created_at TIMESTAMP(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
    updated_at TIMESTAMP(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6) ON UPDATE CURRENT_TIMESTAMP(6),
    deleted_at TIMESTAMP(6) NULL,
    PRIMARY KEY (id),
    UNIQUE KEY uq_subscribers_membership_number (membership_number),
    UNIQUE KEY uq_subscribers_legacy_postgres_id (legacy_postgres_id),
    KEY ix_subscribers_name (last_name, first_name),
    KEY ix_subscribers_phone (phone),
    KEY ix_subscribers_email (email),
    KEY ix_subscribers_national_id (national_id),
    KEY ix_subscribers_company (company_name),
    CONSTRAINT ck_subscribers_identity CHECK (first_name IS NOT NULL OR company_name IS NOT NULL),
    CONSTRAINT ck_subscribers_gps CHECK (
        (gps_latitude IS NULL OR (gps_latitude BETWEEN -90 AND 90)) AND
        (gps_longitude IS NULL OR (gps_longitude BETWEEN -180 AND 180))
    )
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE subscriber_vehicles (
    id CHAR(36) NOT NULL,
    subscriber_id CHAR(36) NOT NULL,
    plate_number VARCHAR(32) NOT NULL,
    vehicle_make VARCHAR(80) NULL,
    vehicle_model VARCHAR(80) NULL,
    vehicle_year SMALLINT UNSIGNED NULL,
    chassis_no VARCHAR(64) NULL,
    engine_no VARCHAR(64) NULL,
    cargo_category VARCHAR(24) NOT NULL DEFAULT 'GENERAL',
    created_at TIMESTAMP(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
    updated_at TIMESTAMP(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6) ON UPDATE CURRENT_TIMESTAMP(6),
    PRIMARY KEY (id),
    KEY ix_subscriber_vehicles_subscriber (subscriber_id, plate_number),
    CONSTRAINT fk_subscriber_vehicles_subscriber FOREIGN KEY (subscriber_id) REFERENCES subscribers (id) ON DELETE CASCADE,
    CONSTRAINT ck_subscriber_vehicles_cargo CHECK (cargo_category IN ('GENERAL', 'PERISHABLE', 'HAZARDOUS', 'HEAVY', 'CONTAINER', 'LIVESTOCK', 'OTHER')),
    CONSTRAINT ck_subscriber_vehicles_year CHECK (vehicle_year IS NULL OR vehicle_year BETWEEN 1950 AND 2100)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE subscriber_history (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    subscriber_id CHAR(36) NOT NULL,
    action VARCHAR(48) NOT NULL,
    description VARCHAR(255) NULL,
    metadata JSON NULL,
    created_by_user_id CHAR(36) NULL,
    created_at TIMESTAMP(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
    PRIMARY KEY (id),
    KEY ix_subscriber_history_subscriber (subscriber_id, created_at),
    CONSTRAINT fk_subscriber_history_subscriber FOREIGN KEY (subscriber_id) REFERENCES subscribers (id) ON DELETE CASCADE,
    CONSTRAINT fk_subscriber_history_actor FOREIGN KEY (created_by_user_id) REFERENCES users (id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE subscriptions (
    id CHAR(36) NOT NULL,
    legacy_postgres_id VARCHAR(64) NULL,
    subscription_no VARCHAR(40) NOT NULL,
    subscriber_id CHAR(36) NOT NULL,
    product_id CHAR(36) NULL,
    status VARCHAR(24) NOT NULL DEFAULT 'PENDING',
    membership_status VARCHAR(24) NOT NULL DEFAULT 'PENDING',
    start_date DATE NOT NULL,
    end_date DATE NOT NULL,
    expiry_date DATE NOT NULL,
    grace_period_days SMALLINT UNSIGNED NOT NULL DEFAULT 30,
    grace_end_date DATE NULL,
    is_renewed BOOLEAN NOT NULL DEFAULT FALSE,
    renewed_from_id CHAR(36) NULL,
    renewal_count SMALLINT UNSIGNED NOT NULL DEFAULT 0,
    total_amount DECIMAL(14,2) NOT NULL,
    taxable_amount DECIMAL(14,2) NOT NULL DEFAULT 0.00,
    currency CHAR(3) NOT NULL DEFAULT 'USD',
    province VARCHAR(80) NOT NULL,
    notes TEXT NULL,
    created_by_user_id CHAR(36) NULL,
    created_at TIMESTAMP(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
    updated_at TIMESTAMP(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6) ON UPDATE CURRENT_TIMESTAMP(6),
    PRIMARY KEY (id),
    UNIQUE KEY uq_subscriptions_number (subscription_no),
    UNIQUE KEY uq_subscriptions_legacy_postgres_id (legacy_postgres_id),
    KEY ix_subscriptions_subscriber (subscriber_id, status),
    KEY ix_subscriptions_expiry (status, expiry_date),
    KEY ix_subscriptions_province (province, created_at),
    KEY ix_subscriptions_product (product_id),
    KEY ix_subscriptions_renewed_from (renewed_from_id),
    CONSTRAINT fk_subscriptions_subscriber FOREIGN KEY (subscriber_id) REFERENCES subscribers (id) ON DELETE CASCADE,
    CONSTRAINT fk_subscriptions_product FOREIGN KEY (product_id) REFERENCES rescue_products (id) ON DELETE RESTRICT,
    CONSTRAINT fk_subscriptions_renewed_from FOREIGN KEY (renewed_from_id) REFERENCES subscriptions (id) ON DELETE SET NULL,
    CONSTRAINT fk_subscriptions_creator FOREIGN KEY (created_by_user_id) REFERENCES users (id) ON DELETE SET NULL,
    CONSTRAINT ck_subscriptions_status CHECK (status IN ('PENDING', 'ACTIVE', 'EXPIRED', 'SUSPENDED', 'CANCELLED', 'RENEWED')),
    CONSTRAINT ck_subscriptions_membership CHECK (membership_status IN ('PENDING', 'ACTIVE', 'EXPIRED', 'SUSPENDED', 'CANCELLED')),
    CONSTRAINT ck_subscriptions_province CHECK (province IN ('HAUT_KATANGA', 'LUALABA')),
    CONSTRAINT ck_subscriptions_total CHECK (total_amount > 0 AND taxable_amount >= 0),
    CONSTRAINT ck_subscriptions_currency CHECK (currency = 'USD'),
    CONSTRAINT ck_subscriptions_dates CHECK (end_date >= start_date AND expiry_date >= start_date)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE subscription_fees (
    id CHAR(36) NOT NULL,
    subscription_id CHAR(36) NOT NULL,
    component_key VARCHAR(48) NOT NULL,
    component_name VARCHAR(160) NOT NULL,
    component_type VARCHAR(48) NOT NULL,
    category VARCHAR(24) NOT NULL,
    allocation_role VARCHAR(16) NOT NULL,
    ledger_account VARCHAR(32) NOT NULL,
    amount DECIMAL(14,2) NOT NULL,
    is_taxable BOOLEAN NOT NULL DEFAULT FALSE,
    province VARCHAR(80) NULL,
    display_order SMALLINT UNSIGNED NOT NULL DEFAULT 0,
    created_at TIMESTAMP(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
    PRIMARY KEY (id),
    UNIQUE KEY uq_subscription_fees_component (subscription_id, component_key),
    KEY ix_subscription_fees_role (subscription_id, allocation_role, display_order),
    CONSTRAINT fk_subscription_fees_subscription FOREIGN KEY (subscription_id) REFERENCES subscriptions (id) ON DELETE CASCADE,
    CONSTRAINT ck_subscription_fees_role CHECK (allocation_role IN ('CHARGEABLE', 'SUBSET')),
    CONSTRAINT ck_subscription_fees_amount CHECK (amount > 0)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE subscription_history (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    subscription_id CHAR(36) NOT NULL,
    action VARCHAR(48) NOT NULL,
    description VARCHAR(255) NULL,
    metadata JSON NULL,
    created_by_user_id CHAR(36) NULL,
    created_at TIMESTAMP(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
    PRIMARY KEY (id),
    KEY ix_subscription_history_subscription (subscription_id, created_at),
    CONSTRAINT fk_subscription_history_subscription FOREIGN KEY (subscription_id) REFERENCES subscriptions (id) ON DELETE CASCADE,
    CONSTRAINT fk_subscription_history_actor FOREIGN KEY (created_by_user_id) REFERENCES users (id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE payments (
    id CHAR(36) NOT NULL,
    legacy_postgres_id VARCHAR(64) NULL,
    payment_reference VARCHAR(48) NOT NULL,
    transaction_number VARCHAR(48) NOT NULL,
    subscription_id CHAR(36) NOT NULL,
    amount DECIMAL(14,2) NOT NULL,
    currency CHAR(3) NOT NULL DEFAULT 'USD',
    amount_cdf DECIMAL(14,2) NULL,
    usd_cdf_rate DECIMAL(14,4) NULL,
    payment_method VARCHAR(32) NOT NULL,
    provider VARCHAR(48) NULL,
    channel VARCHAR(48) NULL,
    provider_reference VARCHAR(120) NULL,
    status VARCHAR(24) NOT NULL DEFAULT 'COMPLETED',
    paid_at TIMESTAMP(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
    operator_id CHAR(36) NULL,
    operator_name VARCHAR(140) NULL,
    location VARCHAR(140) NULL,
    narration VARCHAR(255) NULL,
    idempotency_key VARCHAR(120) NULL,
    received_by_user_id CHAR(36) NOT NULL,
    voided_at TIMESTAMP(6) NULL,
    void_reason VARCHAR(255) NULL,
    created_at TIMESTAMP(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
    updated_at TIMESTAMP(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6) ON UPDATE CURRENT_TIMESTAMP(6),
    PRIMARY KEY (id),
    UNIQUE KEY uq_payments_reference (payment_reference),
    UNIQUE KEY uq_payments_transaction_number (transaction_number),
    UNIQUE KEY uq_payments_idempotency_key (idempotency_key),
    UNIQUE KEY uq_payments_legacy_postgres_id (legacy_postgres_id),
    KEY ix_payments_subscription (subscription_id, paid_at),
    KEY ix_payments_paid (paid_at, status),
    CONSTRAINT fk_payments_subscription FOREIGN KEY (subscription_id) REFERENCES subscriptions (id) ON DELETE RESTRICT,
    CONSTRAINT fk_payments_receiver FOREIGN KEY (received_by_user_id) REFERENCES users (id) ON DELETE RESTRICT,
    CONSTRAINT fk_payments_operator FOREIGN KEY (operator_id) REFERENCES users (id) ON DELETE SET NULL,
    CONSTRAINT ck_payments_method CHECK (payment_method IN ('CASH', 'BANK', 'MOBILE_MONEY', 'CARD', 'BANK_TRANSFER')),
    CONSTRAINT ck_payments_status CHECK (status IN ('PENDING', 'COMPLETED', 'FAILED', 'VOIDED')),
    CONSTRAINT ck_payments_currency CHECK (currency = 'USD'),
    CONSTRAINT ck_payments_amount CHECK (amount > 0),
    CONSTRAINT ck_payments_void CHECK ((status = 'VOIDED' AND voided_at IS NOT NULL) OR (status <> 'VOIDED'))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE payment_allocations (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    payment_id CHAR(36) NOT NULL,
    component_key VARCHAR(48) NOT NULL,
    component_name VARCHAR(160) NOT NULL,
    component_type VARCHAR(48) NOT NULL,
    category VARCHAR(24) NOT NULL,
    allocation_role VARCHAR(16) NOT NULL,
    province VARCHAR(80) NULL,
    amount DECIMAL(14,2) NOT NULL,
    ledger_account VARCHAR(32) NOT NULL,
    created_at TIMESTAMP(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
    PRIMARY KEY (id),
    UNIQUE KEY uq_payment_allocations_component (payment_id, component_key),
    KEY ix_payment_allocations_account (ledger_account, created_at),
    CONSTRAINT fk_payment_allocations_payment FOREIGN KEY (payment_id) REFERENCES payments (id) ON DELETE CASCADE,
    CONSTRAINT ck_payment_allocations_role CHECK (allocation_role IN ('CHARGEABLE', 'SUBSET')),
    CONSTRAINT ck_payment_allocations_amount CHECK (amount > 0)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Provincial / national tax records derived from the SUBSET rule lines of the
-- paid subscription. DGI is recorded against the province of collection; no
-- split between provinces is invented (see MIGRATION_RISK_REGISTER item 2).
CREATE TABLE government_taxes (
    id CHAR(36) NOT NULL,
    payment_id CHAR(36) NOT NULL,
    subscription_id CHAR(36) NOT NULL,
    subscriber_id CHAR(36) NOT NULL,
    component_key VARCHAR(48) NOT NULL,
    component_type VARCHAR(48) NOT NULL,
    province VARCHAR(80) NOT NULL,
    amount DECIMAL(14,2) NOT NULL,
    collection_date TIMESTAMP(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
    collected_by_user_id CHAR(36) NULL,
    status VARCHAR(24) NOT NULL DEFAULT 'RECORDED',
    created_at TIMESTAMP(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
    PRIMARY KEY (id),
    KEY ix_government_taxes_province (province, collection_date),
    KEY ix_government_taxes_subscription (subscription_id),
    CONSTRAINT fk_government_taxes_payment FOREIGN KEY (payment_id) REFERENCES payments (id) ON DELETE CASCADE,
    CONSTRAINT fk_government_taxes_subscription FOREIGN KEY (subscription_id) REFERENCES subscriptions (id) ON DELETE RESTRICT,
    CONSTRAINT fk_government_taxes_subscriber FOREIGN KEY (subscriber_id) REFERENCES subscribers (id) ON DELETE RESTRICT,
    CONSTRAINT fk_government_taxes_collector FOREIGN KEY (collected_by_user_id) REFERENCES users (id) ON DELETE SET NULL,
    CONSTRAINT ck_government_taxes_amount CHECK (amount > 0),
    CONSTRAINT ck_government_taxes_province CHECK (province IN ('HAUT_KATANGA', 'LUALABA')),
    CONSTRAINT ck_government_taxes_status CHECK (status IN ('RECORDED', 'REMITTED', 'VOIDED'))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE revenue_ledgers (
    id CHAR(36) NOT NULL,
    name VARCHAR(64) NOT NULL,
    ledger_type VARCHAR(32) NOT NULL,
    description VARCHAR(255) NULL,
    created_at TIMESTAMP(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
    PRIMARY KEY (id),
    UNIQUE KEY uq_revenue_ledgers_name (name),
    CONSTRAINT ck_revenue_ledgers_type CHECK (ledger_type IN ('REVENUE', 'ASSET', 'LIABILITY', 'EQUITY', 'EXPENSE'))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE ledger_entries (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    ledger_id CHAR(36) NOT NULL,
    payment_id CHAR(36) NULL,
    entry_type VARCHAR(8) NOT NULL,
    account VARCHAR(32) NOT NULL,
    amount DECIMAL(14,2) NOT NULL,
    description VARCHAR(255) NULL,
    reference VARCHAR(64) NULL,
    created_at TIMESTAMP(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
    PRIMARY KEY (id),
    KEY ix_ledger_entries_ledger (ledger_id, created_at),
    KEY ix_ledger_entries_account (account, created_at),
    KEY ix_ledger_entries_payment (payment_id),
    CONSTRAINT fk_ledger_entries_ledger FOREIGN KEY (ledger_id) REFERENCES revenue_ledgers (id) ON DELETE CASCADE,
    CONSTRAINT fk_ledger_entries_payment FOREIGN KEY (payment_id) REFERENCES payments (id) ON DELETE SET NULL,
    CONSTRAINT ck_ledger_entries_type CHECK (entry_type IN ('DEBIT', 'CREDIT')),
    CONSTRAINT ck_ledger_entries_amount CHECK (amount > 0)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE receipts (
    id CHAR(36) NOT NULL,
    legacy_postgres_id VARCHAR(64) NULL,
    payment_id CHAR(36) NOT NULL,
    subscription_id CHAR(36) NULL,
    subscriber_id CHAR(36) NULL,
    receipt_number VARCHAR(32) NOT NULL,
    verification_number VARCHAR(32) NOT NULL,
    qr_data VARCHAR(500) NULL,
    barcode_data VARCHAR(500) NULL,
    breakdown JSON NULL,
    amount DECIMAL(14,2) NOT NULL,
    currency CHAR(3) NOT NULL DEFAULT 'USD',
    status VARCHAR(16) NOT NULL DEFAULT 'ISSUED',
    printed BOOLEAN NOT NULL DEFAULT FALSE,
    print_count INT UNSIGNED NOT NULL DEFAULT 0,
    printed_at TIMESTAMP(6) NULL,
    issued_at TIMESTAMP(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
    created_at TIMESTAMP(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
    updated_at TIMESTAMP(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6) ON UPDATE CURRENT_TIMESTAMP(6),
    PRIMARY KEY (id),
    UNIQUE KEY uq_receipts_payment (payment_id),
    UNIQUE KEY uq_receipts_number (receipt_number),
    UNIQUE KEY uq_receipts_verification (verification_number),
    UNIQUE KEY uq_receipts_legacy_postgres_id (legacy_postgres_id),
    KEY ix_receipts_subscriber (subscriber_id, issued_at),
    KEY ix_receipts_subscription (subscription_id),
    CONSTRAINT fk_receipts_payment FOREIGN KEY (payment_id) REFERENCES payments (id) ON DELETE RESTRICT,
    CONSTRAINT fk_receipts_subscription FOREIGN KEY (subscription_id) REFERENCES subscriptions (id) ON DELETE RESTRICT,
    CONSTRAINT fk_receipts_subscriber FOREIGN KEY (subscriber_id) REFERENCES subscribers (id) ON DELETE RESTRICT,
    CONSTRAINT ck_receipts_status CHECK (status IN ('ISSUED', 'VOID', 'REPRINTED')),
    CONSTRAINT ck_receipts_currency CHECK (currency = 'USD'),
    CONSTRAINT ck_receipts_amount CHECK (amount > 0)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Portal identity link (canonical User.subscriberId, optional + unique).
ALTER TABLE users
    ADD COLUMN subscriber_id CHAR(36) NULL AFTER role_id,
    ADD UNIQUE KEY uq_users_subscriber (subscriber_id),
    ADD CONSTRAINT fk_users_subscriber FOREIGN KEY (subscriber_id) REFERENCES subscribers (id) ON DELETE SET NULL;

-- Canonical product catalog (mirrors app/Support/FeeEngine.php).
INSERT INTO rescue_products (id, code, name, product_type, vehicle_type, billing_frequency, base_fee, total_fee, applicable_provinces) VALUES
    ('40000000-0000-4000-8000-000000000001', 'TRUCK_RESCUE', 'Truck Rescue Standby', 'TRUCK_RESCUE', 'TRUCK', 'ONE_TIME', 430.00, 600.00, JSON_ARRAY('HAUT_KATANGA', 'LUALABA')),
    ('40000000-0000-4000-8000-000000000002', 'PRIVATE_VEHICLE_RESCUE', 'Private Vehicle Rescue', 'PRIVATE_VEHICLE_RESCUE', 'PRIVATE_VEHICLE', 'MONTHLY', 40.00, 80.00, JSON_ARRAY('HAUT_KATANGA', 'LUALABA'));

-- Truck: GRO 430 + TAXABLE 170 = 600 chargeable; DGI 51 + PDC 15/15 + UNALLOCATED 89 = 170 subset.
INSERT INTO rescue_product_rules (id, product_id, component_key, component_name, component_type, category, allocation_role, ledger_account, amount, is_taxable, province, display_order) VALUES
    ('41000000-0000-4000-8000-000000000101', '40000000-0000-4000-8000-000000000001', 'GRO', 'General Rescue Operations', 'GENERAL_RESCUE_OPERATIONS', 'BASE_FEE', 'CHARGEABLE', 'GRO_REVENUE', 430.00, FALSE, NULL, 1),
    ('41000000-0000-4000-8000-000000000102', '40000000-0000-4000-8000-000000000001', 'TAXABLE', 'Taxable (container of DGI + PDC + unallocated remainder)', 'TAXABLE', 'TAXABLE', 'CHARGEABLE', 'TAX_REVENUE', 170.00, TRUE, NULL, 2),
    ('41000000-0000-4000-8000-000000000103', '40000000-0000-4000-8000-000000000001', 'DGI_TAX', 'DGI Tax (subset of Taxable)', 'DGI_TAX', 'TAX', 'SUBSET', 'TAX_REVENUE', 51.00, TRUE, NULL, 3),
    ('41000000-0000-4000-8000-000000000104', '40000000-0000-4000-8000-000000000001', 'PDC_HAUT_KATANGA', 'Haut-Katanga PDC (subset of Taxable)', 'PDC_HAUT_KATANGA', 'PDC', 'SUBSET', 'PDC_PAYABLE', 15.00, FALSE, 'HAUT_KATANGA', 4),
    ('41000000-0000-4000-8000-000000000105', '40000000-0000-4000-8000-000000000001', 'PDC_LUALABA', 'Lualaba PDC (subset of Taxable)', 'PDC_LUALABA', 'PDC', 'SUBSET', 'PDC_PAYABLE', 15.00, FALSE, 'LUALABA', 5),
    ('41000000-0000-4000-8000-000000000106', '40000000-0000-4000-8000-000000000001', 'UNALLOCATED', 'Unallocated remainder of Taxable (awaiting management allocation)', 'UNALLOCATED', 'UNALLOCATED', 'SUBSET', 'UNALLOCATED', 89.00, FALSE, NULL, 6);

-- Private: OP_COST 40 + TAXABLE 40 = 80 chargeable; DGI 12 + PDC 8 + PROFIT 20 = 40 subset.
INSERT INTO rescue_product_rules (id, product_id, component_key, component_name, component_type, category, allocation_role, ledger_account, amount, is_taxable, province, display_order) VALUES
    ('41000000-0000-4000-8000-000000000201', '40000000-0000-4000-8000-000000000002', 'OP_COST', 'Operating Cost', 'OPERATING_COST', 'OPERATING_COST', 'CHARGEABLE', 'OPERATING_COST', 40.00, FALSE, NULL, 1),
    ('41000000-0000-4000-8000-000000000202', '40000000-0000-4000-8000-000000000002', 'TAXABLE', 'Taxable (container of DGI + PDC + profit)', 'TAXABLE', 'TAXABLE', 'CHARGEABLE', 'TAX_REVENUE', 40.00, TRUE, NULL, 2),
    ('41000000-0000-4000-8000-000000000203', '40000000-0000-4000-8000-000000000002', 'DGI_TAX', 'DGI Tax (subset of Taxable)', 'DGI_TAX', 'TAX', 'SUBSET', 'TAX_REVENUE', 12.00, TRUE, NULL, 3),
    ('41000000-0000-4000-8000-000000000204', '40000000-0000-4000-8000-000000000002', 'PDC_TAX', 'PDC Tax (subset of Taxable)', 'PDC_TAX', 'PDC', 'SUBSET', 'PDC_PAYABLE', 8.00, FALSE, NULL, 4),
    ('41000000-0000-4000-8000-000000000205', '40000000-0000-4000-8000-000000000002', 'PROFIT', 'Profit (subset of Taxable)', 'PROFIT', 'PROFIT', 'SUBSET', 'PROFIT_REVENUE', 20.00, FALSE, NULL, 5);

-- Ledger chart of accounts (canonical LedgerAccount enum).
INSERT INTO revenue_ledgers (id, name, ledger_type, description) VALUES
    ('42000000-0000-4000-8000-000000000001', 'CASH', 'ASSET', 'Cash received at counter'),
    ('42000000-0000-4000-8000-000000000002', 'BANK', 'ASSET', 'Bank account receipts'),
    ('42000000-0000-4000-8000-000000000003', 'MOBILE_MONEY', 'ASSET', 'Mobile money receipts'),
    ('42000000-0000-4000-8000-000000000004', 'CARD', 'ASSET', 'Card acquirer receipts'),
    ('42000000-0000-4000-8000-000000000005', 'RECEIVABLE', 'ASSET', 'Amounts still receivable'),
    ('42000000-0000-4000-8000-000000000006', 'GRO_REVENUE', 'REVENUE', 'General rescue operations revenue'),
    ('42000000-0000-4000-8000-000000000007', 'CARGO_REVENUE', 'REVENUE', 'Cargo / driver standby revenue'),
    ('42000000-0000-4000-8000-000000000008', 'TAX_PAYABLE', 'LIABILITY', 'Tax collected pending remittance'),
    ('42000000-0000-4000-8000-000000000009', 'TAX_REVENUE', 'REVENUE', 'Taxable container revenue'),
    ('42000000-0000-4000-8000-000000000010', 'CAPITAL', 'EQUITY', 'Capital contributions'),
    ('42000000-0000-4000-8000-000000000011', 'EXPENSE', 'EXPENSE', 'Operating expenses'),
    ('42000000-0000-4000-8000-000000000012', 'OPERATING_COST', 'EXPENSE', 'Operating cost component'),
    ('42000000-0000-4000-8000-000000000013', 'PDC_PAYABLE', 'LIABILITY', 'Provincial direct cost payable'),
    ('42000000-0000-4000-8000-000000000014', 'PROFIT_REVENUE', 'REVENUE', 'Profit component revenue'),
    ('42000000-0000-4000-8000-000000000015', 'RESERVE', 'EQUITY', 'Reserve fund'),
    ('42000000-0000-4000-8000-000000000016', 'UNALLOCATED', 'LIABILITY', 'Unallocated fee remainder awaiting management allocation');
