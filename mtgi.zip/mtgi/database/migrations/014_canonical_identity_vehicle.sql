-- 014_canonical_identity_vehicle.sql
-- Canonical Identity, Organization, Vehicle and Location cores.
--
-- Purpose: give the platform ONE person, ONE company, ONE vehicle and ONE
-- location, so Smart Bus, VIP, Truck & Cargo and Private Vehicles can extend a
-- shared row instead of each keeping its own copy.
--
-- Preconditions: migrations 001-013 applied. This file only ADDS tables and
-- columns. No existing row is updated in place except by an additive backfill
-- into a new column.
--
-- Validation: bin/verify-migration.php compares counts before/after.
-- Rollback: database/rollback/014_canonical_identity_vehicle.sql (drops only what
-- this file added).

-- ---------------------------------------------------------------- reference data
-- Configurable vocabularies: adding a vehicle or location type is an INSERT, not
-- a deploy. Nothing in the domain code deep-codes these lists.
CREATE TABLE vehicle_types (
    code VARCHAR(24) NOT NULL,
    label VARCHAR(80) NOT NULL,
    category VARCHAR(24) NOT NULL DEFAULT 'OTHER',
    requires_license BOOLEAN NOT NULL DEFAULT FALSE,
    PRIMARY KEY (code)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE location_types (
    code VARCHAR(32) NOT NULL,
    label VARCHAR(80) NOT NULL,
    requires_coordinates BOOLEAN NOT NULL DEFAULT FALSE,
    PRIMARY KEY (code)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO vehicle_types (code, label, category) VALUES
    ('BUS', 'Bus', 'PASSENGER'), ('TRUCK', 'Truck', 'CARGO'), ('PRIVATE_CAR', 'Private car', 'PRIVATE'),
    ('MOTORCYCLE', 'Motorcycle', 'PRIVATE'), ('VAN', 'Van', 'CARGO'), ('AMBULANCE', 'Ambulance', 'RESCUE'),
    ('RESCUE_VEHICLE', 'Rescue vehicle', 'RESCUE'), ('TRAILER', 'Trailer', 'CARGO'),
    ('OTHER', 'Other', 'OTHER');

INSERT INTO location_types (code, label, requires_coordinates) VALUES
    ('COUNTRY', 'Country', FALSE), ('PROVINCE', 'Province', FALSE), ('CITY', 'City', FALSE),
    ('STATION', 'Bus or truck station', FALSE), ('TERMINAL', 'Terminal', FALSE),
    ('DEPOT', 'Depot', FALSE), ('WAREHOUSE', 'Warehouse', FALSE), ('BORDER_POST', 'Border post', FALSE),
    ('HOSPITAL', 'Hospital', TRUE), ('GARAGE', 'Garage', TRUE), ('FUEL_STATION', 'Fuel station', TRUE),
    ('RESCUE_BASE', 'Rescue base', TRUE), ('CHECKPOINT', 'Checkpoint', FALSE), ('OTHER', 'Other', FALSE);

-- ------------------------------------------------------------------- canonical person
CREATE TABLE persons (
    id CHAR(36) NOT NULL,
    first_name VARCHAR(100) NULL,
    middle_name VARCHAR(100) NULL,
    last_name VARCHAR(100) NULL,
    gender VARCHAR(16) NULL,
    date_of_birth DATE NULL,
    nationality CHAR(2) NULL,
    national_id VARCHAR(64) NULL,
    passport_number VARCHAR(64) NULL,
    email VARCHAR(190) NULL,
    phone VARCHAR(32) NULL,
    alternative_phone VARCHAR(32) NULL,
    photo_url VARCHAR(500) NULL,
    preferred_language VARCHAR(8) NOT NULL DEFAULT 'en',
    status VARCHAR(24) NOT NULL DEFAULT 'ACTIVE',
    created_at TIMESTAMP(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
    updated_at TIMESTAMP(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6) ON UPDATE CURRENT_TIMESTAMP(6),
    deleted_at TIMESTAMP(6) NULL,
    PRIMARY KEY (id),
    KEY ix_persons_email (email),
    KEY ix_persons_phone (phone),
    KEY ix_persons_national_id (national_id),
    KEY ix_persons_names (last_name, first_name)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- One person per existing user account.
INSERT INTO persons (id, first_name, last_name, email, phone, status, created_at, updated_at)
SELECT u.id, u.first_name, u.last_name, u.email, u.phone, 'ACTIVE', u.created_at, u.updated_at
FROM users u WHERE u.deleted_at IS NULL
  AND NOT EXISTS (SELECT 1 FROM persons p WHERE p.id = u.id);

-- One person per existing subscriber that does not already map to a user.
INSERT INTO persons (id, first_name, last_name, email, phone, alternative_phone, national_id,
                      passport_number, photo_url, status, created_at, updated_at)
SELECT s.id, s.first_name, s.last_name, s.email, s.phone, s.alternative_phone, s.national_id,
       s.passport_number, s.photo_url, 'ACTIVE', s.created_at, s.updated_at
FROM subscribers s
WHERE s.deleted_at IS NULL
  AND NOT EXISTS (SELECT 1 FROM persons p WHERE p.id = s.id)
  AND NOT EXISTS (SELECT 1 FROM users u WHERE u.subscriber_id = s.id);

-- ------------------------------------------------------------- canonical organization
CREATE TABLE organizations (
    id CHAR(36) NOT NULL,
    name VARCHAR(160) NOT NULL,
    registration_number VARCHAR(80) NULL,
    tax_number VARCHAR(80) NULL,
    organization_type VARCHAR(32) NOT NULL DEFAULT 'OTHER',
    country_code CHAR(2) NOT NULL DEFAULT 'CD',
    region VARCHAR(80) NULL,
    city VARCHAR(120) NULL,
    email VARCHAR(190) NULL,
    phone VARCHAR(32) NULL,
    address_text VARCHAR(255) NULL,
    status VARCHAR(24) NOT NULL DEFAULT 'ACTIVE',
    verified_at TIMESTAMP(6) NULL,
    created_at TIMESTAMP(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
    updated_at TIMESTAMP(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6) ON UPDATE CURRENT_TIMESTAMP(6),
    PRIMARY KEY (id),
    UNIQUE KEY uq_organizations_registration (registration_number),
    KEY ix_organizations_name (name),
    KEY ix_organizations_country (country_code, region)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- One organization per existing Smart Bus operator.
INSERT INTO organizations (id, name, organization_type, country_code, status, created_at)
SELECT o.id, o.name, 'TRANSPORT_OPERATOR', COALESCE(NULLIF(r.country_code, ''), 'CD'), 'ACTIVE', o.created_at
FROM smartbus_operators o
LEFT JOIN (SELECT origin, MIN(country_code) AS country_code FROM smartbus_routes GROUP BY origin) r
       ON r.origin = o.name
WHERE NOT EXISTS (SELECT 1 FROM organizations g WHERE g.id = o.id);

-- --------------------------------------------------------------- canonical location
CREATE TABLE locations (
    id CHAR(36) NOT NULL,
    location_type VARCHAR(32) NOT NULL,
    name VARCHAR(160) NOT NULL,
    country_code CHAR(2) NOT NULL DEFAULT 'CD',
    region VARCHAR(80) NULL,
    city VARCHAR(120) NULL,
    address_text VARCHAR(255) NULL,
    latitude DECIMAL(10,7) NULL,
    longitude DECIMAL(10,7) NULL,
    contact_phone VARCHAR(32) NULL,
    timezone VARCHAR(64) NOT NULL DEFAULT 'UTC',
    status VARCHAR(24) NOT NULL DEFAULT 'ACTIVE',
    parent_location_id CHAR(36) NULL,
    created_at TIMESTAMP(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
    updated_at TIMESTAMP(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6) ON UPDATE CURRENT_TIMESTAMP(6),
    PRIMARY KEY (id),
    KEY ix_locations_type_region (location_type, country_code, region, status),
    KEY ix_locations_geo (latitude, longitude),
    KEY ix_locations_parent (parent_location_id),
    CONSTRAINT fk_locations_parent FOREIGN KEY (parent_location_id) REFERENCES locations (id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Canonical location per existing service location and station, originals kept.
INSERT INTO locations (id, location_type, name, country_code, region, city, address_text,
                       latitude, longitude, contact_phone, status, created_at)
SELECT s.id, s.location_type, s.name, 'CD', s.province, NULL, s.address_text,
       s.latitude, s.longitude, s.contact_phone, s.status, s.created_at
FROM service_locations s
WHERE NOT EXISTS (SELECT 1 FROM locations l WHERE l.id = s.id);

INSERT INTO locations (id, location_type, name, country_code, region, city, address_text,
                       latitude, longitude, contact_phone, status, created_at)
SELECT st.id, 'STATION', st.name, st.country_code, st.province, st.city, st.address_text,
       st.latitude, st.longitude, st.contact_phone, st.status, st.created_at
FROM smartbus_stations st
WHERE NOT EXISTS (SELECT 1 FROM locations l WHERE l.id = st.id);

-- The original tables now point at the canonical row (they keep their own id).
ALTER TABLE service_locations ADD COLUMN location_id CHAR(36) NULL AFTER id;
UPDATE service_locations SET location_id = id WHERE location_id IS NULL;
ALTER TABLE service_locations
    ADD KEY ix_service_locations_canonical (location_id),
    ADD CONSTRAINT fk_service_locations_canonical FOREIGN KEY (location_id) REFERENCES locations (id) ON DELETE SET NULL;

ALTER TABLE smartbus_stations ADD COLUMN location_id CHAR(36) NULL AFTER id;
UPDATE smartbus_stations SET location_id = id WHERE location_id IS NULL;
ALTER TABLE smartbus_stations
    ADD KEY ix_smartbus_stations_canonical (location_id),
    ADD CONSTRAINT fk_smartbus_stations_canonical FOREIGN KEY (location_id) REFERENCES locations (id) ON DELETE SET NULL;
