-- 022_domain_rbac.sql
-- Domain permissions and an explicit role grant matrix.
--
-- No existing permission is widened implicitly: every grant below is a stated
-- decision (see docs/multi-domain/RBAC_IMPACT.md). "own" scoping is enforced by
-- ownership policies in the services, never by the permission column.

INSERT INTO permissions (id, code, name) VALUES
    ('15000000-0000-4000-8000-000000000001', 'identity.view', 'View canonical identity'),
    ('15000000-0000-4000-8000-000000000002', 'vehicle.view', 'View vehicles'),
    ('15000000-0000-4000-8000-000000000003', 'search.global', 'Global entity search'),
    ('15000000-0000-4000-8000-000000000004', 'tracking.global_view', 'View all tracked assets'),
    ('15000000-0000-4000-8000-000000000005', 'tracking.current_location', 'View a current location'),
    ('15000000-0000-4000-8000-000000000006', 'tracking.location_history', 'View location history'),
    ('15000000-0000-4000-8000-000000000007', 'tracking.device_manage', 'Manage tracking devices'),
    ('15000000-0000-4000-8000-000000000008', 'coverage.view', 'View rescue coverage'),
    ('15000000-0000-4000-8000-000000000009', 'coverage.manage', 'Manage rescue coverage'),
    ('15000000-0000-4000-8000-00000000000a', 'incident.global_view', 'View all incidents'),
    ('15000000-0000-4000-8000-00000000000b', 'incident.create', 'Create an incident'),
    ('15000000-0000-4000-8000-00000000000c', 'dispatch.manage', 'Manage dispatch'),
    ('15000000-0000-4000-8000-00000000000d', 'rescue_unit.manage', 'Manage rescue units'),
    ('15000000-0000-4000-8000-00000000000e', 'geofence.manage', 'Manage geofences'),
    ('15000000-0000-4000-8000-00000000000f', 'alert.manage', 'Manage alerts'),
    ('15000000-0000-4000-8000-000000000010', 'analytics.global_view', 'View cross-domain analytics'),
    ('15000000-0000-4000-8000-000000000011', 'vip.view', 'View VIP subscribers'),
    ('15000000-0000-4000-8000-000000000012', 'vip.create', 'Create VIP subscribers'),
    ('15000000-0000-4000-8000-000000000013', 'vip.update', 'Update VIP subscribers'),
    ('15000000-0000-4000-8000-000000000014', 'vip.manage_subscription', 'Manage VIP subscriptions'),
    ('15000000-0000-4000-8000-000000000015', 'vip.view_rescue_code', 'View a VIP rescue code'),
    ('15000000-0000-4000-8000-000000000016', 'vip.view_analytics', 'View VIP analytics'),
    ('15000000-0000-4000-8000-000000000017', 'vip.dependant_manage', 'Manage VIP dependants'),
    ('15000000-0000-4000-8000-000000000018', 'vip.emergency_request', 'Raise a VIP rescue request'),
    ('15000000-0000-4000-8000-000000000019', 'truck.view', 'View trucks'),
    ('15000000-0000-4000-8000-00000000001a', 'truck.create', 'Create trucks'),
    ('15000000-0000-4000-8000-00000000001b', 'truck.update', 'Update trucks'),
    ('15000000-0000-4000-8000-00000000001c', 'truck.operator_manage', 'Manage truck operators'),
    ('15000000-0000-4000-8000-00000000001d', 'truck.driver_manage', 'Manage truck drivers'),
    ('15000000-0000-4000-8000-00000000001e', 'truck.trailer_manage', 'Manage trailers'),
    ('15000000-0000-4000-8000-00000000001f', 'truck.cargo_view', 'View cargo'),
    ('15000000-0000-4000-8000-000000000020', 'truck.cargo_manage', 'Manage cargo'),
    ('15000000-0000-4000-8000-000000000021', 'truck.journey_manage', 'Manage truck journeys'),
    ('15000000-0000-4000-8000-000000000022', 'truck.tracking_view', 'View truck tracking'),
    ('15000000-0000-4000-8000-000000000023', 'private_vehicle.view', 'View private vehicles'),
    ('15000000-0000-4000-8000-000000000024', 'private_vehicle.manage', 'Manage private vehicles'),
    ('15000000-0000-4000-8000-000000000025', 'private_subscriber.manage', 'Manage private subscribers'),
    ('15000000-0000-4000-8000-000000000026', 'private_tracking_view', 'View private vehicle tracking'),
    ('15000000-0000-4000-8000-000000000027', 'private_journey.manage', 'Manage private journeys'),
    ('15000000-0000-4000-8000-000000000028', 'private_analytics.view', 'View private vehicle analytics');

-- SYSTEM_ADMIN holds every permission by construction.
INSERT INTO role_permissions (role_id, permission_id)
SELECT '00000000-0000-4000-8000-000000000001', id FROM permissions
WHERE id LIKE '15000000-0000-4000-8000-%';

-- HQ_DISPATCHER: coordinates response across every domain, read heavy.
INSERT INTO role_permissions (role_id, permission_id)
SELECT '00000000-0000-4000-8000-000000000002', id FROM permissions
WHERE id LIKE '15000000-0000-4000-8000-%'
  AND code IN ('identity.view', 'vehicle.view', 'search.global', 'tracking.global_view',
               'tracking.current_location', 'tracking.location_history', 'coverage.view',
               'incident.global_view', 'incident.create', 'dispatch.manage', 'rescue_unit.manage',
               'analytics.global_view', 'vip.view', 'vip.view_rescue_code', 'vip.view_analytics',
               'vip.emergency_request', 'truck.view', 'truck.cargo_view', 'truck.tracking_view',
               'private_vehicle.view', 'private_tracking_view', 'private_analytics.view');

-- RESCUE_OPERATOR: sees who and what they are rescuing; changes nothing else.
INSERT INTO role_permissions (role_id, permission_id)
SELECT '00000000-0000-4000-8000-000000000003', id FROM permissions
WHERE id LIKE '15000000-0000-4000-8000-%'
  AND code IN ('vehicle.view', 'tracking.global_view', 'tracking.current_location', 'coverage.view',
               'incident.global_view', 'incident.create', 'vip.view', 'vip.view_rescue_code',
               'truck.view', 'truck.cargo_view', 'private_vehicle.view');

-- AUDITOR: read-only verification across every domain.
INSERT INTO role_permissions (role_id, permission_id)
SELECT '00000000-0000-4000-8000-000000000008', id FROM permissions
WHERE id LIKE '15000000-0000-4000-8000-%'
  AND code IN ('identity.view', 'vehicle.view', 'search.global', 'tracking.global_view',
               'tracking.current_location', 'coverage.view', 'incident.global_view',
               'analytics.global_view', 'vip.view', 'truck.view', 'private_vehicle.view');

-- FINANCE_MANAGER: reconciliation visibility, no manifests, no positions.
INSERT INTO role_permissions (role_id, permission_id)
SELECT '00000000-0000-4000-8000-000000000004', id FROM permissions
WHERE id LIKE '15000000-0000-4000-8000-%'
  AND code IN ('vehicle.view', 'coverage.view', 'analytics.global_view', 'vip.view',
               'vip.view_analytics', 'truck.view', 'truck.cargo_view', 'private_vehicle.view');

-- DRIVER and CONDUCTOR: their own assigned work only - no cross-domain view.
INSERT INTO role_permissions (role_id, permission_id)
SELECT '00000000-0000-4000-8000-000000000006', id FROM permissions
WHERE id LIKE '15000000-0000-4000-8000-%' AND code IN ('tracking.current_location', 'incident.create');
INSERT INTO role_permissions (role_id, permission_id)
SELECT '00000000-0000-4000-8000-000000000007', id FROM permissions
WHERE id LIKE '15000000-0000-4000-8000-%' AND code = 'incident.create';

-- BUS_OPERATOR keeps Smart Bus and is explicitly denied the truck and private
-- domains: a bus operator has no business seeing a competitor's fleet.
INSERT INTO role_permissions (role_id, permission_id)
SELECT '00000000-0000-4000-8000-000000000005', id FROM permissions
WHERE id LIKE '15000000-0000-4000-8000-%'
  AND code IN ('vehicle.view', 'tracking.current_location', 'incident.create', 'vip.view');

-- CUSTOMER: no staff permission at all. "Own" is enforced by ownership checks.
