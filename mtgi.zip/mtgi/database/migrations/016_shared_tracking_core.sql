-- 016_shared_tracking_core.sql
-- ONE normalized tracking core for every domain.
--
-- The existing tracking_assets / tracking_positions pair is preserved. This adds
-- a typed asset model with a real vehicle foreign key, a device model with
-- assignment history, a one-row-per-asset current position for maps, an
-- append-only history for when someone explicitly asks, geofences, and alerts.
--
-- tracking_positions (the legacy history table) is left exactly as it is and is
-- still written by TrackingService::checkIn(); new ingestion writes
-- location_history and upserts tracked_asset_positions.

CREATE TABLE asset_types (
    code VARCHAR(24) NOT NULL,
    label VARCHAR(80) NOT NULL,
    is_vehicle BOOLEAN NOT NULL DEFAULT FALSE,
    PRIMARY KEY (code)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO asset_types (code, label, is_vehicle) VALUES
    ('BUS', 'Bus', TRUE), ('TRUCK', 'Truck', TRUE), ('PRIVATE_VEHICLE', 'Private vehicle', TRUE),
    ('RESCUE_VEHICLE', 'Rescue vehicle', TRUE), ('PERSON_DEVICE', 'Personal device', FALSE),
    ('TRAILER', 'Trailer', TRUE), ('OTHER', 'Other', FALSE);

-- ------------------------------------------------------------------- assets
CREATE TABLE tracked_assets (
    id CHAR(36) NOT NULL,
    asset_type VARCHAR(24) NOT NULL,
    vehicle_id CHAR(36) NULL,
    person_id CHAR(36) NULL,
    asset_code VARCHAR(40) NULL,
    label VARCHAR(160) NULL,
    tracking_status VARCHAR(24) NOT NULL DEFAULT 'UNKNOWN',
    last_seen_at TIMESTAMP(6) NULL,
    domain VARCHAR(24) NULL,
    status VARCHAR(24) NOT NULL DEFAULT 'ACTIVE',
    created_at TIMESTAMP(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
    updated_at TIMESTAMP(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6) ON UPDATE CURRENT_TIMESTAMP(6),
    PRIMARY KEY (id),
    UNIQUE KEY uq_tracked_assets_vehicle (vehicle_id),
    KEY ix_tracked_assets_type (asset_type, status),
    KEY ix_tracked_assets_domain (domain, asset_type, status),
    KEY ix_tracked_assets_person (person_id),
    KEY ix_tracked_assets_status_seen (tracking_status, last_seen_at),
    CONSTRAINT fk_tracked_assets_vehicle FOREIGN KEY (vehicle_id) REFERENCES vehicles (id) ON DELETE CASCADE,
    CONSTRAINT fk_tracked_assets_person FOREIGN KEY (person_id) REFERENCES persons (id) ON DELETE SET NULL,
    CONSTRAINT fk_tracked_assets_type FOREIGN KEY (asset_type) REFERENCES asset_types (code)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Bridge: every existing tracking asset gets a typed canonical asset. The old
-- table keeps working untouched, so no existing screen or test breaks.
INSERT INTO tracked_assets (id, asset_type, vehicle_id, asset_code, label, tracking_status, domain, status, created_at)
SELECT a.id,
       CASE a.asset_type WHEN 'SMARTBUS_VEHICLE' THEN 'BUS' WHEN 'RESCUE_UNIT' THEN 'RESCUE_VEHICLE' ELSE 'OTHER' END,
       a.reference_id,
       a.code, a.label,
       CASE a.status WHEN 'ACTIVE' THEN 'UNKNOWN' WHEN 'OFFLINE' THEN 'OFFLINE' ELSE 'UNKNOWN' END,
       CASE a.asset_type WHEN 'SMARTBUS_VEHICLE' THEN 'SMART_BUS' WHEN 'RESCUE_UNIT' THEN 'RESCUE' ELSE NULL END,
       'ACTIVE', a.created_at
FROM tracking_assets a
WHERE NOT EXISTS (SELECT 1 FROM tracked_assets t WHERE t.id = a.id);

ALTER TABLE tracking_assets
    ADD COLUMN tracked_asset_id CHAR(36) NULL AFTER id,
    ADD KEY ix_tracking_assets_canonical (tracked_asset_id),
    ADD CONSTRAINT fk_tracking_assets_canonical FOREIGN KEY (tracked_asset_id) REFERENCES tracked_assets (id) ON DELETE SET NULL;
UPDATE tracking_assets SET tracked_asset_id = id WHERE tracked_asset_id IS NULL;

-- ------------------------------------------------------------------ devices
CREATE TABLE tracking_devices (
    id CHAR(36) NOT NULL,
    device_uid VARCHAR(64) NOT NULL,
    device_token_hash CHAR(64) NOT NULL,
    imei VARCHAR(32) NULL,
    serial_number VARCHAR(64) NULL,
    provider VARCHAR(48) NULL,
    model VARCHAR(80) NULL,
    sim_number VARCHAR(32) NULL,
    firmware_version VARCHAR(32) NULL,
    status VARCHAR(16) NOT NULL DEFAULT 'ACTIVE',
    last_seen_at TIMESTAMP(6) NULL,
    installed_at TIMESTAMP(6) NULL,
    created_at TIMESTAMP(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
    updated_at TIMESTAMP(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6) ON UPDATE CURRENT_TIMESTAMP(6),
    PRIMARY KEY (id),
    UNIQUE KEY uq_tracking_devices_uid (device_uid),
    UNIQUE KEY uq_tracking_devices_imei (imei),
    KEY ix_tracking_devices_status (status, last_seen_at),
    CONSTRAINT ck_tracking_devices_status CHECK (status IN ('ACTIVE', 'OFFLINE', 'SUSPENDED', 'REMOVED', 'FAULT', 'UNKNOWN'))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Devices are replaced, never embedded in the vehicle master, so assignment is
-- history rather than a column.
CREATE TABLE tracking_device_assignments (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    device_id CHAR(36) NOT NULL,
    tracked_asset_id CHAR(36) NOT NULL,
    assigned_at TIMESTAMP(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
    unassigned_at TIMESTAMP(6) NULL,
    assigned_by_user_id CHAR(36) NULL,
    reason VARCHAR(255) NULL,
    PRIMARY KEY (id),
    KEY ix_device_assignments_current (tracked_asset_id, unassigned_at),
    KEY ix_device_assignments_device (device_id, unassigned_at),
    CONSTRAINT fk_device_assignments_device FOREIGN KEY (device_id) REFERENCES tracking_devices (id) ON DELETE CASCADE,
    CONSTRAINT fk_device_assignments_asset FOREIGN KEY (tracked_asset_id) REFERENCES tracked_assets (id) ON DELETE CASCADE,
    CONSTRAINT fk_device_assignments_actor FOREIGN KEY (assigned_by_user_id) REFERENCES users (id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ------------------------------------------------------- current position
-- One row per asset: this is what a map reads, so map latency is independent of
-- history size. Never loaded for ordinary screens.
CREATE TABLE tracked_asset_positions (
    tracked_asset_id CHAR(36) NOT NULL,
    latitude DECIMAL(10,7) NOT NULL,
    longitude DECIMAL(10,7) NOT NULL,
    altitude_meters DECIMAL(8,2) NULL,
    speed_kph DECIMAL(8,2) NULL,
    heading_degrees DECIMAL(6,2) NULL,
    accuracy_meters DECIMAL(8,2) NULL,
    engine_status VARCHAR(16) NULL,
    ignition_status VARCHAR(16) NULL,
    source VARCHAR(24) NOT NULL DEFAULT 'DEVICE',
    recorded_at TIMESTAMP(6) NOT NULL,
    received_at TIMESTAMP(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
    PRIMARY KEY (tracked_asset_id),
    KEY ix_positions_recorded (recorded_at),
    CONSTRAINT fk_positions_asset FOREIGN KEY (tracked_asset_id) REFERENCES tracked_assets (id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Append-only history, designed for scale. Partitioning is a documented upgrade
-- step (see docs/multi-domain/DATABASE_IMPACT.md), not applied now: a partitioned
-- table needs operational care before there is volume to justify it.
CREATE TABLE location_history (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    tracked_asset_id CHAR(36) NOT NULL,
    latitude DECIMAL(10,7) NOT NULL,
    longitude DECIMAL(10,7) NOT NULL,
    altitude_meters DECIMAL(8,2) NULL,
    speed_kph DECIMAL(8,2) NULL,
    heading_degrees DECIMAL(6,2) NULL,
    recorded_at TIMESTAMP(6) NOT NULL,
    received_at TIMESTAMP(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
    device_position_id VARCHAR(64) NULL,
    metadata JSON NULL,
    PRIMARY KEY (id),
    UNIQUE KEY uq_location_history_replay (tracked_asset_id, device_position_id),
    KEY ix_location_history_asset_time (tracked_asset_id, recorded_at DESC),
    KEY ix_location_history_time (recorded_at),
    CONSTRAINT fk_location_history_asset FOREIGN KEY (tracked_asset_id) REFERENCES tracked_assets (id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ------------------------------------------------------------- geofencing
CREATE TABLE geofence_types (
    code VARCHAR(32) NOT NULL,
    label VARCHAR(80) NOT NULL,
    PRIMARY KEY (code)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
INSERT INTO geofence_types (code, label) VALUES
    ('STATION', 'Station'), ('CORRIDOR', 'Corridor'), ('CITY', 'City'), ('DEPOT', 'Depot'),
    ('TERMINAL', 'Terminal'), ('WAREHOUSE', 'Warehouse'), ('BORDER_POST', 'Border post'),
    ('RESTRICTED', 'Restricted area'), ('HIGH_RISK', 'High risk zone'), ('CUSTOM', 'Custom');

CREATE TABLE geofences (
    id CHAR(36) NOT NULL,
    geofence_type VARCHAR(32) NOT NULL,
    name VARCHAR(160) NOT NULL,
    country_code CHAR(2) NOT NULL DEFAULT 'CD',
    region VARCHAR(80) NULL,
    center_latitude DECIMAL(10,7) NOT NULL,
    center_longitude DECIMAL(10,7) NOT NULL,
    radius_meters INT UNSIGNED NULL,
    polygon JSON NULL,
    applies_to_domains JSON NULL,
    alert_on_enter BOOLEAN NOT NULL DEFAULT TRUE,
    alert_on_exit BOOLEAN NOT NULL DEFAULT FALSE,
    status VARCHAR(16) NOT NULL DEFAULT 'ACTIVE',
    created_by_user_id CHAR(36) NULL,
    created_at TIMESTAMP(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
    updated_at TIMESTAMP(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6) ON UPDATE CURRENT_TIMESTAMP(6),
    PRIMARY KEY (id),
    KEY ix_geofences_type (geofence_type, country_code, status),
    KEY ix_geofences_geo (center_latitude, center_longitude),
    CONSTRAINT fk_geofences_type FOREIGN KEY (geofence_type) REFERENCES geofence_types (code),
    CONSTRAINT fk_geofences_creator FOREIGN KEY (created_by_user_id) REFERENCES users (id) ON DELETE SET NULL,
    CONSTRAINT ck_geofences_shape CHECK (radius_meters IS NOT NULL OR polygon IS NOT NULL)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE asset_geofence_state (
    tracked_asset_id CHAR(36) NOT NULL,
    geofence_id CHAR(36) NOT NULL,
    is_inside BOOLEAN NOT NULL DEFAULT FALSE,
    entered_at TIMESTAMP(6) NULL,
    exited_at TIMESTAMP(6) NULL,
    last_evaluated_at TIMESTAMP(6) NULL,
    PRIMARY KEY (tracked_asset_id, geofence_id),
    CONSTRAINT fk_asset_geofence_state_asset FOREIGN KEY (tracked_asset_id) REFERENCES tracked_assets (id) ON DELETE CASCADE,
    CONSTRAINT fk_asset_geofence_state_geofence FOREIGN KEY (geofence_id) REFERENCES geofences (id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------------------------------------------- alerts
CREATE TABLE alert_types (
    code VARCHAR(48) NOT NULL,
    label VARCHAR(120) NOT NULL,
    domain VARCHAR(24) NULL,
    default_severity VARCHAR(16) NOT NULL DEFAULT 'MEDIUM',
    is_actionable BOOLEAN NOT NULL DEFAULT TRUE,
    PRIMARY KEY (code),
    CONSTRAINT ck_alert_types_severity CHECK (default_severity IN ('LOW', 'MEDIUM', 'HIGH', 'CRITICAL'))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE tracking_alerts (
    id CHAR(36) NOT NULL,
    alert_code VARCHAR(48) NOT NULL,
    tracked_asset_id CHAR(36) NULL,
    incident_id CHAR(36) NULL,
    domain VARCHAR(24) NULL,
    severity VARCHAR(16) NOT NULL DEFAULT 'MEDIUM',
    message VARCHAR(500) NOT NULL,
    status VARCHAR(16) NOT NULL DEFAULT 'NEW',
    context JSON NULL,
    opened_at TIMESTAMP(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
    acknowledged_at TIMESTAMP(6) NULL,
    acknowledged_by_user_id CHAR(36) NULL,
    resolved_at TIMESTAMP(6) NULL,
    resolved_by_user_id CHAR(36) NULL,
    resolution_note VARCHAR(500) NULL,
    PRIMARY KEY (id),
    UNIQUE KEY uq_tracking_alerts_open (alert_code, tracked_asset_id, status),
    KEY ix_tracking_alerts_status (status, opened_at DESC),
    KEY ix_tracking_alerts_asset (tracked_asset_id, opened_at DESC),
    CONSTRAINT fk_tracking_alerts_type FOREIGN KEY (alert_code) REFERENCES alert_types (code),
    CONSTRAINT fk_tracking_alerts_asset FOREIGN KEY (tracked_asset_id) REFERENCES tracked_assets (id) ON DELETE CASCADE,
    CONSTRAINT fk_tracking_alerts_incident FOREIGN KEY (incident_id) REFERENCES rescue_incidents (id) ON DELETE SET NULL,
    CONSTRAINT fk_tracking_alerts_ack_user FOREIGN KEY (acknowledged_by_user_id) REFERENCES users (id) ON DELETE SET NULL,
    CONSTRAINT fk_tracking_alerts_resolved_user FOREIGN KEY (resolved_by_user_id) REFERENCES users (id) ON DELETE SET NULL,
    CONSTRAINT ck_tracking_alerts_status CHECK (status IN ('NEW', 'ACKNOWLEDGED', 'INVESTIGATING', 'RESOLVED', 'DISMISSED')),
    CONSTRAINT ck_tracking_alerts_severity CHECK (severity IN ('LOW', 'MEDIUM', 'HIGH', 'CRITICAL'))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Alert catalogue. Domains add their own rows; nothing is hard-coded in a
-- controller. A non-actionable alert is a device-health notice, not an operator
-- task, and is marked as such here.
INSERT INTO alert_types (code, label, domain, default_severity, is_actionable) VALUES
    ('GPS_OFFLINE', 'GPS signal lost', NULL, 'HIGH', TRUE),
    ('GPS_RECOVERED', 'GPS signal restored', NULL, 'LOW', FALSE),
    ('DEVICE_TAMPER', 'Device tamper detected', NULL, 'CRITICAL', TRUE),
    ('DEVICE_FAULT', 'Device fault', NULL, 'MEDIUM', TRUE),
    ('DEVICE_UNASSIGNED', 'Position from an unassigned device', NULL, 'HIGH', TRUE),
    ('GEOFENCE_ENTER', 'Geofence entered', NULL, 'MEDIUM', TRUE),
    ('GEOFENCE_EXIT', 'Geofence exited', NULL, 'MEDIUM', TRUE),
    ('HIGH_SPEED', 'Speed above limit', NULL, 'HIGH', TRUE),
    ('UNUSUAL_STOP', 'Unusual long stop', NULL, 'MEDIUM', TRUE),
    ('SUBSCRIPTION_EXPIRED', 'Rescue subscription expired', NULL, 'HIGH', TRUE),
    ('DEPARTURE_DELAY', 'Trip departed late', 'SMART_BUS', 'MEDIUM', TRUE),
    ('PASSENGER_BOARDING_INCOMPLETE', 'Boarding incomplete at departure', 'SMART_BUS', 'MEDIUM', TRUE),
    ('BUS_ROUTE_DEVIATION', 'Bus outside its route', 'SMART_BUS', 'MEDIUM', TRUE),
    ('CARGO_ROUTE_DEVIATION', 'Cargo movement deviated from plan', 'TRUCK_CARGO', 'HIGH', TRUE),
    ('REFRIGERATION_ALERT', 'Refrigeration out of range', 'TRUCK_CARGO', 'CRITICAL', TRUE),
    ('TRAILER_DISCONNECTED', 'Trailer disconnected', 'TRUCK_CARGO', 'CRITICAL', TRUE),
    ('LONG_UNPLANNED_STOP', 'Long unplanned stop', 'TRUCK_CARGO', 'MEDIUM', TRUE),
    ('FUEL_SHORTAGE', 'Fuel shortage', 'TRUCK_CARGO', 'MEDIUM', TRUE),
    ('EMERGENCY_REQUEST', 'Emergency request', 'PRIVATE_VEHICLE', 'CRITICAL', TRUE),
    ('PRIVATE_VEHICLE_OFFLINE', 'Private vehicle offline', 'PRIVATE_VEHICLE', 'MEDIUM', TRUE),
    ('VIP_COVERAGE_EXPIRING', 'VIP coverage expiring', 'VIP', 'MEDIUM', TRUE);
