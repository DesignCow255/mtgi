-- 008_audit_completeness.sql
-- The risk register (item 7) requires every audit row to carry
-- actor, role, action, entity + ids, previous/new data, IP, user agent,
-- session, time and metadata. The identity table already had most of it;
-- this migration adds the actor ROLE (frozen at write time, so a later role
-- change cannot rewrite history) and the SESSION that performed the action,
-- plus an index for the /api/audit timeline.

ALTER TABLE audit_logs
    ADD COLUMN actor_role VARCHAR(64) NULL AFTER actor_user_id,
    ADD COLUMN session_id CHAR(36) NULL AFTER actor_role,
    ADD KEY ix_audit_action_time (action, occurred_at),
    ADD KEY ix_audit_session (session_id);

UPDATE audit_logs a
    JOIN users u ON u.id = a.actor_user_id
    JOIN roles r ON r.id = u.role_id
SET a.actor_role = r.code
WHERE a.actor_role IS NULL;

ALTER TABLE audit_logs
    ADD CONSTRAINT fk_audit_session FOREIGN KEY (session_id) REFERENCES user_sessions (id) ON DELETE SET NULL;
