CREATE TABLE finance_transactions (
    id CHAR(36) NOT NULL, receipt_number VARCHAR(32) NOT NULL, smartbus_booking_id CHAR(36) NULL,
    transaction_type VARCHAR(32) NOT NULL DEFAULT 'SMARTBUS_PAYMENT', payment_method VARCHAR(32) NOT NULL,
    currency CHAR(3) NOT NULL, amount DECIMAL(14,2) NOT NULL, usd_cdf_rate DECIMAL(14,4) NOT NULL,
    amount_cdf DECIMAL(14,2) NOT NULL, expected_cdf DECIMAL(14,2) NOT NULL, variance_cdf DECIMAL(14,2) NOT NULL,
    status VARCHAR(24) NOT NULL, external_reference VARCHAR(120) NULL, received_by_user_id CHAR(36) NOT NULL,
    received_at TIMESTAMP(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
    PRIMARY KEY (id), UNIQUE KEY uq_finance_receipt (receipt_number), UNIQUE KEY uq_finance_smartbus_booking (smartbus_booking_id),
    KEY ix_finance_received_status (received_at, status),
    CONSTRAINT fk_finance_smartbus_booking FOREIGN KEY (smartbus_booking_id) REFERENCES smartbus_bookings (id) ON DELETE RESTRICT,
    CONSTRAINT fk_finance_receiver FOREIGN KEY (received_by_user_id) REFERENCES users (id) ON DELETE RESTRICT,
    CONSTRAINT ck_finance_method CHECK (payment_method IN ('CASH','MOBILE_MONEY','CARD','BANK_TRANSFER')),
    CONSTRAINT ck_finance_currency CHECK (currency IN ('CDF','USD')),
    CONSTRAINT ck_finance_status CHECK (status IN ('RECONCILED','VARIANCE','VOIDED'))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE finance_allocations (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT, transaction_id CHAR(36) NOT NULL, account_code VARCHAR(64) NOT NULL,
    beneficiary_type VARCHAR(32) NOT NULL, beneficiary_id CHAR(36) NULL, amount_cdf DECIMAL(14,2) NOT NULL,
    created_at TIMESTAMP(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
    PRIMARY KEY (id), KEY ix_finance_allocation_account (account_code, created_at),
    CONSTRAINT fk_finance_allocation_transaction FOREIGN KEY (transaction_id) REFERENCES finance_transactions (id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
