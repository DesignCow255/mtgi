-- 024_rate_precision.sql
-- Widen exchange_rates.rate to 12 decimal places.
--
-- WHY THIS EXISTS
--
-- 023 created the column as DECIMAL(18,6). That is not enough. 1/2900 is
-- 0.000344827586..., and at 6 decimals it rounds to 0.000344 -- a 0.24% error
-- applied to every USD->CDF conversion, which on a 1,740,000 CDF fare is real
-- money. Storing a rate at a precision that cannot represent the reciprocal of
-- a realistic rate is not a rounding detail.
--
-- It is a separate migration rather than an edit to 023 because Core\Migrator
-- checksums applied migrations and refuses to continue when one is modified.
-- That guard is correct and worth keeping: a changed checksum usually means
-- the schema on disk no longer matches what the file says.
--
-- Existing rows are widened in place and keep their values; DECIMAL widening is
-- lossless in this direction.

ALTER TABLE exchange_rates MODIFY rate DECIMAL(24,12) NOT NULL;
