CREATE TABLE panic_alerts (
    id CHAR(36) NOT NULL, alert_code VARCHAR(32) NOT NULL, subscriber_user_id CHAR(36) NOT NULL,
    rescue_incident_id CHAR(36) NOT NULL, latitude DECIMAL(10,7) NULL, longitude DECIMAL(10,7) NULL,
    location_text VARCHAR(255) NOT NULL, message VARCHAR(500) NULL, status VARCHAR(24) NOT NULL DEFAULT 'ACTIVE',
    acknowledged_by_user_id CHAR(36) NULL, activated_at TIMESTAMP(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
    acknowledged_at TIMESTAMP(6) NULL, resolved_at TIMESTAMP(6) NULL,
    PRIMARY KEY(id), UNIQUE KEY uq_panic_alert_code(alert_code), KEY ix_panic_status_time(status,activated_at),
    CONSTRAINT fk_panic_subscriber FOREIGN KEY(subscriber_user_id) REFERENCES users(id) ON DELETE RESTRICT,
    CONSTRAINT fk_panic_incident FOREIGN KEY(rescue_incident_id) REFERENCES rescue_incidents(id) ON DELETE RESTRICT,
    CONSTRAINT fk_panic_acknowledger FOREIGN KEY(acknowledged_by_user_id) REFERENCES users(id) ON DELETE SET NULL,
    CONSTRAINT ck_panic_status CHECK(status IN('ACTIVE','ACKNOWLEDGED','RESOLVED','CANCELLED'))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE user_notifications (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT, user_id CHAR(36) NOT NULL, notification_type VARCHAR(48) NOT NULL,
    title VARCHAR(180) NOT NULL, message VARCHAR(500) NOT NULL, entity_type VARCHAR(48) NULL, entity_id CHAR(36) NULL,
    read_at TIMESTAMP(6) NULL, created_at TIMESTAMP(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
    PRIMARY KEY(id), KEY ix_notification_user_unread(user_id,read_at,created_at),
    CONSTRAINT fk_notification_user FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
