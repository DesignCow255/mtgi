-- 010_smartbus_v2.sql
-- Smart Bus v2: rescue codes, VIP linkage, boarding windows, seat holds,
-- live manifest states, active journeys, stations, notification outbox and
-- configurable VIP benefits.
--
-- Rules honoured here:
--   * ADDITIVE ONLY. No DROP, no TRUNCATE, no re-keying, no history rewrite.
--   * The two CHECK constraints are WIDENED only; every pre-existing status
--     value stays valid, so historical rows are untouched.
--   * GPS is never duplicated: active journeys hold no coordinates, they
--     derive them from the existing tracking_assets/tracking_positions pair.
--   * Money stays DECIMAL; no float column is introduced.

-- ---------------------------------------------------------------- rescue codes
CREATE TABLE rescue_codes (
    id CHAR(36) NOT NULL,
    code VARCHAR(32) NOT NULL,
    country_code CHAR(2) NOT NULL DEFAULT 'CD',
    subscriber_id CHAR(36) NOT NULL,
    user_id CHAR(36) NULL,
    subscription_id CHAR(36) NULL,
    status VARCHAR(16) NOT NULL DEFAULT 'ACTIVE',
    issued_at TIMESTAMP(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
    activated_at TIMESTAMP(6) NULL,
    expires_at TIMESTAMP(6) NULL,
    revoked_at TIMESTAMP(6) NULL,
    revocation_reason VARCHAR(255) NULL,
    regeneration_of CHAR(36) NULL,
    generation INTEGER UNSIGNED NOT NULL DEFAULT 1,
    created_by_user_id CHAR(36) NULL,
    created_at TIMESTAMP(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
    updated_at TIMESTAMP(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6) ON UPDATE CURRENT_TIMESTAMP(6),
    -- A subscriber may hold exactly ONE ACTIVE code per subscription, while
    -- revoked codes are kept as history. MySQL unique indexes ignore NULLs, so a
    -- virtual column that is NULL for non-active rows enforces that in the
    -- database rather than only in the service.
    active_subscription_id CHAR(36) GENERATED ALWAYS AS (CASE WHEN status = 'ACTIVE' THEN subscription_id ELSE NULL END) VIRTUAL,
    active_subscriber_id CHAR(36) GENERATED ALWAYS AS (CASE WHEN status = 'ACTIVE' THEN subscriber_id ELSE NULL END) VIRTUAL,
    PRIMARY KEY (id),
    UNIQUE KEY uq_rescue_codes_code (code),
    UNIQUE KEY uq_rescue_codes_active_subscription (active_subscription_id),
    UNIQUE KEY uq_rescue_codes_active_subscriber (active_subscriber_id),
    KEY ix_rescue_codes_subscriber (subscriber_id, status),
    KEY ix_rescue_codes_status_expiry (status, expires_at),
    CONSTRAINT fk_rescue_codes_subscriber FOREIGN KEY (subscriber_id) REFERENCES subscribers (id) ON DELETE CASCADE,
    CONSTRAINT fk_rescue_codes_user FOREIGN KEY (user_id) REFERENCES users (id) ON DELETE SET NULL,
    CONSTRAINT fk_rescue_codes_subscription FOREIGN KEY (subscription_id) REFERENCES subscriptions (id) ON DELETE SET NULL,
    CONSTRAINT fk_rescue_codes_regeneration FOREIGN KEY (regeneration_of) REFERENCES rescue_codes (id) ON DELETE SET NULL,
    CONSTRAINT fk_rescue_codes_creator FOREIGN KEY (created_by_user_id) REFERENCES users (id) ON DELETE SET NULL,
    CONSTRAINT ck_rescue_codes_status CHECK (status IN ('PENDING', 'ACTIVE', 'EXPIRED', 'REVOKED', 'SUSPENDED')),
    CONSTRAINT ck_rescue_codes_format CHECK (code REGEXP '^MRC-[A-Z]{2}-[0-9]{2}-[0-9A-Z]{6}$')
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- rescue_code_id is NULLABLE on purpose: a guessed or unknown code is exactly
-- the event an auditor needs to see, and it has no code row to point at.
CREATE TABLE rescue_code_access_log (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    rescue_code_id CHAR(36) NULL,
    code_entered VARCHAR(32) NOT NULL,
    access_mode VARCHAR(16) NOT NULL,
    actor_user_id CHAR(36) NULL,
    session_id CHAR(36) NULL,
    actor_role VARCHAR(64) NULL,
    reason VARCHAR(255) NULL,
    ip_address VARCHAR(45) NULL,
    user_agent VARCHAR(500) NULL,
    granted TINYINT(1) NOT NULL DEFAULT 0,
    detail_level VARCHAR(16) NOT NULL DEFAULT 'VALIDITY_ONLY',
    created_at TIMESTAMP(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
    PRIMARY KEY (id),
    KEY ix_rescue_code_access_code (rescue_code_id, created_at),
    KEY ix_rescue_code_access_actor (actor_user_id, created_at),
    KEY ix_rescue_code_access_mode (access_mode, created_at),
    KEY ix_rescue_code_access_entered (code_entered, created_at),
    CONSTRAINT fk_rescue_code_access_code FOREIGN KEY (rescue_code_id) REFERENCES rescue_codes (id) ON DELETE CASCADE,
    CONSTRAINT fk_rescue_code_access_actor FOREIGN KEY (actor_user_id) REFERENCES users (id) ON DELETE SET NULL,
    CONSTRAINT ck_rescue_code_access_mode CHECK (access_mode IN ('PUBLIC_VERIFY', 'CONTROL_CENTER', 'PORTAL_SELF')),
    CONSTRAINT ck_rescue_code_access_detail CHECK (detail_level IN ('VALIDITY_ONLY', 'SUBSCRIBER', 'JOURNEY'))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ------------------------------------------------------------------- stations
CREATE TABLE smartbus_stations (
    id CHAR(36) NOT NULL,
    code VARCHAR(32) NOT NULL,
    name VARCHAR(160) NOT NULL,
    country_code CHAR(2) NOT NULL DEFAULT 'CD',
    province VARCHAR(80) NOT NULL,
    city VARCHAR(120) NOT NULL,
    terminal_name VARCHAR(120) NULL,
    bay_code VARCHAR(32) NULL,
    address_text VARCHAR(255) NULL,
    landmark VARCHAR(160) NULL,
    latitude DECIMAL(10,7) NULL,
    longitude DECIMAL(10,7) NULL,
    contact_phone VARCHAR(32) NULL,
    opening_hours VARCHAR(160) NULL,
    reporting_instructions VARCHAR(255) NULL,
    amenities JSON NULL,
    operator_instructions JSON NULL,
    status VARCHAR(16) NOT NULL DEFAULT 'ACTIVE',
    created_at TIMESTAMP(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
    updated_at TIMESTAMP(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6) ON UPDATE CURRENT_TIMESTAMP(6),
    PRIMARY KEY (id),
    UNIQUE KEY uq_smartbus_stations_code (code),
    KEY ix_smartbus_stations_hierarchy (country_code, province, city),
    CONSTRAINT ck_smartbus_stations_status CHECK (status IN ('ACTIVE', 'INACTIVE'))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- -------------------------------------------------------------- seat holds
CREATE TABLE smartbus_seat_holds (
    id CHAR(36) NOT NULL,
    trip_id CHAR(36) NOT NULL,
    seat_number SMALLINT UNSIGNED NOT NULL,
    held_by_user_id CHAR(36) NULL,
    hold_token CHAR(64) NOT NULL,
    expires_at TIMESTAMP(6) NOT NULL,
    released_at TIMESTAMP(6) NULL,
    converted_booking_id CHAR(36) NULL,
    created_at TIMESTAMP(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
    PRIMARY KEY (id),
    UNIQUE KEY uq_smartbus_seat_holds_token (hold_token),
    KEY ix_smartbus_seat_holds_seat (trip_id, seat_number, expires_at),
    KEY ix_smartbus_seat_holds_expiry (expires_at),
    CONSTRAINT fk_smartbus_seat_holds_trip FOREIGN KEY (trip_id) REFERENCES smartbus_trips (id) ON DELETE CASCADE,
    CONSTRAINT fk_smartbus_seat_holds_user FOREIGN KEY (held_by_user_id) REFERENCES users (id) ON DELETE SET NULL,
    CONSTRAINT fk_smartbus_seat_holds_booking FOREIGN KEY (converted_booking_id) REFERENCES smartbus_bookings (id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------- active journeys
-- No latitude/longitude columns: live position is derived from
-- tracking_assets(asset_type='SMARTBUS_VEHICLE') + tracking_positions.
CREATE TABLE active_journeys (
    id CHAR(36) NOT NULL,
    trip_id CHAR(36) NOT NULL,
    booking_id CHAR(36) NOT NULL,
    user_id CHAR(36) NULL,
    subscriber_id CHAR(36) NULL,
    rescue_code_id CHAR(36) NULL,
    vehicle_id CHAR(36) NOT NULL,
    operator_id CHAR(36) NOT NULL,
    route_id CHAR(36) NOT NULL,
    seat_number SMALLINT UNSIGNED NOT NULL,
    status VARCHAR(16) NOT NULL DEFAULT 'ACTIVE',
    rescue_coverage_status VARCHAR(16) NOT NULL DEFAULT 'ACTIVE',
    checked_in_at TIMESTAMP(6) NULL,
    boarded_at TIMESTAMP(6) NULL,
    journey_started_at TIMESTAMP(6) NULL,
    journey_completed_at TIMESTAMP(6) NULL,
    created_at TIMESTAMP(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
    updated_at TIMESTAMP(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6) ON UPDATE CURRENT_TIMESTAMP(6),
    PRIMARY KEY (id),
    UNIQUE KEY uq_active_journeys_booking (booking_id),
    KEY ix_active_journeys_trip (trip_id, status),
    KEY ix_active_journeys_subscriber (subscriber_id, status),
    CONSTRAINT fk_active_journeys_trip FOREIGN KEY (trip_id) REFERENCES smartbus_trips (id) ON DELETE CASCADE,
    CONSTRAINT fk_active_journeys_booking FOREIGN KEY (booking_id) REFERENCES smartbus_bookings (id) ON DELETE CASCADE,
    CONSTRAINT fk_active_journeys_user FOREIGN KEY (user_id) REFERENCES users (id) ON DELETE SET NULL,
    CONSTRAINT fk_active_journeys_subscriber FOREIGN KEY (subscriber_id) REFERENCES subscribers (id) ON DELETE SET NULL,
    CONSTRAINT fk_active_journeys_rescue_code FOREIGN KEY (rescue_code_id) REFERENCES rescue_codes (id) ON DELETE SET NULL,
    CONSTRAINT fk_active_journeys_vehicle FOREIGN KEY (vehicle_id) REFERENCES smartbus_vehicles (id) ON DELETE RESTRICT,
    CONSTRAINT fk_active_journeys_operator FOREIGN KEY (operator_id) REFERENCES smartbus_operators (id) ON DELETE RESTRICT,
    CONSTRAINT fk_active_journeys_route FOREIGN KEY (route_id) REFERENCES smartbus_routes (id) ON DELETE RESTRICT,
    CONSTRAINT ck_active_journeys_status CHECK (status IN ('ACTIVE', 'COMPLETED', 'CANCELLED', 'TERMINATED')),
    CONSTRAINT ck_active_journeys_rescue CHECK (rescue_coverage_status IN ('ACTIVE', 'INACTIVE', 'EXPIRED'))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------- notification outbox
CREATE TABLE message_templates (
    id CHAR(36) NOT NULL,
    event_code VARCHAR(48) NOT NULL,
    channel VARCHAR(16) NOT NULL,
    subject VARCHAR(160) NULL,
    body_template VARCHAR(500) NOT NULL,
    active BOOLEAN NOT NULL DEFAULT TRUE,
    created_at TIMESTAMP(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
    updated_at TIMESTAMP(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6) ON UPDATE CURRENT_TIMESTAMP(6),
    PRIMARY KEY (id),
    UNIQUE KEY uq_message_templates_event_channel (event_code, channel),
    CONSTRAINT ck_message_templates_channel CHECK (channel IN ('EMAIL', 'SMS', 'WHATSAPP', 'IN_APP'))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- status stays QUEUED until a real provider confirms delivery; the API reports
-- NOT_CONFIGURED rather than pretending a message was sent.
CREATE TABLE message_outbox (
    id CHAR(36) NOT NULL,
    event_code VARCHAR(48) NOT NULL,
    channel VARCHAR(16) NOT NULL,
    recipient_user_id CHAR(36) NULL,
    recipient_address VARCHAR(160) NULL,
    related_type VARCHAR(48) NULL,
    related_id CHAR(36) NULL,
    payload JSON NOT NULL,
    status VARCHAR(16) NOT NULL DEFAULT 'QUEUED',
    provider VARCHAR(48) NULL,
    provider_reference VARCHAR(120) NULL,
    failure_reason VARCHAR(255) NULL,
    scheduled_for TIMESTAMP(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
    sent_at TIMESTAMP(6) NULL,
    created_at TIMESTAMP(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
    PRIMARY KEY (id),
    KEY ix_message_outbox_dispatch (status, scheduled_for),
    KEY ix_message_outbox_related (related_type, related_id),
    CONSTRAINT fk_message_outbox_user FOREIGN KEY (recipient_user_id) REFERENCES users (id) ON DELETE CASCADE,
    CONSTRAINT ck_message_outbox_status CHECK (status IN ('QUEUED', 'SENDING', 'SENT', 'FAILED', 'CANCELLED'))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ------------------------------------------------------- vip benefits
CREATE TABLE vip_benefits (
    id CHAR(36) NOT NULL,
    benefit_code VARCHAR(48) NOT NULL,
    name VARCHAR(120) NOT NULL,
    description VARCHAR(255) NULL,
    applies_to VARCHAR(24) NOT NULL DEFAULT 'SUBSCRIBER',
    active BOOLEAN NOT NULL DEFAULT TRUE,
    created_at TIMESTAMP(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
    PRIMARY KEY (id),
    UNIQUE KEY uq_vip_benefits_code (benefit_code),
    CONSTRAINT ck_vip_benefits_scope CHECK (applies_to IN ('SUBSCRIBER', 'BOOKING', 'TRIP', 'JOURNEY'))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE subscriber_vip_benefits (
    id CHAR(36) NOT NULL,
    subscriber_id CHAR(36) NOT NULL,
    benefit_id CHAR(36) NOT NULL,
    granted_at TIMESTAMP(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
    granted_by_user_id CHAR(36) NULL,
    expires_at TIMESTAMP(6) NULL,
    PRIMARY KEY (id),
    UNIQUE KEY uq_subscriber_vip_benefits (subscriber_id, benefit_id),
    CONSTRAINT fk_subscriber_vip_benefits_subscriber FOREIGN KEY (subscriber_id) REFERENCES subscribers (id) ON DELETE CASCADE,
    CONSTRAINT fk_subscriber_vip_benefits_benefit FOREIGN KEY (benefit_id) REFERENCES vip_benefits (id) ON DELETE CASCADE,
    CONSTRAINT fk_subscriber_vip_benefits_grantor FOREIGN KEY (granted_by_user_id) REFERENCES users (id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ------------------------------------------------ additive column changes
ALTER TABLE smartbus_operators
    ADD COLUMN verification_status VARCHAR(16) NOT NULL DEFAULT 'PENDING' AFTER status,
    ADD COLUMN business_registration VARCHAR(80) NULL,
    ADD COLUMN license_number VARCHAR(80) NULL,
    ADD COLUMN support_phone VARCHAR(32) NULL,
    ADD COLUMN rescue_integration BOOLEAN NOT NULL DEFAULT FALSE,
    ADD COLUMN reporting_minutes_before_departure SMALLINT UNSIGNED NOT NULL DEFAULT 45,
    ADD COLUMN boarding_open_minutes_before_departure SMALLINT UNSIGNED NOT NULL DEFAULT 20,
    ADD COLUMN boarding_close_minutes_before_departure SMALLINT UNSIGNED NOT NULL DEFAULT 10;

ALTER TABLE smartbus_vehicles
    ADD COLUMN make VARCHAR(80) NULL AFTER code,
    ADD COLUMN model VARCHAR(80) NULL AFTER make,
    ADD COLUMN year SMALLINT UNSIGNED NULL AFTER model,
    ADD COLUMN has_air_conditioning BOOLEAN NOT NULL DEFAULT FALSE,
    ADD COLUMN has_wifi BOOLEAN NOT NULL DEFAULT FALSE,
    ADD COLUMN has_charging BOOLEAN NOT NULL DEFAULT FALSE,
    ADD COLUMN has_toilet BOOLEAN NOT NULL DEFAULT FALSE,
    ADD COLUMN gps_enabled BOOLEAN NOT NULL DEFAULT FALSE,
    ADD COLUMN verification_status VARCHAR(16) NOT NULL DEFAULT 'PENDING',
    ADD COLUMN inspection_status VARCHAR(16) NOT NULL DEFAULT 'PENDING',
    ADD COLUMN insurance_status VARCHAR(16) NOT NULL DEFAULT 'PENDING';

ALTER TABLE smartbus_routes
    ADD COLUMN country_code CHAR(2) NOT NULL DEFAULT 'CD' AFTER code,
    ADD COLUMN province VARCHAR(80) NULL,
    ADD COLUMN city VARCHAR(120) NULL,
    ADD COLUMN origin_station_id CHAR(36) NULL,
    ADD COLUMN destination_station_id CHAR(36) NULL,
    ADD COLUMN estimated_duration_minutes SMALLINT UNSIGNED NULL,
    ADD COLUMN is_direct BOOLEAN NOT NULL DEFAULT TRUE,
    ADD KEY ix_smartbus_routes_country (country_code, province, city),
    ADD KEY ix_smartbus_routes_origin_destination (origin, destination, status),
    ADD CONSTRAINT fk_smartbus_routes_origin_station FOREIGN KEY (origin_station_id) REFERENCES smartbus_stations (id) ON DELETE SET NULL,
    ADD CONSTRAINT fk_smartbus_routes_destination_station FOREIGN KEY (destination_station_id) REFERENCES smartbus_stations (id) ON DELETE SET NULL;

ALTER TABLE smartbus_trips
    ADD COLUMN reporting_at TIMESTAMP(6) NULL AFTER departure_at,
    ADD COLUMN boarding_opens_at TIMESTAMP(6) NULL,
    ADD COLUMN boarding_closes_at TIMESTAMP(6) NULL,
    ADD COLUMN arrival_estimate_at TIMESTAMP(6) NULL,
    ADD COLUMN departed_at TIMESTAMP(6) NULL,
    ADD COLUMN completed_at TIMESTAMP(6) NULL,
    ADD COLUMN delay_minutes SMALLINT UNSIGNED NOT NULL DEFAULT 0,
    ADD COLUMN vehicle_assignment_status VARCHAR(16) NOT NULL DEFAULT 'CONFIRMED',
    ADD COLUMN driver_user_id CHAR(36) NULL,
    ADD COLUMN conductor_user_id CHAR(36) NULL,
    ADD KEY ix_smartbus_trip_boarding (status, boarding_opens_at, boarding_closes_at),
    ADD KEY ix_smartbus_trip_route_departure (route_id, departure_at),
    ADD CONSTRAINT fk_smartbus_trip_driver FOREIGN KEY (driver_user_id) REFERENCES users (id) ON DELETE SET NULL,
    ADD CONSTRAINT fk_smartbus_trip_conductor FOREIGN KEY (conductor_user_id) REFERENCES users (id) ON DELETE SET NULL;

ALTER TABLE smartbus_bookings
    ADD COLUMN user_id CHAR(36) NULL AFTER created_by_user_id,
    ADD COLUMN subscriber_id CHAR(36) NULL AFTER user_id,
    ADD COLUMN rescue_code_id CHAR(36) NULL AFTER subscriber_id,
    ADD COLUMN vip_at_booking BOOLEAN NOT NULL DEFAULT FALSE,
    ADD COLUMN special_assistance VARCHAR(120) NULL,
    ADD COLUMN manifest_status VARCHAR(16) NOT NULL DEFAULT 'CONFIRMED',
    ADD COLUMN check_in_at TIMESTAMP(6) NULL,
    ADD COLUMN boarded_at TIMESTAMP(6) NULL,
    ADD COLUMN no_show_at TIMESTAMP(6) NULL,
    ADD COLUMN completed_at TIMESTAMP(6) NULL,
    ADD COLUMN cancelled_at TIMESTAMP(6) NULL,
    ADD COLUMN updated_at TIMESTAMP(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6) ON UPDATE CURRENT_TIMESTAMP(6),
    ADD KEY ix_smartbus_booking_manifest (trip_id, manifest_status),
    ADD KEY ix_smartbus_booking_user (user_id, created_at),
    ADD KEY ix_smartbus_booking_phone_trip (passenger_phone, trip_id),
    ADD CONSTRAINT fk_smartbus_booking_user FOREIGN KEY (user_id) REFERENCES users (id) ON DELETE SET NULL,
    ADD CONSTRAINT fk_smartbus_booking_subscriber FOREIGN KEY (subscriber_id) REFERENCES subscribers (id) ON DELETE SET NULL,
    ADD CONSTRAINT fk_smartbus_booking_rescue_code FOREIGN KEY (rescue_code_id) REFERENCES rescue_codes (id) ON DELETE SET NULL;

ALTER TABLE rescue_incidents
    ADD COLUMN smartbus_trip_id CHAR(36) NULL AFTER caller_phone,
    ADD COLUMN smartbus_booking_id CHAR(36) NULL AFTER smartbus_trip_id,
    ADD COLUMN smartbus_vehicle_id CHAR(36) NULL AFTER smartbus_booking_id,
    ADD COLUMN smartbus_operator_id CHAR(36) NULL AFTER smartbus_vehicle_id,
    ADD COLUMN passenger_count SMALLINT UNSIGNED NULL AFTER smartbus_operator_id,
    ADD COLUMN vip_passenger_count SMALLINT UNSIGNED NULL AFTER passenger_count,
    ADD COLUMN source_latitude DECIMAL(10,7) NULL AFTER vip_passenger_count,
    ADD COLUMN source_longitude DECIMAL(10,7) NULL AFTER source_latitude,
    ADD KEY ix_rescue_incidents_trip (smartbus_trip_id, status),
    ADD CONSTRAINT fk_rescue_incidents_trip FOREIGN KEY (smartbus_trip_id) REFERENCES smartbus_trips (id) ON DELETE SET NULL,
    ADD CONSTRAINT fk_rescue_incidents_vehicle FOREIGN KEY (smartbus_vehicle_id) REFERENCES smartbus_vehicles (id) ON DELETE SET NULL,
    ADD CONSTRAINT fk_rescue_incidents_operator FOREIGN KEY (smartbus_operator_id) REFERENCES smartbus_operators (id) ON DELETE SET NULL;

-- ------------------------------------------------------------- widen checks
-- Widening only: every historical status value remains valid.
ALTER TABLE smartbus_trips DROP CHECK ck_smartbus_trip_status;
ALTER TABLE smartbus_trips ADD CONSTRAINT ck_smartbus_trip_status
    CHECK (status IN ('SCHEDULED', 'BOARDING', 'DEPARTED', 'DELAYED', 'COMPLETED', 'CANCELLED'));

ALTER TABLE smartbus_bookings DROP CHECK ck_smartbus_booking_status;
ALTER TABLE smartbus_bookings ADD CONSTRAINT ck_smartbus_booking_status
    CHECK (status IN ('RESERVED', 'CONFIRMED', 'CHECKED_IN', 'BOARDED', 'NO_SHOW', 'COMPLETED', 'CANCELLED', 'REFUNDED'));

-- --------------------------------------------------------------- backfill
-- Historical bookings get the manifest state their status already implies.
UPDATE smartbus_bookings SET manifest_status = 'BOARDED' WHERE status = 'BOARDED' AND manifest_status = 'CONFIRMED';
UPDATE smartbus_bookings SET manifest_status = 'COMPLETED' WHERE status = 'COMPLETED';
UPDATE smartbus_bookings SET manifest_status = 'CANCELLED' WHERE status IN ('CANCELLED', 'REFUNDED') AND manifest_status = 'CONFIRMED';
-- A portal booking's creator is the passenger when that creator is a customer.
UPDATE smartbus_bookings b JOIN users u ON u.id = b.created_by_user_id
JOIN roles r ON r.id = u.role_id
SET b.user_id = u.id WHERE b.user_id IS NULL AND r.code = 'CUSTOMER';
-- GPS availability is a fact about the existing tracking asset, not a guess.
UPDATE smartbus_vehicles v SET v.gps_enabled = 1
WHERE EXISTS (SELECT 1 FROM tracking_assets a WHERE a.asset_type = 'SMARTBUS_VEHICLE' AND a.reference_id = v.id);

-- --------------------------------------------------------- smart bus perms
-- Granular permissions. Role grants are explicit (see PERMISSION_IMPACT.md);
-- no existing permission is widened implicitly.
INSERT INTO permissions (id, code, name) VALUES
    ('10000000-0000-4000-8000-000000000101', 'smartbus.rescue_status.view',    'View Smart Bus rescue protection status'),
    ('10000000-0000-4000-8000-000000000102', 'smartbus.rescue_status.manage',  'Manage Smart Bus rescue protection status'),
    ('10000000-0000-4000-8000-000000000103', 'smartbus.manifest.view',         'View a Smart Bus passenger manifest'),
    ('10000000-0000-4000-8000-000000000104', 'smartbus.checkin.passenger',     'Check a passenger in'),
    ('10000000-0000-4000-8000-000000000105', 'smartbus.board.passenger',       'Confirm a passenger boarded'),
    ('10000000-0000-4000-8000-000000000106', 'smartbus.rescue_code.manage',    'Issue, revoke and regenerate rescue codes'),
    ('10000000-0000-4000-8000-000000000107', 'smartbus.rescue_code.verify',    'Look up a rescue code in the control center'),
    ('10000000-0000-4000-8000-000000000108', 'smartbus.incident.create',       'Raise an incident from a Smart Bus trip'),
    ('10000000-0000-4000-8000-000000000109', 'smartbus.pilot.view',           'View Smart Bus pilot analytics');

-- SYSTEM_ADMIN holds every permission by construction.
-- smartbus.manage is excluded: migration 001 already granted it to this role,
-- and re-granting it would violate the role_permissions primary key.
INSERT INTO role_permissions (role_id, permission_id)
SELECT '00000000-0000-4000-8000-000000000001', id FROM permissions
WHERE code LIKE 'smartbus.%' AND code <> 'smartbus.manage';

-- HQ_DISPATCHER: coordinates response, verifies codes, raises incidents.
INSERT INTO role_permissions (role_id, permission_id) VALUES
    ('00000000-0000-4000-8000-000000000002', '10000000-0000-4000-8000-000000000101'),
    ('00000000-0000-4000-8000-000000000002', '10000000-0000-4000-8000-000000000103'),
    ('00000000-0000-4000-8000-000000000002', '10000000-0000-4000-8000-000000000104'),
    ('00000000-0000-4000-8000-000000000002', '10000000-0000-4000-8000-000000000107'),
    ('00000000-0000-4000-8000-000000000002', '10000000-0000-4000-8000-000000000108'),
    ('00000000-0000-4000-8000-000000000002', '10000000-0000-4000-8000-000000000109');

-- BUS_OPERATOR: own operator data, boarding facts, incidents, pilot view.
INSERT INTO role_permissions (role_id, permission_id) VALUES
    ('00000000-0000-4000-8000-000000000005', '10000000-0000-4000-8000-000000000101'),
    ('00000000-0000-4000-8000-000000000005', '10000000-0000-4000-8000-000000000103'),
    ('00000000-0000-4000-8000-000000000005', '10000000-0000-4000-8000-000000000105'),
    ('00000000-0000-4000-8000-000000000005', '10000000-0000-4000-8000-000000000107'),
    ('00000000-0000-4000-8000-000000000005', '10000000-0000-4000-8000-000000000108'),
    ('00000000-0000-4000-8000-000000000005', '10000000-0000-4000-8000-000000000109');

-- CONDUCTOR: a single assigned trip - manifest, check-in, boarding, incident.
INSERT INTO role_permissions (role_id, permission_id) VALUES
    ('00000000-0000-4000-8000-000000000007', '10000000-0000-4000-8000-000000000101'),
    ('00000000-0000-4000-8000-000000000007', '10000000-0000-4000-8000-000000000103'),
    ('00000000-0000-4000-8000-000000000007', '10000000-0000-4000-8000-000000000104'),
    ('00000000-0000-4000-8000-000000000007', '10000000-0000-4000-8000-000000000105'),
    ('00000000-0000-4000-8000-000000000007', '10000000-0000-4000-8000-000000000108');

-- DRIVER: safety status, incident only - no passenger PII, no boarding.
INSERT INTO role_permissions (role_id, permission_id) VALUES
    ('00000000-0000-4000-8000-000000000006', '10000000-0000-4000-8000-000000000101'),
    ('00000000-0000-4000-8000-000000000006', '10000000-0000-4000-8000-000000000108');

-- RESCUE_OPERATOR: sees who they are rescuing, can raise incidents.
INSERT INTO role_permissions (role_id, permission_id) VALUES
    ('00000000-0000-4000-8000-000000000003', '10000000-0000-4000-8000-000000000101'),
    ('00000000-0000-4000-8000-000000000003', '10000000-0000-4000-8000-000000000103'),
    ('00000000-0000-4000-8000-000000000003', '10000000-0000-4000-8000-000000000107'),
    ('00000000-0000-4000-8000-000000000003', '10000000-0000-4000-8000-000000000108');

-- AUDITOR: read-only verification of what happened.
INSERT INTO role_permissions (role_id, permission_id) VALUES
    ('00000000-0000-4000-8000-000000000008', '10000000-0000-4000-8000-000000000101'),
    ('00000000-0000-4000-8000-000000000008', '10000000-0000-4000-8000-000000000103'),
    ('00000000-0000-4000-8000-000000000008', '10000000-0000-4000-8000-000000000109');

-- FINANCE_MANAGER: pilot analytics for reconciliation, no manifests.
INSERT INTO role_permissions (role_id, permission_id) VALUES
    ('00000000-0000-4000-8000-000000000004', '10000000-0000-4000-8000-000000000109');

-- ---------------------------------------------------------------- vip seeds
INSERT INTO vip_benefits (id, benefit_code, name, description, applies_to) VALUES
    ('11000000-0000-4000-8000-000000000001', 'RESCUE_CODE',        'Mamore Rescue Code',              'A permanent, human-readable rescue code for the subscriber', 'SUBSCRIBER'),
    ('11000000-0000-4000-8000-000000000002', 'JOURNEY_SAFETY',     'Live journey safety status',      'Safety status, manifest sync and GPS health for an active trip', 'JOURNEY'),
    ('11000000-0000-4000-8000-000000000003', 'PRIORITY_ASSISTANCE', 'Priority rescue assistance',      'Subscriber is flagged as a VIP on the rescue manifest', 'SUBSCRIBER'),
    ('11000000-0000-4000-8000-000000000004', 'EMERGENCY_PROFILE',  'Emergency profile',               'Emergency contact and assistance notes visible to responders', 'SUBSCRIBER');
