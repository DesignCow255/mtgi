CREATE TABLE rescue_units (
    id CHAR(36) NOT NULL,
    code VARCHAR(32) NOT NULL,
    name VARCHAR(120) NOT NULL,
    unit_type VARCHAR(32) NOT NULL DEFAULT 'AMBULANCE',
    province VARCHAR(80) NOT NULL,
    base_name VARCHAR(140) NOT NULL,
    status VARCHAR(32) NOT NULL DEFAULT 'AVAILABLE',
    contact_phone VARCHAR(32) NULL,
    latitude DECIMAL(10, 7) NULL,
    longitude DECIMAL(10, 7) NULL,
    created_at TIMESTAMP(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
    updated_at TIMESTAMP(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6) ON UPDATE CURRENT_TIMESTAMP(6),
    PRIMARY KEY (id),
    UNIQUE KEY uq_rescue_units_code (code),
    KEY ix_rescue_units_status_province (status, province),
    CONSTRAINT ck_rescue_units_status CHECK (status IN ('AVAILABLE', 'DISPATCHED', 'OFFLINE', 'MAINTENANCE'))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE rescue_incidents (
    id CHAR(36) NOT NULL,
    incident_code VARCHAR(32) NOT NULL,
    source VARCHAR(32) NOT NULL DEFAULT 'HQ_MANUAL',
    caller_name VARCHAR(140) NULL,
    caller_phone VARCHAR(32) NOT NULL,
    province VARCHAR(80) NOT NULL,
    location_text VARCHAR(255) NOT NULL,
    latitude DECIMAL(10, 7) NULL,
    longitude DECIMAL(10, 7) NULL,
    description TEXT NOT NULL,
    priority VARCHAR(16) NOT NULL,
    status VARCHAR(32) NOT NULL DEFAULT 'REPORTED',
    assigned_unit_id CHAR(36) NULL,
    reported_by_user_id CHAR(36) NOT NULL,
    dispatched_by_user_id CHAR(36) NULL,
    reported_at TIMESTAMP(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
    dispatched_at TIMESTAMP(6) NULL,
    acknowledged_at TIMESTAMP(6) NULL,
    arrived_at TIMESTAMP(6) NULL,
    resolved_at TIMESTAMP(6) NULL,
    updated_at TIMESTAMP(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6) ON UPDATE CURRENT_TIMESTAMP(6),
    PRIMARY KEY (id),
    UNIQUE KEY uq_rescue_incident_code (incident_code),
    KEY ix_rescue_incidents_status_priority (status, priority, reported_at),
    KEY ix_rescue_incidents_province_time (province, reported_at),
    CONSTRAINT fk_rescue_incident_unit FOREIGN KEY (assigned_unit_id) REFERENCES rescue_units (id) ON DELETE SET NULL,
    CONSTRAINT fk_rescue_incident_reporter FOREIGN KEY (reported_by_user_id) REFERENCES users (id) ON DELETE RESTRICT,
    CONSTRAINT fk_rescue_incident_dispatcher FOREIGN KEY (dispatched_by_user_id) REFERENCES users (id) ON DELETE SET NULL,
    CONSTRAINT ck_rescue_incident_priority CHECK (priority IN ('CRITICAL', 'HIGH', 'MEDIUM', 'LOW')),
    CONSTRAINT ck_rescue_incident_status CHECK (status IN ('REPORTED', 'DISPATCHED', 'ACKNOWLEDGED', 'EN_ROUTE', 'ON_SCENE', 'RESOLVED', 'CANCELLED'))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE rescue_incident_events (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    incident_id CHAR(36) NOT NULL,
    actor_user_id CHAR(36) NOT NULL,
    event_type VARCHAR(64) NOT NULL,
    from_status VARCHAR(32) NULL,
    to_status VARCHAR(32) NULL,
    notes VARCHAR(500) NULL,
    occurred_at TIMESTAMP(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
    PRIMARY KEY (id),
    KEY ix_rescue_events_incident_time (incident_id, occurred_at),
    CONSTRAINT fk_rescue_event_incident FOREIGN KEY (incident_id) REFERENCES rescue_incidents (id) ON DELETE CASCADE,
    CONSTRAINT fk_rescue_event_actor FOREIGN KEY (actor_user_id) REFERENCES users (id) ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO rescue_units (id, code, name, province, base_name, status) VALUES
    ('20000000-0000-4000-8000-000000000001', 'MR-B0', 'Kasumbalesa Rescue 01', 'HAUT_KATANGA', 'Base 0 Kasumbalesa', 'AVAILABLE'),
    ('20000000-0000-4000-8000-000000000002', 'MR-S1', 'Munama Response 01', 'HAUT_KATANGA', 'Station 1 Munama–Lumata', 'AVAILABLE'),
    ('20000000-0000-4000-8000-000000000003', 'MR-S2', 'Kiswishi Response 01', 'HAUT_KATANGA', 'Station 2 Kiswishi–Tumbwe', 'AVAILABLE'),
    ('20000000-0000-4000-8000-000000000004', 'MR-S4', 'Kisenda Response 01', 'LUALABA', 'Station 4 Kisenda–Gombela', 'AVAILABLE'),
    ('20000000-0000-4000-8000-000000000005', 'MR-R5', 'Kolwezi Rescue 01', 'LUALABA', 'Base 5 Kolwezi', 'AVAILABLE');
