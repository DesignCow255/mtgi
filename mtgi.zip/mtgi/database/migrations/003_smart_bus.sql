CREATE TABLE smartbus_operators (
    id CHAR(36) NOT NULL, code VARCHAR(32) NOT NULL, name VARCHAR(120) NOT NULL,
    status VARCHAR(24) NOT NULL DEFAULT 'ACTIVE', created_at TIMESTAMP(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
    PRIMARY KEY (id), UNIQUE KEY uq_smartbus_operator_code (code), UNIQUE KEY uq_smartbus_operator_name (name),
    CONSTRAINT ck_smartbus_operator_status CHECK (status IN ('ACTIVE', 'SUSPENDED'))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE smartbus_routes (
    id CHAR(36) NOT NULL, code VARCHAR(32) NOT NULL, origin VARCHAR(120) NOT NULL, destination VARCHAR(120) NOT NULL,
    distance_km DECIMAL(8,2) NULL, base_fare_cdf DECIMAL(14,2) NOT NULL, rescue_fee_usd DECIMAL(8,2) NOT NULL DEFAULT 1.50,
    status VARCHAR(24) NOT NULL DEFAULT 'ACTIVE', created_at TIMESTAMP(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
    PRIMARY KEY (id), UNIQUE KEY uq_smartbus_route_code (code),
    CONSTRAINT ck_smartbus_route_status CHECK (status IN ('ACTIVE', 'SUSPENDED'))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE smartbus_vehicles (
    id CHAR(36) NOT NULL, operator_id CHAR(36) NOT NULL, code VARCHAR(32) NOT NULL, registration_number VARCHAR(40) NOT NULL,
    capacity SMALLINT UNSIGNED NOT NULL, status VARCHAR(24) NOT NULL DEFAULT 'ACTIVE', created_at TIMESTAMP(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
    PRIMARY KEY (id), UNIQUE KEY uq_smartbus_vehicle_code (code), UNIQUE KEY uq_smartbus_vehicle_registration (registration_number),
    KEY ix_smartbus_vehicle_operator (operator_id, status),
    CONSTRAINT fk_smartbus_vehicle_operator FOREIGN KEY (operator_id) REFERENCES smartbus_operators (id) ON DELETE RESTRICT,
    CONSTRAINT ck_smartbus_vehicle_status CHECK (status IN ('ACTIVE', 'MAINTENANCE', 'SUSPENDED'))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE smartbus_trips (
    id CHAR(36) NOT NULL, trip_code VARCHAR(32) NOT NULL, route_id CHAR(36) NOT NULL, vehicle_id CHAR(36) NOT NULL,
    departure_at TIMESTAMP(6) NOT NULL, fare_cdf DECIMAL(14,2) NOT NULL, rescue_fee_usd DECIMAL(8,2) NOT NULL,
    usd_cdf_rate DECIMAL(14,4) NOT NULL, status VARCHAR(24) NOT NULL DEFAULT 'SCHEDULED', created_by_user_id CHAR(36) NOT NULL,
    created_at TIMESTAMP(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6), updated_at TIMESTAMP(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6) ON UPDATE CURRENT_TIMESTAMP(6),
    PRIMARY KEY (id), UNIQUE KEY uq_smartbus_trip_code (trip_code), KEY ix_smartbus_trip_departure (status, departure_at),
    CONSTRAINT fk_smartbus_trip_route FOREIGN KEY (route_id) REFERENCES smartbus_routes (id) ON DELETE RESTRICT,
    CONSTRAINT fk_smartbus_trip_vehicle FOREIGN KEY (vehicle_id) REFERENCES smartbus_vehicles (id) ON DELETE RESTRICT,
    CONSTRAINT fk_smartbus_trip_creator FOREIGN KEY (created_by_user_id) REFERENCES users (id) ON DELETE RESTRICT,
    CONSTRAINT ck_smartbus_trip_status CHECK (status IN ('SCHEDULED', 'BOARDING', 'DEPARTED', 'COMPLETED', 'CANCELLED'))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE smartbus_bookings (
    id CHAR(36) NOT NULL, booking_reference VARCHAR(32) NOT NULL, trip_id CHAR(36) NOT NULL, seat_number SMALLINT UNSIGNED NOT NULL,
    passenger_name VARCHAR(160) NOT NULL, passenger_phone VARCHAR(32) NOT NULL, fare_cdf DECIMAL(14,2) NOT NULL,
    rescue_fee_usd DECIMAL(8,2) NOT NULL, rescue_fee_cdf DECIMAL(14,2) NOT NULL, total_cdf DECIMAL(14,2) NOT NULL,
    status VARCHAR(24) NOT NULL DEFAULT 'CONFIRMED', qr_payload VARCHAR(500) NOT NULL, created_by_user_id CHAR(36) NOT NULL,
    created_at TIMESTAMP(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
    PRIMARY KEY (id), UNIQUE KEY uq_smartbus_booking_reference (booking_reference), UNIQUE KEY uq_smartbus_trip_seat (trip_id, seat_number),
    KEY ix_smartbus_booking_phone (passenger_phone, created_at),
    CONSTRAINT fk_smartbus_booking_trip FOREIGN KEY (trip_id) REFERENCES smartbus_trips (id) ON DELETE RESTRICT,
    CONSTRAINT fk_smartbus_booking_creator FOREIGN KEY (created_by_user_id) REFERENCES users (id) ON DELETE RESTRICT,
    CONSTRAINT ck_smartbus_booking_status CHECK (status IN ('CONFIRMED', 'BOARDED', 'CANCELLED', 'REFUNDED'))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO smartbus_operators (id, code, name) VALUES
('30000000-0000-4000-8000-000000000001','MULYKAP','Mulykap'),('30000000-0000-4000-8000-000000000002','RATCO','Ratco'),
('30000000-0000-4000-8000-000000000003','NGOKAF','Ngokaf'),('30000000-0000-4000-8000-000000000004','EMMILIE','Emmilie'),
('30000000-0000-4000-8000-000000000005','CLASSIC','Classic'),('30000000-0000-4000-8000-000000000006','NADIA','Nadia'),
('30000000-0000-4000-8000-000000000007','JOHN_KENNEDY','John Kennedy'),('30000000-0000-4000-8000-000000000008','KKS','K.K.S'),
('30000000-0000-4000-8000-000000000009','KETNEY','Ketney');

INSERT INTO smartbus_routes (id, code, origin, destination, distance_km, base_fare_cdf) VALUES
('31000000-0000-4000-8000-000000000001','FBM-KZI','Lubumbashi','Kolwezi',390,50000),
('31000000-0000-4000-8000-000000000002','FBM-LIK','Lubumbashi','Likasi',120,20000),
('31000000-0000-4000-8000-000000000003','FBM-KAS','Lubumbashi','Kasumbalesa',95,20000),
('31000000-0000-4000-8000-000000000004','FBM-FUN','Lubumbashi','Fungurume',290,30000);

INSERT INTO smartbus_vehicles (id, operator_id, code, registration_number, capacity) VALUES
('32000000-0000-4000-8000-000000000001','30000000-0000-4000-8000-000000000001','MUL-01','MUL-001-CD',40),
('32000000-0000-4000-8000-000000000002','30000000-0000-4000-8000-000000000002','RAT-01','RAT-001-CD',40),
('32000000-0000-4000-8000-000000000003','30000000-0000-4000-8000-000000000005','CLA-01','CLA-001-CD',36);
