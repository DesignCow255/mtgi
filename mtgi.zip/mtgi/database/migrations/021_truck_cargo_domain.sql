-- 021_truck_cargo_domain.sql
-- The Truck & Cargo domain: operators, trucks, trailers, drivers, cargo,
-- consignments, containers and journeys.
--
-- Every vehicle is a canonical vehicles row. Cargo is modelled properly - a
-- consignment with items and containers - not a free-text description. Nothing
-- here duplicates identity, vehicle identity, money or incidents.

CREATE TABLE truck_types (
    code VARCHAR(24) NOT NULL,
    label VARCHAR(80) NOT NULL,
    requires_trailer BOOLEAN NOT NULL DEFAULT FALSE,
    PRIMARY KEY (code)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO truck_types (code, label, requires_trailer) VALUES
    ('TRACTOR_HEAD', 'Tractor head', TRUE), ('RIGID_TRUCK', 'Rigid truck', FALSE),
    ('FLATBED', 'Flatbed', FALSE), ('BOX_TRUCK', 'Box truck', FALSE),
    ('TANKER', 'Tanker', FALSE), ('TIPPER', 'Tipper', FALSE),
    ('REFRIGERATED', 'Refrigerated', FALSE), ('CAR_CARRIER', 'Car carrier', FALSE),
    ('LOWBED', 'Lowbed', FALSE), ('OTHER', 'Other', FALSE);

CREATE TABLE trailer_types (
    code VARCHAR(24) NOT NULL,
    label VARCHAR(80) NOT NULL,
    PRIMARY KEY (code)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO trailer_types (code, label) VALUES
    ('BOX', 'Box trailer'), ('FLATBED', 'Flatbed trailer'), ('TANKER', 'Tanker trailer'),
    ('TIPPER', 'Tipper trailer'), ('REFRIGERATED', 'Refrigerated trailer'),
    ('LOWBED', 'Lowbed trailer'), ('CAR_CARRIER', 'Car carrier trailer'), ('OTHER', 'Other');

CREATE TABLE cargo_categories (
    code VARCHAR(32) NOT NULL,
    label VARCHAR(80) NOT NULL,
    requires_hazard_class BOOLEAN NOT NULL DEFAULT FALSE,
    requires_temperature_control BOOLEAN NOT NULL DEFAULT FALSE,
    PRIMARY KEY (code)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO cargo_categories (code, label, requires_hazard_class, requires_temperature_control) VALUES
    ('GENERAL', 'General goods', FALSE, FALSE),
    ('AGRICULTURAL', 'Agricultural', FALSE, FALSE),
    ('FOOD', 'Food', FALSE, TRUE),
    ('BEVERAGE', 'Beverage', FALSE, FALSE),
    ('CONSTRUCTION', 'Construction materials', FALSE, FALSE),
    ('MINING', 'Mining output', FALSE, FALSE),
    ('INDUSTRIAL', 'Industrial goods', FALSE, FALSE),
    ('AUTOMOTIVE', 'Automotive parts', FALSE, FALSE),
    ('FUEL', 'Fuel', TRUE, FALSE),
    ('CHEMICAL', 'Chemicals', TRUE, FALSE),
    ('REFRIGERATED', 'Refrigerated goods', FALSE, TRUE),
    ('HIGH_VALUE', 'High value goods', FALSE, FALSE),
    ('OVERSIZED', 'Oversized load', FALSE, FALSE),
    ('HAZARDOUS', 'Hazardous goods', TRUE, FALSE),
    ('OTHER', 'Other', FALSE, FALSE);

CREATE TABLE truck_operators (
    id CHAR(36) NOT NULL,
    organization_id CHAR(36) NULL,
    operator_number VARCHAR(48) NOT NULL,
    verification_status VARCHAR(16) NOT NULL DEFAULT 'PENDING',
    license_number VARCHAR(80) NULL,
    license_expires_at DATE NULL,
    service_plan_id CHAR(36) NULL,
    rescue_subscription_id CHAR(36) NULL,
    fleet_size INT UNSIGNED NULL,
    operating_country CHAR(2) NOT NULL DEFAULT 'CD',
    support_phone VARCHAR(32) NULL,
    status VARCHAR(16) NOT NULL DEFAULT 'ACTIVE',
    created_by_user_id CHAR(36) NULL,
    created_at TIMESTAMP(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
    updated_at TIMESTAMP(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6) ON UPDATE CURRENT_TIMESTAMP(6),
    PRIMARY KEY (id),
    UNIQUE KEY uq_truck_operators_number (operator_number),
    KEY ix_truck_operators_verification (verification_status, status),
    KEY ix_truck_operators_country (operating_country),
    CONSTRAINT fk_truck_operators_organization FOREIGN KEY (organization_id) REFERENCES organizations (id) ON DELETE SET NULL,
    CONSTRAINT fk_truck_operators_plan FOREIGN KEY (service_plan_id) REFERENCES service_plans (id) ON DELETE SET NULL,
    CONSTRAINT fk_truck_operators_subscription FOREIGN KEY (rescue_subscription_id) REFERENCES subscriptions (id) ON DELETE SET NULL,
    CONSTRAINT fk_truck_operators_creator FOREIGN KEY (created_by_user_id) REFERENCES users (id) ON DELETE SET NULL,
    CONSTRAINT ck_truck_operators_verification CHECK (verification_status IN
        ('UNVERIFIED', 'PENDING', 'VERIFIED', 'EXPIRED', 'SUSPENDED', 'REJECTED')),
    CONSTRAINT ck_truck_operators_status CHECK (status IN ('ACTIVE', 'INACTIVE', 'SUSPENDED'))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE trucks (
    id CHAR(36) NOT NULL,
    vehicle_id CHAR(36) NOT NULL,
    truck_operator_id CHAR(36) NOT NULL,
    truck_number VARCHAR(40) NOT NULL,
    truck_type VARCHAR(24) NOT NULL,
    axle_configuration VARCHAR(24) NULL,
    gross_vehicle_weight_kg DECIMAL(12,2) NULL,
    tare_weight_kg DECIMAL(12,2) NULL,
    maximum_payload_kg DECIMAL(12,2) NULL,
    body_type VARCHAR(60) NULL,
    trailer_required BOOLEAN NOT NULL DEFAULT FALSE,
    hazardous_goods_approved BOOLEAN NOT NULL DEFAULT FALSE,
    cross_border_enabled BOOLEAN NOT NULL DEFAULT FALSE,
    rescue_coverage_status VARCHAR(16) NOT NULL DEFAULT 'UNCOVERED',
    tracking_status VARCHAR(16) NOT NULL DEFAULT 'NO_DEVICE',
    status VARCHAR(16) NOT NULL DEFAULT 'ACTIVE',
    created_at TIMESTAMP(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
    updated_at TIMESTAMP(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6) ON UPDATE CURRENT_TIMESTAMP(6),
    PRIMARY KEY (id),
    UNIQUE KEY uq_trucks_vehicle (vehicle_id),
    UNIQUE KEY uq_trucks_number (truck_operator_id, truck_number),
    KEY ix_trucks_operator (truck_operator_id, status),
    KEY ix_trucks_coverage (rescue_coverage_status),
    KEY ix_trucks_type (truck_type),
    CONSTRAINT fk_trucks_vehicle FOREIGN KEY (vehicle_id) REFERENCES vehicles (id) ON DELETE CASCADE,
    CONSTRAINT fk_trucks_operator FOREIGN KEY (truck_operator_id) REFERENCES truck_operators (id) ON DELETE CASCADE,
    CONSTRAINT fk_trucks_type FOREIGN KEY (truck_type) REFERENCES truck_types (code),
    CONSTRAINT ck_trucks_coverage CHECK (rescue_coverage_status IN ('ACTIVE', 'UNCOVERED', 'EXPIRED', 'SUSPENDED')),
    CONSTRAINT ck_trucks_tracking CHECK (tracking_status IN ('ONLINE', 'OFFLINE', 'NO_DEVICE', 'UNKNOWN')),
    CONSTRAINT ck_trucks_status CHECK (status IN ('ACTIVE', 'INACTIVE', 'MAINTENANCE')),
    -- A truck cannot carry more than it is rated for.
    CONSTRAINT ck_trucks_payload CHECK (
        maximum_payload_kg IS NULL OR gross_vehicle_weight_kg IS NULL
        OR maximum_payload_kg <= gross_vehicle_weight_kg
    )
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE trailers (
    id CHAR(36) NOT NULL,
    vehicle_id CHAR(36) NULL,
    truck_operator_id CHAR(36) NOT NULL,
    trailer_number VARCHAR(40) NOT NULL,
    trailer_type VARCHAR(24) NOT NULL,
    max_load_kg DECIMAL(12,2) NULL,
    status VARCHAR(16) NOT NULL DEFAULT 'ACTIVE',
    created_at TIMESTAMP(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
    updated_at TIMESTAMP(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6) ON UPDATE CURRENT_TIMESTAMP(6),
    PRIMARY KEY (id),
    UNIQUE KEY uq_trailers_number (truck_operator_id, trailer_number),
    KEY ix_trailers_operator (truck_operator_id, status),
    KEY ix_trailers_vehicle (vehicle_id),
    CONSTRAINT fk_trailers_vehicle FOREIGN KEY (vehicle_id) REFERENCES vehicles (id) ON DELETE SET NULL,
    CONSTRAINT fk_trailers_operator FOREIGN KEY (truck_operator_id) REFERENCES truck_operators (id) ON DELETE CASCADE,
    CONSTRAINT fk_trailers_type FOREIGN KEY (trailer_type) REFERENCES trailer_types (code),
    CONSTRAINT ck_trailers_status CHECK (status IN ('ACTIVE', 'INACTIVE', 'MAINTENANCE'))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE truck_drivers (
    id CHAR(36) NOT NULL,
    person_id CHAR(36) NOT NULL,
    truck_operator_id CHAR(36) NOT NULL,
    driver_number VARCHAR(40) NOT NULL,
    license_number VARCHAR(64) NULL,
    license_class VARCHAR(24) NULL,
    license_expiry DATE NULL,
    cross_border_authorized BOOLEAN NOT NULL DEFAULT FALSE,
    status VARCHAR(16) NOT NULL DEFAULT 'ACTIVE',
    created_at TIMESTAMP(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
    updated_at TIMESTAMP(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6) ON UPDATE CURRENT_TIMESTAMP(6),
    PRIMARY KEY (id),
    UNIQUE KEY uq_truck_drivers_person_operator (person_id, truck_operator_id),
    UNIQUE KEY uq_truck_drivers_number (truck_operator_id, driver_number),
    KEY ix_truck_drivers_license_expiry (license_expiry),
    CONSTRAINT fk_truck_drivers_person FOREIGN KEY (person_id) REFERENCES persons (id) ON DELETE CASCADE,
    CONSTRAINT fk_truck_drivers_operator FOREIGN KEY (truck_operator_id) REFERENCES truck_operators (id) ON DELETE CASCADE,
    CONSTRAINT ck_truck_drivers_status CHECK (status IN ('ACTIVE', 'SUSPENDED', 'INACTIVE'))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE consignments (
    id CHAR(36) NOT NULL,
    consignment_number VARCHAR(48) NOT NULL,
    cargo_owner_person_id CHAR(36) NULL,
    cargo_owner_organization_id CHAR(36) NULL,
    shipper_organization_id CHAR(36) NULL,
    consignee_person_id CHAR(36) NULL,
    consignee_organization_id CHAR(36) NULL,
    origin_location_id CHAR(36) NULL,
    destination_location_id CHAR(36) NULL,
    origin_text VARCHAR(160) NULL,
    destination_text VARCHAR(160) NULL,
    declared_value DECIMAL(14,2) NULL,
    declared_currency CHAR(3) NOT NULL DEFAULT 'USD',
    cargo_category VARCHAR(32) NOT NULL DEFAULT 'GENERAL',
    total_weight_kg DECIMAL(12,2) NOT NULL DEFAULT 0,
    total_volume_m3 DECIMAL(12,3) NULL,
    package_count INT UNSIGNED NULL,
    hazardous BOOLEAN NOT NULL DEFAULT FALSE,
    hazard_class VARCHAR(24) NULL,
    un_number VARCHAR(16) NULL,
    temperature_controlled BOOLEAN NOT NULL DEFAULT FALSE,
    special_handling VARCHAR(255) NULL,
    status VARCHAR(16) NOT NULL DEFAULT 'PLANNED',
    created_by_user_id CHAR(36) NULL,
    created_at TIMESTAMP(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
    updated_at TIMESTAMP(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6) ON UPDATE CURRENT_TIMESTAMP(6),
    PRIMARY KEY (id),
    UNIQUE KEY uq_consignments_number (consignment_number),
    KEY ix_consignments_status (status, created_at DESC),
    KEY ix_consignments_category (cargo_category, status),
    KEY ix_consignments_route (origin_location_id, destination_location_id),
    CONSTRAINT fk_consignments_owner_person FOREIGN KEY (cargo_owner_person_id) REFERENCES persons (id) ON DELETE SET NULL,
    CONSTRAINT fk_consignments_owner_organization FOREIGN KEY (cargo_owner_organization_id) REFERENCES organizations (id) ON DELETE SET NULL,
    CONSTRAINT fk_consignments_shipper FOREIGN KEY (shipper_organization_id) REFERENCES organizations (id) ON DELETE SET NULL,
    CONSTRAINT fk_consignments_consignee_person FOREIGN KEY (consignee_person_id) REFERENCES persons (id) ON DELETE SET NULL,
    CONSTRAINT fk_consignments_consignee_organization FOREIGN KEY (consignee_organization_id) REFERENCES organizations (id) ON DELETE SET NULL,
    CONSTRAINT fk_consignments_origin FOREIGN KEY (origin_location_id) REFERENCES locations (id) ON DELETE SET NULL,
    CONSTRAINT fk_consignments_destination FOREIGN KEY (destination_location_id) REFERENCES locations (id) ON DELETE SET NULL,
    CONSTRAINT fk_consignments_category FOREIGN KEY (cargo_category) REFERENCES cargo_categories (code),
    CONSTRAINT fk_consignments_creator FOREIGN KEY (created_by_user_id) REFERENCES users (id) ON DELETE SET NULL,
    CONSTRAINT ck_consignments_status CHECK (status IN ('PLANNED', 'BOOKED', 'IN_TRANSIT', 'DELIVERED', 'CANCELLED')),
    -- A hazardous consignment must declare its class; the platform never guesses
    -- handling instructions for dangerous goods.
    CONSTRAINT ck_consignments_hazard CHECK (hazardous = FALSE OR hazard_class IS NOT NULL)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE cargo_items (
    id CHAR(36) NOT NULL,
    consignment_id CHAR(36) NOT NULL,
    description VARCHAR(255) NOT NULL,
    category VARCHAR(32) NULL,
    quantity DECIMAL(14,3) NULL,
    unit VARCHAR(24) NULL,
    weight_kg DECIMAL(12,3) NULL,
    volume_m3 DECIMAL(12,3) NULL,
    declared_value DECIMAL(14,2) NULL,
    currency CHAR(3) NULL,
    hazard_class VARCHAR(24) NULL,
    temperature_min_c DECIMAL(5,2) NULL,
    temperature_max_c DECIMAL(5,2) NULL,
    fragile BOOLEAN NOT NULL DEFAULT FALSE,
    special_instructions VARCHAR(255) NULL,
    created_at TIMESTAMP(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
    PRIMARY KEY (id),
    KEY ix_cargo_items_consignment (consignment_id),
    CONSTRAINT fk_cargo_items_consignment FOREIGN KEY (consignment_id) REFERENCES consignments (id) ON DELETE CASCADE,
    CONSTRAINT fk_cargo_items_category FOREIGN KEY (category) REFERENCES cargo_categories (code)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE containers (
    id CHAR(36) NOT NULL,
    container_number VARCHAR(16) NOT NULL,
    container_type VARCHAR(24) NULL,
    seal_number VARCHAR(48) NULL,
    gross_weight_kg DECIMAL(12,2) NULL,
    status VARCHAR(16) NOT NULL DEFAULT 'EMPTY',
    created_at TIMESTAMP(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
    updated_at TIMESTAMP(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6) ON UPDATE CURRENT_TIMESTAMP(6),
    PRIMARY KEY (id),
    UNIQUE KEY uq_containers_number (container_number),
    KEY ix_containers_status (status),
    CONSTRAINT ck_containers_status CHECK (status IN ('EMPTY', 'LOADED', 'IN_TRANSIT', 'DELIVERED', 'DAMAGED'))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE consignment_containers (
    consignment_id CHAR(36) NOT NULL,
    container_id CHAR(36) NOT NULL,
    assigned_at TIMESTAMP(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
    released_at TIMESTAMP(6) NULL,
    PRIMARY KEY (consignment_id, container_id),
    KEY ix_consignment_containers_container (container_id, released_at),
    CONSTRAINT fk_consignment_containers_consignment FOREIGN KEY (consignment_id) REFERENCES consignments (id) ON DELETE CASCADE,
    CONSTRAINT fk_consignment_containers_container FOREIGN KEY (container_id) REFERENCES containers (id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE truck_journeys (
    id CHAR(36) NOT NULL,
    journey_code VARCHAR(40) NOT NULL,
    truck_id CHAR(36) NOT NULL,
    trailer_id CHAR(36) NULL,
    truck_operator_id CHAR(36) NOT NULL,
    tracked_asset_id CHAR(36) NULL,
    consignment_id CHAR(36) NULL,
    status VARCHAR(16) NOT NULL DEFAULT 'PLANNED',
    origin_location_id CHAR(36) NULL,
    destination_location_id CHAR(36) NULL,
    origin_text VARCHAR(160) NULL,
    destination_text VARCHAR(160) NULL,
    planned_departure_at TIMESTAMP(6) NULL,
    started_at TIMESTAMP(6) NULL,
    arrived_at TIMESTAMP(6) NULL,
    completed_at TIMESTAMP(6) NULL,
    delay_minutes SMALLINT UNSIGNED NOT NULL DEFAULT 0,
    rescue_coverage_status VARCHAR(16) NOT NULL DEFAULT 'UNCOVERED',
    cargo_weight_kg DECIMAL(12,2) NULL,
    cargo_hazardous BOOLEAN NOT NULL DEFAULT FALSE,
    created_by_user_id CHAR(36) NULL,
    created_at TIMESTAMP(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
    updated_at TIMESTAMP(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6) ON UPDATE CURRENT_TIMESTAMP(6),
    PRIMARY KEY (id),
    UNIQUE KEY uq_truck_journeys_code (journey_code),
    KEY ix_truck_journeys_status (status, planned_departure_at),
    KEY ix_truck_journeys_truck (truck_id, status),
    KEY ix_truck_journeys_operator (truck_operator_id, status),
    KEY ix_truck_journeys_open (tracked_asset_id),
    CONSTRAINT fk_truck_journeys_truck FOREIGN KEY (truck_id) REFERENCES trucks (id) ON DELETE CASCADE,
    CONSTRAINT fk_truck_journeys_trailer FOREIGN KEY (trailer_id) REFERENCES trailers (id) ON DELETE SET NULL,
    CONSTRAINT fk_truck_journeys_operator FOREIGN KEY (truck_operator_id) REFERENCES truck_operators (id) ON DELETE CASCADE,
    CONSTRAINT fk_truck_journeys_asset FOREIGN KEY (tracked_asset_id) REFERENCES tracked_assets (id) ON DELETE SET NULL,
    CONSTRAINT fk_truck_journeys_consignment FOREIGN KEY (consignment_id) REFERENCES consignments (id) ON DELETE SET NULL,
    CONSTRAINT fk_truck_journeys_origin FOREIGN KEY (origin_location_id) REFERENCES locations (id) ON DELETE SET NULL,
    CONSTRAINT fk_truck_journeys_destination FOREIGN KEY (destination_location_id) REFERENCES locations (id) ON DELETE SET NULL,
    CONSTRAINT fk_truck_journeys_creator FOREIGN KEY (created_by_user_id) REFERENCES users (id) ON DELETE SET NULL,
    CONSTRAINT ck_truck_journeys_status CHECK (status IN
        ('PLANNED', 'READY', 'IN_TRANSIT', 'PAUSED', 'DELAYED', 'BREAKDOWN', 'INCIDENT', 'ARRIVED', 'COMPLETED', 'CANCELLED'))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- A tractor is not permanently hard-linked to one trailer: the assignment is
-- history, because a trailer is swapped per journey.
CREATE TABLE truck_trailer_assignments (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    truck_id CHAR(36) NOT NULL,
    trailer_id CHAR(36) NOT NULL,
    assigned_at TIMESTAMP(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
    released_at TIMESTAMP(6) NULL,
    journey_id CHAR(36) NULL,
    assigned_by_user_id CHAR(36) NULL,
    reason VARCHAR(255) NULL,
    PRIMARY KEY (id),
    KEY ix_trailer_assignments_current (truck_id, released_at),
    KEY ix_trailer_assignments_trailer (trailer_id, released_at),
    KEY ix_trailer_assignments_journey (journey_id),
    CONSTRAINT fk_trailer_assignments_truck FOREIGN KEY (truck_id) REFERENCES trucks (id) ON DELETE CASCADE,
    CONSTRAINT fk_trailer_assignments_trailer FOREIGN KEY (trailer_id) REFERENCES trailers (id) ON DELETE CASCADE,
    CONSTRAINT fk_trailer_assignments_journey FOREIGN KEY (journey_id) REFERENCES truck_journeys (id) ON DELETE SET NULL,
    CONSTRAINT fk_trailer_assignments_actor FOREIGN KEY (assigned_by_user_id) REFERENCES users (id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE truck_driver_assignments (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    truck_id CHAR(36) NOT NULL,
    driver_id CHAR(36) NOT NULL,
    role VARCHAR(16) NOT NULL DEFAULT 'DRIVER',
    assigned_at TIMESTAMP(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
    released_at TIMESTAMP(6) NULL,
    journey_id CHAR(36) NULL,
    PRIMARY KEY (id),
    UNIQUE KEY uq_truck_driver_current (truck_id, role, assigned_at),
    KEY ix_truck_driver_assignments_driver (driver_id, released_at),
    KEY ix_truck_driver_assignments_journey (journey_id),
    CONSTRAINT fk_truck_driver_assignments_truck FOREIGN KEY (truck_id) REFERENCES trucks (id) ON DELETE CASCADE,
    CONSTRAINT fk_truck_driver_assignments_driver FOREIGN KEY (driver_id) REFERENCES truck_drivers (id) ON DELETE CASCADE,
    CONSTRAINT fk_truck_driver_assignments_journey FOREIGN KEY (journey_id) REFERENCES truck_journeys (id) ON DELETE SET NULL,
    CONSTRAINT ck_truck_driver_assignments_role CHECK (role IN ('DRIVER', 'CO_DRIVER'))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- A journey may carry several consignments; the single consignment_id above is
-- the primary one.
CREATE TABLE truck_journey_consignments (
    truck_journey_id CHAR(36) NOT NULL,
    consignment_id CHAR(36) NOT NULL,
    is_primary BOOLEAN NOT NULL DEFAULT FALSE,
    added_at TIMESTAMP(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
    PRIMARY KEY (truck_journey_id, consignment_id),
    KEY ix_truck_journey_consignments_consignment (consignment_id),
    CONSTRAINT fk_truck_journey_consignments_journey FOREIGN KEY (truck_journey_id) REFERENCES truck_journeys (id) ON DELETE CASCADE,
    CONSTRAINT fk_truck_journey_consignments_consignment FOREIGN KEY (consignment_id) REFERENCES consignments (id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- The consignment foreign key on rescue_incidents, added now that the table exists.
ALTER TABLE rescue_incidents
    ADD CONSTRAINT fk_rescue_incidents_consignment FOREIGN KEY (consignment_id) REFERENCES consignments (id) ON DELETE SET NULL;

CREATE TABLE truck_journey_occupants (
    id CHAR(36) NOT NULL,
    truck_journey_id CHAR(36) NOT NULL,
    person_id CHAR(36) NOT NULL,
    role VARCHAR(16) NOT NULL DEFAULT 'DRIVER',
    created_at TIMESTAMP(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
    PRIMARY KEY (id),
    UNIQUE KEY uq_truck_journey_occupants (truck_journey_id, person_id, role),
    KEY ix_truck_journey_occupants_person (person_id),
    CONSTRAINT fk_truck_journey_occupants_journey FOREIGN KEY (truck_journey_id) REFERENCES truck_journeys (id) ON DELETE CASCADE,
    CONSTRAINT fk_truck_journey_occupants_person FOREIGN KEY (person_id) REFERENCES persons (id) ON DELETE CASCADE,
    CONSTRAINT ck_truck_journey_occupants_role CHECK (role IN ('DRIVER', 'CO_DRIVER'))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
