-- 019_private_vehicle_domain.sql
-- The private vehicle domain: owners, authorized drivers, protected journeys and
-- the emergency request path.
--
-- Vehicle identity lives in vehicles; this table is the subscriber's enrolment of
-- that vehicle into Mamore Rescue.

CREATE TABLE private_vehicle_relationships (
    code VARCHAR(24) NOT NULL,
    label VARCHAR(80) NOT NULL,
    PRIMARY KEY (code)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO private_vehicle_relationships (code, label) VALUES
    ('OWNER', 'Owner'), ('SPOUSE', 'Spouse'), ('FAMILY', 'Family member'),
    ('EMPLOYEE', 'Employee'), ('AUTHORIZED_DRIVER', 'Authorized driver');

CREATE TABLE private_vehicles (
    id CHAR(36) NOT NULL,
    vehicle_id CHAR(36) NOT NULL,
    subscriber_id CHAR(36) NOT NULL,
    service_plan_id CHAR(36) NULL,
    rescue_code_id CHAR(36) NULL,
    primary_driver_person_id CHAR(36) NULL,
    rescue_coverage_status VARCHAR(16) NOT NULL DEFAULT 'UNCOVERED',
    tracking_status VARCHAR(16) NOT NULL DEFAULT 'NO_DEVICE',
    subscription_status VARCHAR(16) NOT NULL DEFAULT 'PENDING',
    activated_at TIMESTAMP(6) NULL,
    expires_at TIMESTAMP(6) NULL,
    created_by_user_id CHAR(36) NULL,
    created_at TIMESTAMP(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
    updated_at TIMESTAMP(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6) ON UPDATE CURRENT_TIMESTAMP(6),
    PRIMARY KEY (id),
    UNIQUE KEY uq_private_vehicles_vehicle (vehicle_id),
    KEY ix_private_vehicles_subscriber (subscriber_id, subscription_status),
    KEY ix_private_vehicles_coverage (rescue_coverage_status),
    KEY ix_private_vehicles_expiry (expires_at),
    CONSTRAINT fk_private_vehicles_vehicle FOREIGN KEY (vehicle_id) REFERENCES vehicles (id) ON DELETE CASCADE,
    CONSTRAINT fk_private_vehicles_subscriber FOREIGN KEY (subscriber_id) REFERENCES subscribers (id) ON DELETE CASCADE,
    CONSTRAINT fk_private_vehicles_plan FOREIGN KEY (service_plan_id) REFERENCES service_plans (id) ON DELETE SET NULL,
    CONSTRAINT fk_private_vehicles_code FOREIGN KEY (rescue_code_id) REFERENCES rescue_codes (id) ON DELETE SET NULL,
    CONSTRAINT fk_private_vehicles_driver FOREIGN KEY (primary_driver_person_id) REFERENCES persons (id) ON DELETE SET NULL,
    CONSTRAINT fk_private_vehicles_creator FOREIGN KEY (created_by_user_id) REFERENCES users (id) ON DELETE SET NULL,
    CONSTRAINT ck_private_vehicles_coverage CHECK (rescue_coverage_status IN ('ACTIVE', 'UNCOVERED', 'EXPIRED', 'SUSPENDED')),
    CONSTRAINT ck_private_vehicles_tracking CHECK (tracking_status IN ('ONLINE', 'OFFLINE', 'NO_DEVICE', 'UNKNOWN')),
    CONSTRAINT ck_private_vehicles_subscription CHECK (subscription_status IN ('PENDING', 'ACTIVE', 'SUSPENDED', 'EXPIRED', 'CANCELLED'))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE private_vehicle_drivers (
    id CHAR(36) NOT NULL,
    private_vehicle_id CHAR(36) NOT NULL,
    person_id CHAR(36) NOT NULL,
    relationship VARCHAR(24) NOT NULL DEFAULT 'AUTHORIZED_DRIVER',
    is_primary BOOLEAN NOT NULL DEFAULT FALSE,
    authorized_from TIMESTAMP(6) NULL,
    authorized_until TIMESTAMP(6) NULL,
    status VARCHAR(16) NOT NULL DEFAULT 'ACTIVE',
    created_at TIMESTAMP(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
    PRIMARY KEY (id),
    UNIQUE KEY uq_private_vehicle_drivers (private_vehicle_id, person_id),
    KEY ix_private_vehicle_drivers_person (person_id, status),
    CONSTRAINT fk_private_vehicle_drivers_vehicle FOREIGN KEY (private_vehicle_id) REFERENCES private_vehicles (id) ON DELETE CASCADE,
    CONSTRAINT fk_private_vehicle_drivers_person FOREIGN KEY (person_id) REFERENCES persons (id) ON DELETE CASCADE,
    CONSTRAINT ck_private_vehicle_drivers_relationship FOREIGN KEY (relationship) REFERENCES private_vehicle_relationships (code),
    CONSTRAINT ck_private_vehicle_drivers_status CHECK (status IN ('ACTIVE', 'SUSPENDED', 'REVOKED'))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Only one primary driver per vehicle, enforced with the same virtual-column
-- pattern used for VIP primary vehicles.
CREATE TABLE private_vehicle_journeys (
    id CHAR(36) NOT NULL,
    private_vehicle_id CHAR(36) NOT NULL,
    tracked_asset_id CHAR(36) NULL,
    status VARCHAR(16) NOT NULL DEFAULT 'PLANNED',
    origin_location_id CHAR(36) NULL,
    origin_text VARCHAR(160) NULL,
    destination_location_id CHAR(36) NULL,
    destination_text VARCHAR(160) NULL,
    started_at TIMESTAMP(6) NULL,
    arrived_at TIMESTAMP(6) NULL,
    completed_at TIMESTAMP(6) NULL,
    planned_at TIMESTAMP(6) NULL,
    passenger_count SMALLINT UNSIGNED NOT NULL DEFAULT 1,
    started_by_user_id CHAR(36) NULL,
    created_at TIMESTAMP(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
    updated_at TIMESTAMP(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6) ON UPDATE CURRENT_TIMESTAMP(6),
    -- Only one OPEN journey per vehicle, while finished journeys accumulate as
    -- history. A plain UNIQUE(vehicle_id, status) would allow only one COMPLETED
    -- journey ever, which would destroy the trip history.
    open_vehicle_id CHAR(36) GENERATED ALWAYS AS (
        CASE WHEN status IN ('PLANNED', 'ACTIVE', 'PAUSED') THEN private_vehicle_id ELSE NULL END
    ) VIRTUAL,
    PRIMARY KEY (id),
    UNIQUE KEY uq_private_vehicle_open_journey (open_vehicle_id),
    KEY ix_private_vehicle_journeys_status (status, started_at DESC),
    KEY ix_private_vehicle_journeys_started_by (started_by_user_id),
    CONSTRAINT fk_private_vehicle_journeys_vehicle FOREIGN KEY (private_vehicle_id) REFERENCES private_vehicles (id) ON DELETE CASCADE,
    CONSTRAINT fk_private_vehicle_journeys_asset FOREIGN KEY (tracked_asset_id) REFERENCES tracked_assets (id) ON DELETE SET NULL,
    CONSTRAINT fk_private_vehicle_journeys_origin FOREIGN KEY (origin_location_id) REFERENCES locations (id) ON DELETE SET NULL,
    CONSTRAINT fk_private_vehicle_journeys_destination FOREIGN KEY (destination_location_id) REFERENCES locations (id) ON DELETE SET NULL,
    CONSTRAINT fk_private_vehicle_journeys_actor FOREIGN KEY (started_by_user_id) REFERENCES users (id) ON DELETE SET NULL,
    CONSTRAINT ck_private_vehicle_journeys_status CHECK (status IN ('PLANNED', 'ACTIVE', 'PAUSED', 'INCIDENT', 'ARRIVED', 'COMPLETED', 'CANCELLED'))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Occupants are recorded only for an active journey, and only what operations
-- needs: never a permanent passenger list.
CREATE TABLE journey_passengers (
    id CHAR(36) NOT NULL,
    private_vehicle_journey_id CHAR(36) NOT NULL,
    person_id CHAR(36) NULL,
    guest_name VARCHAR(140) NULL,
    guest_phone VARCHAR(32) NULL,
    relationship VARCHAR(32) NULL,
    is_vip BOOLEAN NOT NULL DEFAULT FALSE,
    rescue_covered BOOLEAN NOT NULL DEFAULT FALSE,
    created_at TIMESTAMP(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
    PRIMARY KEY (id),
    UNIQUE KEY uq_journey_passengers (private_vehicle_journey_id, person_id, guest_name),
    KEY ix_journey_passengers_person (person_id),
    CONSTRAINT fk_journey_passengers_journey FOREIGN KEY (private_vehicle_journey_id) REFERENCES private_vehicle_journeys (id) ON DELETE CASCADE,
    CONSTRAINT fk_journey_passengers_person FOREIGN KEY (person_id) REFERENCES persons (id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
