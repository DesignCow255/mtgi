CREATE TABLE roles (
    id CHAR(36) NOT NULL,
    code VARCHAR(64) NOT NULL,
    name VARCHAR(120) NOT NULL,
    description VARCHAR(255) NULL,
    is_system BOOLEAN NOT NULL DEFAULT TRUE,
    created_at TIMESTAMP(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
    updated_at TIMESTAMP(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6) ON UPDATE CURRENT_TIMESTAMP(6),
    PRIMARY KEY (id),
    UNIQUE KEY uq_roles_code (code)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE permissions (
    id CHAR(36) NOT NULL,
    code VARCHAR(100) NOT NULL,
    name VARCHAR(150) NOT NULL,
    description VARCHAR(255) NULL,
    created_at TIMESTAMP(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
    PRIMARY KEY (id),
    UNIQUE KEY uq_permissions_code (code)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE role_permissions (
    role_id CHAR(36) NOT NULL,
    permission_id CHAR(36) NOT NULL,
    created_at TIMESTAMP(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
    PRIMARY KEY (role_id, permission_id),
    CONSTRAINT fk_role_permissions_role FOREIGN KEY (role_id) REFERENCES roles (id) ON DELETE CASCADE,
    CONSTRAINT fk_role_permissions_permission FOREIGN KEY (permission_id) REFERENCES permissions (id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE users (
    id CHAR(36) NOT NULL,
    legacy_postgres_id VARCHAR(64) NULL,
    role_id CHAR(36) NOT NULL,
    first_name VARCHAR(100) NOT NULL,
    last_name VARCHAR(100) NOT NULL,
    email VARCHAR(190) NOT NULL,
    phone VARCHAR(32) NULL,
    password_hash VARCHAR(255) NOT NULL,
    status VARCHAR(32) NOT NULL DEFAULT 'PENDING',
    email_verified_at TIMESTAMP(6) NULL,
    last_login_at TIMESTAMP(6) NULL,
    created_at TIMESTAMP(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
    updated_at TIMESTAMP(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6) ON UPDATE CURRENT_TIMESTAMP(6),
    deleted_at TIMESTAMP(6) NULL,
    PRIMARY KEY (id),
    UNIQUE KEY uq_users_email (email),
    UNIQUE KEY uq_users_phone (phone),
    UNIQUE KEY uq_users_legacy_postgres_id (legacy_postgres_id),
    KEY ix_users_role_status (role_id, status),
    CONSTRAINT fk_users_role FOREIGN KEY (role_id) REFERENCES roles (id) ON DELETE RESTRICT,
    CONSTRAINT ck_users_status CHECK (status IN ('PENDING', 'ACTIVE', 'SUSPENDED', 'LOCKED', 'DISABLED'))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE user_sessions (
    id CHAR(36) NOT NULL,
    user_id CHAR(36) NOT NULL,
    access_token_hash CHAR(64) NOT NULL,
    refresh_token_hash CHAR(64) NOT NULL,
    ip_address VARCHAR(45) NULL,
    user_agent VARCHAR(500) NULL,
    expires_at TIMESTAMP(6) NOT NULL,
    refresh_expires_at TIMESTAMP(6) NOT NULL,
    last_activity_at TIMESTAMP(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
    revoked_at TIMESTAMP(6) NULL,
    revoke_reason VARCHAR(120) NULL,
    created_at TIMESTAMP(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
    PRIMARY KEY (id),
    UNIQUE KEY uq_sessions_access_hash (access_token_hash),
    UNIQUE KEY uq_sessions_refresh_hash (refresh_token_hash),
    KEY ix_sessions_user_active (user_id, revoked_at, refresh_expires_at),
    CONSTRAINT fk_sessions_user FOREIGN KEY (user_id) REFERENCES users (id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE login_history (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    user_id CHAR(36) NULL,
    attempted_email VARCHAR(190) NULL,
    succeeded BOOLEAN NOT NULL,
    failure_reason VARCHAR(120) NULL,
    ip_address VARCHAR(45) NULL,
    user_agent VARCHAR(500) NULL,
    occurred_at TIMESTAMP(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
    PRIMARY KEY (id),
    KEY ix_login_history_user_time (user_id, occurred_at),
    KEY ix_login_history_email_time (attempted_email, occurred_at),
    CONSTRAINT fk_login_history_user FOREIGN KEY (user_id) REFERENCES users (id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE audit_logs (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    actor_user_id CHAR(36) NULL,
    action VARCHAR(100) NOT NULL,
    entity_type VARCHAR(100) NOT NULL,
    entity_id VARCHAR(64) NULL,
    request_id CHAR(36) NOT NULL,
    ip_address VARCHAR(45) NULL,
    user_agent VARCHAR(500) NULL,
    previous_data JSON NULL,
    new_data JSON NULL,
    metadata JSON NULL,
    occurred_at TIMESTAMP(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
    PRIMARY KEY (id),
    KEY ix_audit_entity_time (entity_type, entity_id, occurred_at),
    KEY ix_audit_actor_time (actor_user_id, occurred_at),
    KEY ix_audit_request (request_id),
    CONSTRAINT fk_audit_actor FOREIGN KEY (actor_user_id) REFERENCES users (id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO roles (id, code, name, description) VALUES
    ('00000000-0000-4000-8000-000000000001', 'SYSTEM_ADMIN', 'System Administrator', 'Full platform administration'),
    ('00000000-0000-4000-8000-000000000002', 'HQ_DISPATCHER', 'HQ Dispatcher', 'Rescue incident coordination and dispatch'),
    ('00000000-0000-4000-8000-000000000003', 'RESCUE_OPERATOR', 'Rescue Operator', 'Field rescue operations'),
    ('00000000-0000-4000-8000-000000000004', 'FINANCE_MANAGER', 'Finance Manager', 'Financial control and reconciliation'),
    ('00000000-0000-4000-8000-000000000005', 'BUS_OPERATOR', 'Bus Operator', 'Operator fleet, schedule and booking management'),
    ('00000000-0000-4000-8000-000000000006', 'DRIVER', 'Driver', 'Assigned vehicle operations'),
    ('00000000-0000-4000-8000-000000000007', 'CONDUCTOR', 'Conductor', 'Boarding and ticket verification'),
    ('00000000-0000-4000-8000-000000000008', 'AUDITOR', 'Auditor', 'Read-only financial and operational audit'),
    ('00000000-0000-4000-8000-000000000009', 'CUSTOMER', 'Customer', 'Customer rescue subscriptions and Smart Bus bookings');

INSERT INTO permissions (id, code, name) VALUES
    ('10000000-0000-4000-8000-000000000001', 'users.manage', 'Manage users'),
    ('10000000-0000-4000-8000-000000000002', 'rescue.dispatch', 'Dispatch rescue resources'),
    ('10000000-0000-4000-8000-000000000003', 'rescue.respond', 'Respond to rescue incidents'),
    ('10000000-0000-4000-8000-000000000004', 'tracking.view', 'View live tracking'),
    ('10000000-0000-4000-8000-000000000005', 'finance.manage', 'Manage finance and reconciliation'),
    ('10000000-0000-4000-8000-000000000006', 'smartbus.manage', 'Manage Smart Bus operations'),
    ('10000000-0000-4000-8000-000000000007', 'tickets.validate', 'Validate and board tickets'),
    ('10000000-0000-4000-8000-000000000008', 'audit.view', 'View audit records'),
    ('10000000-0000-4000-8000-000000000009', 'portal.use', 'Use customer portal');

INSERT INTO role_permissions (role_id, permission_id)
SELECT '00000000-0000-4000-8000-000000000001', id FROM permissions;

INSERT INTO role_permissions (role_id, permission_id) VALUES
    ('00000000-0000-4000-8000-000000000002', '10000000-0000-4000-8000-000000000002'),
    ('00000000-0000-4000-8000-000000000002', '10000000-0000-4000-8000-000000000004'),
    ('00000000-0000-4000-8000-000000000003', '10000000-0000-4000-8000-000000000003'),
    ('00000000-0000-4000-8000-000000000003', '10000000-0000-4000-8000-000000000004'),
    ('00000000-0000-4000-8000-000000000004', '10000000-0000-4000-8000-000000000005'),
    ('00000000-0000-4000-8000-000000000004', '10000000-0000-4000-8000-000000000008'),
    ('00000000-0000-4000-8000-000000000005', '10000000-0000-4000-8000-000000000006'),
    ('00000000-0000-4000-8000-000000000006', '10000000-0000-4000-8000-000000000004'),
    ('00000000-0000-4000-8000-000000000007', '10000000-0000-4000-8000-000000000007'),
    ('00000000-0000-4000-8000-000000000008', '10000000-0000-4000-8000-000000000008'),
    ('00000000-0000-4000-8000-000000000009', '10000000-0000-4000-8000-000000000009');
