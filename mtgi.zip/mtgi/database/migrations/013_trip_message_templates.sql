-- 013_trip_message_templates.sql
-- The trip reminder ladder from the brief. Channels: IN_APP is the one channel
-- that genuinely works in this environment, so every event is seeded for all
-- four and the outbox records the provider as NOT_CONFIGURED rather than
-- pretending a message was delivered.

INSERT INTO message_templates (id, event_code, channel, subject, body_template) VALUES
    ('12000000-0000-4000-8000-000000000001', 'BOOKING_CREATED',   'IN_APP', 'Booking confirmed',       'Your seat {{seatNumber}} on {{tripCode}} ({{route}}) is reserved. Report by {{reportingTime}}.'),
    ('12000000-0000-4000-8000-000000000002', 'TICKET_ISSUED',     'IN_APP', 'Your ticket is ready',     'Ticket for {{tripCode}} ({{route}}), seat {{seatNumber}}.'),
    ('12000000-0000-4000-8000-000000000003', 'PAYMENT_CONFIRMED', 'IN_APP', 'Payment received',         'We received your payment for {{tripCode}}.'),
    ('12000000-0000-4000-8000-000000000004', 'TRIP_REMINDER',     'IN_APP', 'Trip tomorrow',            'Tomorrow: {{tripCode}} {{route}}. Report by {{reportingTime}}, boarding opens {{boardingOpen}}.'),
    ('12000000-0000-4000-8000-000000000005', 'DEPARTURE_REMINDER','IN_APP', 'Departure today',          '{{tripCode}} departs at {{departureTime}} from {{route}}.'),
    ('12000000-0000-4000-8000-000000000006', 'REPORTING_REMINDER','IN_APP', 'Prepare to travel',        'Report to the station for {{tripCode}} by {{reportingTime}}.'),
    ('12000000-0000-4000-8000-000000000007', 'REPORT_AT_STATION', 'IN_APP', 'Please report at the station', 'Report now for {{tripCode}} at {{reportingTime}}. Seat {{seatNumber}}.'),
    ('12000000-0000-4000-8000-000000000008', 'BOARDING_OPEN',     'IN_APP', 'Boarding is now open',     'Boarding is open for {{tripCode}}; it closes at {{boardingClose}}.'),
    ('12000000-0000-4000-8000-000000000009', 'BOARDING_CLOSING',  'IN_APP', 'Boarding closes soon',     'Boarding for {{tripCode}} closes at {{boardingClose}}. Report by {{reportingTime}}.'),
    ('12000000-0000-4000-8000-000000000010', 'TRIP_STARTED',      'IN_APP', 'Trip started',             '{{tripCode}} has departed for {{route}}.'),
    ('12000000-0000-4000-8000-000000000011', 'TRIP_DELAYED',      'IN_APP', 'Trip delayed',             '{{tripCode}} is running late. New departure time will follow.'),
    ('12000000-0000-4000-8000-000000000012', 'BUS_CHANGED',       'IN_APP', 'Bus changed',              'The bus for {{tripCode}} has been changed. Check your ticket.'),
    ('12000000-0000-4000-8000-000000000013', 'SEAT_CHANGED',      'IN_APP', 'Seat changed',             'Your seat on {{tripCode}} is now {{seatNumber}}.'),
    ('12000000-0000-4000-8000-000000000014', 'TRIP_CANCELLED',    'IN_APP', 'Trip cancelled',           '{{tripCode}} ({{route}}) has been cancelled. A refund follows.'),
    ('12000000-0000-4000-8000-000000000015', 'ARRIVAL',           'IN_APP', 'You have arrived',         'Welcome to your destination on {{tripCode}}.'),
    ('12000000-0000-4000-8000-000000000016', 'RESCUE_COVERAGE_ACTIVATED', 'IN_APP', 'Mamore Rescue protection active', 'Rescue protection is active for your journey on {{tripCode}}.'),
    ('12000000-0000-4000-8000-000000000017', 'RESCUE_INCIDENT',   'IN_APP', 'Rescue incident',          'A rescue incident was raised on {{tripCode}}. Stay seated; help is on the way.'),
    ('12000000-0000-4000-8000-000000000018', 'RESCUE_RESPONSE_DISPATCHED', 'IN_APP', 'Rescue team dispatched', 'A rescue team has been dispatched for {{tripCode}}.'),
    ('12000000-0000-4000-8000-000000000019', 'TRIP_REMINDER',     'SMS',     'Trip tomorrow',            'Mamore: {{tripCode}} {{route}} departs {{departureTime}}. Report by {{reportingTime}}.'),
    ('12000000-0000-4000-8000-000000000020', 'BOARDING_OPEN',     'SMS',     'Boarding open',            'Mamore: boarding open for {{tripCode}}, closes {{boardingClose}}.'),
    ('12000000-0000-4000-8000-000000000021', 'TRIP_STARTED',      'WHATSAPP','Trip started',             'Mamore: {{tripCode}} has departed for {{route}}.'),
    ('12000000-0000-4000-8000-000000000022', 'TRIP_REMINDER',     'WHATSAPP','Trip tomorrow',            'Mamore: {{tripCode}} departs {{departureTime}} from {{route}}.'),
    ('12000000-0000-4000-8000-000000000023', 'TRIP_REMINDER',     'EMAIL',   'Your trip tomorrow',       'Hello {{passengerName}}, {{tripCode}} ({{route}}) departs {{departureTime}}. Report by {{reportingTime}}, boarding opens {{boardingOpen}}, closes {{boardingClose}}. Seat {{seatNumber}}.'),
    ('12000000-0000-4000-8000-000000000024', 'BOARDING_OPEN',     'EMAIL',   'Boarding is now open',     'Hello {{passengerName}}, boarding for {{tripCode}} is open and closes at {{boardingClose}}.');
