-- 012_rescue_unit_coordinates.sql
-- The five seeded rescue units had no coordinates, so "nearest unit" could only
-- ever answer UNKNOWN. These are the operational bases the platform already
-- names (Kasumbalesa, Munama-Lumata, Kiswishi-Tumbwe, Kisenda-Gombela, Kolwezi),
-- given coordinates so nearest-asset lookups work out of the box. Data only, no
-- schema change, and it never overwrites a coordinate an operator has set.

UPDATE rescue_units SET latitude = -12.3667000, longitude = 28.8333000 WHERE code = 'MR-B0' AND latitude IS NULL;
UPDATE rescue_units SET latitude = -11.5944000, longitude = 27.4894000 WHERE code = 'MR-S1' AND latitude IS NULL;
UPDATE rescue_units SET latitude = -11.5539000, longitude = 27.4006000 WHERE code = 'MR-S2' AND latitude IS NULL;
UPDATE rescue_units SET latitude = -10.7592000, longitude = 25.8794000 WHERE code = 'MR-S4' AND latitude IS NULL;
UPDATE rescue_units SET latitude = -10.7167000, longitude = 25.4667000 WHERE code = 'MR-R5' AND latitude IS NULL;
