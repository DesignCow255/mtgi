-- 009_portal_auth.sql
-- One-time passcodes for portal onboarding (email verification) and password
-- resets, mirroring the canonical Otp model plus the delivery seam.
--
-- The code is stored as a SHA-256 hash, never in clear text: a stolen database
-- dump must not hand an attacker a working one-time code. (The canonical
-- Prisma model keeps the code in clear; the hashing is a deliberate hardening,
-- see docs/migration/MIGRATION_RISK_REGISTER.md item 4.)
--
-- Delivery is pluggable: app/Auth/OtpService.php hands the code to a delivery
-- sink (Logger in this environment), so wiring SMS/email later touches one
-- place. The channel records whether the subscriber asked for EMAIL or SMS.

CREATE TABLE otp_codes (
    id CHAR(36) NOT NULL,
    user_id CHAR(36) NOT NULL,
    purpose VARCHAR(32) NOT NULL DEFAULT 'EMAIL_VERIFICATION',
    code_hash CHAR(64) NOT NULL,
    channel VARCHAR(16) NOT NULL DEFAULT 'EMAIL',
    attempts SMALLINT UNSIGNED NOT NULL DEFAULT 0,
    max_attempts SMALLINT UNSIGNED NOT NULL DEFAULT 5,
    expires_at TIMESTAMP(6) NOT NULL,
    used_at TIMESTAMP(6) NULL,
    delivered_at TIMESTAMP(6) NULL,
    created_at TIMESTAMP(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
    PRIMARY KEY (id),
    KEY ix_otp_codes_user_purpose (user_id, purpose, used_at, expires_at),
    KEY ix_otp_codes_expires (expires_at),
    CONSTRAINT fk_otp_codes_user FOREIGN KEY (user_id) REFERENCES users (id) ON DELETE CASCADE,
    CONSTRAINT ck_otp_codes_purpose CHECK (purpose IN ('EMAIL_VERIFICATION', 'PASSWORD_RESET')),
    CONSTRAINT ck_otp_codes_channel CHECK (channel IN ('EMAIL', 'SMS')),
    CONSTRAINT ck_otp_codes_attempts CHECK (attempts <= max_attempts),
    CONSTRAINT ck_otp_codes_expiry CHECK (expires_at > created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
