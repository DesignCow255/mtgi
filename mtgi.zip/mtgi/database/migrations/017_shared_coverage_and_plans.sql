-- 017_shared_coverage_and_plans.sql
-- Configurable service plans, a vehicle-level coverage link, and the tables that
-- let one Rescue Code serve more than one domain subject.
--
-- The existing subscriber-centric subscriptions keep working. This adds the
-- plan concept and a coverage link so a truck fleet, a bus or a private car can
-- be covered, and so "am I covered?" has exactly one answer.

CREATE TABLE coverage_types (
    code VARCHAR(24) NOT NULL,
    label VARCHAR(80) NOT NULL,
    description VARCHAR(255) NULL,
    PRIMARY KEY (code)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO coverage_types (code, label, description) VALUES
    ('ROAD_ASSISTANCE', 'Road assistance', 'Towing, jump start, fuel and minor mechanical assistance'),
    ('MEDICAL', 'Medical response', 'First response and transport to a medical facility'),
    ('SECURITY', 'Security response', 'Security support for a stopped or threatened vehicle'),
    ('CARGO_CARE', 'Cargo care', 'Cover for a commercial consignment in transit'),
    ('FULL', 'Full protection', 'Road assistance, medical and security response');

CREATE TABLE plan_categories (
    code VARCHAR(24) NOT NULL,
    label VARCHAR(80) NOT NULL,
    billing_subject VARCHAR(24) NOT NULL DEFAULT 'PERSON',
    PRIMARY KEY (code)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO plan_categories (code, label, billing_subject) VALUES
    ('INDIVIDUAL', 'Individual', 'PERSON'),
    ('VEHICLE', 'Vehicle', 'VEHICLE'),
    ('FLEET', 'Fleet', 'VEHICLE'),
    ('CORPORATE', 'Corporate', 'PERSON');

CREATE TABLE service_plans (
    id CHAR(36) NOT NULL,
    plan_code VARCHAR(48) NOT NULL,
    name VARCHAR(120) NOT NULL,
    domain VARCHAR(24) NOT NULL,
    category_code VARCHAR(24) NOT NULL,
    coverage_type VARCHAR(24) NOT NULL,
    billing_period VARCHAR(16) NOT NULL,
    currency CHAR(3) NOT NULL,
    base_fee DECIMAL(14,2) NOT NULL,
    vehicle_limit INT UNSIGNED NULL,
    response_target_minutes SMALLINT UNSIGNED NULL,
    status VARCHAR(16) NOT NULL DEFAULT 'ACTIVE',
    description VARCHAR(255) NULL,
    created_at TIMESTAMP(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
    updated_at TIMESTAMP(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6) ON UPDATE CURRENT_TIMESTAMP(6),
    PRIMARY KEY (id),
    UNIQUE KEY uq_service_plans_code (plan_code),
    KEY ix_service_plans_domain (domain, status),
    CONSTRAINT fk_service_plans_category FOREIGN KEY (category_code) REFERENCES plan_categories (code),
    CONSTRAINT fk_service_plans_coverage FOREIGN KEY (coverage_type) REFERENCES coverage_types (code),
    CONSTRAINT ck_service_plans_period CHECK (billing_period IN ('ONE_TIME', 'MONTHLY', 'QUARTERLY', 'ANNUAL')),
    CONSTRAINT ck_service_plans_domain CHECK (domain IN ('VIP', 'SMART_BUS', 'TRUCK', 'PRIVATE_VEHICLE', 'SHARED'))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE plan_fees (
    id CHAR(36) NOT NULL,
    service_plan_id CHAR(36) NOT NULL,
    fee_code VARCHAR(48) NOT NULL,
    name VARCHAR(120) NOT NULL,
    amount DECIMAL(14,2) NOT NULL,
    currency CHAR(3) NOT NULL,
    taxable BOOLEAN NOT NULL DEFAULT FALSE,
    status VARCHAR(16) NOT NULL DEFAULT 'ACTIVE',
    PRIMARY KEY (id),
    UNIQUE KEY uq_plan_fees (service_plan_id, fee_code),
    CONSTRAINT fk_plan_fees_plan FOREIGN KEY (service_plan_id) REFERENCES service_plans (id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- The coverage link: what is covered, by which subscription, since when and
-- until when. This is the record RescueCoverageService reads.
CREATE TABLE rescue_coverage_links (
    id CHAR(36) NOT NULL,
    subject_type VARCHAR(32) NOT NULL,
    subject_id CHAR(36) NOT NULL,
    vehicle_id CHAR(36) NULL,
    subscriber_id CHAR(36) NULL,
    organization_id CHAR(36) NULL,
    subscription_id CHAR(36) NULL,
    service_plan_id CHAR(36) NULL,
    coverage_type VARCHAR(24) NOT NULL,
    status VARCHAR(16) NOT NULL DEFAULT 'ACTIVE',
    starts_at TIMESTAMP(6) NOT NULL,
    ends_at TIMESTAMP(6) NULL,
    rescue_code_id CHAR(36) NULL,
    restrictions JSON NULL,
    created_at TIMESTAMP(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
    updated_at TIMESTAMP(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6) ON UPDATE CURRENT_TIMESTAMP(6),
    PRIMARY KEY (id),
    KEY ix_coverage_subject (subject_type, subject_id, status),
    KEY ix_coverage_vehicle (vehicle_id, status),
    KEY ix_coverage_subscriber (subscriber_id, status),
    KEY ix_coverage_window (status, starts_at, ends_at),
    CONSTRAINT fk_coverage_vehicle FOREIGN KEY (vehicle_id) REFERENCES vehicles (id) ON DELETE CASCADE,
    CONSTRAINT fk_coverage_subscriber FOREIGN KEY (subscriber_id) REFERENCES subscribers (id) ON DELETE CASCADE,
    CONSTRAINT fk_coverage_organization FOREIGN KEY (organization_id) REFERENCES organizations (id) ON DELETE CASCADE,
    CONSTRAINT fk_coverage_subscription FOREIGN KEY (subscription_id) REFERENCES subscriptions (id) ON DELETE CASCADE,
    CONSTRAINT fk_coverage_plan FOREIGN KEY (service_plan_id) REFERENCES service_plans (id) ON DELETE SET NULL,
    CONSTRAINT fk_coverage_code FOREIGN KEY (rescue_code_id) REFERENCES rescue_codes (id) ON DELETE SET NULL,
    CONSTRAINT ck_coverage_subject CHECK (subject_type IN ('PERSON', 'VEHICLE', 'TRIP', 'JOURNEY', 'CONSIGNMENT', 'FLEET')),
    CONSTRAINT ck_coverage_status CHECK (status IN ('ACTIVE', 'PENDING', 'EXPIRED', 'SUSPENDED', 'REVOKED'))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- A rescue code may cover more than one subject (a VIP person and their car, a
-- fleet), through links, so the code system itself stays single-sourced.
CREATE TABLE rescue_code_links (
    id CHAR(36) NOT NULL,
    rescue_code_id CHAR(36) NOT NULL,
    subject_type VARCHAR(32) NOT NULL,
    subject_id CHAR(36) NOT NULL,
    relationship VARCHAR(24) NOT NULL DEFAULT 'PRIMARY',
    created_at TIMESTAMP(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
    PRIMARY KEY (id),
    UNIQUE KEY uq_rescue_code_links (rescue_code_id, subject_type, subject_id),
    KEY ix_rescue_code_links_subject (subject_type, subject_id),
    CONSTRAINT fk_rescue_code_links_code FOREIGN KEY (rescue_code_id) REFERENCES rescue_codes (id) ON DELETE CASCADE,
    CONSTRAINT ck_rescue_code_links_relationship CHECK (relationship IN ('PRIMARY', 'ADDITIONAL'))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- A membership becomes a plan-backed subscription. The billing engine is
-- unchanged: this only adds the plan reference the domain needs.
ALTER TABLE subscriptions
    ADD COLUMN service_plan_id CHAR(36) NULL AFTER product_id,
    ADD COLUMN domain VARCHAR(24) NULL AFTER service_plan_id,
    ADD COLUMN vehicle_id CHAR(36) NULL AFTER domain,
    ADD KEY ix_subscriptions_plan (service_plan_id),
    ADD KEY ix_subscriptions_domain (domain, status),
    ADD KEY ix_subscriptions_vehicle (vehicle_id),
    ADD CONSTRAINT fk_subscriptions_plan FOREIGN KEY (service_plan_id) REFERENCES service_plans (id) ON DELETE SET NULL,
    ADD CONSTRAINT fk_subscriptions_vehicle FOREIGN KEY (vehicle_id) REFERENCES vehicles (id) ON DELETE SET NULL;

ALTER TABLE rescue_codes
    ADD COLUMN domain VARCHAR(24) NULL AFTER country_code,
    ADD COLUMN subject_type VARCHAR(24) NULL AFTER domain,
    ADD KEY ix_rescue_codes_domain (domain, status);
UPDATE rescue_codes SET domain = 'VIP', subject_type = 'PERSON' WHERE domain IS NULL;

-- Seed plans. Names are configuration, not code: an operator can add a plan row.
INSERT INTO service_plans (id, plan_code, name, domain, category_code, coverage_type, billing_period, currency, base_fee, vehicle_limit, response_target_minutes, status, description) VALUES
    ('13000000-0000-4000-8000-000000000001', 'VIP-ROAD-ASSIST', 'VIP Road Assistance', 'VIP', 'INDIVIDUAL', 'ROAD_ASSISTANCE', 'ANNUAL', 'USD', 240.00, 2, 45, 'ACTIVE', 'Annual VIP cover for a person and up to two vehicles'),
    ('13000000-0000-4000-8000-000000000002', 'VIP-FULL-PROTECT', 'VIP Full Protection', 'VIP', 'INDIVIDUAL', 'FULL', 'ANNUAL', 'USD', 480.00, 3, 30, 'ACTIVE', 'Road assistance, medical and security response'),
    ('13000000-0000-4000-8000-000000000003', 'BUS-OPERATOR-COVER', 'Smart Bus Operator Cover', 'SMART_BUS', 'FLEET', 'ROAD_ASSISTANCE', 'MONTHLY', 'USD', 90.00, NULL, 60, 'ACTIVE', 'Monthly cover for a bus operator vehicle'),
    ('13000000-0000-4000-8000-000000000004', 'TRUCK-ROAD-ASSIST', 'Truck Road Assistance', 'TRUCK', 'VEHICLE', 'ROAD_ASSISTANCE', 'MONTHLY', 'USD', 150.00, 1, 60, 'ACTIVE', 'Monthly cover for one truck or trailer'),
    ('13000000-0000-4000-8000-000000000005', 'TRUCK-FLEET-CARGO', 'Truck Fleet and Cargo Cover', 'TRUCK', 'FLEET', 'CARGO_CARE', 'MONTHLY', 'USD', 60.00, NULL, 45, 'ACTIVE', 'Fleet cover including cargo in transit'),
    ('13000000-0000-4000-8000-000000000006', 'PRIVATE-ROAD-ASSIST', 'Private Road Assistance', 'PRIVATE_VEHICLE', 'VEHICLE', 'ROAD_ASSISTANCE', 'MONTHLY', 'USD', 25.00, 1, 60, 'ACTIVE', 'Monthly cover for one private vehicle'),
    ('13000000-0000-4000-8000-000000000007', 'PRIVATE-FAMILY', 'Private Family Cover', 'PRIVATE_VEHICLE', 'VEHICLE', 'MEDICAL', 'MONTHLY', 'USD', 40.00, 1, 45, 'ACTIVE', 'Monthly cover including a medical response');

INSERT INTO plan_fees (id, service_plan_id, fee_code, name, amount, currency, taxable) VALUES
    ('14000000-0000-4000-8000-000000000001', '13000000-0000-4000-8000-000000000001', 'BASE', 'Annual membership', 240.00, 'USD', FALSE),
    ('14000000-0000-4000-8000-000000000002', '13000000-0000-4000-8000-000000000004', 'BASE', 'Monthly vehicle cover', 150.00, 'USD', FALSE),
    ('14000000-0000-4000-8000-000000000003', '13000000-0000-4000-8000-000000000004', 'SECOND_VEHICLE', 'Additional vehicle', 90.00, 'USD', FALSE);
