CREATE TABLE tracking_assets (
    id CHAR(36) NOT NULL, asset_type VARCHAR(32) NOT NULL, reference_id CHAR(36) NOT NULL,
    code VARCHAR(40) NOT NULL, label VARCHAR(160) NOT NULL, status VARCHAR(24) NOT NULL DEFAULT 'ACTIVE',
    created_at TIMESTAMP(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
    PRIMARY KEY(id), UNIQUE KEY uq_tracking_asset_reference(asset_type,reference_id), UNIQUE KEY uq_tracking_asset_code(code),
    CONSTRAINT ck_tracking_asset_type CHECK(asset_type IN('RESCUE_UNIT','SMARTBUS_VEHICLE')),
    CONSTRAINT ck_tracking_asset_status CHECK(status IN('ACTIVE','OFFLINE','MAINTENANCE'))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE tracking_positions (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT, asset_id CHAR(36) NOT NULL,
    latitude DECIMAL(10,7) NOT NULL, longitude DECIMAL(10,7) NOT NULL, speed_kph DECIMAL(8,2) NULL,
    heading_degrees DECIMAL(6,2) NULL, accuracy_meters DECIMAL(8,2) NULL,
    recorded_at TIMESTAMP(6) NOT NULL, received_at TIMESTAMP(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
    PRIMARY KEY(id), KEY ix_tracking_position_asset_time(asset_id,recorded_at),
    CONSTRAINT fk_tracking_position_asset FOREIGN KEY(asset_id) REFERENCES tracking_assets(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE service_locations (
    id CHAR(36) NOT NULL, location_type VARCHAR(32) NOT NULL, name VARCHAR(160) NOT NULL,
    province VARCHAR(80) NOT NULL, address_text VARCHAR(255) NULL, latitude DECIMAL(10,7) NOT NULL,
    longitude DECIMAL(10,7) NOT NULL, contact_phone VARCHAR(32) NULL, status VARCHAR(24) NOT NULL DEFAULT 'ACTIVE',
    created_at TIMESTAMP(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
    PRIMARY KEY(id), KEY ix_service_location_type_province(location_type,province,status),
    CONSTRAINT ck_service_location_type CHECK(location_type IN('HOSPITAL','GARAGE','FUEL_STATION','COMMAND_STATION','RESCUE_BASE')),
    CONSTRAINT ck_service_location_status CHECK(status IN('ACTIVE','INACTIVE'))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO tracking_assets(id,asset_type,reference_id,code,label)
SELECT UUID(),'RESCUE_UNIT',id,CONCAT('TRK-',code),name FROM rescue_units;
INSERT INTO tracking_assets(id,asset_type,reference_id,code,label)
SELECT UUID(),'SMARTBUS_VEHICLE',id,CONCAT('TRK-',code),CONCAT(code,' ',registration_number) FROM smartbus_vehicles;
