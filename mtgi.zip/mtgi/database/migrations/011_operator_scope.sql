-- 011_operator_scope.sql
-- Operator isolation needs a link from an account to the operator it belongs
-- to. smartbus_operators has no user column today, so the link lives on the
-- account: a BUS_OPERATOR with operator_id set sees only their own trips,
-- manifests and passengers. NULL means "no operator scope" (staff roles), and
-- a BUS_OPERATOR with NULL is refused manifest access rather than granted a
-- global view (fail closed).

ALTER TABLE users
    ADD COLUMN operator_id CHAR(36) NULL AFTER subscriber_id,
    ADD KEY ix_users_operator (operator_id),
    ADD CONSTRAINT fk_users_operator FOREIGN KEY (operator_id) REFERENCES smartbus_operators (id) ON DELETE SET NULL;
