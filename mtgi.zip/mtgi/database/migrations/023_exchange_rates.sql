-- 023_exchange_rates.sql
-- Display currency for USD / CDF / TZS, and the rate history behind it.
--
-- WHY THIS MIGRATION EXISTS
--
-- The brief refers to an "existing Mamore ExchangeRateService". There is none:
-- `grep -r ExchangeRate` across the repository returns zero matches. The
-- service is built in this phase (app/Finance/ExchangeRateService.php) and this
-- migration gives it somewhere to read.
--
-- THE STORAGE MODEL WAS ALREADY CORRECT
--
-- payments, receipts, subscriptions and finance_transactions already store an
-- amount WITH its currency, and CDF-collected money already carries the rate
-- that was applied. No stored figure is rewritten by this migration and none
-- ever will be: changing the DISPLAY currency re-renders numbers, it does not
-- write. The invariant is asserted by tests/currency-integration.php, which
-- hashes the finance tables before and after a full conversion round-trip.
--
-- WHAT DOES CHANGE
--
-- The CHECK constraints pinned currency to ('USD') or ('CDF','USD'). TZS has to
-- be admitted, so those constraints are dropped and re-added wider. TZS is a
-- real settlement currency for this operation, not a display-only fiction, and
-- modelling it as display-only would mean a TZS payment could never be recorded.

-- ---------------------------------------------------------------------------
-- Rate history.
--
-- Rows are never deleted: a rate is evidence. `source` records where a rate came
-- from, so an operator-entered rate is visibly different from a fetched one and
-- nobody mistakes it for a market quote.
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS exchange_rates (
    id CHAR(36) NOT NULL PRIMARY KEY,
    base_currency CHAR(3) NOT NULL,
    quote_currency CHAR(3) NOT NULL,
    rate DECIMAL(18,6) NOT NULL,
    source VARCHAR(40) NOT NULL DEFAULT 'MANUAL',
    retrieved_at DATETIME(6) NOT NULL,
    valid_at DATETIME(6) NOT NULL,
    created_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
    CONSTRAINT ck_exchange_rate_pair UNIQUE (base_currency, quote_currency, retrieved_at),
    CONSTRAINT ck_exchange_rate_currencies CHECK (
        base_currency IN ('USD', 'CDF', 'TZS') AND quote_currency IN ('USD', 'CDF', 'TZS')
    ),
    CONSTRAINT ck_exchange_rate_positive CHECK (rate > 0)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE INDEX idx_exchange_rates_pair ON exchange_rates (base_currency, quote_currency, retrieved_at DESC);

-- ---------------------------------------------------------------------------
-- Widen the currency CHECK constraints to admit TZS.
--
-- MySQL 8 has no "ALTER CONSTRAINT", so the constraint is dropped and re-added.
--
-- The column definition MUST be repeated in full, not just the constraint. The
-- first draft of this migration wrote `MODIFY currency CHAR(3) NOT NULL` and
-- dropped every table's `DEFAULT 'USD'`, which broke
-- SubscriptionService::create() with "Field 'currency' doesn't have a default
-- value" -- caught by tests/audit-notification-integration.php. Nullability
-- and default are part of the column definition, so widening the allowed SET
-- has to restate them exactly as they were.
-- ---------------------------------------------------------------------------
ALTER TABLE payments DROP CHECK ck_payments_currency;
ALTER TABLE payments MODIFY currency CHAR(3) NOT NULL DEFAULT 'USD',
    ADD CONSTRAINT ck_payments_currency CHECK (currency IN ('USD', 'CDF', 'TZS'));

ALTER TABLE receipts DROP CHECK ck_receipts_currency;
ALTER TABLE receipts MODIFY currency CHAR(3) NOT NULL DEFAULT 'USD',
    ADD CONSTRAINT ck_receipts_currency CHECK (currency IN ('USD', 'CDF', 'TZS'));

ALTER TABLE subscriptions DROP CHECK ck_subscriptions_currency;
ALTER TABLE subscriptions MODIFY currency CHAR(3) NOT NULL DEFAULT 'USD',
    ADD CONSTRAINT ck_subscriptions_currency CHECK (currency IN ('USD', 'CDF', 'TZS'));

ALTER TABLE finance_transactions DROP CHECK ck_finance_currency;
ALTER TABLE finance_transactions MODIFY currency CHAR(3) NULL DEFAULT NULL,
    ADD CONSTRAINT ck_finance_currency CHECK (currency IN ('USD', 'CDF', 'TZS'));

-- ---------------------------------------------------------------------------
-- Settlement context on finance_transactions.
--
-- A transaction records the currency it was SETTLED in alongside the currency
-- it was collected in, so a converted receipt can be re-derived exactly rather
-- than re-converted at today's rate.
-- ---------------------------------------------------------------------------
ALTER TABLE finance_transactions
    ADD COLUMN settlement_currency CHAR(3) NULL DEFAULT NULL AFTER currency,
    ADD COLUMN rate_timestamp DATETIME(6) NULL DEFAULT NULL AFTER usd_cdf_rate;

-- ---------------------------------------------------------------------------
-- Seed the rates this deployment needs to operate with no egress.
--
-- These are MANUAL: operator-entered, visibly so. They are the reason a site
-- with no internet access can still run, and the reason the UI can always show
-- SOMETHING honest rather than nothing. The ExchangeRateService marks a rate
-- 'STALE' once it ages past its window, so an old seed is never presented as
-- live.
--
-- 1 USD = 2,900 CDF and 1 USD = 2,900 TZS are placeholders chosen to be
-- plausible for the operating region; an operator replaces them via settings.
-- They are seeded, not invented at render time.
-- ---------------------------------------------------------------------------
INSERT INTO exchange_rates (id, base_currency, quote_currency, rate, source, retrieved_at, valid_at) VALUES
    ('23000000-0000-4000-8000-000000000001', 'USD', 'CDF', 2900.000000, 'MANUAL', CURRENT_TIMESTAMP(6), CURRENT_TIMESTAMP(6)),
    ('23000000-0000-4000-8000-000000000002', 'USD', 'TZS', 2900.000000, 'MANUAL', CURRENT_TIMESTAMP(6), CURRENT_TIMESTAMP(6))
ON DUPLICATE KEY UPDATE rate = VALUES(rate);
