-- 018_vip_domain.sql
-- The VIP domain: a real operational domain, not a flag on a user.
--
-- Everything hangs off the canonical person and the canonical vehicle, so a VIP
-- is never a fifth copy of a human or a second vehicle registry.
--
-- Note: vip_benefits / subscriber_vip_benefits already exist (migration 010) and
-- are deliberately not recreated here.

CREATE TABLE vip_membership_types (
    code VARCHAR(24) NOT NULL,
    label VARCHAR(80) NOT NULL,
    allows_dependants BOOLEAN NOT NULL DEFAULT FALSE,
    allows_multiple_vehicles BOOLEAN NOT NULL DEFAULT FALSE,
    PRIMARY KEY (code)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO vip_membership_types (code, label, allows_dependants, allows_multiple_vehicles) VALUES
    ('INDIVIDUAL', 'Individual', FALSE, TRUE),
    ('FAMILY', 'Family', TRUE, TRUE),
    ('CORPORATE', 'Corporate', TRUE, TRUE),
    ('FLEET_OWNER', 'Fleet owner', FALSE, TRUE),
    ('EXECUTIVE', 'Executive', FALSE, TRUE),
    ('DRIVER', 'Driver', FALSE, FALSE),
    ('PASSENGER', 'Passenger', FALSE, FALSE);

CREATE TABLE vip_priority_levels (
    code VARCHAR(16) NOT NULL,
    label VARCHAR(60) NOT NULL,
    rank_order SMALLINT UNSIGNED NOT NULL,
    PRIMARY KEY (code)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO vip_priority_levels (code, label, rank_order) VALUES
    ('STANDARD', 'Standard', 1), ('PRIORITY', 'Priority', 2),
    ('EXECUTIVE', 'Executive', 3), ('CRITICAL', 'Critical', 4);

CREATE TABLE vip_subscribers (
    id CHAR(36) NOT NULL,
    person_id CHAR(36) NOT NULL,
    organization_id CHAR(36) NULL,
    membership_number VARCHAR(40) NOT NULL,
    subscription_id CHAR(36) NULL,
    rescue_code_id CHAR(36) NULL,
    membership_type VARCHAR(24) NOT NULL DEFAULT 'INDIVIDUAL',
    service_plan_id CHAR(36) NULL,
    status VARCHAR(16) NOT NULL DEFAULT 'PENDING',
    priority_level VARCHAR(16) NOT NULL DEFAULT 'STANDARD',
    home_country CHAR(2) NOT NULL DEFAULT 'CD',
    home_region VARCHAR(80) NULL,
    home_city VARCHAR(120) NULL,
    primary_phone VARCHAR(32) NULL,
    alternative_phone VARCHAR(32) NULL,
    preferred_language VARCHAR(8) NOT NULL DEFAULT 'en',
    preferred_currency CHAR(3) NOT NULL DEFAULT 'USD',
    rescue_coverage_status VARCHAR(16) NOT NULL DEFAULT 'UNCOVERED',
    emergency_profile_complete BOOLEAN NOT NULL DEFAULT FALSE,
    activated_at TIMESTAMP(6) NULL,
    expires_at TIMESTAMP(6) NULL,
    created_by_user_id CHAR(36) NULL,
    created_at TIMESTAMP(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
    updated_at TIMESTAMP(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6) ON UPDATE CURRENT_TIMESTAMP(6),
    PRIMARY KEY (id),
    UNIQUE KEY uq_vip_subscribers_membership (membership_number),
    UNIQUE KEY uq_vip_subscribers_person (person_id),
    KEY ix_vip_subscribers_status (status, rescue_coverage_status),
    KEY ix_vip_subscribers_expiry (expires_at),
    KEY ix_vip_subscribers_geo (home_country, home_region, home_city),
    KEY ix_vip_subscribers_organization (organization_id),
    CONSTRAINT fk_vip_subscribers_person FOREIGN KEY (person_id) REFERENCES persons (id) ON DELETE CASCADE,
    CONSTRAINT fk_vip_subscribers_organization FOREIGN KEY (organization_id) REFERENCES organizations (id) ON DELETE SET NULL,
    CONSTRAINT fk_vip_subscribers_subscription FOREIGN KEY (subscription_id) REFERENCES subscriptions (id) ON DELETE SET NULL,
    CONSTRAINT fk_vip_subscribers_code FOREIGN KEY (rescue_code_id) REFERENCES rescue_codes (id) ON DELETE SET NULL,
    CONSTRAINT fk_vip_subscribers_plan FOREIGN KEY (service_plan_id) REFERENCES service_plans (id) ON DELETE SET NULL,
    CONSTRAINT fk_vip_subscribers_creator FOREIGN KEY (created_by_user_id) REFERENCES users (id) ON DELETE SET NULL,
    CONSTRAINT ck_vip_subscribers_type FOREIGN KEY (membership_type) REFERENCES vip_membership_types (code),
    CONSTRAINT ck_vip_subscribers_priority FOREIGN KEY (priority_level) REFERENCES vip_priority_levels (code),
    CONSTRAINT ck_vip_subscribers_status CHECK (status IN ('PENDING', 'ACTIVE', 'SUSPENDED', 'EXPIRED', 'CANCELLED')),
    CONSTRAINT ck_vip_subscribers_coverage CHECK (rescue_coverage_status IN ('ACTIVE', 'UNCOVERED', 'EXPIRED', 'SUSPENDED'))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE vip_vehicle_links (
    id CHAR(36) NOT NULL,
    vip_subscriber_id CHAR(36) NOT NULL,
    vehicle_id CHAR(36) NOT NULL,
    relationship VARCHAR(24) NOT NULL DEFAULT 'OWNER',
    is_primary BOOLEAN NOT NULL DEFAULT FALSE,
    coverage_status VARCHAR(16) NOT NULL DEFAULT 'UNCOVERED',
    coverage_start TIMESTAMP(6) NULL,
    coverage_end TIMESTAMP(6) NULL,
    created_at TIMESTAMP(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
    updated_at TIMESTAMP(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6) ON UPDATE CURRENT_TIMESTAMP(6),
    -- MySQL has no filtered index, so "one primary vehicle per membership" is
    -- enforced with a virtual column that is NULL on non-primary rows: unique
    -- indexes ignore NULLs, exactly as for rescue codes.
    primary_owner_id CHAR(36)
        GENERATED ALWAYS AS (CASE WHEN is_primary = 1 THEN vip_subscriber_id ELSE NULL END) VIRTUAL,
    PRIMARY KEY (id),
    UNIQUE KEY uq_vip_vehicle_links (vip_subscriber_id, vehicle_id),
    UNIQUE KEY uq_vip_vehicle_links_primary (primary_owner_id),
    KEY ix_vip_vehicle_links_vehicle (vehicle_id),
    KEY ix_vip_vehicle_links_coverage (coverage_status),
    CONSTRAINT fk_vip_vehicle_links_subscriber FOREIGN KEY (vip_subscriber_id) REFERENCES vip_subscribers (id) ON DELETE CASCADE,
    CONSTRAINT fk_vip_vehicle_links_vehicle FOREIGN KEY (vehicle_id) REFERENCES vehicles (id) ON DELETE CASCADE,
    CONSTRAINT ck_vip_vehicle_links_relationship CHECK (relationship IN
        ('OWNER', 'PRIMARY_DRIVER', 'FAMILY_VEHICLE', 'COMPANY_VEHICLE', 'AUTHORIZED_USER'))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE vip_dependants (
    id CHAR(36) NOT NULL,
    vip_subscriber_id CHAR(36) NOT NULL,
    person_id CHAR(36) NOT NULL,
    relationship VARCHAR(24) NOT NULL,
    rescue_covered BOOLEAN NOT NULL DEFAULT FALSE,
    emergency_priority SMALLINT UNSIGNED NULL,
    notes VARCHAR(255) NULL,
    created_at TIMESTAMP(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
    PRIMARY KEY (id),
    UNIQUE KEY uq_vip_dependants (vip_subscriber_id, person_id),
    KEY ix_vip_dependants_person (person_id),
    CONSTRAINT fk_vip_dependants_subscriber FOREIGN KEY (vip_subscriber_id) REFERENCES vip_subscribers (id) ON DELETE CASCADE,
    CONSTRAINT fk_vip_dependants_person FOREIGN KEY (person_id) REFERENCES persons (id) ON DELETE CASCADE,
    CONSTRAINT ck_vip_dependants_relationship CHECK (relationship IN
        ('SPOUSE', 'CHILD', 'PARENT', 'DEPENDANT', 'STAFF'))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Emergency profile is deliberately separated so access can be role-restricted
-- independently of the membership itself.
CREATE TABLE vip_emergency_profiles (
    vip_subscriber_id CHAR(36) NOT NULL,
    preferred_hospital_location_id CHAR(36) NULL,
    preferred_language VARCHAR(8) NOT NULL DEFAULT 'en',
    accessibility_requirements VARCHAR(255) NULL,
    insurance_provider VARCHAR(120) NULL,
    insurance_policy_number VARCHAR(64) NULL,
    critical_notes VARCHAR(500) NULL,
    blood_type VARCHAR(8) NULL,
    updated_by_user_id CHAR(36) NULL,
    updated_at TIMESTAMP(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6) ON UPDATE CURRENT_TIMESTAMP(6),
    PRIMARY KEY (vip_subscriber_id),
    CONSTRAINT fk_vip_emergency_profiles_subscriber FOREIGN KEY (vip_subscriber_id) REFERENCES vip_subscribers (id) ON DELETE CASCADE,
    CONSTRAINT fk_vip_emergency_profiles_hospital FOREIGN KEY (preferred_hospital_location_id) REFERENCES locations (id) ON DELETE SET NULL,
    CONSTRAINT fk_vip_emergency_profiles_user FOREIGN KEY (updated_by_user_id) REFERENCES users (id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
