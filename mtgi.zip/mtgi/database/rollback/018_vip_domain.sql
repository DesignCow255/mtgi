DROP TABLE IF EXISTS vip_emergency_profiles;
DROP TABLE IF EXISTS vip_dependants;
DROP TABLE IF EXISTS vip_vehicle_links;
DROP TABLE IF EXISTS vip_subscribers;
DELETE FROM vip_priority_levels;
DELETE FROM vip_membership_types;
