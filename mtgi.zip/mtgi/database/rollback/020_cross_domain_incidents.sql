ALTER TABLE rescue_incidents
    DROP FOREIGN KEY fk_rescue_incidents_domain, DROP FOREIGN KEY fk_rescue_incidents_type,
    DROP FOREIGN KEY fk_rescue_incidents_subscriber, DROP FOREIGN KEY fk_rescue_incidents_canonical_vehicle,
    DROP FOREIGN KEY fk_rescue_incidents_asset, DROP FOREIGN KEY fk_rescue_incidents_consignment,
    DROP FOREIGN KEY fk_rescue_incidents_code, DROP CHECK ck_rescue_incidents_severity,
    DROP KEY ix_rescue_incidents_domain_status, DROP KEY ix_rescue_incidents_subscriber,
    DROP KEY ix_rescue_incidents_vehicle, DROP KEY ix_rescue_incidents_asset,
    DROP KEY ix_rescue_incidents_journey, DROP KEY ix_rescue_incidents_severity,
    DROP COLUMN distance_basis, DROP COLUMN response_notes, DROP COLUMN cargo_hazardous,
    DROP COLUMN cargo_weight_kg, DROP COLUMN rescue_code_id, DROP COLUMN consignment_id,
    DROP COLUMN journey_id, DROP COLUMN tracked_asset_id, DROP COLUMN vehicle_id,
    DROP COLUMN subscriber_id, DROP COLUMN severity, DROP COLUMN incident_type, DROP COLUMN domain;
DROP TABLE IF EXISTS rescue_unit_capabilities;
DROP TABLE IF EXISTS rescue_capabilities;
DROP TABLE IF EXISTS incident_types;
DROP TABLE IF EXISTS incident_domains;
