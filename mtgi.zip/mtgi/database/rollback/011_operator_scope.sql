ALTER TABLE users
    DROP FOREIGN KEY fk_users_operator,
    DROP KEY ix_users_operator,
    DROP COLUMN operator_id;
