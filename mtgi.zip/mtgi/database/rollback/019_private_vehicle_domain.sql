DROP TABLE IF EXISTS journey_passengers;
DROP TABLE IF EXISTS private_vehicle_journeys;
DROP TABLE IF EXISTS private_vehicle_drivers;
DROP TABLE IF EXISTS private_vehicles;
DELETE FROM private_vehicle_relationships;
