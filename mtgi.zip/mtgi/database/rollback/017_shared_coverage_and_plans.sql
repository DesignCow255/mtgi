ALTER TABLE rescue_codes DROP KEY ix_rescue_codes_domain, DROP COLUMN subject_type, DROP COLUMN domain;
ALTER TABLE subscriptions
    DROP FOREIGN KEY fk_subscriptions_plan, DROP FOREIGN KEY fk_subscriptions_vehicle,
    DROP KEY ix_subscriptions_plan, DROP KEY ix_subscriptions_domain, DROP KEY ix_subscriptions_vehicle,
    DROP COLUMN vehicle_id, DROP COLUMN domain, DROP COLUMN service_plan_id;
DROP TABLE IF EXISTS rescue_code_links;
DROP TABLE IF EXISTS rescue_coverage_links;
DROP TABLE IF EXISTS plan_fees;
DROP TABLE IF EXISTS service_plans;
DELETE FROM plan_categories;
DELETE FROM coverage_types;
