DROP TABLE IF EXISTS rescue_incident_events;
DROP TABLE IF EXISTS rescue_incidents;
DROP TABLE IF EXISTS rescue_units;
