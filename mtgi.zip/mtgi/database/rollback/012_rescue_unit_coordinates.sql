UPDATE rescue_units SET latitude = NULL, longitude = NULL WHERE code IN ('MR-B0', 'MR-S1', 'MR-S2', 'MR-S4', 'MR-R5');
