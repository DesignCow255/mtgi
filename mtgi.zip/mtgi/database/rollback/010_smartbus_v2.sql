-- Reverse of 010_smartbus_v2.sql, in dependency order.
ALTER TABLE rescue_incidents
    DROP FOREIGN KEY fk_rescue_incidents_trip,
    DROP FOREIGN KEY fk_rescue_incidents_vehicle,
    DROP FOREIGN KEY fk_rescue_incidents_operator,
    DROP KEY ix_rescue_incidents_trip,
    DROP COLUMN source_longitude, DROP COLUMN source_latitude,
    DROP COLUMN vip_passenger_count, DROP COLUMN passenger_count,
    DROP COLUMN smartbus_operator_id, DROP COLUMN smartbus_vehicle_id,
    DROP COLUMN smartbus_booking_id, DROP COLUMN smartbus_trip_id;

ALTER TABLE smartbus_bookings
    DROP FOREIGN KEY fk_smartbus_booking_user,
    DROP FOREIGN KEY fk_smartbus_booking_subscriber,
    DROP FOREIGN KEY fk_smartbus_booking_rescue_code,
    DROP KEY ix_smartbus_booking_manifest, DROP KEY ix_smartbus_booking_user, DROP KEY ix_smartbus_booking_phone_trip,
    DROP COLUMN updated_at, DROP COLUMN cancelled_at, DROP COLUMN completed_at,
    DROP COLUMN no_show_at, DROP COLUMN boarded_at, DROP COLUMN check_in_at,
    DROP COLUMN manifest_status, DROP COLUMN special_assistance, DROP COLUMN vip_at_booking,
    DROP COLUMN rescue_code_id, DROP COLUMN subscriber_id, DROP COLUMN user_id;
ALTER TABLE smartbus_bookings DROP CHECK ck_smartbus_booking_status;
ALTER TABLE smartbus_bookings ADD CONSTRAINT ck_smartbus_booking_status
    CHECK (status IN ('CONFIRMED', 'BOARDED', 'CANCELLED', 'REFUNDED'));

ALTER TABLE smartbus_trips
    DROP FOREIGN KEY fk_smartbus_trip_driver,
    DROP FOREIGN KEY fk_smartbus_trip_conductor,
    DROP KEY ix_smartbus_trip_boarding, DROP KEY ix_smartbus_trip_route_departure,
    DROP COLUMN conductor_user_id, DROP COLUMN driver_user_id,
    DROP COLUMN vehicle_assignment_status, DROP COLUMN delay_minutes,
    DROP COLUMN completed_at, DROP COLUMN departed_at, DROP COLUMN arrival_estimate_at,
    DROP COLUMN boarding_closes_at, DROP COLUMN boarding_opens_at, DROP COLUMN reporting_at;
ALTER TABLE smartbus_trips DROP CHECK ck_smartbus_trip_status;
ALTER TABLE smartbus_trips ADD CONSTRAINT ck_smartbus_trip_status
    CHECK (status IN ('SCHEDULED', 'BOARDING', 'DEPARTED', 'COMPLETED', 'CANCELLED'));

ALTER TABLE smartbus_routes
    DROP FOREIGN KEY fk_smartbus_routes_origin_station,
    DROP FOREIGN KEY fk_smartbus_routes_destination_station,
    DROP KEY ix_smartbus_routes_country, DROP KEY ix_smartbus_routes_origin_destination,
    DROP COLUMN is_direct, DROP COLUMN estimated_duration_minutes,
    DROP COLUMN destination_station_id, DROP COLUMN origin_station_id,
    DROP COLUMN city, DROP COLUMN province, DROP COLUMN country_code;

ALTER TABLE smartbus_vehicles
    DROP COLUMN insurance_status, DROP COLUMN inspection_status, DROP COLUMN verification_status,
    DROP COLUMN gps_enabled, DROP COLUMN has_toilet, DROP COLUMN has_charging, DROP COLUMN has_wifi,
    DROP COLUMN has_air_conditioning, DROP COLUMN year, DROP COLUMN model, DROP COLUMN make;

ALTER TABLE smartbus_operators
    DROP COLUMN boarding_close_minutes_before_departure, DROP COLUMN boarding_open_minutes_before_departure,
    DROP COLUMN reporting_minutes_before_departure, DROP COLUMN rescue_integration,
    DROP COLUMN support_phone, DROP COLUMN license_number, DROP COLUMN business_registration,
    DROP COLUMN verification_status;

DELETE FROM role_permissions WHERE permission_id IN (SELECT id FROM permissions WHERE code LIKE 'smartbus.%');
DELETE FROM permissions WHERE code LIKE 'smartbus.%';

DROP TABLE IF EXISTS subscriber_vip_benefits;
DROP TABLE IF EXISTS vip_benefits;
DROP TABLE IF EXISTS message_outbox;
DROP TABLE IF EXISTS message_templates;
DROP TABLE IF EXISTS active_journeys;
DROP TABLE IF EXISTS smartbus_seat_holds;
DROP TABLE IF EXISTS smartbus_stations;
DROP TABLE IF EXISTS rescue_code_access_log;
DROP TABLE IF EXISTS rescue_codes;
