ALTER TABLE smartbus_operators
    DROP FOREIGN KEY fk_smartbus_operators_organization, DROP KEY ix_smartbus_operators_organization,
    DROP COLUMN organization_id;
ALTER TABLE subscribers
    DROP FOREIGN KEY fk_subscribers_person, DROP FOREIGN KEY fk_subscribers_organization,
    DROP KEY ix_subscribers_person, DROP KEY ix_subscribers_organization,
    DROP COLUMN organization_id, DROP COLUMN person_id;
ALTER TABLE users
    DROP FOREIGN KEY fk_users_person, DROP FOREIGN KEY fk_users_organization,
    DROP KEY ix_users_person, DROP KEY ix_users_organization,
    DROP COLUMN organization_id, DROP COLUMN person_id;
ALTER TABLE subscriber_vehicles
    DROP FOREIGN KEY fk_subscriber_vehicles_vehicle, DROP KEY uq_subscriber_vehicles_vehicle, DROP COLUMN vehicle_id;
ALTER TABLE rescue_units
    DROP FOREIGN KEY fk_rescue_units_vehicle, DROP KEY uq_rescue_units_vehicle, DROP COLUMN vehicle_id;
ALTER TABLE smartbus_vehicles
    DROP FOREIGN KEY fk_smartbus_vehicles_vehicle, DROP KEY uq_smartbus_vehicles_vehicle, DROP COLUMN vehicle_id;
DROP TABLE IF EXISTS vehicles;
