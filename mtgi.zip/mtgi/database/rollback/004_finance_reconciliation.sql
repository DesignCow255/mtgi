DROP TABLE IF EXISTS finance_allocations;
DROP TABLE IF EXISTS finance_transactions;
