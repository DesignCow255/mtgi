DROP TABLE IF EXISTS user_notifications;
DROP TABLE IF EXISTS panic_alerts;
