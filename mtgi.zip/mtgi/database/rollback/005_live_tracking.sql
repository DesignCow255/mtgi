DROP TABLE IF EXISTS tracking_positions;
DROP TABLE IF EXISTS service_locations;
DROP TABLE IF EXISTS tracking_assets;
