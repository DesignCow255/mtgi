DROP TABLE IF EXISTS smartbus_bookings;
DROP TABLE IF EXISTS smartbus_trips;
DROP TABLE IF EXISTS smartbus_vehicles;
DROP TABLE IF EXISTS smartbus_routes;
DROP TABLE IF EXISTS smartbus_operators;
