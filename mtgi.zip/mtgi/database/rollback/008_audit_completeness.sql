ALTER TABLE audit_logs
    DROP FOREIGN KEY fk_audit_session,
    DROP KEY ix_audit_session,
    DROP KEY ix_audit_action_time,
    DROP COLUMN session_id,
    DROP COLUMN actor_role;
