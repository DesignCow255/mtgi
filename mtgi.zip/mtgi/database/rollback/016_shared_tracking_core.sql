ALTER TABLE tracking_assets
    DROP FOREIGN KEY fk_tracking_assets_canonical, DROP KEY ix_tracking_assets_canonical, DROP COLUMN tracked_asset_id;
DROP TABLE IF EXISTS tracking_alerts;
DROP TABLE IF EXISTS alert_types;
DROP TABLE IF EXISTS asset_geofence_state;
DROP TABLE IF EXISTS geofences;
DROP TABLE IF EXISTS geofence_types;
DROP TABLE IF EXISTS location_history;
DROP TABLE IF EXISTS tracked_asset_positions;
DROP TABLE IF EXISTS tracking_device_assignments;
DROP TABLE IF EXISTS tracking_devices;
DROP TABLE IF EXISTS tracked_assets;
DROP TABLE IF EXISTS asset_types;
