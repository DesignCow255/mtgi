ALTER TABLE users
    DROP FOREIGN KEY fk_users_subscriber,
    DROP KEY uq_users_subscriber,
    DROP COLUMN subscriber_id;
DROP TABLE IF EXISTS receipts;
DROP TABLE IF EXISTS ledger_entries;
DROP TABLE IF EXISTS revenue_ledgers;
DROP TABLE IF EXISTS government_taxes;
DROP TABLE IF EXISTS payment_allocations;
DROP TABLE IF EXISTS payments;
DROP TABLE IF EXISTS subscription_history;
DROP TABLE IF EXISTS subscription_fees;
DROP TABLE IF EXISTS subscriptions;
DROP TABLE IF EXISTS subscriber_history;
DROP TABLE IF EXISTS subscriber_vehicles;
DROP TABLE IF EXISTS subscribers;
DROP TABLE IF EXISTS rescue_product_rules;
DROP TABLE IF EXISTS rescue_products;
