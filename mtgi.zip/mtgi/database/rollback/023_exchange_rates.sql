-- Reverses 023_exchange_rates.sql.
--
-- TZS is NOT written back into the constraints, because re-pinning them to
-- ('USD','USD') would reject any TZS row that was legitimately recorded while
-- 023 was live. The rollback removes what 023 added and leaves the widened
-- constraints in place, which is the only ordering that cannot destroy data.
--
-- Narrowing the constraints back is a separate, manual decision that must be
-- made after confirming no TZS rows exist -- never as part of an automatic
-- rollback.

-- Drop the seeded rates and the table. Rates are re-seedable, unlike finance rows.
DELETE FROM exchange_rates WHERE base_currency = 'USD' AND quote_currency IN ('CDF', 'TZS');
DROP TABLE IF EXISTS exchange_rates;

-- Remove the settlement context added to finance_transactions.
ALTER TABLE finance_transactions
    DROP COLUMN settlement_currency,
    DROP COLUMN rate_timestamp;
