ALTER TABLE smartbus_stations
    DROP FOREIGN KEY fk_smartbus_stations_canonical, DROP KEY ix_smartbus_stations_canonical, DROP COLUMN location_id;
ALTER TABLE service_locations
    DROP FOREIGN KEY fk_service_locations_canonical, DROP KEY ix_service_locations_canonical, DROP COLUMN location_id;
DROP TABLE IF EXISTS locations;
DROP TABLE IF EXISTS organizations;
DROP TABLE IF EXISTS persons;
DELETE FROM location_types;
DELETE FROM vehicle_types;
