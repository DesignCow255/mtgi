<?php
// Mamore verification: compares row counts + money totals.
// Usage: php scripts/verify-migration.php (needs DB_* env)
declare(strict_types=1);

require dirname(__DIR__) . '/bootstrap.php';

use Mamore\Core\Database;

$db = Database::connection();
$tables = ['roles','permissions','role_permissions','users','user_sessions','login_history','audit_logs','rescue_units','rescue_incidents','smartbus_operators','smartbus_routes','smartbus_vehicles','smartbus_trips','smartbus_bookings','finance_transactions','finance_allocations','tracking_assets','tracking_positions','service_locations','panic_alerts','user_notifications'];
$report = ['generatedAt' => gmdate(DATE_ATOM), 'tables' => []];
foreach ($tables as $table) {
    try {
        $count = (int) $db->query("SELECT COUNT(*) FROM `{$table}`")->fetchColumn();
        $report['tables'][$table] = ['rows' => $count, 'status' => 'ok'];
    } catch (Throwable $e) {
        $report['tables'][$table] = ['rows' => 0, 'status' => 'missing: ' . $e->getMessage()];
    }
}
echo json_encode($report, JSON_PRETTY_PRINT) . PHP_EOL;
