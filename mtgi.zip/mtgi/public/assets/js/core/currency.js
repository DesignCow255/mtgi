// Mamore UI v2 — currency (DISPLAY only).
//
// The invariant this file exists to protect:
//
//   CHANGING THE DISPLAY CURRENCY NEVER CHANGES A STORED AMOUNT.
//
// Everything here is presentation. A payment keeps its original amount and
// original currency forever; this module only decides which of the two to draw
// on screen, and it always says which.
//
// The audit found three independent formatters, one of which hard-suffixed
// "CDF" on every value regardless of its real currency and another of which was
// used to print cargo weight in kilograms. There is one formatter now, and a
// separate unit formatter for weights, because a weight is not money.
(() => {
  'use strict';

  const STORAGE_KEY = 'mamore.displayCurrency';
  const SYMBOLS = { USD: '$', CDF: 'FC', TZS: 'TSh' };
  const NAMES = { USD: 'US Dollar', CDF: 'Congolese Franc', TZS: 'Tanzanian Shilling' };

  let display = 'USD';
  let rates = {};
  let status = 'unavailable';
  let loadedAt = null;

  const number = (value) => {
    const n = Number(value);
    return Number.isFinite(n) ? n : 0;
  };

  /**
   * Group and round an amount to exactly two decimals.
   *
   * toFixed(2) plus en-US grouping rather than locale formatting, because the
   * grouping must match the PHP side exactly or a figure in a table and the
   * same figure on a receipt will disagree. Locale grouping (French's narrow
   * no-break space) is a presentation choice the caller layers on top.
   */
  const format = (amount, currency) => {
    const value = Number(amount);
    const safe = Number.isFinite(value) ? value : 0;
    const [units, cents] = Math.abs(safe).toFixed(2).split('.');
    const grouped = Number(units).toLocaleString('en-US', { minimumFractionDigits: 0, maximumFractionDigits: 0 });
    return `${safe < 0 ? '-' : ''}${currency} ${grouped}.${cents}`;
  };

  /**
   * Convert for display.
   *
   * When no rate is available the ORIGINAL amount and currency come back with
   * `converted: false`. A missing rate must never produce a zero and never
   * produce a guess -- the caller shows the source figure and a notice.
   */
  const convert = (amount, sourceCurrency, targetCurrency) => {
    const source = String(sourceCurrency || '').toUpperCase();
    const target = String(targetCurrency || display).toUpperCase();
    const value = Number(amount) || 0;

    if (!source || !target || source === target) {
      return { amount: value, currency: source, converted: false, rate: null, status: 'identity' };
    }

    const rate = rates[source + '/' + target];
    if (rate === undefined || rate === null || !Number.isFinite(Number(rate))) {
      return { amount: value, currency: source, converted: false, rate: null, status: 'unavailable' };
    }

    return {
      amount: Math.round(value * Number(rate) * 100) / 100,
      currency: target,
      converted: true,
      rate: Number(rate),
      status,
    };
  };

  const display = (amount, sourceCurrency) => {
    const result = convert(amount, sourceCurrency, display);
    return format(result.amount, result.currency);
  };

  /**
   * A figure plus its provenance, for a tooltip or a title attribute.
   *

  /**
   * Emit a money span that re-renders when the display currency changes.
   *
   * The amount and its source currency ride along as data attributes, so
   * switching currency re-formats every figure already on the page without a
   * round trip and without re-rendering the panel that contains it.
   */
  const node = (amount, sourceCurrency, options = {}) => {
    const result = presentation(amount, sourceCurrency);
    const classes = ['is-money'];
    if (options.className) classes.push(options.className);

    return `<span class="${classes.join(' ')}" data-money data-amount="${result.sourceAmount}" data-currency="${result.sourceCurrency}" title="${title(result)}">${format(result.amount, result.currency)}</span>`;
  };

  const title = (result) => {
    if (result.converted) {
      return `${result.sourceCurrency} ${result.sourceAmount.toFixed(2)} · converted at ${result.rate} (${result.status})`;
    }
    if (result.status === 'unavailable' && result.sourceCurrency !== display) {
      return `${result.sourceCurrency} ${result.sourceAmount.toFixed(2)} · no rate available, showing the original`;
    }
    return result.sourceCurrency;
  };

  /** Re-render every money figure currently on the page. */
  const refresh = () => {
    document.querySelectorAll('[data-money]').forEach((element) => {
      const result = presentation(element.getAttribute('data-amount'), element.getAttribute('data-currency'));
      element.textContent = format(result.amount, result.currency);
      element.setAttribute('title', title(result));
    });
  };

  /** Load rates and adopt a display currency. */
  const load = async (requested) => {
    const base = (document.querySelector('meta[name="mamore-base"]')?.content || '').replace(/\/$/, '');

    try {
      const response = await fetch(base + '/api/currency', { credentials: 'same-origin' });
      const payload = await response.json();
      if (!response.ok) throw new Error(payload.error || 'Could not load rates.');

      rates = {};
      (payload.rates || []).forEach((entry) => {
        // A null rate is stored as absent, never as 0: a zero rate would make
        // every converted figure zero, which is the exact failure this layer
        // exists to prevent.
        if (entry.rate !== null && entry.rate !== undefined) {
          rates[entry.pair] = entry.rate;
        }
      });

      status = payload.status || 'unavailable';
      loadedAt = payload.retrievedAt || null;
      display = requested || payload.display || 'USD';
      try { window.localStorage.setItem(STORAGE_KEY, display); } catch (_) { /* storage blocked */ }

      refresh();
      document.dispatchEvent(new CustomEvent('mamore:currencychange', { detail: { display, status } }));
      return display;
    } catch (_) {
      // A failed rate load leaves every figure in its ORIGINAL currency, which
      // is correct. It never blanks a number and never shows zero.
      status = 'unavailable';
      refresh();
      return null;
    }
  };

  const preferred = () => {
    try {
      const value = window.localStorage.getItem(STORAGE_KEY);
      return value === 'USD' || value === 'CDF' || value === 'TZS' ? value : null;
    } catch (_) {
      return null;
    }
  };

  /* ------------------------------------------------------- units, not money
   *
   * The audit found a weight being rendered by a function called `asMoney()`.
   * A weight is not money: it has no currency and no conversion. It gets its own
   * formatters so the two can never be confused again.
   */
  const kilograms = (value) => `${number(value).toLocaleString('en-US', { maximumFractionDigits: 0 })} kg`;
  const tonnes = (value) => `${number(value).toLocaleString('en-US', { maximumFractionDigits: 2 })} t`;
  const kilometres = (value) => `${number(value).toLocaleString('en-US', { maximumFractionDigits: 1 })} km`;
  const speed = (value) => `${number(value).toLocaleString('en-US', { maximumFractionDigits: 0 })} km/h`;
  const percent = (value) => `${number(value).toLocaleString('en-US', { maximumFractionDigits: 1 })}%`;
  const plain = (value) => number(value).toLocaleString('en-US');

  document.addEventListener('click', (event) => {
    const option = event.target.closest('[data-currency-option]');
    if (!option) return;
    event.preventDefault();
    load(option.getAttribute('data-currency-option'));
  });

  (window.Mamore = window.Mamore || {}).currency = {
    format, convert, display, presentation, node, refresh, load, preferred,
    kilograms, tonnes, kilometres, speed, percent, plain,
    SYMBOLS, NAMES, STORAGE_KEY,
    get display() { return display; },
    get status() { return status; },
    get rates() { return rates; },
    get loadedAt() { return loadedAt; },
  };
})();

   * A converted figure is always distinguishable from a source one: the reader
   * can find out what it was and what rate was used.
   */
  const presentation = (amount, sourceCurrency) => ({
    ...convert(amount, sourceCurrency, display),
    sourceAmount: Number(amount) || 0,
    sourceCurrency: String(sourceCurrency || '').toUpperCase(),
  });
