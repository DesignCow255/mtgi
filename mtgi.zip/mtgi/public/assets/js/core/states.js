// Mamore UI v2 — asynchronous surface states.
//
// The audit's most consequential finding was S1.4: a failed request rendered
// as a zero. `Number(value || 0)` over a rejected fetch is the default pattern
// in app.js, and it makes a dead endpoint indistinguishable from a genuinely
// empty metric. That is the most misleading thing the product can do, because
// an operator reading "0 incidents" would conclude the opposite of the truth.
//
// This module makes the four states first-class and, critically, makes
// `render` refuse to invent a value it was not given.
(() => {
  'use strict';

  const icon = (name) => `<i class="fa-solid fa-${name}" aria-hidden="true"></i>`;

  const escape = (value) => String(value ?? '').replace(/[&<>"']/g, (character) => ({
    '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;',
  })[character]);

  const shell = (inner, extraClass = '') =>
    `<div class="${extraClass}" role="status" aria-live="polite">${inner}</div>`;

  /* ---------------------------------------------------------------- loading
   * A skeleton shaped like the content it replaces, so nothing shifts when the
   * data lands. Never a spinner over the whole screen. */
  const skeleton = (options = {}) => {
    const kind = options.kind || 'block';
    const rows = options.rows || 5;
    let body;

    if (kind === 'metric') {
      body = '<div class="skeleton skeleton--text" style="width:45%"></div>'
           + '<div class="skeleton skeleton--value"></div>'
           + '<div class="skeleton skeleton--text" style="width:70%"></div>';
    } else if (kind === 'chart') {
      body = '<div class="skeleton skeleton--block"></div>';
    } else if (kind === 'row' || kind === 'table') {
      body = Array.from({ length: rows }, () => '<div class="skeleton skeleton--row"></div>').join('');
    } else {
      body = '<div class="skeleton skeleton--block"></div>';
    }

    return shell(body, 'skeleton-group');
  };

  /* ------------------------------------------------------------------ empty
   * Three parts: what this area is, why it is empty, and the action available.
   * Never "No Data." */
  const empty = (options = {}) => {
    const title = options.title || 'Nothing here yet';
    const body = options.body || '';
    const action = options.actionLabel
      ? `<button class="btn btn--secondary" type="button" data-state-action="${escape(options.actionTarget || '')}">${icon(options.actionIcon || 'plus')}${escape(options.actionLabel)}</button>`
      : '';

    return shell(`
      <div class="empty-state">
        <span class="empty-state__icon">${icon(options.icon || 'circle-info')}</span>
        <p class="empty-state__title">${escape(title)}</p>
        ${body ? `<p class="empty-state__body">${escape(body)}</p>` : ''}
        ${action}
      </div>`, 'state-shell');
  };

  /* ------------------------------------------------------------------ error
   * The distinction that matters: a failure NEVER renders a value.
   *
   * `kind` changes the copy, because the reader's next action differs:
   *   permission -> ask someone, do not retry
   *   network    -> retry will probably work
   *   server     -> retry may work, report it
   *   stale      -> do NOT retry; the data is old but real
   *   offline    -> reconnect
   */
  const KINDS = {
    permission: { title: 'You do not have access to this', body: 'This area is limited by your role. Ask an administrator if you need it.' },
    network: { title: 'Could not reach the server', body: 'The request did not complete. Check the connection and try again.' },
    server: { title: 'The server could not complete this', body: 'Something failed while loading this data. Try again, and report it if it continues.' },
    stale: { title: 'This data is out of date', body: 'It was loaded earlier and has not refreshed. The figures shown are the last known values.' },
    offline: { title: 'You are offline', body: 'This device has no connection, so live data cannot be fetched. Values shown are from the last sync.' },
  };

  // "Try again" is only offered when retrying is actually the right advice.
  const NO_RETRY = ['stale', 'permission', 'offline'];

  const error = (options = {}) => {
    const kind = KINDS[options.kind] ? options.kind : 'network';
    const copy = KINDS[kind];
    const title = options.title || copy.title;
    const body = options.body || copy.body;
    const retry = NO_RETRY.includes(kind)
      ? ''
      : `<button class="btn btn--secondary" type="button" data-state-action="retry">${icon('arrows-rotate')}Try again</button>`;

    return shell(`
      <div class="error-state" data-kind="${kind}">
        <p class="error-state__title">${escape(title)}</p>
        <p class="error-state__body">${escape(body)}</p>
        ${retry}
      </div>`, 'state-shell');
  };

  /* ------------------------------------------------------------------ ready */
  const ready = (content) => shell(content ?? '', 'state-shell');

  /**
   * Render an asynchronous region.
   *
   * The `error` branch is checked before anything else and never falls through
   * to a value, which is the entire point of this module.
   */
  const render = (state, payload, options = {}) => {
    switch (state) {
      case 'loading':
        return skeleton(options);
      case 'error':
        return error(isObject(payload) ? payload : { kind: options.kind });
      case 'empty':
        return empty(isObject(payload) ? payload : options);
      case 'ready':
        return ready(payload);
      default:
        // An unknown state is a programming error, not a value. Rendering an
        // empty region here would hide the mistake, so it is made visible.
        return error({
          kind: 'server',
          title: 'Could not display this section',
          body: `"${String(state)}" is not a known render state.`,
        });
    }
  };

  const isObject = (value) => typeof value === 'object' && value !== null;

  /** Decide the state from what actually came back. */
  const resolve = (payload) => {
    if (payload === null || payload === undefined) return 'error';
    if (Array.isArray(payload)) return payload.length === 0 ? 'empty' : 'ready';
    if (typeof payload === 'object') {
      for (const key of ['items', 'rows', 'results', 'data']) {
        if (Array.isArray(payload[key])) return payload[key].length === 0 ? 'empty' : 'ready';
      }
      return 'ready';
    }
    return 'ready';
  };

  (window.Mamore = window.Mamore || {}).states = { render, resolve, skeleton, empty, error, ready, KINDS };
})();

