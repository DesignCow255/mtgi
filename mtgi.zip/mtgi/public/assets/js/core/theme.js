// Mamore UI v2 — theme client.
//
// The theme is decided SERVER SIDE and shipped as <html data-theme="...">, so
// there is nothing to do on boot: the correct theme is already applied when
// this file runs, which is why there is no flash and no inline script (the
// Content-Security-Policy, script-src 'self', forbids one).
//
// This module only handles the operator CHANGING the theme: it updates the
// attribute immediately so the UI responds without a round trip, persists the
// choice, and keeps the server in agreement on the next request.
(() => {
  'use strict';

  const root = document.documentElement;
  const STORAGE_KEY = 'mamore.theme';
  const VALID = ['light', 'dark', 'system'];

  /** The theme currently rendered. */
  const current = () => root.getAttribute('data-theme') === 'dark' ? 'dark' : 'light';

  /** The stored preference, which may be "system". */
  const preference = () => {
    try {
      const value = window.localStorage.getItem(STORAGE_KEY);
      return VALID.includes(value) ? value : 'system';
    } catch (_) {
      // Private browsing and a blocked storage partition both throw here. The
      // server still has the cookie, so the theme keeps working; only the
      // client-side shortcut is unavailable.
      return 'system';
    }
  };

  /**
   * Apply a preference.
   *
   * `system` is resolved locally against the media query so the UI responds
   * immediately, and the OS is also watched so a system-wide theme change is
   * reflected while the app stays open.
   */
  const apply = (value) => {
    const next = VALID.includes(value) ? value : 'system';
    const resolved = next === 'system'
      ? (window.matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light')
      : next;

    root.setAttribute('data-theme', resolved);

    try {
      if (next === 'system') {
        window.localStorage.removeItem(STORAGE_KEY);
      } else {
        window.localStorage.setItem(STORAGE_KEY, next);
      }
    } catch (_) { /* Storage unavailable; the cookie set below still persists it. */ }

    // A same-origin POST keeps the SERVER cookie in step with the attribute.
    // The theme is a presentation preference, not a security decision, so a
    // failure here is not surfaced: the browser state is already correct and
    // the next navigation re-reads the cookie.
    fetch((document.querySelector('meta[name="mamore-base"]')?.content || '') + '/api/theme', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      credentials: 'same-origin',
      body: JSON.stringify({ theme: next })
    }).catch(() => { /* Offline or the route is unreachable; keep the local theme. */ });

    document.dispatchEvent(new CustomEvent('mamore:themechange', {
      detail: { theme: resolved, preference: next }
    }));
  };

  // Follow the OS while the preference is "system".
  const media = window.matchMedia('(prefers-color-scheme: dark)');
  const onSystemChange = () => { if (preference() === 'system') apply('system'); };
  if (typeof media.addEventListener === 'function') {
    media.addEventListener('change', onSystemChange);
  } else if (typeof media.addListener === 'function') {
    // Safari below 14 only has the deprecated MediaQueryList.addListener.
    media.addListener(onSystemChange);
  }

  // Keep every control on the page in step with the rendered theme. The
  // preference is what is marked as active, not the resolved theme: with
  // "system" selected the user must be able to see that they delegated the
  // choice, even though the page is currently rendering one concrete theme.
  const syncControls = () => {
    const preferred = preference();
    document.querySelectorAll('[data-theme-option]').forEach((button) => {
      const isActive = button.getAttribute('data-theme-option') === preferred;
      button.setAttribute('aria-checked', isActive ? 'true' : 'false');
      button.classList.toggle('is-active', isActive);
    });
  };

  // The visible control is a toggle button; the menu is the radio group. Opening
  // and closing is a plain show/hide driven from the same delegated listener, so
  // it keeps working for controls added to the page later.
  const menu = document.querySelector('[data-theme-menu]');

  const setMenu = (open) => {
    if (!menu) return;
    menu.hidden = !open;
    document.querySelectorAll('[data-theme-toggle]').forEach((button) => {
      button.setAttribute('aria-expanded', open ? 'true' : 'false');
    });
  };

  document.addEventListener('click', (event) => {
    const toggle = event.target.closest('[data-theme-toggle]');
    if (toggle) {
      event.preventDefault();
      setMenu(!menu || menu.hidden);
      return;
    }

    const option = event.target.closest('[data-theme-option]');
    if (option) {
      event.preventDefault();
      apply(option.getAttribute('data-theme-option'));
      syncControls();
      setMenu(false);
      // Return focus to the control that opened the menu, so keyboard and
      // screen-reader users are not dropped at the top of the document.
      document.querySelector('[data-theme-toggle]')?.focus();
      return;
    }

    if (menu && !menu.hidden && !event.target.closest('.theme-switcher')) {
      setMenu(false);
    }
  });

  // Esc closes the menu without applying anything, matching every other overlay.
  document.addEventListener('keydown', (event) => {
    if (event.key !== 'Escape' || !menu || menu.hidden) return;
    setMenu(false);
    document.querySelector('[data-theme-toggle]')?.focus();
  });

  // Arrow keys move between options, per the radiogroup pattern.
  document.addEventListener('keydown', (event) => {
    if (!menu || menu.hidden) return;
    const keys = ['ArrowDown', 'ArrowUp', 'ArrowLeft', 'ArrowRight'];
    if (!keys.includes(event.key)) return;
    const options = [...menu.querySelectorAll('[data-theme-option]')];
    const currentIndex = options.indexOf(document.activeElement);
    if (currentIndex < 0) return;
    event.preventDefault();
    const step = (event.key === 'ArrowDown' || event.key === 'ArrowRight') ? 1 : -1;
    options[(currentIndex + step + options.length) % options.length].focus();
  });

  root.setAttribute('data-theme-preference', preference());
  document.addEventListener('mamore:ready', syncControls);
  if (document.readyState !== 'loading') syncControls();
  syncControls();

  (window.Mamore = window.Mamore || {}).theme = { current, preference, apply };
})();
