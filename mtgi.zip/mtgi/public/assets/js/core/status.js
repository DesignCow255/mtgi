// Mamore UI v2 — status.
//
// ONE lookup table maps a domain value to a tone. No page picks a colour, and
// no page writes a raw status string: the stored value is a CODE ("IN_TRANSIT"),
// the label comes from the i18n catalogue (Phase 10), and the tone comes from
// here. That is what makes "ACTIVE", "ONLINE" and "READY" look and read the
// same on every screen.
//
// This module also replaces the nine hard-coded "Live" badges the audit found.
// Freshness is derived from a timestamp, never asserted by markup -- see
// Mamore.status.freshness below.
(() => {
  'use strict';

  /*
   * Domain value -> tone.
   *
   * Grouped by meaning, not alphabetically, so the intent stays reviewable.
   * Anything absent falls through to `unknown`, which renders the raw value in
   * a neutral pill: a status added to the backend later degrades readably
   * instead of disappearing.
   */
  const TONES = {
    // Healthy / normal / complete
    ONLINE: 'success', ACTIVE: 'success', READY: 'success', AVAILABLE: 'success',
    COVERED: 'success', COMPLETED: 'success', COMPLETE: 'success', PAID: 'success',
    SETTLED: 'success', RESOLVED: 'success', CLOSED: 'success', VERIFIED: 'success',
    APPROVED: 'success', DELIVERED: 'success', BOARDED: 'success', CONFIRMED: 'success',
    OK: 'success', HEALTHY: 'success', NORMAL: 'success', SUCCESS: 'success',
    OPERATIONAL: 'success', RECOVERED: 'success', DELIVERING: 'success',

    // In progress / working
    IN_TRANSIT: 'info', DISPATCHED: 'info', EN_ROUTE: 'info', SCHEDULED: 'info',
    BOARDING: 'info', PROCESSING: 'info', PENDING: 'info', IN_PROGRESS: 'info',
    RUNNING: 'info', DEPARTED: 'info', ACKNOWLEDGED: 'info', IN_TRANSACTION: 'info',
    ASSIGNED: 'info',

    // Needs attention but not broken
    DELAYED: 'warning', STALE: 'warning', DEGRADED: 'warning', DEGRADING: 'warning',
    EXPIRING: 'warning', PENDING_PAYMENT: 'warning', PARTIAL: 'warning',
    MAINTENANCE: 'warning', OFF_ROUTE: 'warning', DELAY: 'warning', LOW: 'warning',
    // Severity values double as standalone status (incident priority, alert
    // severity), so they are mapped here rather than through a second severity
    // path that could drift out of step with this one.
    MEDIUM: 'warning', HIGH: 'danger',

    // Subscriptions
    RENEWED: 'success', PENDING_ACTIVATION: 'info',

    // Broken / blocking
    CRITICAL: 'danger', FAILED: 'danger', EXPIRED: 'danger', SUSPENDED: 'danger',
    CANCELLED: 'danger', DECLINED: 'danger', VOID: 'danger', BREACH: 'danger',
    OFFLINE: 'danger', DOWN: 'danger', EMERGENCY: 'danger', OVERDUE: 'danger',
    UNPAID: 'danger', ESCALATED: 'danger', LOCKED: 'danger', BLOCKED: 'danger',

  /**
   * Build a status pill.
   *
   * `label` is passed in rather than looked up here, because translating it is
   * the i18n service's job (Phase 10) and this module must not depend on the
   * locale. Callers today pass the raw value; after Phase 10 they pass
   * t('status.' + value).
   */
  const pill = (value, options = {}) => {
    const normalised = normalise(value);
    const resolved = tone(normalised);
    const label = options.label ?? normalised.replace(/_/g, ' ');
    const icon = options.icon ?? '';
    const classes = ['pill', `pill--${resolved}`];

    if (options.className) classes.push(options.className);

    const glyph = icon ? `<i class="fa-solid fa-${icon}" aria-hidden="true"></i>` : '';

    // Tone is never the only signal: the label is always visible, and the
    // optional glyph is aria-hidden so it is not announced twice (WCAG 1.4.1).
    return `<span class="${classes.join(' ')}">${glyph}${Mamore.escapeHtml(label)}</span>`;
  };

  /* ------------------------------------------------------------- freshness
   * The replacement for nine hard-coded "Live" badges. Freshness is computed
   * from a real timestamp and the age is always shown, so an eight-minute-old
   * GPS reading can never present itself as current.
   *
   * Thresholds are per-domain and declared ONCE here rather than guessed per
   * screen. GPS goes stale in minutes; a daily revenue figure does not.
   */
  const FRESHNESS = {
    // Seconds. `stale` is the point at which presenting the value as live
    // would be misleading rather than merely out of date.
    live: 45,
    delayed: 300,
    stale: 900,
  };

  const FRESHNESS_BY_DOMAIN = {
    tracking: { live: 45, delayed: 180, stale: 600 },
    rescue: { live: 30, delayed: 120, stale: 600 },
    exchange_rate: { live: 900, delayed: 3600, stale: 86400 },
    finance: { live: 300, delayed: 1800, stale: 86400 },
    default: FRESHNESS,
  };

  const secondsSince = (timestamp, now) => {
    if (!timestamp) return Infinity;
    const parsed = timestamp instanceof Date ? timestamp : new Date(String(timestamp).replace(' ', 'T'));
    const value = parsed.getTime();
    if (Number.isNaN(value)) return Infinity;
    return Math.max(0, Math.floor((now - value) / 1000));
  };

  /** 'live' | 'delayed' | 'stale' | 'offline' | 'unknown' */
  const freshnessState = (timestamp, domain = 'default', now = Date.now()) => {
    const age = secondsSince(timestamp, now);
    if (!Number.isFinite(age)) return 'unknown';
    const limits = FRESHNESS_BY_DOMAIN[domain] || FRESHNESS;
    if (age <= limits.live) return 'live';
    if (age <= limits.delayed) return 'delayed';
    return 'stale';
  };

  /** A short human age: "now", "42 sec ago", "8 min ago", "3 h ago", "2 d ago". */
  const relativeAge = (timestamp, now = Date.now()) => {
    const age = secondsSince(timestamp, now);
    if (!Number.isFinite(age)) return 'unknown';
    if (age < 10) return 'now';
    if (age < 60) return `${age} sec ago`;
    const minutes = Math.floor(age / 60);
    if (minutes < 60) return `${minutes} min ago`;
    const hours = Math.floor(minutes / 60);
    if (hours < 24) return `${hours} h ago`;
    return `${Math.floor(hours / 24)} d ago`;
  };

  /** A freshness indicator. Never claims "Live" without a timestamp to prove it. */
  const freshness = (timestamp, options = {}) => {
    const state = freshnessState(timestamp, options.domain || 'default');
    const label = relativeAge(timestamp);
    const text = state === 'live' ? `Live · ${label}` : label;
    const classes = ['freshness'];

    if (options.className) classes.push(options.className);

    return `<span class="${classes.join(' ')}" data-state="${state}" title="${Mamore.escapeHtml(text)}">${Mamore.escapeHtml(text)}</span>`;
  };

  const api = {
    TONES, tone, pill, normalise,
    freshness, freshnessState, relativeAge,
    FRESHNESS, FRESHNESS_BY_DOMAIN,
  };
  (window.Mamore = window.Mamore || {}).status = api;
})();


    // Neutral / not applicable
    NO_DEVICE: 'neutral', NO_POSITION: 'neutral', NOT_APPLICABLE: 'neutral',
    DRAFT: 'neutral', IDLE: 'neutral', INACTIVE: 'neutral', DISABLED: 'neutral',
    ARCHIVED: 'neutral', UNKNOWN: 'neutral', NONE: 'neutral', PLANNED: 'neutral',
  };

  /** A status the lookup does not know, normalised for display. */
  const normalise = (value) => String(value ?? '').trim().toUpperCase().replace(/[\s-]+/g, '_');

  const tone = (value) => TONES[normalise(value)] || 'unknown';
