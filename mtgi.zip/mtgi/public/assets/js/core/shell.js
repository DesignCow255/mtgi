// Mamore UI v2 — shell: navigation, breadcrumbs, page context, sidebar state.
//
// The navigation is DATA, fetched from /api/navigation, because the server is
// the only thing that knows what this user may do. The previous shell hard-coded
// eighteen entries in app.html and showed all of them to any non-customer role,
// so a conductor saw the whole operations platform. Now the server returns only
// the destinations that role can actually open, and this module renders them.
//
// This is presentation, not security: every route still enforces its own
// permission. Hiding a destination the server would reject is a usability
// decision; refusing the action is the service layer's job, and it is unchanged.
(() => {
  'use strict';

  const SIDEBAR_KEY = 'mamore.sidebar';
  const DENSITY_KEY = 'mamore.density';

  const el = (selector) => document.querySelector(selector);
  const icon = (name) => `<i class="fa-solid fa-${name}" aria-hidden="true"></i>`;
  const escape = (value) => String(value ?? '').replace(/[&<>"']/g, (character) => ({
    '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;',
  })[character]);

  /* -------------------------------------------------------------- rendering */

  const renderGroups = (groups) => groups.map((group) => `
    <div class="nav-group" role="group" aria-labelledby="nav-group-${group.key}">
      <p class="nav-group__label" id="nav-group-${group.key}">${escape(group.label)}</p>
      <ul class="nav-group__list">
        ${group.items.map((item) => `
          <li>
            <button class="nav-item" type="button" data-panel="${escape(item.panel)}" title="${escape(item.label)}">
              ${icon(item.icon)}
              <span class="nav-item__label">${escape(item.label)}</span>
            </button>
          </li>`).join('')}
      </ul>
    </div>`).join('');

  /** Render the sidebar navigation into its mount point. */
  const render = (navigation) => {
    const mount = el('[data-nav-mount]');
    if (!mount) return;

    // A user with no permitted destinations gets an explanation rather than an
    // empty column, which would look like a broken product.
    const hasAny = navigation.groups.some((group) => group.items.length > 0);
    mount.innerHTML = hasAny
      ? renderGroups(navigation.groups)
      : '<p class="nav-empty">No sections are available for your role. Contact an administrator.</p>';

    Mamore.labels = navigation.panels;
    Mamore.allowedPanels = Object.keys(navigation.panels);
    Mamore.domains = navigation.domains;
  };

  /* ------------------------------------------------------------- URL state
   * switchPanel historically mutated nothing, so nothing was linkable, nothing
   * survived a refresh, and the browser back button walked out of the app. The
   * panel now lives in the query string. Only the panel is added -- search and
   * filter state is Phase 13 (tables/forms), so this stays a small, honest step
   * rather than a half-built router. */
  const panelFromUrl = () => {
    const value = new URLSearchParams(window.location.search).get('panel');
    return typeof value === 'string' && value !== '' ? value : null;
  };

  const writeUrl = (panel) => {
    const url = new URL(window.location.href);
    if (panel) url.searchParams.set('panel', panel);
    else url.searchParams.delete('panel');
    // replaceState, not pushState: a back button full of panel switches is
    // worse than none at all.
    window.history.replaceState({ panel }, '', url);
  };

  const onPopState = (handler) => {
    window.addEventListener('popstate', () => {
      const panel = panelFromUrl();
      if (panel && handler) handler(panel);
    });
  };

  /* ------------------------------------------------------------ breadcrumbs
   * Shown only on deep operational paths. A breadcrumb on "Home" would be noise,
   * so the home panel renders none. */
  const renderBreadcrumb = (groupLabel, panelLabel) => {
    const mount = el('[data-breadcrumb-mount]');
    if (!mount) return;

    if (!panelLabel || panelLabel === 'Home') {
      mount.innerHTML = '';
      mount.hidden = true;
      return;
    }

    mount.hidden = false;
    mount.innerHTML = `
      <nav class="breadcrumb" aria-label="Breadcrumb">
        <ol>
          <li><span class="breadcrumb__root">Mamore</span></li>
          ${groupLabel ? `<li><span>${escape(groupLabel)}</span></li>` : ''}
          <li><span aria-current="page">${escape(panelLabel)}</span></li>
        </ol>
      </nav>`;
  };

  /* --------------------------------------------------------- sidebar state
   * Collapsed is a preference, not a transient: an operator who works in the
   * collapsed rail should not have to collapse it on every page load. */
  const sidebarPreference = () => {
    try {
      const value = window.localStorage.getItem(SIDEBAR_KEY);
      return value === 'collapsed' || value === 'expanded' ? value : 'expanded';
    } catch (_) {
      return 'expanded';
    }
  };

  const applySidebar = (state) => {
    const shell = el('.shell');
    if (!shell) return;
    const collapsed = state === 'collapsed';
    shell.setAttribute('data-sidebar', collapsed ? 'collapsed' : 'expanded');

    const toggle = el('[data-sidebar-toggle]');
    if (toggle) {
      toggle.setAttribute('aria-expanded', collapsed ? 'false' : 'true');
      toggle.setAttribute('aria-label', collapsed ? 'Expand navigation' : 'Collapse navigation');
    }

    // In the collapsed rail the label is hidden by CSS, which would leave an
    // unlabelled button. The text is copied to aria-label so the control keeps
    // its accessible name at every width, not just the wide one.
    document.querySelectorAll('.nav-item').forEach((item) => {
      const text = item.querySelector('.nav-item__label')?.textContent?.trim();
      if (text) item.setAttribute('aria-label', text);
    });
  };

  const toggleSidebar = () => {
    const next = sidebarPreference() === 'collapsed' ? 'expanded' : 'collapsed';
    try { window.localStorage.setItem(SIDEBAR_KEY, next); } catch (_) { /* storage blocked */ }
    applySidebar(next);
    closeDrawer();
  };

  /* -------------------------------------------------------- mobile drawer */
  const openDrawer = () => {
    el('.shell')?.setAttribute('data-drawer', 'open');
    el('[data-drawer-toggle]')?.setAttribute('aria-expanded', 'true');
    document.body.classList.add('is-drawer-open');
  };

  const closeDrawer = () => {
    el('.shell')?.setAttribute('data-drawer', 'closed');
    el('[data-drawer-toggle]')?.setAttribute('aria-expanded', 'false');
    document.body.classList.remove('is-drawer-open');
  };

  /* ------------------------------------------------------------- density */
  const applyDensity = (value) => {
    const mode = value === 'compact' ? 'compact' : 'comfortable';
    document.body.setAttribute('data-density', mode);
    try { window.localStorage.setItem(DENSITY_KEY, mode); } catch (_) { /* storage blocked */ }
  };

  const densityPreference = () => {
    try { return window.localStorage.getItem(DENSITY_KEY) === 'compact' ? 'compact' : 'comfortable'; }
    catch (_) { return 'comfortable'; }
  };

  /* ------------------------------------------------------------- currency
   * The display currency is a PRESENTATION choice. Choosing one re-renders the
   * figures already on the page and writes a preference; it never touches a
   * payment, a receipt or the ledger, and the server is told so explicitly. */
  const currencyMenu = document.querySelector('[data-currency-menu]');

  const setCurrencyMenu = (open) => {
    if (!currencyMenu) return;
    currencyMenu.hidden = !open;
    document.querySelectorAll('[data-currency-toggle]').forEach((button) => {
      button.setAttribute('aria-expanded', open ? 'true' : 'false');
    });
  };

  const syncCurrency = () => {
    if (!window.Mamore || !Mamore.currency) return;
    const current = Mamore.currency.display;
    const status = Mamore.currency.status;

    document.querySelectorAll('[data-currency-code]').forEach((node) => { node.textContent = current; });
    document.querySelectorAll('[data-currency-option]').forEach((button) => {
      const isActive = button.getAttribute('data-currency-option') === current;
      button.setAttribute('aria-checked', isActive ? 'true' : 'false');
      button.classList.toggle('is-active', isActive);
    });

    const holder = document.querySelector('[data-currency-switcher]');
    if (holder) holder.setAttribute('data-rate-status', status);

    // The rate line says which rate is in play AND how much to trust it. A rate
    // that is not LIVE is named as such, because a converted figure shown with
    // the same confidence as a fresh one is a quiet lie.
    const line = document.querySelector('[data-currency-rate]');
    if (line) {
      if (status === 'unavailable') {
        line.textContent = 'No rate available — figures are shown in their original currency.';
      } else {
        const rate = Mamore.currency.rates['USD/' + current];
        const amount = rate === undefined ? '' : '1 USD = ' + Number(rate).toLocaleString('en-US', { maximumFractionDigits: 2 }) + ' ' + current;
        line.textContent = (amount ? amount + ' · ' : '') + (status === 'live' ? 'Live' : status.charAt(0).toUpperCase() + status.slice(1));
      }
    }
  };

  document.addEventListener('click', (event) => {
    const toggle = event.target.closest('[data-currency-toggle]');
    if (toggle) {
      event.preventDefault();
      setCurrencyMenu(!(currencyMenu && !currencyMenu.hidden));
      syncCurrency();
      return;
    }

    const option = event.target.closest('[data-currency-option]');
    if (option) {
      event.preventDefault();
      const wanted = option.getAttribute('data-currency-option');
      setCurrencyMenu(false);
      document.querySelector('[data-currency-toggle]')?.focus();

      const base = (document.querySelector('meta[name="mamore-base"]')?.content || '').replace(/\/$/, '');
      fetch(base + '/api/currency', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        credentials: 'same-origin',
        body: JSON.stringify({ display: wanted })
      }).catch(() => { /* offline: the client formatter still applies locally */ })
        .finally(() => {
          if (window.Mamore && Mamore.currency) {
            Mamore.currency.load(wanted).then(syncCurrency);
          }
        });
      return;
    }

    if (currencyMenu && !currencyMenu.hidden && !event.target.closest('.currency-switcher')) {
      setCurrencyMenu(false);
    }
  });

  document.addEventListener('mamore:currencychange', syncCurrency);
  if (document.readyState !== 'loading') syncCurrency();

  // Open/close the locale menu, and mark the active language.
  const localeMenu = document.querySelector('[data-locale-menu]');

  const setLocaleMenu = (open) => {
    if (!localeMenu) return;
    localeMenu.hidden = !open;
    document.querySelectorAll('[data-locale-toggle]').forEach((button) => {
      button.setAttribute('aria-expanded', open ? 'true' : 'false');
    });
  };

  const syncLocale = () => {
    const current = (window.Mamore && Mamore.i18n) ? Mamore.i18n.locale : 'en';
    document.querySelectorAll('[data-locale-option]').forEach((button) => {
      const isActive = button.getAttribute('data-locale-option') === current;
      button.setAttribute('aria-checked', isActive ? 'true' : 'false');
      button.classList.toggle('is-active', isActive);
    });
  };

  /* ------------------------------------------------------------- wiring */
  document.addEventListener('click', (event) => {
    if (event.target.closest('[data-sidebar-toggle]')) { event.preventDefault(); toggleSidebar(); return; }
    if (event.target.closest('[data-drawer-toggle]')) { event.preventDefault(); openDrawer(); return; }
    if (event.target.closest('[data-drawer-close]')) { event.preventDefault(); closeDrawer(); return; }
    if (event.target.closest('[data-density-toggle]')) {
      event.preventDefault();
      applyDensity(densityPreference() === 'compact' ? 'comfortable' : 'compact');
      return;
    }

    const localeToggle = event.target.closest('[data-locale-toggle]');
    if (localeToggle) {
      event.preventDefault();
      setLocaleMenu(!(localeMenu && !localeMenu.hidden));
      syncLocale();
      return;
    }

    const option = event.target.closest('[data-locale-option]');
    if (option) {
      event.preventDefault();
      const wanted = option.getAttribute('data-locale-option');
      setLocaleMenu(false);
      document.querySelector('[data-locale-toggle]')?.focus();

      // Persist on the server FIRST: navigation labels are resolved there, so
      // the sidebar only comes back translated once the session locale is set.
      const base = (document.querySelector('meta[name="mamore-base"]')?.content || '').replace(/\/$/, '');
      fetch(base + '/api/i18n', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        credentials: 'same-origin',
        body: JSON.stringify({ locale: wanted })
      }).catch(() => { /* offline: the client catalogue still applies */ })
        .finally(() => {
          if (window.Mamore && Mamore.i18n) {
            Mamore.i18n.load(wanted).then(() => {
              syncLocale();
              // Ask the app to re-render navigation so its labels match.
              document.dispatchEvent(new CustomEvent('mamore:reloadnavigation'));
            });
          }
        });
      return;
    }

    if (localeMenu && !localeMenu.hidden && !event.target.closest('.locale-switcher')) {
      setLocaleMenu(false);
    }
  });

  document.addEventListener('keydown', (event) => {
    if (event.key !== 'Escape') return;
    // Esc closes only the topmost overlay: the locale menu if that is open,
    // otherwise the drawer. Closing both at once would be disorienting.
    if (localeMenu && !localeMenu.hidden) {
      setLocaleMenu(false);
      document.querySelector('[data-locale-toggle]')?.focus();
      return;
    }
    closeDrawer();
  });

  document.addEventListener('mamore:localechange', syncLocale);
  if (document.readyState !== 'loading') syncLocale();

  // Apply persisted state immediately, so the shell never renders in the wrong
  // state and then corrects itself on the next frame.
  applySidebar(sidebarPreference());
  applyDensity(densityPreference());

  (window.Mamore = window.Mamore || {}).shell = {
    render,
    renderBreadcrumb,
    applySidebar,
    applyDensity,
    openDrawer,
    closeDrawer,
    panelFromUrl,
    writeUrl,
    onPopState,
    SIDEBAR_KEY,
    DENSITY_KEY,
  };
})();
