// Mamore UI v2 — client i18n.
//
// The server ships the whole catalogue for the ACTIVE locale (GET /api/i18n),
// so this module never guesses and never falls back to an English string the
// user should not be reading. It is the same lookup the server performs, not a
// second vocabulary.
//
// `data-i18n` gives a no-JS baseline and lets the shell re-render on a locale
// change without a page load; `data-i18n-attr` does the same for an attribute,
// which is how aria-label and placeholder are translated.
(() => {
  'use strict';

  const STORAGE_KEY = 'mamore.locale';
  const VALID = ['en', 'fr', 'sw'];

  let messages = {};
  let locale = 'en';
  let fallback = 'en';
  let available = ['en'];
  const missing = new Set();

  const el = (selector) => document.querySelector(selector);

  /** Translate a key. Missing keys return the key, exactly as the server does. */
  const t = (key, replace) => {
    let value = messages[key];

    if (value === undefined) {
      missing.add(key);
      // The catalogue always arrives topped up from English, so reaching this
      // branch means a genuine gap rather than an untranslated locale. Returning
      // the key makes it visible; tests/ui-v2-core-test.php fails on any use.
      return key;
    }

    if (replace) {
      Object.entries(replace).forEach(([token, replacement]) => {
        value = value.split('{' + token + '}').join(String(replacement));
      });
    }

    return value;
  };

  const choice = (key, count, replace) => {
    const entry = messages[key];
    if (entry === undefined) {
      missing.add(key);
      return key;
    }
    const form = count === 1 ? (entry.one ?? entry.other) : (entry.other ?? entry.one);
    return t0(String(form).replace('{count}', String(count)), replace);
  };

  // t() with an already-resolved string, used by choice() to apply replacements
  // to a form rather than re-entering the lookup.
  const t0 = (value, replace) => {
    if (!replace) return value;
    return Object.entries(replace).reduce(
      (acc, [token, replacement]) => acc.split('{' + token + '}').join(String(replacement)),
      value
    );
  };

  /**
   * Apply the catalogue to the document.
   *
   * Elements opt in with data-i18n, so this is safe to call on any page and
   * never has to know what is on it.
   */
  const apply = () => {
    document.documentElement.setAttribute('lang', locale);
    document.documentElement.setAttribute('data-locale', locale);

    document.querySelectorAll('[data-i18n]').forEach((node) => {
      const key = node.getAttribute('data-i18n');
      const translated = t(key);
      // Never write a raw key into the document: if the key is missing, the
      // original server-rendered text is better than "navigation.home".
      if (translated !== key) node.textContent = translated;
    });

    document.querySelectorAll('[data-i18n-attr]').forEach((node) => {
      node.getAttribute('data-i18n-attr').split('|').forEach((pair) => {
        const [attribute, key] = pair.split(':').map((part) => part.trim());
        if (!attribute || !key) return;
        const translated = t(key);
        if (translated !== key) node.setAttribute(attribute, translated);
      });
    });
  };

  /** Load the catalogue for a locale and adopt it. */
  const load = async (requested) => {
    const base = (document.querySelector('meta[name="mamore-base"]')?.content || '').replace(/\/$/, '');

    try {
      const response = await fetch(base + '/api/i18n?lang=' + encodeURIComponent(requested), {
        credentials: 'same-origin',
      });
      const payload = await response.json();
      if (!response.ok) throw new Error(payload.error || 'Could not load translations.');

      messages = payload.messages || {};
      locale = payload.locale || 'en';
      fallback = payload.fallback || 'en';
      available = payload.available || ['en'];

      try { window.localStorage.setItem(STORAGE_KEY, locale); } catch (_) { /* storage blocked */ }
      apply();
      document.dispatchEvent(new CustomEvent('mamore:localechange', { detail: { locale, fallback } }));
      return locale;
    } catch (error) {
      // A failed translation load must not break the application: the
      // server-rendered English is already on screen and stays there.
      return null;
    }
  };

  const preferred = () => {
    try {
      const value = window.localStorage.getItem(STORAGE_KEY);
      return VALID.includes(value) ? value : null;
    } catch (_) {
      return null;
    }
  };

  document.addEventListener('click', (event) => {
    const button = event.target.closest('[data-locale-option]');
    if (!button) return;
    event.preventDefault();
    load(button.getAttribute('data-locale-option'));
  });

  (window.Mamore = window.Mamore || {}).i18n = {
    t, choice, apply, load, preferred, STORAGE_KEY,
    get locale() { return locale; },
    get fallback() { return fallback; },
    get available() { return available; },
    get missing() { return [...missing]; },
  };
})();
