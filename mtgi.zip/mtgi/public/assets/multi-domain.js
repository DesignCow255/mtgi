/**
 * Multi-domain operational surfaces.
 *
 * One design system, four domains. Each panel shows what its operational model
 * actually needs - a truck board is about cargo and crew, a VIP board about
 * cover and codes - rather than four copies of the same dashboard. Nothing here
 * computes a business rule: every figure arrives from the API, and an empty
 * source renders "No data available" rather than a zero.
 */
(() => {
  'use strict';

  const $ = (selector) => document.querySelector(selector);
  const bind = () => window.Mamore || null;

  // escapeHtml and toast belong to app.js and are published on window.Mamore.
  // This module is loaded separately and calls them directly, so the only safe
  // way to reference them is to resolve them off the shared shell at call time.
  // Binding them as fixed constants at load is not an option: this file can be
  // evaluated before app.js has assigned them, which would capture undefined.
  const escapeHtml = (value) => {
    const shell = bind();
    if (shell && typeof shell.escapeHtml === 'function') {
      return shell.escapeHtml(value);
    }
    // Fall back to the same neutralisation app.js performs, so a value is never
    // interpolated raw even if the shell is not available yet.
    return String(value ?? '').replace(/[&<>"']/g, (character) => (
      { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[character]
    ));
  };

  const notify = (message) => {
    const shell = bind();
    if (shell && typeof shell.toast === 'function') {
      shell.toast(message);
    }
  };

  /**
   * Cargo WEIGHT, not money.
   *
   * This function was called `asMoney` and was used to print cargo weight in
   * kilograms, which meant a 12,500 kg load rendered as "12500.00" with no unit
   * and two decimal places nobody in freight cares about. A weight is not money:
   * it has no currency and no conversion, so it now goes through the unit
   * formatter and carries its unit.
   */
  const asWeight = (value) => {
    const shell = window.Mamore || null;
    if (shell?.currency) return shell.currency.kilograms(value);
    const number = Number(value || 0);
    return `${number.toLocaleString('en-US', { maximumFractionDigits: 0 })} kg`;
  };

  const kpiRow = (pairs) => `<div class="domain-kpis">${pairs
    .map(([label, value]) => `<div><span>${escapeHtml(label)}</span><strong>${escapeHtml(String(value ?? '—'))}</strong></div>`)
    .join('')}</div>`;

  const emptyOr = (message, html) => (message ? `<p class="empty">${escapeHtml(message)}</p>` : html);

  /** Badge set driven only by what the API proved. */
  const statusPill = (status) => {
    const tone = { ONLINE: 'ok', ACTIVE: 'ok', READY: 'ok', COVERED: 'ok', AVAILABLE: 'ok',
      OFFLINE: 'bad', CRITICAL: 'bad', EXPIRED: 'bad', SUSPENDED: 'bad', CANCELLED: 'bad',
      NO_DEVICE: 'wait', NO_POSITION: 'wait', UNKNOWN: 'wait', DEGRADED: 'wait' }[status] || 'wait';
    return `<span class="pill pill-${tone}">${escapeHtml(String(status || 'UNKNOWN'))}</span>`;
  };

  const domainSwitcher = (current, available) => `<div class="domain-switch" role="tablist" aria-label="Operational domain">
    ${['ALL', ...available].map((domain) => `
      <button role="tab" aria-selected="${domain === current}" class="domain-tab${domain === current ? ' active' : ''}"
              data-domain="${escapeHtml(domain)}" type="button">${escapeHtml(domain.replace(/_/g, ' '))}</button>`).join('')}
  </div>`;

  const assetCard = (asset) => `<article class="domain-asset">
    <div class="domain-asset-head">
      <div><h3>${escapeHtml(asset.label || asset.code || 'Asset')}</h3>
        <p class="muted">${escapeHtml([asset.assetType, asset.registrationNumber].filter(Boolean).join(' · '))}</p></div>
      ${statusPill(asset.trackingStatus)}
    </div>
    <dl class="trip-facts">
      <div><dt>Domain</dt><dd>${escapeHtml(String(asset.domain || 'UNASSIGNED').replace(/_/g, ' '))}</dd></div>
      <div><dt>Device</dt><dd>${asset.hasDevice ? 'Fitted' : 'None'}</dd></div>
      <div><dt>Position</dt><dd>${asset.latitude === null || asset.latitude === undefined
        ? 'No position'
        : `${escapeHtml(String(asset.latitude))}, ${escapeHtml(String(asset.longitude))}`}</dd></div>
      <div><dt>Speed</dt><dd>${asset.speedKph === null || asset.speedKph === undefined ? '—' : `${escapeHtml(String(asset.speedKph))} km/h`}</dd></div>
    </dl>
  </article>`;

  const incidentCard = (incident) => `<article class="domain-incident severity-${escapeHtml(String(incident.severity || '').toLowerCase())}">
    <div class="domain-asset-head">
      <div><h3>${escapeHtml(incident.code)}</h3><p class="muted">${escapeHtml(incident.description || '')}</p></div>
      <div>${statusPill(incident.severity)}</div>
    </div>
    <dl class="trip-facts">
      <div><dt>Domain</dt><dd>${escapeHtml(String(incident.domain).replace(/_/g, ' '))}</dd></div>
      <div><dt>Type</dt><dd>${escapeHtml(String(incident.type || 'Unclassified'))}</dd></div>
      <div><dt>Status</dt><dd>${escapeHtml(incident.status)}</dd></div>
      <div><dt>Position</dt><dd>${incident.hasPosition ? 'Known' : 'Unknown'}</dd></div>
      <div><dt>Unit</dt><dd>${escapeHtml(incident.assignedUnit || 'Unassigned')}</dd></div>
    </dl>
  </article>`;

  const alertRow = (alert) => `<li class="domain-alert">
    ${statusPill(alert.severity)} <strong>${escapeHtml(alert.code.replace(/_/g, ' '))}</strong>
    <span class="muted">${escapeHtml(alert.message || '')}</span>
    <small>${escapeHtml(alert.status)} · ${escapeHtml(alert.openedAt || '')}</small>
  </li>`;

  const renderOperations = (data) => `
    ${domainSwitcher(data.domain, data.availableDomains || [])}
    ${kpiRow([
      ['Tracked assets', data.kpis.trackedAssets],
      ['Buses', data.kpis.activeBuses],
      ['Trucks', data.kpis.activeTrucks],
      ['Private vehicles', data.kpis.activePrivateVehicles],
      ['Rescue units available', data.kpis.rescueVehiclesAvailable],
      ['Open incidents', data.kpis.openIncidents],
      ['Critical', data.kpis.criticalIncidents],
      ['GPS offline', data.kpis.gpsOffline],
      ['Open alerts', data.kpis.openAlerts],
    ])}
    ${data.message ? `<p class="empty">${escapeHtml(data.message)}</p>` : ''}
    <div class="domain-columns">
      <section class="data-section">
        <div class="section-heading compact"><div><p class="eyebrow">Live map data</p><h2>Assets</h2></div></div>
        <div class="domain-list">${data.assets.length ? data.assets.map(assetCard).join('') : '<p class="empty">No assets for this domain.</p>'}</div>
      </section>
      <section class="data-section">
        <div class="section-heading compact"><div><p class="eyebrow">Response</p><h2>Incidents and alerts</h2></div></div>
        <div class="domain-list">${data.incidents.length ? data.incidents.map(incidentCard).join('') : '<p class="empty">No open incidents.</p>'}</div>
        <h3 class="domain-subhead">Alerts</h3>
        <ul class="domain-alerts">${data.alerts.length ? data.alerts.map(alertRow).join('') : '<li class="empty">No open alerts.</li>'}</ul>
      </section>
    </div>`;

  const renderAnalytics = (data) => {
    const groups = (title, rows) => `<div class="domain-kpi-block">
      <h3>${escapeHtml(title)}</h3>
      ${rows && rows.length
        ? `<ul class="domain-bars">${rows.map((row) => `<li><span>${escapeHtml(row.label)}</span>
            <i style="--bar:${Math.min(100, row.total)}%"></i><strong>${escapeHtml(String(row.total))}</strong></li>`).join('')}</ul>`
        : '<p class="empty">No data available.</p>'}
    </div>`;
    return `<div class="domain-columns">
      <section>${groups('Assets by domain', data.assetsByDomain)}${groups('Assets by type', data.assetsByType)}</section>
      <section>${groups('Incidents by domain', data.incidentsByDomain)}${groups('Incidents by severity', data.incidentsBySeverity)}</section>
      <section>
        ${kpiRow([
          ['People in movement (bus)', data.peopleInMovement.smartBusPassengers],
          ['Truck crew', data.peopleInMovement.truckCrew],
          ['Private occupants', data.peopleInMovement.privateOccupants],
          ['Consignments in motion', data.cargoInMotion.consignments],
          ['Cargo in motion', asWeight(data.cargoInMotion.weightKg)],
          ['Hazardous loads', data.cargoInMotion.hazardous],
        ])}
        ${kpiRow([
          ['Tracking online', data.trackingHealth.online],
          ['Delayed signal', data.trackingHealth.delayedSignal],
          ['Offline', data.trackingHealth.offline],
          ['No device', data.trackingHealth.noDevice],
        ])}
        <p class="muted">Average dispatch ${data.response.avgDispatchMinutes === null ? 'no data' : `${data.response.avgDispatchMinutes} min`}
          · average on scene ${data.response.avgArriveMinutes === null ? 'no data' : `${data.response.avgArriveMinutes} min`}</p>
      </section>
    </div>`;
  };

  const renderVip = (data) => `
    ${kpiRow([
      ['VIPs', data.metrics.total], ['Active', data.metrics.active], ['Pending', data.metrics.pending],
      ['Expiring soon', data.metrics.expiringSoon], ['Covered', data.metrics.covered],
      ['Covered vehicles', data.metrics.coveredVehicles], ['Active journeys', data.metrics.activeJourneys],
      ['Open incidents', data.metrics.incidents],
    ])}
    ${data.message ? `<p class="empty">${escapeHtml(data.message)}</p>` : ''}
    <div class="domain-columns">
      ${groupsBlock('By plan', data.byPlan)}${groupsBlock('By status', data.byStatus)}
      ${groupsBlock('By type', data.byType)}${groupsBlock('By geography', data.byGeography)}
    </div>`;

  const groupsBlock = (title, rows) => `<div class="domain-kpi-block">
    <h3>${escapeHtml(title)}</h3>
    ${rows && rows.length
      ? `<ul class="domain-bars">${rows.map((row) => `<li><span>${escapeHtml(row.label)}</span><strong>${escapeHtml(String(row.total))}</strong></li>`).join('')}</ul>`
      : '<p class="empty">No data available.</p>'}
  </div>`;

  const renderPrivate = (data) => `
    ${kpiRow([
      ['Vehicles', data.metrics.vehicles], ['Covered', data.metrics.covered],
      ['Tracking online', data.metrics.trackingOnline], ['Open journeys', data.metrics.openJourneys],
      ['Active incidents', data.metrics.activeIncidents],
    ])}
    ${data.message ? `<p class="empty">${escapeHtml(data.message)}</p>` : `
      <div class="domain-list">${data.vehicles.map((vehicle) => `<article class="domain-asset">
        <div class="domain-asset-head"><div>
          <h3>${escapeHtml(vehicle.vehicle.registrationNumber)}</h3>
          <p class="muted">${escapeHtml(vehicle.vehicle.description || '')}</p></div>
          ${statusPill(vehicle.rescueCoverage.covered ? 'COVERED' : vehicle.rescueCoverage.status)}
        </div>
        <dl class="trip-facts">
          <div><dt>Subscription</dt><dd>${escapeHtml(vehicle.subscriptionStatus)}</dd></div>
          <div><dt>Tracking</dt><dd>${escapeHtml(vehicle.trackingStatus)}</dd></div>
          <div><dt>Rescue code</dt><dd>${escapeHtml(vehicle.rescueCode || 'Not issued')}</dd></div>
          <div><dt>Drivers</dt><dd>${vehicle.drivers.length}</dd></div>
          <div><dt>Position</dt><dd>${vehicle.position.status}</dd></div>
          <div><dt>Expires</dt><dd>${escapeHtml(String(vehicle.expiresAt || '—'))}</dd></div>
        </dl>
      </article>`).join('')}</div>`}`;

  const renderTruck = (data) => `
    ${kpiRow([
      ['Fleet', data.metrics.fleet], ['In transit', data.metrics.inTransit], ['Delayed', data.metrics.delayed],
      ['Breakdowns', data.metrics.breakdowns], ['Open incidents', data.metrics.openIncidents],
      ['Cargo in motion', asWeight(data.metrics.cargoWeightInTransitKg)],
      ['Covered trucks', data.metrics.coveredTrucks], ['Tracking online', data.metrics.trackingOnline],
      ['Tracking offline', data.metrics.trackingOffline], ['Active drivers', data.metrics.activeDrivers],
    ])}
    ${data.message ? `<p class="empty">${escapeHtml(data.message)}</p>` : ''}
    ${groupsBlock('Cargo by category', data.cargoByCategory)}`;

  // The api/auth helpers live on the shared window.Mamore object (see
  // Object.assign(Mamore, { api, ... }) in app.js). The loaders below are plain
  // async functions captured at definition time, so they cannot reach that
  // closure directly; resolving it per call keeps them working like every other
  // feature script. Without this, "api is not defined" throws and the
  // Operations, Analytics, VIP and Truck panels silently stay empty.
  const apiRequest = (path, options) => {
    const shell = bind();
    if (shell && typeof shell.api === 'function') {
      return shell.api(path, options);
    }

    return Promise.reject(new Error('The application API is not ready yet.'));
  };

  let currentDomain = 'ALL';

  const app = {
    loadOperations: async (domain) => {
      currentDomain = domain || currentDomain;
      const data = await apiRequest(`/api/control-center/operations${currentDomain === 'ALL' ? '' : `?domain=${currentDomain}`}`);
      setServerEpochFromServerTime(data.generatedAt);
      $('#operations-body').innerHTML = renderOperations(data);
    },
    loadAnalytics: async () => {
      const data = await apiRequest('/api/analytics/global');
      $('#analytics-body').innerHTML = renderAnalytics(data);
    },
    loadVip: async () => {
      const data = await apiRequest('/api/vip/dashboard');
      $('#vip-body').innerHTML = renderVip(data);
    },
    loadPrivate: async () => {
      const data = await apiRequest('/api/private-vehicles');
      $('#private-body').innerHTML = renderPrivate(data);
    },
    loadTruck: async () => {
      const data = await apiRequest('/api/trucks');
      $('#truck-body').innerHTML = renderTruck(data);
    },
  };

  const setServerEpochFromServerTime = (iso) => {
    if (iso && window.MamoreSmartBus) {
      window.MamoreSmartBus.setServerEpoch(Date.parse(iso) / 1000);
    }
  };

  const init = () => {
    const shell = bind();
    if (!shell) return;
    // The shell already carries the api, escapeHtml and formatting helpers from
    // app.js; this module only contributes its renderers. Naming any of those
    // identifiers directly would reference something that does not exist in this
    // scope and throw on every load, so the shell is left as it is.
    shell.loaders = shell.loaders || {};
    shell.loaders.operations = () => app.loadOperations('ALL').catch((error) => notify(error.message));
    shell.loaders.analytics = () => app.loadAnalytics().catch((error) => notify(error.message));
    shell.loaders.vip = () => app.loadVip().catch((error) => notify(error.message));
    shell.loaders.privatevehicles = () => app.loadPrivate().catch((error) => notify(error.message));
    shell.loaders.truckcargo = () => app.loadTruck().catch((error) => notify(error.message));

    document.addEventListener('click', (event) => {
      const tab = event.target.closest('[data-domain]');
      if (tab) {
        currentDomain = tab.dataset.domain;
        app.loadOperations(currentDomain).catch((error) => notify(error.message));
      }
    });
  };

  window.MamoreDomains = { app, renderOperations, renderAnalytics };
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }
})();
