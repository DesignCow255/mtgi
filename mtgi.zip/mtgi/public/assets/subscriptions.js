// Rescue subscriptions, receipts, audit, notifications, the subscriber
// membership view and the portal self-service auth screens.
//
// It reuses the shared helpers app.js publishes on window.Mamore instead of
// duplicating the fetch/auth logic, and registers its own panel loaders.
(() => {
  'use strict';

  const $ = (selector) => document.querySelector(selector);
  const $$ = (selector) => [...document.querySelectorAll(selector)];
  const bind = () => window.Mamore || null;

  /**
   * A USD figure for display.
   *
   * This was a second, independent formatter that always said "USD" regardless
   * of the display currency, so the subscription screens and the dashboard could
   * disagree about the same number on the same page. It now delegates to
   * core/currency.js, which converts when a rate exists and falls back to the
   * source currency when one does not.
   */
  const usd = (value) => {
    const shell = window.Mamore || null;
    if (shell?.currency) return shell.currency.display(value, 'USD');
    return `USD ${Number(value || 0).toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
  };
  const when = (value) => (value ? new Date(String(value).replace(' ', 'T') + (String(value).includes('Z') ? '' : 'Z')).toLocaleString() : '—');

  const quoteFor = async (app, productCode, province) => {
    const params = new URLSearchParams({ productCode, province });
    const { quote } = await app.api(`/api/subscriptions/quote?${params}`);
    return quote;
  };

  const quoteMarkup = (app, quote) => `
    <div class="fee-breakdown">
      <p class="eyebrow">You pay</p>
      ${quote.chargeable.map((line) => `<div class="fee-line"><span>${app.escapeHtml(line.name)}</span><strong>${usd(line.amount)}</strong></div>`).join('')}
      <div class="fee-line total"><span>Total</span><strong>${usd(quote.totals.chargeableUsd)}</strong></div>
      <p class="eyebrow">Breakdown of the ${usd(quote.totals.taxableContainerUsd)} taxable portion</p>
      ${quote.subsets.map((line) => `<div class="fee-line subtle"><span>${app.escapeHtml(line.name)}</span><span>${usd(line.amount)}</span></div>`).join('')}
      <p class="receipt-note">The lines above add up to ${usd(quote.totals.taxableContainerUsd)}, already included in your ${usd(quote.totals.chargeableUsd)} total.</p>
    </div>`;

  // ---- Staff: subscriptions ---------------------------------------------
  const loadSubscriptions = async () => {
    const app = bind();
    const params = new URLSearchParams({ limit: '50' });
    const search = $('#subscription-search').value.trim();
    if (search) params.set('search', search);
    if ($('#subscription-status-filter').value) params.set('status', $('#subscription-status-filter').value);
    const { subscriptions } = await app.api(`/api/subscriptions?${params}`);
    const body = $('#subscription-list');
    body.innerHTML = subscriptions.length ? subscriptions.map((row) => `
      <tr data-subscription-row="${app.escapeHtml(row.id)}" tabindex="0" role="button">
        <td><strong>${app.escapeHtml(row.subscriptionNo)}</strong><small>${app.escapeHtml(row.productName || row.productCode || '')}</small></td>
        <td>${app.escapeHtml(row.subscriberName || '—')}<small>${app.escapeHtml(row.membershipNumber || '')}</small></td>
        <td>${app.escapeHtml(row.province)}</td>
        <td>${usd(row.totalAmount)}</td>
        <td><span class="status-badge ${row.status === 'ACTIVE' ? 'active' : ''}">${app.escapeHtml(row.status)}</span></td>
        <td>${app.escapeHtml(row.expiryDate)}</td>
      </tr>`).join('') : '<tr><td colspan="6" class="empty">No subscriptions match this filter.</td></tr>';
    body.querySelectorAll('[data-subscription-row]').forEach((row) => {
      const open = () => openSubscriptionDetail(app, row.dataset.subscriptionRow);
      row.addEventListener('click', open);
      row.addEventListener('keydown', (event) => { if (event.key === 'Enter' || event.key === ' ') { event.preventDefault(); open(); } });
    });
  };

  const openSubscriptionDetail = async (app, id) => {
    const { subscription } = await app.api(`/api/subscriptions?id=${encodeURIComponent(id)}`);
    const fees = subscription.fees || { chargeable: [], subsets: [], totals: {} };
    $('#detail-title').textContent = subscription.subscriptionNo;
    $('#detail-print-link').hidden = true;
    $('#detail-body').innerHTML = `
      <p class="receipt-note">${app.escapeHtml(subscription.productName || '')} · ${app.escapeHtml(subscription.province)} · ${app.escapeHtml(subscription.status)}</p>
      ${quoteMarkup(app, { chargeable: fees.chargeable, subsets: fees.subsets, totals: fees.totals })}
      <dl class="detail-list">
        <div><dt>Subscriber id</dt><dd>${app.escapeHtml(subscription.subscriberId)}</dd></div>
        <div><dt>Coverage</dt><dd>${app.escapeHtml(subscription.startDate)} → ${app.escapeHtml(subscription.endDate)}</dd></div>
        <div><dt>Grace ends</dt><dd>${app.escapeHtml(subscription.graceEndDate || '—')}</dd></div>
        <div><dt>Renewals</dt><dd>${subscription.renewalCount}</dd></div>
      </dl>
      <div class="dialog-actions">
        ${subscription.status === 'PENDING'
          ? `<button class="primary-button" data-take-payment="${app.escapeHtml(subscription.id)}" data-amount="${app.escapeHtml(subscription.totalAmount)}" data-label="${app.escapeHtml(subscription.subscriptionNo)}" type="button">Record payment</button>`
          : ''}
        ${['ACTIVE', 'EXPIRED', 'PENDING'].includes(subscription.status)
          ? `<button class="secondary-button" data-renew="${app.escapeHtml(subscription.id)}" type="button">Start renewal</button>`
          : ''}
      </div>`;
    $('#detail-dialog').showModal();
    $('#detail-body').querySelectorAll('[data-take-payment]').forEach((button) => {
      button.addEventListener('click', () => { $('#detail-dialog').close(); openPaymentDialog(app, button.dataset.takePayment, button.dataset.amount, button.dataset.label); });
    });
    $('#detail-body').querySelectorAll('[data-renew]').forEach((button) => {
      button.addEventListener('click', async () => {
        try {
          const { subscription: renewed } = await app.api('/api/subscriptions/renew', { method: 'POST', body: JSON.stringify({ subscriptionId: button.dataset.renew }) });
          app.toast(`Renewal ${renewed.subscriptionNo} opened.`);
          $('#detail-dialog').close();
          await loadSubscriptions();
        } catch (error) { app.toast(error.message); }
      });
    });
  };

  const openPaymentDialog = (app, id, amount, label) => {
    $('#subscription-payment-id').value = id;
    $('#subscription-payment-title').textContent = `Payment · ${label}`;
    $('#subscription-payment-summary').textContent = `Amount due ${usd(amount)}. The fee lines are posted automatically; the amount can never be changed.`;
    $('#subscription-payment-form').reset();
    $('#subscription-payment-id').value = id;
    $('#subscription-payment-error').textContent = '';
    $('#subscription-payment-dialog').showModal();
  };


  // ---- Staff: receipts ----------------------------------------------------
  const loadReceipts = async () => {
    const app = bind();
    const { receipts } = await app.api('/api/receipts?limit=50');
    $('#receipt-list').innerHTML = receipts.length ? receipts.map((receipt) => `
      <tr data-receipt-row="${app.escapeHtml(receipt.id)}" tabindex="0" role="button">
        <td><strong>${app.escapeHtml(receipt.receiptNumber)}</strong><small>${app.escapeHtml(receipt.verificationNumber)}</small></td>
        <td>${app.escapeHtml(receipt.subscriber.name || '-')}<small>${app.escapeHtml(receipt.subscriber.membershipNumber || '')}</small></td>
        <td>${app.escapeHtml(receipt.amountFormatted)}</td>
        <td>${app.escapeHtml(receipt.payment.method || '')}</td>
        <td><span class="status-badge ${receipt.status === 'ISSUED' ? 'active' : ''}">${app.escapeHtml(receipt.status)}</span><small>${receipt.printCount ? 'printed ' + receipt.printCount + 'x' : ''}</small></td>
        <td><button class="text-button" data-receipt-print="${app.escapeHtml(receipt.id)}" type="button">Print</button></td>
      </tr>`).join('') : '<tr><td colspan="6" class="empty">No receipts issued yet.</td></tr>';
    $$('#receipt-list [data-receipt-row]').forEach((row) => {
      const open = () => openReceipt(app, row.dataset.receiptRow);
      row.addEventListener('click', (event) => { if (!event.target.closest('[data-receipt-print]')) open(); });
      row.addEventListener('keydown', (event) => { if (event.key === 'Enter') open(); });
    });
    $$('#receipt-list [data-receipt-print]').forEach((button) => {
      button.addEventListener('click', async (event) => {
        event.stopPropagation();
        try {
          await app.api('/api/receipts/print', { method: 'POST', body: JSON.stringify({ receiptId: button.dataset.receiptPrint }) });
          app.toast('Print recorded.');
          await loadReceipts();
        } catch (error) { app.toast(error.message); }
      });
    });
  };

  const openReceipt = async (app, id) => {
    const { receipt } = await app.api('/api/receipts?id=' + encodeURIComponent(id));
    $('#detail-title').textContent = 'Receipt ' + receipt.receiptNumber;
    const link = $('#detail-print-link');
    link.hidden = false;
    link.href = app.url('/receipts/print?code=' + encodeURIComponent(receipt.verificationNumber));
    $('#detail-body').innerHTML = `
      <p class="receipt-note">${app.escapeHtml(receipt.subscriber.name || '')} - ${app.escapeHtml(receipt.subscription.subscriptionNo || '')} - ${app.escapeHtml(receipt.subscription.province || '')}</p>
      ${quoteMarkup(app, receipt.breakdown || { chargeable: [], subsets: [], totals: {} })}
      <dl class="detail-list">
        <div><dt>Amount</dt><dd>${app.escapeHtml(receipt.amountFormatted)}</dd></div>
        <div><dt>Method</dt><dd>${app.escapeHtml(receipt.payment.method || '')} - ${app.escapeHtml(receipt.payment.provider || '')}</dd></div>
        <div><dt>Paid at</dt><dd>${when(receipt.payment.paidAt)}</dd></div>
        <div><dt>Verify with</dt><dd>${app.escapeHtml(receipt.verificationNumber)}</dd></div>
        <div><dt>Status</dt><dd>${app.escapeHtml(receipt.status)}</dd></div>
      </dl>`;
    $('#detail-dialog').showModal();
  };

  // ---- Staff: audit -------------------------------------------------------
  const loadAudit = async () => {
    const app = bind();
    const params = new URLSearchParams({ limit: '50' });
    if ($('#audit-action').value.trim()) params.set('action', $('#audit-action').value.trim());
    if ($('#audit-entity').value) params.set('entityType', $('#audit-entity').value);
    const { audit } = await app.api('/api/audit?' + params.toString());
    $('#audit-list').innerHTML = audit.length ? audit.map((row) => `
      <article class="activity-row">
        <div>
          <strong>${app.escapeHtml(row.action)}</strong>
          <p>${app.escapeHtml(row.entityType)}${row.entityId ? ' - ' + app.escapeHtml(row.entityId) : ''}</p>
          <small>${row.actorEmail ? app.escapeHtml(row.actorEmail) : 'system'}${row.actorRole ? ' (' + app.escapeHtml(row.actorRole) + ')' : ''} - ${when(row.occurredAt)}${row.ipAddress ? ' - ' + app.escapeHtml(row.ipAddress) : ''}</small>
          ${row.newData ? '<details><summary>What changed</summary><pre>' + app.escapeHtml(JSON.stringify(row.newData, null, 2)) + '</pre></details>' : ''}
        </div>
      </article>`).join('') : '<p class="empty">No audit rows match this filter.</p>';
  };

  // ---- Notifications (both roles) -----------------------------------------
  const loadNotifications = async () => {
    const app = bind();
    const listed = await app.api('/api/notifications');
    const count = await app.api('/api/notifications/unread-count');
    const notifications = listed.notifications || [];
    $('#notification-list').innerHTML = notifications.length ? notifications.map((row) => `
      <article class="activity-row ${row.read ? '' : 'unread'}">
        <div>
          <strong>${app.escapeHtml(row.title)}</strong>
          <p>${app.escapeHtml(row.message)}</p>
          <small>${app.escapeHtml(row.type)} - ${when(row.createdAt)}${row.read ? '' : ' - unread'}</small>
        </div>
        ${row.read ? '' : '<button class="secondary-button" data-read-notification="' + row.id + '" type="button">Mark read</button>'}
      </article>`).join('') : '<p class="empty">No notifications.</p>';
    $$('[data-read-notification]').forEach((button) => {
      button.addEventListener('click', async () => {
        try {
          await app.api('/api/notifications/read', { method: 'POST', body: JSON.stringify({ notificationId: Number(button.dataset.readNotification) }) });
          await loadNotifications();
        } catch (error) { app.toast(error.message); }
      });
    });
    $('#mark-all-read').textContent = count.unread > 0 ? 'Mark all read (' + count.unread + ')' : 'Mark all read';
  };

  // ---- Subscriber: my rescue cover ----------------------------------------
  const loadMembership = async () => {
    const app = bind();
    const { subscriptions } = await app.api('/api/portal/subscriptions?detail=1');
    const mine = subscriptions || [];
    const active = mine.find((row) => row.status === 'ACTIVE');
    const pending = mine.find((row) => row.status === 'PENDING');
    $('#membership-heading').textContent = active
      ? 'You are covered until ' + active.expiryDate
      : (pending ? 'Payment pending for ' + pending.subscriptionNo : 'Choose your rescue cover');

    $('#membership-list').innerHTML = mine.length ? mine.map((row) => {
      const fees = row.fees || null;
      return `
        <article class="my-booking">
          <div>
            <h3>${app.escapeHtml(row.productName || row.productCode || 'Rescue cover')}</h3>
            <p>${app.escapeHtml(row.subscriptionNo)} - ${app.escapeHtml(row.province)}</p>
            <p>${app.escapeHtml(row.startDate)} to ${app.escapeHtml(row.endDate)}${row.graceEndDate ? ' (grace to ' + app.escapeHtml(row.graceEndDate) + ')' : ''}</p>
            <p>Total ${usd(row.totalAmount)}</p>
          </div>
          <div class="ticket-status">
            <strong>${app.escapeHtml(row.status)}</strong>
            <small>${app.escapeHtml(row.membershipStatus)}</small>
            ${fees ? '<details><summary>Fee breakdown</summary>' + quoteMarkup(app, fees) + '</details>' : ''}
            ${row.status === 'PENDING' ? '<small>Pay at any Mamore counter or agent.</small>' : ''}
            ${['ACTIVE', 'EXPIRED', 'PENDING'].includes(row.status) ? '<button class="secondary-button" data-renew-mine="' + app.escapeHtml(row.id) + '" type="button">Renew</button>' : ''}
          </div>
        </article>`;
    }).join('') : '<div class="empty"><strong>No rescue cover yet</strong><p>Buy the Truck or Private Vehicle cover to receive standby rescue.</p></div>';

    $$('[data-renew-mine]').forEach((button) => {
      button.addEventListener('click', async () => {
        try {
          const { subscription } = await app.api('/api/subscriptions/renew', { method: 'POST', body: JSON.stringify({ subscriptionId: button.dataset.renewMine }) });
          app.toast('Renewal ' + subscription.subscriptionNo + ' opened. Pay it at any counter.');
          await loadMembership();
        } catch (error) { app.toast(error.message); }
      });
    });

    try {
      const { receipts } = await app.api('/api/portal/receipts');
      $('#membership-receipts').innerHTML = (receipts || []).length ? receipts.map((receipt) => `
        <article class="activity-row">
          <div>
            <strong>${app.escapeHtml(receipt.receiptNumber)}</strong>
            <p>${app.escapeHtml(receipt.amountFormatted)} - ${app.escapeHtml(receipt.payment.method || '')}</p>
            <small>${when(receipt.issuedAt)} - ${app.escapeHtml(receipt.status)}</small>
          </div>
          <a class="secondary-button" href="${app.url('/receipts/print?code=' + encodeURIComponent(receipt.verificationNumber))}" target="_blank" rel="noopener">Print</a>
        </article>`).join('') : '<p class="empty">No receipts yet.</p>';
    } catch (error) {
      $('#membership-receipts').innerHTML = '<p class="empty">Receipts are unavailable right now.</p>';
    }
  };

  // ---- Wiring -------------------------------------------------------------
  // Portal auth is public (no bearer token), so it posts directly rather than
  // through app.api. app.url re-roots the path onto the install's mount point.
  const publicPost = async (path, body) => {
    const response = await fetch(bind()?.url ? bind().url(path) : path, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(body)
    });
    const payload = await response.json().catch(() => ({}));
    if (!response.ok) throw new Error(payload.error || 'Request failed (' + response.status + ').');
    return payload;
  };

  const showOnly = (formId) => {
    ['login-form', 'register-form', 'verify-form', 'forgot-form', 'reset-form']
      .forEach((id) => { const element = document.getElementById(id); if (element) element.hidden = id !== formId; });
  };

  const wirePortalAuth = () => {
    const go = (id) => {
      showOnly(id);
      const first = document.querySelector('#' + id + ' input');
      if (first) first.focus();
    };
    const back = (id) => {
      showOnly(id);
      ['register-error', 'verify-error', 'forgot-error', 'reset-error'].forEach((e) => { const el = document.getElementById(e); if (el) el.textContent = ''; });
      ['register-success', 'verify-success', 'forgot-success', 'reset-success'].forEach((e) => { const el = document.getElementById(e); if (el) el.textContent = ''; });
    };

    $('#show-register').addEventListener('click', () => go('register-form'));
    $('#show-verify').addEventListener('click', () => go('verify-form'));
    $('#show-forgot').addEventListener('click', () => go('forgot-form'));
    $('#show-reset').addEventListener('click', () => go('reset-form'));
    ['back-to-login', 'back-to-login-verify', 'back-to-login-forgot', 'back-to-login-reset']
      .forEach((id) => { const button = document.getElementById(id); if (button) button.addEventListener('click', () => back('login-form')); });

    $('#register-form').addEventListener('submit', async (event) => {
      event.preventDefault();
      const button = $('#register-button');
      button.disabled = true;
      $('#register-error').textContent = '';
      $('#register-success').textContent = '';
      try {
        const { subscriber } = await publicPost('/api/auth/register-subscriber', {
          firstName: $('#register-first-name').value.trim(),
          lastName: $('#register-last-name').value.trim(),
          email: $('#register-email').value.trim(),
          phone: $('#register-phone').value.trim(),
          password: $('#register-password').value,
          acceptTerms: $('#register-terms').checked,
          acceptPrivacy: $('#register-privacy').checked
        });
        $('#verify-email').value = subscriber.email;
        $('#verify-code').value = subscriber.debugCode || '';
        $('#register-success').textContent = 'Account created as ' + subscriber.membershipNumber + '. ' +
          (subscriber.debugCode ? 'Local code: ' + subscriber.debugCode : 'Check your email for the code.');
        showOnly('verify-form');
        $('#verify-code').focus();
      } catch (error) { $('#register-error').textContent = error.message; }
      finally { button.disabled = false; }
    });

    $('#verify-form').addEventListener('submit', async (event) => {
      event.preventDefault();
      const button = $('#verify-button');
      button.disabled = true;
      $('#verify-error').textContent = '';
      try {
        const { verification } = await publicPost('/api/auth/verify-otp', {
          email: $('#verify-email').value.trim(),
          code: $('#verify-code').value.trim()
        });
        $('#verify-success').textContent = verification.message;
        $('#email').value = $('#verify-email').value.trim();
        showOnly('login-form');
        $('#password').focus();
      } catch (error) { $('#verify-error').textContent = error.message; }
      finally { button.disabled = false; }
    });

    $('#resend-code').addEventListener('click', async () => {
      try {
        const payload = await publicPost('/api/auth/resend-otp', { email: $('#verify-email').value.trim() });
        $('#verify-code').value = payload.resend.debugCode || '';
        $('#verify-success').textContent = payload.resend.message;
      } catch (error) { $('#verify-error').textContent = error.message; }
    });

    $('#forgot-form').addEventListener('submit', async (event) => {
      event.preventDefault();
      const button = $('#forgot-button');
      button.disabled = true;
      $('#forgot-error').textContent = '';
      try {
        const { forgot } = await publicPost('/api/auth/forgot-password', { email: $('#forgot-email').value.trim() });
        $('#reset-email').value = $('#forgot-email').value.trim();
        $('#reset-code').value = forgot.debugCode || '';
        $('#forgot-success').textContent = forgot.message + (forgot.debugCode ? ' Local code: ' + forgot.debugCode : '');
        showOnly('reset-form');
        $('#reset-code').focus();
      } catch (error) { $('#forgot-error').textContent = error.message; }
      finally { button.disabled = false; }
    });

    $('#reset-form').addEventListener('submit', async (event) => {
      event.preventDefault();
      const button = $('#reset-button');
      button.disabled = true;
      $('#reset-error').textContent = '';
      try {
        const { reset } = await publicPost('/api/auth/reset-password', {
          email: $('#reset-email').value.trim(),
          code: $('#reset-code').value.trim(),
          password: $('#reset-password').value
        });
        $('#reset-success').textContent = reset.message;
        $('#email').value = $('#reset-email').value.trim();
      } catch (error) { $('#reset-error').textContent = error.message; }
      finally { button.disabled = false; }
    });
  };

  const wireStaffPanels = () => {
    const app = bind();
    const guard = (handler) => (event) => {
      const element = event.target;
      if (!element) return;
      handler(event);
    };

    // New subscription
    $('#new-subscription-button').addEventListener('click', async () => {
      $('#subscription-form').reset();
      $('#subscription-form-error').textContent = '';
      try {
        $('#subscription-quote').innerHTML = quoteMarkup(app, await quoteFor(app, $('#subscription-product').value, $('#subscription-province').value));
      } catch (error) { $('#subscription-quote').textContent = error.message; }
      $('#subscription-dialog').showModal();
      $('#subscription-first-name').focus();
    });
    const requote = async () => {
      try {
        $('#subscription-quote').innerHTML = quoteMarkup(app, await quoteFor(app, $('#subscription-product').value, $('#subscription-province').value));
      } catch (error) { $('#subscription-quote').textContent = error.message; }
    };
    $('#subscription-product').addEventListener('change', guard(requote));
    $('#subscription-province').addEventListener('change', guard(requote));
    $('#close-subscription-dialog').addEventListener('click', () => $('#subscription-dialog').close());
    $('#cancel-subscription-dialog').addEventListener('click', () => $('#subscription-dialog').close());

    $('#subscription-form').addEventListener('submit', async (event) => {
      event.preventDefault();
      const button = $('#save-subscription-button');
      button.disabled = true;
      $('#subscription-form-error').textContent = '';
      const vehicles = $('#subscription-plate').value.trim() ? [{ plateNumber: $('#subscription-plate').value.trim() }] : [];
      try {
        const { subscription } = await app.api('/api/subscriptions/create', {
          method: 'POST',
          body: JSON.stringify({
            productCode: $('#subscription-product').value,
            province: $('#subscription-province').value,
            subscriber: {
              firstName: $('#subscription-first-name').value.trim(),
              lastName: $('#subscription-last-name').value.trim(),
              phone: $('#subscription-phone').value.trim()
            },
            vehicles
          })
        });
        $('#subscription-dialog').close();
        app.toast('Subscription ' + subscription.subscriptionNo + ' opened as PENDING.');
        await loadSubscriptions();
      } catch (error) { $('#subscription-form-error').textContent = error.message; }
      finally { button.disabled = false; }
    });

    $('#subscription-filter').addEventListener('submit', (event) => { event.preventDefault(); loadSubscriptions().catch((error) => app.toast(error.message)); });

    // Payment
    $('#close-subscription-payment-dialog').addEventListener('click', () => $('#subscription-payment-dialog').close());
    $('#cancel-subscription-payment-dialog').addEventListener('click', () => $('#subscription-payment-dialog').close());
    $('#subscription-payment-form').addEventListener('submit', async (event) => {
      event.preventDefault();
      const button = $('#save-subscription-payment-button');
      button.disabled = true;
      $('#subscription-payment-error').textContent = '';
      const body = {
        subscriptionId: $('#subscription-payment-id').value,
        paymentMethod: $('#subscription-payment-method').value
      };
      if ($('#subscription-payment-rate').value) body.usdCdfRate = Number($('#subscription-payment-rate').value);
      try {
        const { payment } = await app.api('/api/finance/subscription-payments/receive', { method: 'POST', body: JSON.stringify(body) });
        $('#subscription-payment-dialog').close();
        app.toast('Payment ' + payment.paymentReference + ' recorded, receipt ' + payment.receipt.receiptNumber + '.');
        await Promise.all([loadSubscriptions(), loadReceipts()]);
      } catch (error) { $('#subscription-payment-error').textContent = error.message; }
      finally { button.disabled = false; }
    });

    // Receipts, audit, notifications
    $('#refresh-receipts').addEventListener('click', () => loadReceipts().catch((error) => app.toast(error.message)));
    $('#refresh-audit').addEventListener('click', () => loadAudit().catch((error) => app.toast(error.message)));
    $('#audit-filter').addEventListener('submit', (event) => { event.preventDefault(); loadAudit().catch((error) => app.toast(error.message)); });
    $('#refresh-notifications').addEventListener('click', () => loadNotifications().catch((error) => app.toast(error.message)));
    $('#mark-all-read').addEventListener('click', async () => {
      try { await app.api('/api/notifications/read-all', { method: 'POST', body: '{}' }); await loadNotifications(); app.toast('All notifications marked read.'); }
      catch (error) { app.toast(error.message); }
    });
    $('#close-detail-dialog').addEventListener('click', () => $('#detail-dialog').close());
    $('#close-detail-dialog-action').addEventListener('click', () => $('#detail-dialog').close());

    // Subscriber: buy cover
    $('#buy-cover-button').addEventListener('click', async () => {
      $('#buy-cover-form').reset();
      $('#buy-cover-error').textContent = '';
      try {
        const params = new URLSearchParams({ productCode: $('#cover-product').value, province: $('#cover-province').value });
        const { quote } = await app.api('/api/portal/subscription/quote?' + params.toString());
        $('#cover-quote').innerHTML = quoteMarkup(app, quote);
      } catch (error) { $('#cover-quote').textContent = error.message; }
      $('#buy-cover-dialog').showModal();
    });
    const requoteCover = async () => {
      try {
        const params = new URLSearchParams({ productCode: $('#cover-product').value, province: $('#cover-province').value });
        const { quote } = await app.api('/api/portal/subscription/quote?' + params.toString());
        $('#cover-quote').innerHTML = quoteMarkup(app, quote);
      } catch (error) { $('#cover-quote').textContent = error.message; }
    };
    $('#cover-product').addEventListener('change', requoteCover);
    $('#cover-province').addEventListener('change', requoteCover);
    $('#close-buy-cover-dialog').addEventListener('click', () => $('#buy-cover-dialog').close());
    $('#cancel-buy-cover-dialog').addEventListener('click', () => $('#buy-cover-dialog').close());
    $('#buy-cover-form').addEventListener('submit', async (event) => {
      event.preventDefault();
      const button = $('#save-buy-cover-button');
      button.disabled = true;
      $('#buy-cover-error').textContent = '';
      const body = { productCode: $('#cover-product').value, province: $('#cover-province').value };
      if ($('#cover-plate').value.trim()) body.vehicles = [{ plateNumber: $('#cover-plate').value.trim() }];
      try {
        const { subscription } = await app.api('/api/portal/subscriptions/create', { method: 'POST', body: JSON.stringify(body) });
        $('#buy-cover-dialog').close();
        app.toast('Subscription ' + subscription.subscriptionNo + ' created. Pay it at any Mamore counter to activate.');
        await loadMembership();
      } catch (error) { $('#buy-cover-error').textContent = error.message; }
      finally { button.disabled = false; }
    });
  };

  // app.js publishes its helpers synchronously, so the registry is ready before
  // this deferred script runs.
  const boot = () => {
    const app = bind();
    if (!app) return;
    app.loaders.subscriptions = loadSubscriptions;
    app.loaders.receipts = loadReceipts;
    app.loaders.audit = loadAudit;
    app.loaders.notifications = loadNotifications;
    app.loaders.membership = loadMembership;
    wirePortalAuth();
    wireStaffPanels();
  };

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', boot);
  } else {
    boot();
  }
})();
