/**
 * Smart Bus v2 surfaces.
 *
 * Additive: the existing panels keep their ids and their behaviour. This file
 * adds the boarding-window countdown, the real-bus trip card, the live manifest
 * and the pilot command centre. It never hard-codes a business rule: every value
 * shown comes from the API, and every badge is rendered only when the backend
 * proved it.
 */

/* The server is the clock. This offset is the measured difference between the
   server epoch and the browser, so a wrong device clock cannot mislead a
   passenger into missing a bus. */
let serverOffsetSeconds = 0;
const setServerEpoch = (epoch) => { serverOffsetSeconds = Number(epoch) - Math.floor(Date.now() / 1000); };
const serverNow = () => Date.now() / 1000 + serverOffsetSeconds;

const pad = (value) => String(value).padStart(2, '0');

/** HH:MM:SS from a server-relative deadline, or null when it has passed. */
function countdownFrom(isoTimestamp) {
  if (!isoTimestamp) return null;
  const target = Date.parse(isoTimestamp.replace(' ', 'T') + 'Z');
  if (Number.isNaN(target)) return null;
  const seconds = Math.floor(target / 1000) - Math.floor(serverNow());
  if (seconds <= 0) return null;
  return `${pad(Math.floor(seconds / 3600))}:${pad(Math.floor((seconds % 3600) / 60))}:${pad(seconds % 60)}`;
}

/** Readable clock time from a TIMESTAMP(6) string, in UTC. */
function clockTime(isoTimestamp) {
  if (!isoTimestamp) return '—';
  const parsed = Date.parse(isoTimestamp.replace(' ', 'T') + 'Z');
  if (Number.isNaN(parsed)) return '—';
  const date = new Date(parsed);
  return `${pad(date.getUTCHours())}:${pad(date.getUTCMinutes())}`;
}

const boardingPhase = (boarding) => {
  if (!boarding || !boarding.phase) return null;
  const label = {
    REPORTING_OPEN: 'Not open yet',
    BOARDING: 'Boarding open',
    BOARDING_CLOSING: 'Report now',
    BOARDING_CLOSED: 'Boarding closed',
    DEPARTED: 'Departed',
    FINISHED: 'Finished',
    CANCELLED: 'Cancelled',
    UNKNOWN: 'Times not set',
  }[boarding.phase] || boarding.phase;
  return { label, message: boarding.message, countdown: boarding.countdown };
};

/** Badges are rendered from the API's verified flags only. */
function badgeRow(badges) {
  if (!badges) return '';
  const entries = [
    [badges.rescueProtected, 'Mamore Rescue Protected', 'rescue'],
    [badges.liveGps, 'Live GPS', 'gps'],
    [badges.verifiedOperator, 'Verified operator', 'verified'],
    [badges.verifiedBus, 'Verified bus', 'verified'],
  ].filter(([on]) => on === true);
  if (!entries.length) return '';
  return `<div class="badge-row">${entries
    .map(([, label, kind]) => `<span class="badge badge-${kind}">${escapeHtml(label)}</span>`)
    .join('')}</div>`;
}

/** The four boarding times, exactly as the conductor sees them. */
function boardingGrid(boarding) {
  if (!boarding) return '';
  const phase = boardingPhase(boarding);
  const rows = [
    ['Departure', clockTime(boarding.departureAt)],
    ['Report by', clockTime(boarding.reportingAt)],
    ['Boarding opens', clockTime(boarding.boardingOpensAt)],
    ['Boarding closes', clockTime(boarding.boardingClosesAt)],
  ];
  return `<div class="boarding-grid">
    ${rows.map(([label, value]) => `<div><span>${escapeHtml(label)}</span><strong>${escapeHtml(value)}</strong></div>`).join('')}
    ${phase ? `<div class="boarding-phase"><span>Status</span><strong>${escapeHtml(phase.label)}</strong>${
      phase.countdown ? `<em>in ${escapeHtml(phase.countdown)}</em>` : ''
    }${phase.message ? `<p class="muted">${escapeHtml(phase.message)}</p>` : ''}</div>` : ''}
  </div>`;
}

const vehicleLine = (trip) => {
  const vehicle = trip.vehicle || {};
  const parts = [vehicle.make, vehicle.model].filter(Boolean).join(' ');
  const capacity = trip.capacity ? `${trip.capacity} seats` : null;
  const remaining = typeof trip.bookedSeats === 'number' && trip.capacity ? Math.max(0, trip.capacity - trip.bookedSeats) : null;
  return [parts, vehicle.plate, capacity, remaining !== null ? `${remaining} free` : null]
    .filter(Boolean)
    .map((part) => escapeHtml(String(part)))
    .join(' · ');
};

const stateTone = (state) => ({
  BOARDED: 'ok', CHECKED_IN: 'ok', COMPLETED: 'ok', CONFIRMED: 'wait', RESERVED: 'wait',
  NO_SHOW: 'bad', CANCELLED: 'bad',
}[state] || 'wait');

/** Live manifest for a conductor: counts first, then the passenger list. */
function renderManifest(manifest) {
  const counts = manifest.counts || {};
  const cards = [
    ['Boarded', `${counts.boarded || 0} / ${counts.capacity || 0}`],
    ['Pending', counts.pending ?? 0],
    ['VIP rescue', counts.vip || 0],
    ['Assistance', counts.assistance || 0],
    ['No-show', counts.noShow || 0],
  ];
  const rows = (manifest.passengers || []).map((passenger) => `
    <tr>
      <td>${escapeHtml(passenger.passengerName)}</td>
      <td>${passenger.seatNumber}</td>
      <td><span class="pill pill-${stateTone(passenger.state)}">${escapeHtml(passenger.state)}</span></td>
      <td>${passenger.vip ? 'VIP' : '—'}</td>
      <td>${escapeHtml(passenger.rescueCoverage)}</td>
      <td>${passenger.rescueCode ? `<code>${escapeHtml(passenger.rescueCode)}</code>` : '—'}</td>
      <td>${escapeHtml(passenger.specialAssistance || '—')}</td>
    </tr>`).join('');

  return `<div class="manifest-summary">${cards
    .map(([label, value]) => `<div><span>${escapeHtml(label)}</span><strong>${escapeHtml(String(value))}</strong></div>`)
    .join('')}</div>
    ${boardingGrid(manifest.boarding)}
    <table class="data-table"><thead><tr><th>Passenger</th><th>Seat</th><th>State</th><th>VIP</th>
      <th>Rescue</th><th>Code</th><th>Assistance</th></tr></thead><tbody>${rows ||
      '<tr><td colspan="7" class="muted">No passengers booked.</td></tr>'}</tbody></table>`;
}

/** Journey safety: text and icons, never colour alone. */
function renderSafety(safety) {
  if (!safety || safety.active === false) {
    return '<p class="empty">No active journey.</p>';
  }
  const rows = Object.entries(safety.components || {}).map(([key, value]) => `
    <div class="safety-row"><span>${escapeHtml(key.replace(/([A-Z])/g, ' $1').replace(/^./, (c) => c.toUpperCase()))}</span>
    <strong class="safety-${escapeHtml(String(value).toLowerCase())}">${escapeHtml(String(value))}</strong></div>`).join('');
  const nearest = Object.entries(safety.nearest || {})
    .filter(([key]) => key !== 'basis')
    .map(([key, value]) => `<div class="safety-row"><span>${escapeHtml(key.replace(/([A-Z])/g, ' $1'))}</span>
      <strong>${value && value.status !== 'UNKNOWN' ? `${escapeHtml(value.name)} · ${escapeHtml(value.distanceKm)} km` : 'UNKNOWN'}</strong></div>`)
    .join('');
  return `<div class="safety-grid"><div>${rows}</div><div>${nearest || '<p class="muted">No position available.</p>'}</div></div>
    <p class="muted">Overall: <strong>${escapeHtml(safety.status)}</strong> · manifest ${safety.manifest?.boarded || 0} boarded ·
    GPS ${escapeHtml(safety.gps?.status || 'UNKNOWN')}</p>`;
}

/** Pilot command centre. Empty sources say so rather than showing zero. */
function renderPilot(payload) {
  const summary = payload.summary || {};
  const metrics = summary.metrics || {};
  const cards = [
    ['Trips', metrics.trips], ['Live trips', metrics.liveTrips], ['Bookings', metrics.bookings],
    ['Boarded', metrics.boarded], ['No-shows', metrics.noShows], ['VIP passengers', metrics.vipPassengers],
    ['Rescue codes', metrics.rescueCodesIssued], ['Rescue protected trips', metrics.rescueProtectedTrips],
    ['GPS-enabled buses', metrics.gpsEnabledBuses], ['Verified operators', `${metrics.verifiedOperators || 0}/${metrics.operators || 0}`],
    ['Incidents', metrics.incidents], ['Smart Bus incidents', metrics.smartBusIncidents],
  ];
  const revenue = summary.revenue || {};
  const rates = summary.rates || {};
  const report = (name) => {
    const item = (payload.insights || {})[name];
    if (!item || !item.rows || !item.rows.length) {
      return `<div class="insight"><h3>${escapeHtml(name)}</h3><p class="empty">${escapeHtml(item?.message || 'No data available.')}</p></div>`;
    }
    const headers = Object.keys(item.rows[0]);
    return `<div class="insight"><h3>${escapeHtml(name)}</h3>
      <table class="data-table"><thead><tr>${headers.map((h) => `<th>${escapeHtml(h)}</th>`).join('')}</tr></thead>
      <tbody>${item.rows.map((row) => `<tr>${headers.map((h) => `<td>${escapeHtml(String(row[h] ?? '—'))}</td>`).join('')}</tr>`).join('')}</tbody></table></div>`;
  };
  return `<div class="mobility-summary">${cards
    .map(([label, value]) => `<div><span>${escapeHtml(label)}</span><strong>${escapeHtml(String(value ?? 0))}</strong></div>`).join('')}</div>
    <div class="mobility-summary">
      <div><span>Revenue (CDF)</span><strong>${money(revenue.totalCdf ?? '0.00')}</strong></div>
      <div><span>Rescue fund (CDF)</span><strong>${money(revenue.rescueFeeCdf ?? '0.00')}</strong></div>
      <div><span>Payment success</span><strong>${rates.paymentSuccessRate === null || rates.paymentSuccessRate === undefined ? 'No data' : Math.round(rates.paymentSuccessRate * 100) + '%'}</strong></div>
      <div><span>Board rate</span><strong>${rates.boardRate === null || rates.boardRate === undefined ? 'No data' : Math.round(rates.boardRate * 100) + '%'}</strong></div>
    </div>
    <div class="insight-grid">
      ${report('busiestRoutes')}${report('operatorBookings')}${report('poorOccupancy')}${report('lateTrips')}
      ${report('noShowHotspots')}${report('incidentRateByRoute')}${report('weakRescueCoverage')}${report('gpsHealth')}
    </div>`;
}

/** Live trips for the Control Center. */
function renderLiveTrips(trips) {
  if (!trips || !trips.length) return '<p class="empty">No active Smart Bus trips.</p>';
  return `<div class="trip-list">${trips.map((trip) => {
    const nearest = trip.nearest || {};
    const nearestLine = (value) => (value && value.status !== 'UNKNOWN' ? `${escapeHtml(value.name)} · ${escapeHtml(value.distanceKm)} km` : 'UNKNOWN');
    return `<article class="trip-card">
      <div class="trip-card-head"><div>
        <h3>${escapeHtml(trip.vehicleLabel)}</h3>
        <p class="muted">${escapeHtml(trip.route)}</p></div>
        <span class="pill pill-${trip.gpsStatus === 'ONLINE' ? 'ok' : 'wait'}">${escapeHtml(trip.tripStatus || trip.status)}</span>
      </div>
      <dl class="trip-facts">
        <div><dt>Passengers</dt><dd>${trip.boarded || 0} / ${trip.passengers || 0} boarded</dd></div>
        <div><dt>VIP</dt><dd>${trip.vipPassengers || 0}</dd></div>
        <div><dt>Rescue coverage</dt><dd>${escapeHtml(trip.rescueCoverage)}</dd></div>
        <div><dt>GPS</dt><dd>${escapeHtml(trip.gpsStatus)}</dd></div>
        <div><dt>Nearest unit</dt><dd>${nearestLine(nearest.rescueUnit)}</dd></div>
        <div><dt>Nearest hospital</dt><dd>${nearestLine(nearest.hospital)}</dd></div>
        <div><dt>Incidents</dt><dd>${trip.incidentCount || 0}</dd></div>
      </dl>
    </article>`;
  }).join('')}</div>`;
}

window.MamoreSmartBus = {
  setServerEpoch, countdownFrom, clockTime, boardingPhase, badgeRow, boardingGrid, vehicleLine,
  renderManifest, renderSafety, renderPilot, renderLiveTrips, stateTone,
};
