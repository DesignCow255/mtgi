(() => {
  'use strict';

  const $ = (selector) => document.querySelector(selector);
  const $$ = (selector) => [...document.querySelectorAll(selector)];
  const tokenKey = 'mamore_access_token';
  const refreshKey = 'mamore_refresh_token';

  // Mount point of the install: "" when the app is served from the web root,
  // "/mtgi" when it is served from a sub-directory (MAMP). The server injects
  // it as a meta tag rather than an inline script, because the Content-Security-
  // Policy it sends allows 'self' scripts only. Every request URL below is
  // routed through url() so the app works unchanged at either mount point.
  const base = (document.querySelector('meta[name="mamore-base"]')?.content || '').replace(/\/$/, '');
  const url = (path) => (path.startsWith('/') ? base + path : path);
  let refreshPromise = null;
  let adminUsers = [];
  let adminRoles = [];
  let rescueIncidents = [];
  let rescueUnits = [];
  let smartBusTrips = [];
  let smartBusRoutes = [];
  let smartBusVehicles = [];
  let unpaidBookings = [];
  let customerMode = false;
  let currentUser = null;
  let trackingAssets = [];
  let panicAlerts = [];

  const escapeHtml = (value) => String(value ?? '').replace(/[&<>'"]/g, (character) => ({
    '&': '&amp;', '<': '&lt;', '>': '&gt;', "'": '&#39;', '"': '&quot;'
  })[character]);

  /**
   * Build a Font Awesome glyph.
   *
   * The icon font is a subset, so only the names in
   * public/assets/fontawesome.css render. Icons are decorative: the surrounding
   * label or the control's aria-label carries the meaning, hence aria-hidden.
   * Never use this for the only text on a control.
   */
  const icon = (name) => `<i class="fa-solid fa-${name}" aria-hidden="true"></i>`;

  const formatDate = (value) => {
    if (!value) return 'Unknown time';
    const normalized = value.includes('T') ? value : `${value.replace(' ', 'T')}Z`;
    const date = new Date(normalized);
    return Number.isNaN(date.valueOf()) ? value : new Intl.DateTimeFormat(undefined, { dateStyle: 'medium', timeStyle: 'short' }).format(date);
  };

  const toast = (message) => {
    const element = $('#toast');
    element.textContent = message;
    element.classList.add('visible');
    window.setTimeout(() => element.classList.remove('visible'), 2800);
  };

  const saveTokens = (payload) => {
    sessionStorage.setItem(tokenKey, payload.accessToken);
    sessionStorage.setItem(refreshKey, payload.refreshToken);
  };

  const clearTokens = () => {
    sessionStorage.removeItem(tokenKey);
    sessionStorage.removeItem(refreshKey);
  };

  const refreshAccess = async () => {
    if (refreshPromise) return refreshPromise;
    const refreshToken = sessionStorage.getItem(refreshKey);
    if (!refreshToken) throw new Error('Your session has ended.');
    refreshPromise = fetch(url('/api/auth/refresh'), {
      method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ refreshToken })
    }).then(async (response) => {
      const payload = await response.json();
      if (!response.ok) throw new Error(payload.error || 'Could not refresh session.');
      saveTokens(payload);
      return payload.accessToken;
    }).finally(() => { refreshPromise = null; });
    return refreshPromise;
  };

  const api = async (path, options = {}, retry = true) => {
    const token = sessionStorage.getItem(tokenKey);
    const response = await fetch(url(path), {
      ...options,
      headers: { 'Content-Type': 'application/json', ...(options.headers || {}), ...(token ? { Authorization: `Bearer ${token}` } : {}) }
    });
    if (response.status === 401 && retry && sessionStorage.getItem(refreshKey)) {
      await refreshAccess();
      return api(path, options, false);
    }
    const payload = await response.json().catch(() => ({}));
    if (!response.ok) throw new Error(payload.error || `Request failed (${response.status}).`);
    return payload;
  };

  const showLogin = (message = '') => {
    clearTokens();
    $('#app-view').hidden = true;
    $('#login-view').hidden = false;
    $('#login-error').textContent = message;
    $('#email').focus();
  };

  /**
   * The old auth-telemetry dashboard.
   *
   * The overview panel used to render users / active sessions / successful and
   * failed logins as the front page of an operations platform, which is what the
   * audit recorded as S2.4: the landing screen answered "how many accounts are
   * there" instead of "what is Mamore doing right now". It is retained because
   * /api/admin/dashboard is still a real endpoint and this is still a legitimate
   * SECURITY view -- it just is not the front page any more.
   *
   * It renders into a container only if one is present, so removing the
   * overview markup did not leave a null dereference behind.
   */
  const renderDashboard = (data) => {
    const mount = $('#security-dashboard-body');
    if (!mount) return;

    const rows = [
      ['Registered users', data.metrics.users, 'All active accounts'],
      ['Active sessions', data.metrics.activeSessions, 'Currently authorized'],
      ['Successful logins', data.metrics.successfulLogins24h, 'Last 24 hours'],
      ['Failed logins', data.metrics.failedLogins24h, 'Last 24 hours'],
    ];

    mount.innerHTML = `
      <div class="grid">${rows.map(([label, value, note]) => `
        <article class="metric col-quarter">
          <p class="metric__label">${escapeHtml(label)}</p>
          <p class="metric__value">${Number(value || 0).toLocaleString()}</p>
          <p class="metric__context">${escapeHtml(note)}</p>
        </article>`).join('')}</div>
      <div class="grid">
        <section class="card col-half">
          <div class="card__header"><h2 class="card__title">Users by role</h2></div>
          <div class="card__body">${data.roles.length ? data.roles.map((role) => `
            <div class="pulse__row"><span class="pulse__service">${escapeHtml(role.name)}</span><span class="pulse__value" data-state="ok">${role.users}</span></div>
          `).join('') : '<p class="metric__context">No roles found.</p>'}</div>
        </section>
        <section class="card col-half">
          <div class="card__header"><h2 class="card__title">Recent sign-ins</h2></div>
          <div class="card__body">${data.recentLogins.length ? data.recentLogins.map((entry) => `
            <div class="pulse__row"><span class="pulse__service">${escapeHtml(entry.email)}</span><span class="pulse__value" data-state="${entry.succeeded ? 'ok' : 'degraded'}">${escapeHtml(entry.succeeded ? 'Success' : (entry.failureReason || 'Blocked'))}</span></div>
          `).join('') : '<p class="metric__context">No sign-in activity yet.</p>'}</div>
        </section>
      </div>`;
  };

  const loadDashboard = async () => renderDashboard(await api('/api/admin/dashboard'));

  const loadSessions = async () => {
    const { sessions } = await api('/api/auth/sessions');
    $('#sessions-list').innerHTML = sessions.length ? sessions.map((session) => `
      <article class="session-row"><div><strong>${escapeHtml(session.user_agent || 'Unknown device')}</strong><small>${escapeHtml(session.ip_address || 'Unknown network')} · Last active ${escapeHtml(formatDate(session.last_activity_at))}</small><small>${Number(session.is_active) === 1 ? 'Active' : 'Expired or revoked'} · Refresh expires ${escapeHtml(formatDate(session.refresh_expires_at))}</small></div><button class="danger-button" data-session-id="${escapeHtml(session.id)}" type="button" ${Number(session.is_active) === 1 ? '' : 'disabled'}>${icon("ban")}Revoke</button></article>
    `).join('') : '<p class="empty">No active sessions.</p>';
  };

  const renderUsers = () => {
    $('#users-list').innerHTML = adminUsers.length ? adminUsers.map((user) => `
      <tr><td><strong>${escapeHtml(user.firstName)} ${escapeHtml(user.lastName)}</strong><small>${escapeHtml(user.email)}${user.phone ? ` · ${escapeHtml(user.phone)}` : ''}</small></td><td><strong>${escapeHtml(user.roleName)}</strong><small>${escapeHtml(user.roleCode)}</small></td><td><span class="status-badge ${user.status === 'ACTIVE' ? 'active' : ''}">${escapeHtml(user.status)}</span></td><td>${escapeHtml(formatDate(user.lastLoginAt))}</td><td><button class="row-action" data-edit-user="${escapeHtml(user.id)}" type="button">${icon("user-check")}Manage</button></td></tr>
    `).join('') : '<tr><td colspan="5" class="empty">No users match your search.</td></tr>';
  };

  const loadUsers = async (search = '') => {
    $('#users-list').innerHTML = '<tr><td colspan="5" class="empty">Loading users…</td></tr>';
    const payload = await api(`/api/admin/users?search=${encodeURIComponent(search)}`);
    adminUsers = payload.users;
    adminRoles = payload.roles;
    $('#user-role').innerHTML = adminRoles.map((role) => `<option value="${escapeHtml(role.id)}">${escapeHtml(role.name)}</option>`).join('');
    renderUsers();
  };

  const openUserDialog = (user = null) => {
    const editing = Boolean(user);
    $('#user-dialog-title').textContent = editing ? 'Manage user' : 'Add user';
    $('#save-user-button').innerHTML = `${icon(editing ? 'floppy-disk' : 'user-plus')}${editing ? 'Save changes' : 'Create user'}`;
    $('#edit-user-id').value = user?.id || '';
    $('#identity-fields').hidden = editing;
    $('#user-first-name').required = !editing;
    $('#user-last-name').required = !editing;
    $('#user-email').required = !editing;
    $('#user-password').required = !editing;
    $('#user-first-name').value = user?.firstName || '';
    $('#user-last-name').value = user?.lastName || '';
    $('#user-email').value = user?.email || '';
    $('#user-phone').value = user?.phone || '';
    $('#user-password').value = '';
    $('#user-role').value = user?.roleId || adminRoles[0]?.id || '';
    $('#user-status').value = user?.status || 'ACTIVE';
    $('#user-form-error').textContent = '';
    $('#user-dialog').showModal();
    window.setTimeout(() => (editing ? $('#user-role') : $('#user-first-name')).focus(), 0);
  };

  const closeUserDialog = () => $('#user-dialog').close();

  const transitionOptions = {
    DISPATCHED: ['ACKNOWLEDGED', 'EN_ROUTE', 'CANCELLED'], ACKNOWLEDGED: ['EN_ROUTE', 'CANCELLED'],
    EN_ROUTE: ['ON_SCENE', 'CANCELLED'], ON_SCENE: ['RESOLVED', 'CANCELLED']
  };

  const renderRescueBoard = (data) => {
    rescueIncidents = data.incidents;
    rescueUnits = data.units;
    const metricValues = [data.metrics.open, data.metrics.critical, data.metrics.dispatched, data.metrics.availableUnits];
    $$('#rescue-metrics strong').forEach((element, index) => { element.textContent = Number(metricValues[index] || 0).toLocaleString(); });
    $('#unit-list').innerHTML = rescueUnits.length ? rescueUnits.map((unit) => `
      <div class="unit-row"><div class="unit-row-head"><strong>${escapeHtml(unit.code)} · ${escapeHtml(unit.name)}</strong><span class="unit-status ${unit.status.toLowerCase()}">${escapeHtml(unit.status)}</span></div><small>${escapeHtml(unit.baseName)}</small><small>${escapeHtml(unit.province.replaceAll('_', '-'))}</small></div>
    `).join('') : '<p class="empty">No rescue units configured.</p>';
    $('#incident-list').innerHTML = rescueIncidents.length ? rescueIncidents.map((incident) => {
      const options = transitionOptions[incident.status] || [];
      return `<article class="incident-card priority-${incident.priority.toLowerCase()}">
        <div class="incident-top"><span class="incident-code">${escapeHtml(incident.code)}</span><span class="priority-label">${escapeHtml(incident.priority)} · ${escapeHtml(incident.status.replaceAll('_', ' '))}</span></div>
        <h3>${escapeHtml(incident.location)}</h3><p>${escapeHtml(incident.description)}</p>
        <div class="incident-meta"><span>${escapeHtml(incident.province.replaceAll('_', '-'))}</span><span>${escapeHtml(incident.callerPhone)}</span><span>${escapeHtml(formatDate(incident.reportedAt))}</span>${incident.unitCode ? `<span>Unit ${escapeHtml(incident.unitCode)}</span>` : ''}</div>
        ${incident.status === 'REPORTED' ? `<div class="incident-actions"><span class="muted">Awaiting response assignment</span><button class="primary-button" data-dispatch-incident="${escapeHtml(incident.id)}" type="button">${icon("truck-medical")}Dispatch unit</button></div>` : options.length ? `<div class="incident-actions"><span class="muted">Update field response</span><div><label class="sr-only" for="status-${escapeHtml(incident.id)}">New incident status</label><select id="status-${escapeHtml(incident.id)}" data-status-select="${escapeHtml(incident.id)}">${options.map((option) => `<option value="${option}">${option.replaceAll('_', ' ')}</option>`).join('')}</select> <button class="primary-button" data-update-incident="${escapeHtml(incident.id)}" type="button">${icon("arrows-rotate")}Update</button></div></div>` : ''}
      </article>`;
    }).join('') : '<div class="empty"><strong>No incidents reported</strong><p>The command queue is clear.</p></div>';
  };

  const loadRescueBoard = async () => renderRescueBoard(await api('/api/rescue/board'));
  const closeIncidentDialog = () => $('#incident-dialog').close();
  const closeDispatchDialog = () => $('#dispatch-dialog').close();

  const openDispatchDialog = (incidentId) => {
    const incident = rescueIncidents.find((item) => item.id === incidentId);
    const available = rescueUnits.filter((unit) => unit.status === 'AVAILABLE' && (!incident || unit.province === incident.province));
    const fallback = rescueUnits.filter((unit) => unit.status === 'AVAILABLE');
    const choices = available.length ? available : fallback;
    $('#dispatch-incident-id').value = incidentId;
    $('#dispatch-unit').innerHTML = choices.map((unit) => `<option value="${escapeHtml(unit.id)}">${escapeHtml(unit.code)} · ${escapeHtml(unit.name)} · ${escapeHtml(unit.baseName)}</option>`).join('');
    $('#confirm-dispatch-button').disabled = choices.length === 0;
    $('#dispatch-form-error').textContent = choices.length ? '' : 'No rescue units are currently available.';
    $('#dispatch-dialog').showModal();
    $('#dispatch-unit').focus();
  };

  /**
   * Money for display.
   *
   * This used to hard-suffix "CDF" on every value regardless of its real
   * currency, which is how a USD fare ended up labelled as francs. It is now a
   * thin delegate to core/currency.js, which knows the display currency, the
   * rate and whether a rate is trustworthy, and which falls back to the ORIGINAL
   * currency rather than guessing.
   *
   * `sourceCurrency` defaults to CDF because the legacy call sites pass values
   * that are already francs; the per-dashboard phases replace those calls with
   * the real source currency as each panel is rebuilt.
   */
  const money = (value, sourceCurrency = 'CDF') => {
    const currency = window.Mamore?.currency;
    return currency
      ? currency.display(value, sourceCurrency)
      : `${Number(value || 0).toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })} ${sourceCurrency}`;
  };
  const renderMobility = (data) => {
    smartBusTrips = data.trips; smartBusRoutes = data.routes; smartBusVehicles = data.vehicles;
    $('#operator-count').textContent = data.operators.length.toLocaleString();
    $('#trip-count').textContent = smartBusTrips.filter((trip) => ['SCHEDULED', 'BOARDING'].includes(trip.status)).length.toLocaleString();
    $('#trip-route').innerHTML = smartBusRoutes.map((route) => `<option value="${escapeHtml(route.id)}">${escapeHtml(route.origin)} → ${escapeHtml(route.destination)} · ${money(route.base_fare_cdf)}</option>`).join('');
    $('#trip-vehicle').innerHTML = smartBusVehicles.map((vehicle) => `<option value="${escapeHtml(vehicle.id)}">${escapeHtml(vehicle.operator_name)} · ${escapeHtml(vehicle.code)} · ${vehicle.capacity} seats</option>`).join('');
    $('#trip-list').innerHTML = smartBusTrips.length ? smartBusTrips.map((trip) => {
      const rescueCdf = trip.rescueFeeUsd * trip.usdCdfRate;
      const v2 = window.MamoreSmartBus || {};
      return `<article class="trip-card"><div class="trip-route"><strong>${escapeHtml(trip.origin)} → ${escapeHtml(trip.destination)}</strong><small>${escapeHtml(trip.code)} · ${escapeHtml(trip.operatorName)} · ${escapeHtml(trip.vehicleCode)}</small><small>${escapeHtml(v2.vehicleLine ? v2.vehicleLine(trip) : '')}</small><small>${escapeHtml(formatDate(trip.departureAt))} · ${escapeHtml(trip.status)}</small>${v2.badgeRow ? v2.badgeRow(trip.badges) : ''}<div class="trip-price">${money(trip.fareCdf)} + ${money(rescueCdf)} rescue</div></div>${v2.boardingGrid ? `<div class="trip-boarding">${v2.boardingGrid(trip.boarding)}</div>` : ''}<div class="trip-capacity"><strong>${trip.capacity - trip.bookedSeats} seats available</strong><small>${trip.bookedSeats} of ${trip.capacity} booked</small><progress class="capacity-track" max="${trip.capacity}" value="${trip.bookedSeats}" aria-label="${trip.bookedSeats} of ${trip.capacity} seats booked"></progress></div><div class="trip-actions"><button class="primary-button" data-book-trip="${escapeHtml(trip.id)}" type="button" ${trip.bookedSeats >= trip.capacity ? 'disabled' : ''}>${icon("ticket")}Book seat</button>${trip.manifestAllowed ? `<button class="secondary-button" data-manifest-trip="${escapeHtml(trip.id)}" type="button">${icon("clipboard-check")}Manifest</button>` : ''}</div></article>`;
    }).join('') : '<div class="empty"><strong>No trips scheduled</strong><p>Create the first departure using the Schedule trip button.</p></div>';
  };
  const loadMobility = async () => {
    const board = await api('/api/smartbus/board');
    renderMobility(board);
    const select = $('#boarding-trip-select');
    if (select) {
      const previous = select.value;
      select.innerHTML = board.trips.map((trip) => `<option value="${escapeHtml(trip.id)}">${escapeHtml(trip.code)} · ${escapeHtml(trip.origin)} → ${escapeHtml(trip.destination)}</option>`).join('');
      if (previous && board.trips.some((trip) => trip.id === previous)) select.value = previous;
    }
  };
  const closeTripDialog = () => $('#trip-dialog').close();
  const closeBookingDialog = () => $('#booking-dialog').close();
  const openBookingDialog = (tripId) => {
    const trip = smartBusTrips.find((item) => item.id === tripId); if (!trip) return;
    $('#booking-form').reset(); $('#booking-trip-id').value = trip.id; $('#selected-seat').value = ''; $('#booking-form-error').textContent = '';
    if (customerMode && currentUser) { $('#passenger-name').value = `${currentUser.firstName} ${currentUser.lastName}`.trim(); $('#passenger-phone').value = currentUser.phone || ''; }
    $('#seat-map').innerHTML = Array.from({ length: trip.capacity }, (_, index) => { const seat = index + 1; const occupied = trip.occupiedSeats.includes(seat); return `<button class="seat ${occupied ? 'occupied' : ''}" data-seat="${seat}" type="button" ${occupied ? 'disabled' : ''} aria-label="Seat ${seat}${occupied ? ', occupied' : ''}">${seat}</button>`; }).join('');
    const rescueCdf = trip.rescueFeeUsd * trip.usdCdfRate;
    $('#fare-preview').innerHTML = `Fare: <strong>${money(trip.fareCdf)}</strong><br>Rescue fee: <strong>USD ${trip.rescueFeeUsd.toFixed(2)} (${money(rescueCdf)})</strong><br>Total: <strong>${money(trip.fareCdf + rescueCdf)}</strong>`;
    $('#booking-dialog').showModal(); $('#passenger-name').focus();
  };

  const renderFinance = (data) => {
    unpaidBookings = data.unpaidBookings;
    const values = [data.metrics.paymentsToday, money(data.metrics.collectedCdf), money(data.metrics.rescueFundCdf), money(data.metrics.varianceCdf)];
    $$('#finance-metrics strong').forEach((element, index) => { element.textContent = values[index]; });
    $('#unpaid-list').innerHTML = unpaidBookings.length ? unpaidBookings.map((booking) => `<div class="payment-row"><div><strong>${escapeHtml(booking.reference)} · ${escapeHtml(booking.passengerName)}</strong><small>${escapeHtml(booking.operatorName)} · ${escapeHtml(booking.origin)} → ${escapeHtml(booking.destination)}</small><small>${money(booking.totalCdf)} including ${money(booking.rescueFeeCdf)} rescue</small></div><button class="row-action" data-receive-payment="${escapeHtml(booking.id)}" type="button">${icon("credit-card")}Receive</button></div>`).join('') : '<p class="empty">No unpaid tickets.</p>';
    $('#transaction-list').innerHTML = data.transactions.length ? data.transactions.map((transaction) => `<div class="transaction-row"><div><strong>${escapeHtml(transaction.receiptNumber)}</strong><small>${escapeHtml(transaction.bookingReference || 'Manual')} · ${escapeHtml(transaction.method.replaceAll('_', ' '))}</small><small>${escapeHtml(formatDate(transaction.receivedAt))}</small></div><div class="transaction-amount"><strong>${money(transaction.amountCdf)}</strong><small class="${transaction.status === 'VARIANCE' ? 'variance' : ''}">${escapeHtml(transaction.status)}${transaction.varianceCdf ? ` · ${money(transaction.varianceCdf)}` : ''}</small></div></div>`).join('') : '<p class="empty">No payments recorded.</p>';
  };
  const loadFinance = async () => renderFinance(await api('/api/finance/board'));
  const closePaymentDialog = () => $('#payment-dialog').close();
  const setPaymentAmount = () => {
    const booking = unpaidBookings.find((item) => item.id === $('#payment-booking-id').value); if (!booking) return;
    const rate = Number($('#payment-rate').value || 1);
    $('#payment-amount').value = $('#payment-currency').value === 'USD' ? (booking.totalCdf / rate).toFixed(2) : booking.totalCdf.toFixed(2);
  };
  const openPaymentDialog = (bookingId) => {
    const booking = unpaidBookings.find((item) => item.id === bookingId); if (!booking) return;
    $('#payment-form').reset(); $('#payment-booking-id').value = booking.id; $('#payment-rate').value = '2850'; $('#payment-currency').value = 'CDF';
    $('#payment-booking-summary').innerHTML = `<strong>${escapeHtml(booking.reference)}</strong><br>${escapeHtml(booking.passengerName)} · ${escapeHtml(booking.operatorName)}<br>Expected: <strong>${money(booking.totalCdf)}</strong>`;
    $('#payment-form-error').textContent = ''; setPaymentAmount(); $('#payment-dialog').showModal(); $('#payment-method').focus();
  };

  const renderTracking = (data) => {
    trackingAssets = data.assets;
    // Three states kept distinct, matching the service and the five cells in
    // the panel. Summing stale + noSignal here reported a device that has never
    // checked in as one with a stale signal.
    const values=[data.metrics.assets,data.metrics.live,data.metrics.stale,data.metrics.noSignal,data.metrics.locations];
    $$('#tracking-metrics strong').forEach((element,index)=>{element.textContent=Number(values[index]||0).toLocaleString();});
    $('#position-asset').innerHTML=trackingAssets.map((asset)=>`<option value="${escapeHtml(asset.id)}">${escapeHtml(asset.code)} · ${escapeHtml(asset.label)}</option>`).join('');
    $('#tracking-assets').innerHTML=trackingAssets.length?trackingAssets.map((asset)=>`<div class="tracking-row"><div><strong>${escapeHtml(asset.code)} · ${escapeHtml(asset.label)}</strong><small>${escapeHtml(asset.type.replaceAll('_',' '))}${asset.latitude!==null?` · ${asset.latitude.toFixed(5)}, ${asset.longitude.toFixed(5)}`:' · No position yet'}</small><small>${asset.speedKph!==null?`${asset.speedKph.toFixed(1)} km/h · `:''}${asset.recordedAt?escapeHtml(formatDate(asset.recordedAt)):'Awaiting GPS check-in'}</small></div><span class="signal ${asset.signalStatus.toLowerCase()}">${escapeHtml(asset.signalStatus.replaceAll('_',' '))}</span></div>`).join(''):'<p class="empty">No tracking assets configured.</p>';
    $('#service-location-list').innerHTML=data.locations.length?data.locations.map((location)=>`<div class="tracking-row"><div><strong>${escapeHtml(location.name)}</strong><small>${escapeHtml(location.type.replaceAll('_',' '))} · ${escapeHtml(location.province.replaceAll('_','-'))}</small><small>${location.latitude.toFixed(5)}, ${location.longitude.toFixed(5)}</small></div></div>`).join(''):'<p class="empty">Add hospitals, garages, fuel stations and command bases to enable nearest-resource calculations.</p>';
  };
  const loadTracking=async()=>renderTracking(await api('/api/tracking/board'));
  const closePositionDialog=()=>$('#position-dialog').close(); const closeLocationDialog=()=>$('#location-dialog').close();
  const loadPanicAlerts=async()=>{const data=await api('/api/alerts/board');panicAlerts=data.alerts;const values=[data.metrics.active,data.metrics.acknowledged,data.metrics.resolved];$$('#alert-metrics strong').forEach((element,index)=>{element.textContent=Number(values[index]||0).toLocaleString();});$('#panic-alert-list').innerHTML=panicAlerts.length?panicAlerts.map((alert)=>`<article class="panic-row"><div><h3>${escapeHtml(alert.code)} · ${escapeHtml(alert.subscriberName||'Subscriber')}</h3><p>${escapeHtml(alert.location)} · ${escapeHtml(alert.phone||alert.email||'No contact')}</p><p>${escapeHtml(alert.message||'Emergency assistance requested')} · Incident ${escapeHtml(alert.incidentCode)}</p><p>${escapeHtml(formatDate(alert.activatedAt))}${alert.latitude!==null?` · ${alert.latitude.toFixed(5)}, ${alert.longitude.toFixed(5)}`:''}</p></div><div><span class="status-badge ${alert.status==='ACTIVE'?'':'active'}">${escapeHtml(alert.status)}</span>${alert.status==='ACTIVE'?`<button class="primary-button" data-ack-alert="${escapeHtml(alert.id)}" type="button">${icon("check")}Acknowledge</button>`:''}</div></article>`).join(''):'<p class="empty">No panic alerts.</p>';};
  const loadMyAlerts=async()=>{const{alerts}=await api('/api/portal/sos');const active=alerts.find((alert)=>['ACTIVE','ACKNOWLEDGED'].includes(alert.status));$('#my-alert-status').innerHTML=active?`<div class="my-alert"><strong>${escapeHtml(active.code)} · ${escapeHtml(active.status)}</strong><br>Mamore HQ received your emergency request for ${escapeHtml(active.location)}. Incident ${escapeHtml(active.incidentCode)}.</div>`:'';};

  const renderPortalTrips = (trips) => {
    smartBusTrips = trips;
    $('#portal-trip-list').innerHTML = trips.length ? trips.map((trip) => {
      const rescueCdf = trip.rescueFeeUsd * trip.usdCdfRate;
      return `<article class="portal-trip"><div class="portal-trip-head"><span class="incident-code">${escapeHtml(trip.code)}</span><span class="status-badge active">${trip.capacity - trip.bookedSeats} seats</span></div><h3>${escapeHtml(trip.origin)} → ${escapeHtml(trip.destination)}</h3><p>${escapeHtml(trip.operatorName)} · ${escapeHtml(trip.vehicleCode)}</p><p>${escapeHtml(formatDate(trip.departureAt))}</p><div class="portal-trip-foot"><div class="portal-price"><strong>${money(trip.fareCdf + rescueCdf)}</strong><small>Includes USD ${trip.rescueFeeUsd.toFixed(2)} rescue cover</small></div><button class="primary-button" data-portal-book-trip="${escapeHtml(trip.id)}" type="button">${icon("ticket")}Choose seat</button></div></article>`;
    }).join('') : '<div class="empty"><strong>No upcoming departures</strong><p>New trips will appear here as operators publish schedules.</p></div>';
  };
  const loadPortalTrips = async () => { const { trips } = await api('/api/portal/trips'); renderPortalTrips(trips); };
  const loadMyBookings = async () => {
    const { bookings } = await api('/api/portal/bookings');
    $('#my-bookings-list').innerHTML = bookings.length ? bookings.map((booking) => `<article class="my-booking"><div><h3>${escapeHtml(booking.origin)} → ${escapeHtml(booking.destination)}</h3><p>${escapeHtml(booking.reference)} · ${escapeHtml(booking.operatorName)} · Seat ${booking.seatNumber}</p><p>${escapeHtml(formatDate(booking.departureAt))}</p><p>Total ${money(booking.totalCdf)} · Rescue cover USD ${booking.rescueFeeUsd.toFixed(2)}</p></div><div class="ticket-status"><strong>${escapeHtml(booking.status)}</strong><small>${escapeHtml(booking.paymentStatus)}${booking.receiptNumber ? ` · ${escapeHtml(booking.receiptNumber)}` : ''}</small></div></article>`).join('') : '<div class="empty"><strong>No bookings yet</strong><p>Choose an available trip to create your first ticket.</p></div>';
  };

  // Navigation is fetched, not hard-coded. The server decides which
  // destinations this role may open; the shell only renders them.
  const loadNavigation = async () => {
    const { navigation } = await api('/api/navigation');
    window.Mamore.shell.render(navigation);
    return navigation;
  };

  // A language change re-renders the sidebar: Navigation resolves its labels on
  // the server, so the DOM it produced is now in the previous language.
  document.addEventListener('mamore:reloadnavigation', () => {
    loadNavigation().catch(() => { /* keep the current labels rather than blanking them */ });
  });

  const showApp = async (user) => {
    currentUser = user;
    customerMode = user.role === 'CUSTOMER';
    $('#login-view').hidden = true;
    $('#app-view').hidden = false;
    $('#user-name').textContent = `${user.firstName} ${user.lastName}`.trim();
    $('#account-role').textContent = user.role.replaceAll('_', ' ');

    // Legacy scope markers are kept for the panel markup that still uses them,
    // but the sidebar itself is now driven by the fetched navigation.
    $$('.admin-only').forEach((element) => { element.hidden = customerMode; });
    $$('.customer-only').forEach((element) => { element.hidden = !customerMode; });

    try {
      const navigation = await loadNavigation();
      // The landing panel is chosen by the server, so a CONDUCTER lands on the
      // first thing they can actually do rather than on an Overview that would
      // be empty for them.
      const landing = navigation.landing || (customerMode ? 'portal' : 'overview');
      if (customerMode) $('#portal-greeting').textContent = `Where to next, ${user.firstName}?`;
      switchPanel(Mamore.shell.panelFromUrl() || landing);
      window.Mamore.shell.onPopState((panel) => switchPanel(panel));
    } catch (error) {
      // The shell must still be usable if the navigation call fails; the
      // panel switcher keeps its own allow-list as a fallback.
      toast(error.message);
      switchPanel(customerMode ? 'portal' : 'overview');
    }

    try { await (customerMode ? Promise.all([loadPortalTrips(), loadMyBookings(), loadMyAlerts(), loadSessions()]) : Promise.all([loadDashboard(), loadSessions()])); }
    catch (error) { toast(error.message); }
  };

  // Shared with the feature scripts (subscriptions.js): they register panel
  // loaders here instead of duplicating the api/auth helpers.
  const noopPanel = async () => {};
  const Mamore = window.Mamore || {
    panels: ['overview', 'users', 'sessions', 'alerts', 'rescue', 'tracking', 'mobility', 'finance', 'portal', 'mybookings', 'subscriptions', 'receipts', 'audit', 'notifications', 'membership', 'command', 'boarding', 'operations', 'analytics', 'vip', 'truckcargo', 'privatevehicles'],
    labels: { overview: 'Overview', users: 'User administration', sessions: 'Security & sessions', alerts: 'Panic alerts', rescue: 'Rescue operations', tracking: 'Live tracking', mobility: 'Smart mobility', finance: 'Finance', portal: 'Find a trip', mybookings: 'My bookings', subscriptions: 'Rescue subscriptions', receipts: 'Receipts', audit: 'Audit trail', notifications: 'Notifications', membership: 'My rescue cover', command: 'Smart Bus command centre', boarding: 'Boarding & manifest', operations: 'Rescue operations', analytics: 'Operational intelligence', vip: 'VIP subscribers', truckcargo: 'Truck & cargo', privatevehicles: 'My vehicles' },
    loaders: {},
  };
  /**
   * The executive overview renderer.
   *
   * Follows the seven-layer contract in docs/ui-v2/DASHBOARD_ARCHITECTURE.md:
   * summary, KPI row, exception-first Action Center, Operations Pulse, money.
   *
   * Every number goes through the currency module, so switching the display
   * currency re-renders the whole screen without a round trip. Anything the
   * server did not send is rendered as an explicit state rather than a zero.
   */
  const renderExecutive = (data) => {
    const kpis = Array.isArray(data.kpis) ? data.kpis : [];
    const actions = Array.isArray(data.actionCenter) ? data.actionCenter : [];
    const pulse = Array.isArray(data.pulse) ? data.pulse : [];
    const money = window.Mamore?.currency;

    /* -- summary --------------------------------------------------------- */
    const tone = data.summary?.state === 'critical' ? 'critical' : (data.summary?.state === 'attention' ? 'warning' : 'success');
    const summaryHtml = `
      <div class="alert alert--${tone} executive-summary">
        <span class="executive-summary__icon">${icon(tone === 'success' ? 'circle-check' : 'triangle-exclamation')}</span>
        <div class="alert__body">
          <p class="executive-summary__text">${escapeHtml(data.summary?.sentence || 'No summary available.')}</p>
          <p class="executive-summary__stamp">Generated ${escapeHtml(formatDate(data.generatedAt))}</p>
        </div>
      </div>`;

    /* -- KPI row --------------------------------------------------------- */
    // A KPI states its comparison period, and shows a context line instead of a
    // percentage when there is no baseline. No metric invents a trend.
    const kpiHtml = kpis.map((kpi) => {
      const isMoney = kpi.currency !== undefined;
      const value = isMoney
        ? (money ? money.display(kpi.value, kpi.currency) : String(kpi.value))
        : Number(kpi.value || 0).toLocaleString();

      const trend = kpi.comparison
        ? `<span class="metric__trend" data-direction="${escapeHtml(kpi.comparison.direction)}">
             ${kpi.comparison.direction === 'up' ? '&#9650;' : kpi.comparison.direction === 'down' ? '&#9660;' : '&#9632;'}
             ${Math.abs(kpi.comparison.value)}% <span class="text-muted">${escapeHtml(kpi.comparison.label)}</span>
           </span>`
        : '';

      const context = kpi.context ? `<p class="metric__context">${escapeHtml(kpi.context)}</p>` : '';
      const critical = kpi.critical ? `<p class="metric__critical">${Number(kpi.critical).toLocaleString()} critical</p>` : '';
      const attrs = isMoney && money
        ? `data-money data-amount="${escapeHtml(kpi.value)}" data-currency="${escapeHtml(kpi.currency)}"`
        : '';

      return `<article class="metric" data-good-direction="${escapeHtml(kpi.direction || 'up')}">
        <p class="metric__label">${escapeHtml(kpi.labelKey)}</p>
        <p class="metric__value${isMoney ? ' is-money' : ''}" ${attrs}>${escapeHtml(value)}</p>
        ${trend}${critical}${context}
      </article>`;
    }).join('');

    const kpiRow = kpis.length
      ? `<div class="grid executive-kpis">${kpiHtml}</div>`
      : (window.Mamore?.states
        ? Mamore.states.empty({ title: 'No metrics available', body: 'Nothing could be counted for this period.' })
        : '<div class="empty-state"><p class="empty-state__title">No metrics available</p></div>');

    /* -- 3. Trend (layer 3) ----------------------------------------------- */
    // A sparkline is a shape claim. Bars are drawn for EVERY date in the
    // declared spine, so a quiet day is a short bar rather than a missing one.
    // Skipping empty days would rescale the axis and turn a calm fortnight
    // into a spike -- the most common way a sparkline lies.
    const trend = data.trend || {};
    const sparkline = (values, dates) => {
      if (!Array.isArray(values) || !values.length) return '';
      const peak = Math.max(...values, 1);
      return `<div class="sparkline" role="img" aria-label="Daily activity over the period">${values.map((v, i) => {
        // A real zero is drawn at a minimum visible height, not at nothing:
        // a zero-height bar is indistinguishable from a missing one.
        const height = v === 0 ? 2 : Math.max(6, Math.round((v / peak) * 38));
        const label = dates && dates[i] ? dates[i] : `day ${i + 1}`;
        return `<span class="sparkline__bar" data-zero="${v === 0}" style="height:${height}px" title="${escapeHtml(label)}: ${Number(v).toLocaleString()}"></span>`;
      }).join('')}</div>`;
    };

    const series = Array.isArray(trend.series) ? trend.series : [];
    const trendHtml = series.length
      ? (trend.hasHistory
        ? series.map((s) => `
            <div class="trend-row">
              <span class="trend-row__label">${escapeHtml(s.labelKey)}</span>
              <span class="trend-row__plot">${sparkline(s.values, trend.dates)}</span>
              <span class="trend-row__total">${Number(s.values.reduce((a, b) => a + Number(b || 0), 0)).toLocaleString()}</span>
            </div>`).join('')
        // No history is not a flat line. It is a sentence, and saying so is the
        // whole difference between an honest chart and a decorative one.
        : `<p class="trend-empty">No activity recorded in the last ${escapeHtml(String(trend.window || '14d'))}, so there is no trend to show.</p>`)
      : '';

    /* -- 4. Action Center ------------------------------------------------ */
    // Exception-first. Each row opens the workflow that resolves it, so an
    // alert the reader cannot act on is not shown at all.
    const actionHtml = actions.length
      ? `<div class="action-center">${actions.map((row) => `
          <button class="action-center__row" type="button" data-severity="${escapeHtml(row.severity)}" data-open-panel="${escapeHtml(row.panel)}">
            <span class="action-center__severity">${escapeHtml(row.severity)}</span>
            <span>
              <span class="action-center__title">${escapeHtml(row.titleKey)}</span>
              <span class="action-center__meta">${Number(row.count).toLocaleString()} ${escapeHtml(row.unit)}</span>
            </span>
            <span class="action-center__age">${icon('arrow-right-long')}</span>
          </button>`).join('')}</div>`
      : (window.Mamore?.states
        ? Mamore.states.empty({
            icon: 'circle-check',
            title: 'Nothing needs attention',
            body: 'All monitored operations are currently clear.',
          })
        : '<div class="empty-state"><p class="empty-state__title">Nothing needs attention</p></div>');

    /* -- Operations Pulse ------------------------------------------------ */
    const pulseHtml = pulse.length
      ? `<div class="pulse">${pulse.map((row) => `
          <div class="pulse__row">
            <span class="pulse__service">${escapeHtml(row.key)}</span>
            <span class="pulse__value" data-state="${escapeHtml(row.state)}">${escapeHtml(row.value)}</span>
          </div>`).join('')}</div>`
      : '';

    /* -- 6. Detail (layer 6) and 7. drilldown ----------------------------- */
    // The records behind each Action Center count, so "12 unpaid" is
    // checkable. The cap is stated explicitly: a short list must never be
    // mistaken for the whole story.
    const attention = data.attention || {};
    const groupLabels = { incidents: 'Open incidents', unpaid: 'Unpaid tickets' };
    const detailHtml = Object.entries(attention).map(([key, group]) => {
      const rows = Array.isArray(group.rows) ? group.rows : [];
      if (!rows.length) return '';
      return `
        <section class="card">
          <div class="card__header">
            <h3 class="card__title">${escapeHtml(groupLabels[key] || key)}</h3>
            <span class="text-muted t-caption">${Number(group.count).toLocaleString()} total</span>
          </div>
          <div class="detail-list">
            ${rows.map((row) => `
              <button class="detail-row" type="button"
                      data-detail-group="${escapeHtml(key)}"
                      data-detail-id="${escapeHtml(row.id)}"
                      data-detail-ref="${escapeHtml(row.reference)}"
                      data-detail-status="${escapeHtml(row.status)}"
                      data-detail-severity="${escapeHtml(row.severity)}"
                      data-detail-meta="${escapeHtml(row.meta)}"
                      data-detail-when="${escapeHtml(row.at || '')}"
                      data-detail-amount="${escapeHtml(row.amount || '')}"
                      data-detail-currency="${escapeHtml(row.currency || '')}">
                <span>
                  <span class="detail-row__ref">${escapeHtml(row.reference)}</span>
                  <span class="detail-row__meta">${escapeHtml(row.meta)}</span>
                </span>
                <span class="detail-row__when">${escapeHtml(formatDate(row.at))}</span>
              </button>`).join('')}
          </div>
          ${Number(group.count) > rows.length
            ? `<p class="detail-cap">Showing the ${rows.length} most recent of ${Number(group.count).toLocaleString()}.</p>`
            : ''}
        </section>`;
    }).join('');

    /* -- 5. money ------------------------------------------------------------ */
    const revenue = data.revenue || {};
    const collected = money
      ? money.display(revenue.collectedToday ?? '0.00', revenue.currency ?? 'USD')
      : String(revenue.collectedToday ?? '0.00');
    const revenueAttrs = money
      ? `data-money data-amount="${escapeHtml(revenue.collectedToday ?? '0.00')}" data-currency="${escapeHtml(revenue.currency ?? 'USD')}"`
      : '';

    const revenueHtml = `
      <section class="card">
        <div class="card__header"><h2 class="card__title">Collections today</h2></div>
        <div class="card__body">
          <p class="metric__value is-money" ${revenueAttrs}>${escapeHtml(collected)}</p>
          <p class="metric__context">
            ${Number(revenue.paymentsToday || 0).toLocaleString()} payments received ·
            ${Number(revenue.outstandingBookings || 0).toLocaleString()} tickets outstanding
          </p>
        </div>
      </section>`;

    $('#executive-body').innerHTML = `
      ${summaryHtml}
      ${kpiRow}
      <div class="grid executive-lower">
        <section class="card col-two-thirds">
          <div class="card__header">
            <h2 class="card__title">Requires attention</h2>
            <span class="text-muted t-caption">${actions.length} item${actions.length === 1 ? '' : 's'}</span>
          </div>
          <div class="card__body card__body--flush">${actionHtml}</div>
        </section>
        <div class="col-third stack">
          <section class="card">
            <div class="card__header"><h2 class="card__title">System status</h2></div>
            <div class="card__body">${pulseHtml}</div>
          </section>
          ${revenueHtml}
        </div>
      </div>
      ${trendHtml ? `
      <div class="grid executive-lower">
        <section class="card col-full">
          <div class="card__header">
            <h2 class="card__title">Activity over time</h2>
            <span class="text-muted t-caption">${escapeHtml(String(trend.window || ''))}</span>
          </div>
          <div class="card__body">${trendHtml}</div>
        </section>
      </div>` : ''}
      ${detailHtml ? `<div class="grid executive-lower">${detailHtml}</div>` : ''}`;
  };

  /**
   * Layer 7: the drilldown.
   *
   * A detail row opens the record in the shell's existing #detail-dialog, so
   * the executive view reuses a dialog that already works rather than adding a
   * second one. The dialog shows what the dashboard already knows -- it does not
   * re-fetch, so a row can never disagree with the list it was clicked from.
   */
  const openExecutiveDetail = (row) => {
    const dialog = $('#detail-dialog');
    if (!dialog) return;

    const amount = row.dataset.detailAmount;
    const currency = row.dataset.detailCurrency;
    const money = window.Mamore?.currency;
    const amountLine = amount
      ? `<div class="pulse__row"><span class="pulse__service">Amount due</span><span class="pulse__value" data-state="degraded" ${money ? `data-money data-amount="${escapeHtml(amount)}" data-currency="${escapeHtml(currency)}"` : ''}>${money ? escapeHtml(money.display(amount, currency)) : escapeHtml(amount)}</span></div>`
      : '';

    $('#detail-title').textContent = row.dataset.detailRef || 'Record';
    $('#detail-body').innerHTML = `
      <div class="pulse__row"><span class="pulse__service">Status</span><span class="pulse__value" data-state="${row.dataset.detailSeverity === 'critical' ? 'down' : 'degraded'}">${escapeHtml(row.dataset.detailStatus || '—')}</span></div>
      <div class="pulse__row"><span class="pulse__service">Context</span><span class="pulse__value" data-state="ok">${escapeHtml(row.dataset.detailMeta || '—')}</span></div>
      <div class="pulse__row"><span class="pulse__service">Reported</span><span class="pulse__value" data-state="ok">${escapeHtml(formatDate(row.dataset.detailWhen))}</span></div>
      ${amountLine}`;
    $('#detail-print-link').hidden = true;
    dialog.showModal();
  };

  const loadExecutive = async () => {
    const mount = $('#executive-body');
    // A skeleton matching the final geometry, so nothing shifts when data lands.
    if (mount && window.Mamore?.states) mount.innerHTML = Mamore.states.skeleton({ kind: 'metric' });

    const { executive } = await api('/api/executive');
    if (window.MamoreSmartBus) window.MamoreSmartBus.setServerEpoch(executive.serverEpoch);
    renderExecutive(executive);
  };

  /**
   * The global search palette.
   *
   * The shell shipped a search input and a CMD-K hint with NOTHING bound to
   * them, so the affordance was decorative. This binds it.
   *
   * Three rules:
   *  - the result list is whatever the SERVER decided this role may see.
   *    GlobalSearch filters domains in SQL, so there is nothing to filter here
   *    and no way for the client to widen it;
   *  - a role with no searchable domains is told so, rather than shown an
   *    empty box that looks broken;
   *  - nothing is invented client-side. No local filtering of results the
   *    server did not send, no grouping that implies structure we do not have.
   */
  const SEARCH_KIND_LABELS = {
    RESCUE_CODE: 'Rescue codes', VEHICLE: 'Vehicles', BOOKING: 'Bookings',
    TRIP: 'Trips', VIP: 'VIP members', CONSIGNMENT: 'Consignments',
    PERSON: 'People', SUBSCRIBER: 'Subscribers', INCIDENT: 'Incidents',
    SUBSCRIPTION: 'Subscriptions', TRUCK: 'Trucks', PLATE: 'Plates',
  };

  const initGlobalSearch = () => {
    const input = $('[data-global-search]');
    const results = $('#global-search-results');
    if (!input || !results) return;

    let timer = null;
    let rows = [];
    let cursor = -1;

    const close = () => {
      results.hidden = true;
      input.setAttribute('aria-expanded', 'false');
      cursor = -1;
    };

    const say = (html) => {
      results.innerHTML = html;
      results.hidden = false;
      input.setAttribute('aria-expanded', 'true');
    };

    const render = (payload) => {
      const list = Array.isArray(payload.results) ? payload.results : [];

      // The server's own explanation wins: "no searchable domains for this
      // role" is a different situation from "nothing matched", and only the
      // server knows which of the two it is.
      if (list.length === 0) {
        say(`<p class="palette__message">${escapeHtml(
          payload.message || `No matches for “${payload.query || ''}”.`
        )}</p>`);
        return;
      }

      // Grouped by kind, in the order the server returned them, so the grouping
      // reflects the query rather than a client-side alphabetisation.
      const groups = new Map();
      list.forEach((row) => {
        const kind = row.kind || 'OTHER';
        if (!groups.has(kind)) groups.set(kind, []);
        groups.get(kind).push(row);
      });

      results.innerHTML = [...groups.entries()].map(([kind, items]) => `
        <div class="palette__group">
          <p class="palette__group-label">${escapeHtml(SEARCH_KIND_LABELS[kind] || kind.replace(/_/g, ' '))}</p>
          ${items.map((row) => `
            <button class="palette__row" type="button" role="option" aria-selected="false"
                    data-palette-kind="${escapeHtml(kind)}" data-palette-id="${escapeHtml(row.id || '')}">
              <span class="palette__row-ref">${escapeHtml(row.reference || row.id || '')}</span>
              <span class="palette__row-meta">${escapeHtml(row.secondary || '')}</span>
              ${row.status ? `<span class="palette__row-status">${escapeHtml(row.status)}</span>` : ''}
            </button>`).join('')}
        </div>`).join('');

      rows = [...results.querySelectorAll('.palette__row')];
      results.hidden = false;
      input.setAttribute('aria-expanded', 'true');
    };

    const run = async (term) => {
      // GlobalSearch enforces its own minimum; asking for one character would
      // just earn a 422.
      if (term.trim().length < 2) { close(); return; }
      try {
        render(await api(`/api/search?q=${encodeURIComponent(term)}`));
      } catch (error) {
        // A failed search must not look like "no results". It looks like a
        // failure, which is a different thing and is recoverable.
        say(`<p class="palette__message palette__message--error">${escapeHtml(error.message)}</p>`);
      }
    };

    input.addEventListener('input', () => {
      clearTimeout(timer);
      const term = input.value;
      if (term.trim().length < 2) { close(); return; }
      // Debounced: even a two-character minimum allows fast typing, and firing
      // a query per keystroke would hammer a permission-checked endpoint.
      timer = setTimeout(() => run(term), 180);
    });

    input.addEventListener('keydown', (event) => {
      if (event.key === 'Escape') { close(); return; }
      if (results.hidden || rows.length === 0) return;

      if (event.key === 'ArrowDown' || event.key === 'ArrowUp') {
        event.preventDefault();
        cursor = event.key === 'ArrowDown'
          ? (cursor + 1) % rows.length
          : (cursor - 1 + rows.length) % rows.length;
        rows.forEach((row, index) => row.setAttribute('aria-selected', String(index === cursor)));
        rows[cursor].scrollIntoView({ block: 'nearest' });
        return;
      }

      if (event.key === 'Enter' && cursor >= 0) {
        event.preventDefault();
        rows[cursor].click();
      }
    });

    results.addEventListener('click', (event) => {
      const row = event.target.closest('[data-palette-id]');
      if (!row) return;
      close();
      input.value = '';
      // Dispatched rather than hard-wired: the row knows its own kind and the
      // destination is declared in Navigation, so the palette never invents a
      // route or reaches around the permission-aware navigation.
      document.dispatchEvent(new CustomEvent('mamore:open-record', {
        detail: { kind: row.dataset.paletteKind, id: row.dataset.paletteId },
      }));
    });

    document.addEventListener('click', (event) => {
      if (!event.target.closest('.topbar__search')) close();
    });

    // The CMD-K hint has to actually work, or it is a lie in the interface.
    document.addEventListener('keydown', (event) => {
      if (event.key !== 'k' || !(event.metaKey || event.ctrlKey)) return;
      event.preventDefault();
      input.focus();
      input.select();
    });
  };

  // A search result routes to the workflow that can act on it. The map is
  // declared here rather than fetched, so it is auditable in one place.
  document.addEventListener('mamore:open-record', (event) => {
    const { kind } = event.detail || {};
    const target = {
      RESCUE_CODE: 'rescue', INCIDENT: 'rescue', VEHICLE: 'tracking',
      TRUCK: 'truckcargo', CONSIGNMENT: 'truckcargo', BOOKING: 'finance',
      SUBSCRIPTION: 'subscriptions', VIP: 'vip', TRIP: 'command',
    }[kind];
    if (target) switchPanel(target);
  });

  /**
   * The shared domain-dashboard renderer.
   *
   * Phases 15-20 are six domains, and the obvious failure mode is six bespoke
   * rewrites that drift apart. So there is ONE renderer and a config per
   * domain: the same summary / KPI / breakdown grammar everywhere, and a domain
   * that needs something extra adds it to its config rather than forking the
   * whole screen.
   *
   * Strict about three things, because those are what the v1 panels got wrong:
   *
   *  1. NO DATA IS NOT ZERO. A service that answers with `message` instead of
   *     rows is describing an empty dataset, not a set of zeroes.
   *  2. Every number comes from the payload. Nothing is derived client-side
   *     from a field that might be absent.
   *  3. A metric with no currency is never formatted as money, and a MASS is
   *     never formatted as money either -- that was the Phase 11 defect.
   */
  const DOMAIN_DASHBOARDS = {
    vip: {
      mount: '#vip-body',
      endpoint: '/api/vip/dashboard',
      title: 'VIP members',
      kpis: [
        { key: 'total', label: 'Total members' },
        { key: 'active', label: 'Active', direction: 'up' },
        { key: 'covered', label: 'With rescue coverage', direction: 'up' },
        { key: 'expiringSoon', label: 'Expiring in 30 days', direction: 'down' },
        { key: 'incidents', label: 'Incidents involving VIPs', direction: 'down' },
      ],
      breakdowns: [
        { key: 'byStatus', label: 'By status' },
        { key: 'byPlan', label: 'By plan' },
        { key: 'byGeography', label: 'By province' },
      ],
      // Metrics this summary screen deliberately does not show, named so the
      // omission is a decision on record rather than an oversight. Each is
      // available in the full subscriber list below the summary.
      notShown: {
        pending: 'shown in the subscriber list filter',
        suspended: 'shown in the subscriber list filter',
        expired: 'shown in the subscriber list filter',
        coveredVehicles: 'a per-subscriber count, meaningless as a fleet total',
        activeJourneys: 'belongs on the Smart Bus screen',
      },
    },
    truckcargo: {
      mount: '#truck-body',
      endpoint: '/api/truck-cargo/analytics',
      title: 'Truck & cargo',
      kpis: [
        { key: 'fleet', label: 'Fleet' },
        { key: 'inTransit', label: 'In transit', direction: 'up' },
        { key: 'delayed', label: 'Delayed', direction: 'down' },
        { key: 'breakdowns', label: 'Breakdowns', direction: 'down' },
        { key: 'openIncidents', label: 'Open incidents', direction: 'down' },
      ],
      // Weight is a MASS. Declared as a unit so it cannot be mistaken for money.
      secondary: [{ key: 'cargoWeightInTransitKg', label: 'Cargo in motion', unit: 'kg' }],
      breakdowns: [{ key: 'cargoByCategory', label: 'Cargo by category' }],
      notShown: {
        cargoInTransit: 'a consignment count that duplicates "in transit"',
        coveredTrucks: 'shown on the coverage panel',
        activeDrivers: 'belongs on the driver screen',
        trackingOnline: 'belongs on the tracking screen',
        trackingOffline: 'belongs on the tracking screen',
      },
    },
    privatevehicles: {
      mount: '#private-body',
      endpoint: '/api/private-vehicles/analytics',
      title: 'Private vehicles',
      kpis: [
        { key: 'vehicles', label: 'Vehicles' },
        { key: 'covered', label: 'Covered', direction: 'up' },
        { key: 'trackingOnline', label: 'Reporting now', direction: 'up' },
        { key: 'openJourneys', label: 'Open journeys' },
        { key: 'activeIncidents', label: 'Active incidents', direction: 'down' },
      ],
    },
  };

  /**
   * Render one domain dashboard into its mount point.
   *
   * @param {string} domain   key into DOMAIN_DASHBOARDS
   * @param {object} payload  the service's own dashboard() response
   */
  const renderDomainDashboard = (domain, payload) => {
    const config = DOMAIN_DASHBOARDS[domain];
    const mount = config && $(config.mount);
    if (!config || !mount) return;

    const metrics = payload && typeof payload.metrics === 'object' && payload.metrics !== null
      ? payload.metrics
      : {};

    /* -- the empty case comes first ------------------------------------- */
    // The service already decided this dataset is empty and said so. A row of
    // zeroes here would contradict the server it came from.
    if (payload && payload.message && !Object.keys(metrics).length) {
      mount.innerHTML = window.Mamore?.states
        ? Mamore.states.empty({ title: 'No data available', body: payload.message })
        : `<p class="empty">${escapeHtml(payload.message)}</p>`;
      return;
    }

    /* -- KPI row -------------------------------------------------------- */
    const kpiHtml = config.kpis.map((kpi) => {
      const value = metrics[kpi.key];
      // An absent key is UNKNOWN. Rendering it as 0 is the exact defect this
      // whole redesign exists to remove.
      const unknown = value === undefined || value === null;
      const shown = unknown ? '—' : Number(value).toLocaleString();
      const tone = kpi.direction === 'down' && !unknown && Number(value) > 0 ? 'critical' : '';

      return `<article class="metric"${tone ? ` data-tone="${tone}"` : ''}>
        <p class="metric__label">${escapeHtml(kpi.label)}</p>
        <p class="metric__value">${escapeHtml(shown)}</p>
      </article>`;
    }).join('');

    const secondaryHtml = (config.secondary || []).map((row) => {
      const value = metrics[row.key];
      const unknown = value === undefined || value === null;
      return `<div class="pulse__row">
        <span class="pulse__service">${escapeHtml(row.label)}</span>
        <span class="pulse__value" data-state="${unknown ? 'unknown' : 'ok'}">${escapeHtml(
          unknown ? '—' : `${Number(value).toLocaleString()} ${row.unit}`
        )}</span>
      </div>`;
    }).join('');

    /* -- breakdowns ------------------------------------------------------ */
    // Only real rows. A breakdown with no entries is omitted rather than drawn
    // as an empty frame that implies a distribution of nothing.
    const breakdownHtml = (config.breakdowns || []).map((group) => {
      const rows = Array.isArray(payload?.[group.key]) ? payload[group.key] : [];
      if (!rows.length) return '';
      return `<section class="card">
        <div class="card__header"><h2 class="card__title">${escapeHtml(group.label)}</h2></div>
        <div class="card__body">
          ${rows.map((row) => `
            <div class="pulse__row">
              <span class="pulse__service">${escapeHtml(row.label || '—')}</span>
              <span class="pulse__value" data-state="ok">${Number(row.total).toLocaleString()}</span>
            </div>`).join('')}
        </div>
      </section>`;
    }).join('');

    mount.innerHTML = `
      <div class="grid">${kpiHtml}</div>
      ${secondaryHtml || breakdownHtml ? `<div class="grid executive-lower">
        ${secondaryHtml ? `<section class="card col-half">
          <div class="card__header"><h2 class="card__title">${escapeHtml(config.title)}</h2></div>
          <div class="card__body">${secondaryHtml}</div>
        </section>` : ''}
        ${breakdownHtml}
      </div>` : ''}`;
  };

  /**
   * Load and render a domain dashboard.
   *
   * Errors are NOT swallowed. A failed load is shown through the shared error
   * state rather than leaving the previous figures on screen, which is how a
   * reader ends up trusting numbers that are no longer being fetched.
   */
  const loadDomainDashboard = async (domain) => {
    const config = DOMAIN_DASHBOARDS[domain];
    const mount = config && $(config.mount);
    if (!config || !mount) return;

    if (window.Mamore?.states) mount.innerHTML = Mamore.states.skeleton({ kind: 'metric', rows: 3 });

    try {
      renderDomainDashboard(domain, await api(config.endpoint));
    } catch (error) {
      mount.innerHTML = window.Mamore?.states
        ? Mamore.states.error({ kind: 'server', title: 'Could not load this dashboard', body: error.message })
        : `<p class="empty">${escapeHtml(error.message)}</p>`;
    }
  };

  Mamore.loaders = Mamore.loaders || {};
  Object.keys(DOMAIN_DASHBOARDS).forEach((domain) => {
    Mamore.loaders[domain] = () => loadDomainDashboard(domain);
  });

  /**
   * Phase 22, the Analytics Center.
   *
   * /api/analytics/global existed and the panel existed, but NOTHING rendered
   * the payload -- the panel showed its "Open this section to load analytics"
   * placeholder forever. This is the only screen that could show it, because
   * the endpoint is gated on analytics.global_view.
   *
   * The payload is heterogeneous on purpose: nested objects, group arrays, and
   * one block whose averages are null when there were no incidents. Each is
   * rendered by the rule that fits it rather than forced through one generic
   * metric grid that would turn a null average into a zero.
   */
  const renderAnalytics = (payload) => {
    const mount = $('#analytics-body');
    if (!mount) return;

    const groupRows = (rows) => (Array.isArray(rows) && rows.length
      ? rows.map((row) => `
          <div class="pulse__row">
            <span class="pulse__service">${escapeHtml(row.label || '—')}</span>
            <span class="pulse__value" data-state="ok">${Number(row.total).toLocaleString()}</span>
          </div>`).join('')
      // An empty group is itself a finding -- "no incidents by severity" means
      // the window was quiet -- so it is stated, not left blank.
      : '<p class="metric__context">No records in this window.</p>');

    // A null average means "no incidents happened", which is NOT the same fact
    // as "response took zero minutes". It renders as "no data".
    const minutes = (value) => (value === null || value === undefined ? 'No data' : `${value} min`);

    const people = payload.peopleInMovement || {};
    const cargo = payload.cargoInMotion || {};
    const coverage = payload.rescueCoverage || {};
    const tracking = payload.trackingHealth || {};
    const response = payload.response || {};

    const headline = [
      ['People in motion', (people.smartBusPassengers || 0) + (people.truckCrew || 0) + (people.privateOccupants || 0), 'passengers and crew'],
      ['Cargo in motion', cargo.weightKg === undefined ? null : Number(cargo.weightKg), 'kg across all consignments'],
      ['Hazardous consignments', cargo.hazardous, 'in transit now'],
      ['Protected journeys', coverage.protectedJourneys, 'with active coverage'],
      ['Uncovered subjects', coverage.uncoveredSubjects, 'need a coverage link'],
      ['Pending coverage', coverage.pending, 'awaiting activation'],
    ];

    mount.innerHTML = `
      <div class="grid">
        ${headline.map(([label, value, note]) => `
          <article class="metric col-quarter">
            <p class="metric__label">${escapeHtml(label)}</p>
            <p class="metric__value">${escapeHtml(value === null || value === undefined ? '—' : Number(value).toLocaleString())}</p>
            <p class="metric__context">${escapeHtml(note)}</p>
          </article>`).join('')}
      </div>
      <div class="grid executive-lower">
        ${analyticsResponseCard(response, minutes)}
        ${analyticsTrackingCard(tracking)}
        ${[
          ['Assets by domain', payload.assetsByDomain],
          ['Assets by type', payload.assetsByType],
          ['Incidents by severity', payload.incidentsBySeverity],
          ['Incidents by domain', payload.incidentsByDomain],
        ].map(([label, rows]) => `
          <section class="card col-half">
            <div class="card__header"><h2 class="card__title">${escapeHtml(label)}</h2></div>
            <div class="card__body">${groupRows(rows)}</div>
          </section>`).join('')}
      </div>`;
  };

  const analyticsResponseCard = (response, minutes) => `
    <section class="card col-half">
      <div class="card__header"><h2 class="card__title">Response times</h2>
        <span class="text-muted t-caption">${escapeHtml(response.incidents === 0 || response.incidents === undefined
          ? 'No incidents in this window'
          : `${Number(response.incidents).toLocaleString()} incidents`)}</span>
      </div>
      <div class="card__body">
        ${[
          ['Reported to dispatch', response.avgDispatchMinutes],
          ['Dispatch to arrival', response.avgArriveMinutes],
          ['Reported to resolved', response.avgResolveMinutes],
        ].map(([label, value]) => `
          <div class="pulse__row">
            <span class="pulse__service">${escapeHtml(label)}</span>
            <span class="pulse__value" data-state="${value === null || value === undefined ? 'unknown' : 'ok'}">${escapeHtml(minutes(value))}</span>
          </div>`).join('')}
        ${Number(response.incidents || 0) === 0
          ? '<p class="metric__context">No incidents were recorded in this window, so there are no averages to report.</p>'
          : ''}
      </div>
    </section>`;

  const analyticsTrackingCard = (tracking) => `
    <section class="card col-half">
      <div class="card__header"><h2 class="card__title">Tracking health</h2></div>
      <div class="card__body">
        ${[
          ['Reporting now', tracking.online, 'ok'],
          ['Signal delayed', tracking.delayedSignal, 'degraded'],
          ['Offline', tracking.offline, 'down'],
          ['No device', tracking.noDevice, 'unknown'],
        ].map(([label, value, state]) => `
          <div class="pulse__row">
            <span class="pulse__service">${escapeHtml(label)}</span>
            <span class="pulse__value" data-state="${state}">${Number(value || 0).toLocaleString()}</span>
          </div>`).join('')}
      </div>
    </section>`;

  // Bound here rather than on DOMContentLoaded because this module already runs
  // after the shell is parsed, and the input is static markup in app.html.
  const loadAnalytics = async () => {
    const mount = $('#analytics-body');
    if (mount && window.Mamore?.states) mount.innerHTML = Mamore.states.skeleton({ kind: 'metric', rows: 4 });

    try {
      renderAnalytics(await api('/api/analytics/global'));
    } catch (error) {
      // A failed analytics load is shown as a failure, never as zeroes: this is
      // the screen where someone decides whether the platform looks healthy,
      // and a silent zero there is the most dangerous kind.
      if (mount) {
        mount.innerHTML = window.Mamore?.states
          ? Mamore.states.error({ kind: 'server', title: 'Could not load analytics', body: error.message })
          : `<p class="empty">${escapeHtml(error.message)}</p>`;
      }
    }
  };

  Mamore.loaders = Mamore.loaders || {};
  Mamore.loaders.analytics = loadAnalytics;
  Mamore.loaders.overview = loadExecutive;

  initGlobalSearch();

  // An Action Center row opens the workflow that resolves it.
  document.addEventListener('click', (event) => {
    const panelRow = event.target.closest('[data-open-panel]');
    if (panelRow) {
      switchPanel(panelRow.getAttribute('data-open-panel'));
      return;
    }
    // A detail row drills into the record behind the count.
    const detailRow = event.target.closest('[data-detail-id]');
    if (detailRow) openExecutiveDetail(detailRow);
  });

  // Smart Bus v2 panels. They are additive: every existing panel keeps its id,
  // its loader and its behaviour.

  Mamore.loaders = Mamore.loaders || {};
  Mamore.loaders.command = async () => {
    const payload = await api('/api/smart-bus/pilot');
    setServerEpochFrom(payload);
    $('#command-body').innerHTML = (window.MamoreSmartBus || {}).renderPilot ? window.MamoreSmartBus.renderPilot(payload) : '';
    const trips = await api('/api/control-center/live-trips').catch(() => ({ trips: [] }));
    $('#command-live').innerHTML = (window.MamoreSmartBus || {}).renderLiveTrips ? window.MamoreSmartBus.renderLiveTrips(trips.trips) : '';
  };
  Mamore.loaders.boarding = async () => {
    const tripId = $('#boarding-trip-select').value || (smartBusTrips[0] && smartBusTrips[0].id);
    if (!tripId) { $('#boarding-body').innerHTML = '<p class="empty">No trip selected.</p>'; return; }
    const manifest = await api(`/api/smart-bus/trips/manifest?id=${encodeURIComponent(tripId)}`);
    $('#boarding-body').innerHTML = (window.MamoreSmartBus || {}).renderManifest ? window.MamoreSmartBus.renderManifest(manifest) : '';
    const safety = await api(`/api/smart-bus/trips/safety?tripId=${encodeURIComponent(tripId)}`).catch(() => null);
    $('#boarding-safety').innerHTML = safety && window.MamoreSmartBus ? window.MamoreSmartBus.renderSafety(safety) : '';
  };
  const setServerEpochFrom = (payload) => {
    if (window.MamoreSmartBus && payload.summary && payload.summary.generatedAt) {
      window.MamoreSmartBus.setServerEpoch(Date.parse(payload.summary.generatedAt) / 1000);
    }
  };
  document.addEventListener('click', (event) => {
    const trigger = event.target.closest('[data-manifest-trip]');
    if (trigger) { switchPanel('boarding'); $('#boarding-trip-select').value = trigger.dataset.manifestTrip; Mamore.loaders.boarding(); }
  });
  document.addEventListener('change', (event) => {
    if (event.target.id === 'boarding-trip-select') Mamore.loaders.boarding();
  });
  window.Mamore = Mamore;
  const switchPanel = (name) => {
    // A panel the server did not offer is not reachable from navigation. The
    // legacy allow-list stays as the fallback for the brief window in which the
    // navigation request failed, so the shell degrades rather than dead-ends.
    const allowed = (Mamore.allowedPanels && Mamore.allowedPanels.length)
      ? Mamore.allowedPanels
      : (Mamore.panels || []);
    const realPanel = allowed.includes(name) ? name : 'coming';
    $$('.panel').forEach((panel) => { panel.hidden = panel.id !== `${realPanel}-panel`; });
    $$('.nav-item').forEach((item) => {
      const active = item.dataset.panel === realPanel;
      item.classList.toggle('active', active);
      if (active) item.setAttribute('aria-current', 'page'); else item.removeAttribute('aria-current');
    });
    const labels = Mamore.labels || {};
    const title = labels[realPanel] || labels[name] || 'Overview';
    $('#page-title').textContent = title;
    if (realPanel === 'coming') $('#coming-title').textContent = title;

    // Keep the panel in the URL so the view is linkable and survives a refresh.
    if (Mamore.shell && Mamore.shell.writeUrl) Mamore.shell.writeUrl(realPanel === 'coming' ? null : realPanel);

    // Breadcrumb: the group the panel sits in, resolved from the rendered nav.
    if (Mamore.shell && Mamore.shell.renderBreadcrumb) {
      let groupLabel = '';
      document.querySelectorAll('.nav-group').forEach((group) => {
        if (group.querySelector(`.nav-item[data-panel="${CSS.escape(realPanel)}"]`)) {
          groupLabel = group.querySelector('.nav-group__label')?.textContent?.trim() || '';
        }
      });
      Mamore.shell.renderBreadcrumb(groupLabel, title);
    }

    $('#sidebar').classList.remove('open');
    if (Mamore.shell && Mamore.shell.closeDrawer) Mamore.shell.closeDrawer();
    $('#menu-button').setAttribute('aria-expanded', 'false');
    $('#main').focus();
    // The overview is the exception-first executive board, not the retired
    // auth-telemetry view, so it loads through its own registered loader.
    if (name === 'overview' && !customerMode) (Mamore.loaders.overview || noopPanel)().catch((error) => toast(error.message));
    if (name === 'users' && adminRoles.length === 0) loadUsers().catch((error) => toast(error.message));
    if (name === 'rescue' && rescueUnits.length === 0) loadRescueBoard().catch((error) => toast(error.message));
    if(name==='alerts')loadPanicAlerts().catch((error)=>toast(error.message));
    if (name === 'tracking' && trackingAssets.length === 0) loadTracking().catch((error)=>toast(error.message));
    if (name === 'mobility' && smartBusRoutes.length === 0) loadMobility().catch((error) => toast(error.message));
    if (name === 'finance' && unpaidBookings.length === 0) loadFinance().catch((error) => toast(error.message));
    if (name === 'portal' && customerMode) loadPortalTrips().catch((error) => toast(error.message));
    if (name === 'mybookings' && customerMode) loadMyBookings().catch((error) => toast(error.message));
    if (name === 'notifications') (Mamore.loaders.notifications || noopPanel)().catch((error) => toast(error.message));
    if (name === 'subscriptions' && !customerMode) (Mamore.loaders.subscriptions || noopPanel)().catch((error) => toast(error.message));
    if (name === 'receipts' && !customerMode) (Mamore.loaders.receipts || noopPanel)().catch((error) => toast(error.message));
    if (name === 'audit' && !customerMode) (Mamore.loaders.audit || noopPanel)().catch((error) => toast(error.message));
    if (name === 'membership' && customerMode) (Mamore.loaders.membership || noopPanel)().catch((error) => toast(error.message));
    if (name === 'command' && !customerMode) (Mamore.loaders.command || noopPanel)().catch((error) => toast(error.message));
    if (name === 'boarding' && !customerMode) (Mamore.loaders.boarding || noopPanel)().catch((error) => toast(error.message));
    // Domain dashboards. These three panels previously had NO loader wired at
    // all, so opening them left the static "Open this section to load..."
    // placeholder on screen forever.
    if (DOMAIN_DASHBOARDS[name]) (Mamore.loaders[name] || noopPanel)().catch((error) => toast(error.message));
  };

  $('#login-form').addEventListener('submit', async (event) => {
    event.preventDefault();
    const button = $('#login-button');
    button.disabled = true;
    // innerHTML keeps the lock glyph that textContent would remove.
    button.innerHTML = `${icon('spinner')}Signing in…`;
    $('#login-error').textContent = '';
    try {
      const payload = await api('/api/auth/login', { method: 'POST', body: JSON.stringify({ email: $('#email').value.trim(), password: $('#password').value }) }, false);
      saveTokens(payload);
      await showApp(payload.user);
    } catch (error) { $('#login-error').textContent = error.message; }
    finally { button.disabled = false; button.innerHTML = `${icon('lock')}Sign in securely`; }
  });

  $('#show-password').addEventListener('click', () => {
    const input = $('#password');
    const showing = input.type === 'text';
    const button = $('#show-password');
    input.type = showing ? 'password' : 'text';
    // innerHTML, not textContent: the control carries an eye glyph that
    // textContent would strip along with the label.
    const label = showing ? 'Show' : 'Hide';
    button.innerHTML = `${icon(showing ? 'eye' : 'eye-slash')}${label}`;
    button.setAttribute('aria-label', `${label} password`);
    button.setAttribute('aria-pressed', showing ? 'false' : 'true');
  });

  $('#logout-button').addEventListener('click', async () => {
    try { await api('/api/auth/logout', { method: 'POST' }, false); } catch (_) { /* Clear the browser session even if the API is unavailable. */ }
    showLogin('You have signed out safely.');
  });
  // The overview's refresh button lives in the rebuilt panel; the old
  // #refresh-button belonged to the retired auth-telemetry view.
  $('#refresh-executive')?.addEventListener('click', async () => {
    try { await loadExecutive(); toast('Overview updated.'); } catch (error) { toast(error.message); }
  });
  $('#reload-sessions').addEventListener('click', async () => { try { await loadSessions(); toast('Sessions updated.'); } catch (error) { toast(error.message); } });
  $('#create-user-button').addEventListener('click', async () => {
    try { if (adminRoles.length === 0) await loadUsers(); openUserDialog(); } catch (error) { toast(error.message); }
  });
  $('#close-user-dialog').addEventListener('click', closeUserDialog);
  $('#cancel-user-dialog').addEventListener('click', closeUserDialog);
  $('#user-dialog').addEventListener('click', (event) => { if (event.target === $('#user-dialog')) closeUserDialog(); });
  $('#user-search-form').addEventListener('submit', async (event) => { event.preventDefault(); try { await loadUsers($('#user-search').value.trim()); } catch (error) { toast(error.message); } });
  $('#clear-user-search').addEventListener('click', async () => { $('#user-search').value = ''; try { await loadUsers(); } catch (error) { toast(error.message); } });
  $('#users-list').addEventListener('click', (event) => {
    const button = event.target.closest('[data-edit-user]');
    if (!button) return;
    const user = adminUsers.find((candidate) => candidate.id === button.dataset.editUser);
    if (user) openUserDialog(user);
  });
  $('#user-form').addEventListener('submit', async (event) => {
    event.preventDefault();
    const userId = $('#edit-user-id').value;
    const creating = userId === '';
    const body = creating ? {
      firstName: $('#user-first-name').value.trim(), lastName: $('#user-last-name').value.trim(),
      email: $('#user-email').value.trim(), phone: $('#user-phone').value.trim(), password: $('#user-password').value,
      roleId: $('#user-role').value, status: $('#user-status').value
    } : { userId, roleId: $('#user-role').value, status: $('#user-status').value };
    const button = $('#save-user-button');
    button.disabled = true; $('#user-form-error').textContent = '';
    try {
      await api(`/api/admin/users/${creating ? 'create' : 'update'}`, { method: 'POST', body: JSON.stringify(body) });
      closeUserDialog(); await loadUsers($('#user-search').value.trim()); await loadDashboard(); toast(creating ? 'User created.' : 'User updated.');
    } catch (error) { $('#user-form-error').textContent = error.message; }
    finally { button.disabled = false; }
  });
  $('#report-incident-button').addEventListener('click', () => { $('#incident-form').reset(); $('#incident-form-error').textContent = ''; $('#incident-dialog').showModal(); $('#incident-source').focus(); });
  $('#close-incident-dialog').addEventListener('click', closeIncidentDialog);
  $('#cancel-incident-dialog').addEventListener('click', closeIncidentDialog);
  $('#close-dispatch-dialog').addEventListener('click', closeDispatchDialog);
  $('#cancel-dispatch-dialog').addEventListener('click', closeDispatchDialog);
  $('#incident-dialog').addEventListener('click', (event) => { if (event.target === $('#incident-dialog')) closeIncidentDialog(); });
  $('#dispatch-dialog').addEventListener('click', (event) => { if (event.target === $('#dispatch-dialog')) closeDispatchDialog(); });
  $('#refresh-rescue').addEventListener('click', async () => { try { await loadRescueBoard(); toast('Rescue board updated.'); } catch (error) { toast(error.message); } });
  $('#incident-form').addEventListener('submit', async (event) => {
    event.preventDefault(); const button = $('#save-incident-button'); button.disabled = true; $('#incident-form-error').textContent = '';
    try {
      await api('/api/rescue/incidents/report', { method: 'POST', body: JSON.stringify({ source: $('#incident-source').value, priority: $('#incident-priority').value, callerName: $('#caller-name').value.trim(), callerPhone: $('#caller-phone').value.trim(), province: $('#incident-province').value, location: $('#incident-location').value.trim(), latitude: $('#incident-latitude').value, longitude: $('#incident-longitude').value, description: $('#incident-description').value.trim() }) });
      closeIncidentDialog(); await loadRescueBoard(); toast('Emergency incident reported.');
    } catch (error) { $('#incident-form-error').textContent = error.message; }
    finally { button.disabled = false; }
  });
  $('#dispatch-form').addEventListener('submit', async (event) => {
    event.preventDefault(); const button = $('#confirm-dispatch-button'); button.disabled = true; $('#dispatch-form-error').textContent = '';
    try { await api('/api/rescue/incidents/dispatch', { method: 'POST', body: JSON.stringify({ incidentId: $('#dispatch-incident-id').value, unitId: $('#dispatch-unit').value }) }); closeDispatchDialog(); await loadRescueBoard(); toast('Rescue unit dispatched.'); }
    catch (error) { $('#dispatch-form-error').textContent = error.message; button.disabled = false; }
  });
  $('#incident-list').addEventListener('click', async (event) => {
    const dispatchButton = event.target.closest('[data-dispatch-incident]');
    if (dispatchButton) return openDispatchDialog(dispatchButton.dataset.dispatchIncident);
    const updateButton = event.target.closest('[data-update-incident]');
    if (!updateButton) return;
    const incidentId = updateButton.dataset.updateIncident;
    const status = document.querySelector(`[data-status-select="${incidentId}"]`)?.value;
    updateButton.disabled = true;
    try { await api('/api/rescue/incidents/transition', { method: 'POST', body: JSON.stringify({ incidentId, status }) }); await loadRescueBoard(); toast(`Incident moved to ${status.replaceAll('_', ' ')}.`); }
    catch (error) { updateButton.disabled = false; toast(error.message); }
  });
  $('#schedule-trip-button').addEventListener('click', async () => { try { if (smartBusRoutes.length === 0) await loadMobility(); $('#trip-form-error').textContent = ''; $('#trip-dialog').showModal(); $('#trip-route').focus(); } catch (error) { toast(error.message); } });
  $('#close-trip-dialog').addEventListener('click', closeTripDialog); $('#cancel-trip-dialog').addEventListener('click', closeTripDialog);
  $('#close-booking-dialog').addEventListener('click', closeBookingDialog); $('#cancel-booking-dialog').addEventListener('click', closeBookingDialog);
  $('#close-ticket-dialog').addEventListener('click', () => $('#ticket-dialog').close());
  $('#refresh-mobility').addEventListener('click', async () => { try { await loadMobility(); toast('Departure board updated.'); } catch (error) { toast(error.message); } });
  $('#trip-form').addEventListener('submit', async (event) => { event.preventDefault(); const button = $('#save-trip-button'); button.disabled = true; $('#trip-form-error').textContent = ''; try { await api('/api/smartbus/trips/schedule', { method: 'POST', body: JSON.stringify({ routeId: $('#trip-route').value, vehicleId: $('#trip-vehicle').value, departureAt: $('#trip-departure').value, usdCdfRate: $('#trip-rate').value }) }); closeTripDialog(); await loadMobility(); toast('Trip scheduled.'); } catch (error) { $('#trip-form-error').textContent = error.message; } finally { button.disabled = false; } });
  $('#trip-list').addEventListener('click', (event) => { const button = event.target.closest('[data-book-trip]'); if (button) openBookingDialog(button.dataset.bookTrip); });
  $('#seat-map').addEventListener('click', (event) => { const button = event.target.closest('[data-seat]'); if (!button) return; $$('#seat-map .seat').forEach((seat) => seat.classList.remove('selected')); button.classList.add('selected'); $('#selected-seat').value = button.dataset.seat; });
  $('#booking-form').addEventListener('submit', async (event) => { event.preventDefault(); if (!$('#selected-seat').value) return void ($('#booking-form-error').textContent = 'Select an available seat.'); const button = $('#save-booking-button'); button.disabled = true; $('#booking-form-error').textContent = ''; try { const endpoint = customerMode ? '/api/portal/bookings/create' : '/api/smartbus/bookings/create'; const { booking } = await api(endpoint, { method: 'POST', body: JSON.stringify({ tripId: $('#booking-trip-id').value, passengerName: $('#passenger-name').value.trim(), passengerPhone: $('#passenger-phone').value.trim(), seatNumber: Number($('#selected-seat').value) }) }); closeBookingDialog(); if (customerMode) await Promise.all([loadPortalTrips(), loadMyBookings()]); else await loadMobility(); $('#ticket-reference').textContent = booking.reference; $('#ticket-details').innerHTML = `<strong>${escapeHtml(booking.passengerName)}</strong><br>Trip ${escapeHtml(booking.tripCode)} · Seat ${booking.seatNumber}<br>Total ${money(booking.totalCdf)}<br>Rescue protection USD ${booking.rescueFeeUsd.toFixed(2)}`; $('#ticket-qr').setAttribute('title', booking.qrPayload); $('#ticket-dialog').showModal(); } catch (error) { $('#booking-form-error').textContent = error.message; } finally { button.disabled = false; } });
  $('#portal-trip-list').addEventListener('click', (event) => { const button = event.target.closest('[data-portal-book-trip]'); if (button) openBookingDialog(button.dataset.portalBookTrip); });
  $('#refresh-portal').addEventListener('click', async () => { try { await loadPortalTrips(); toast('Trips updated.'); } catch (error) { toast(error.message); } });
  $('#refresh-my-bookings').addEventListener('click', async () => { try { await loadMyBookings(); toast('Bookings updated.'); } catch (error) { toast(error.message); } });
  $('#refresh-finance').addEventListener('click', async () => { try { await loadFinance(); toast('Finance ledger updated.'); } catch (error) { toast(error.message); } });
  $('#unpaid-list').addEventListener('click', (event) => { const button = event.target.closest('[data-receive-payment]'); if (button) openPaymentDialog(button.dataset.receivePayment); });
  $('#close-payment-dialog').addEventListener('click', closePaymentDialog); $('#cancel-payment-dialog').addEventListener('click', closePaymentDialog);
  $('#close-receipt-dialog').addEventListener('click', () => $('#receipt-dialog').close());
  $('#payment-currency').addEventListener('change', setPaymentAmount); $('#payment-rate').addEventListener('input', setPaymentAmount);
  $('#payment-form').addEventListener('submit', async (event) => { event.preventDefault(); const button = $('#save-payment-button'); button.disabled = true; $('#payment-form-error').textContent = ''; try { const { receipt } = await api('/api/finance/payments/receive', { method: 'POST', body: JSON.stringify({ bookingId: $('#payment-booking-id').value, paymentMethod: $('#payment-method').value, currency: $('#payment-currency').value, usdCdfRate: $('#payment-rate').value, amount: $('#payment-amount').value, externalReference: $('#payment-reference').value.trim() }) }); closePaymentDialog(); await loadFinance(); $('#receipt-number').textContent = receipt.receiptNumber; $('#receipt-details').innerHTML = `<strong>${escapeHtml(receipt.passengerName)}</strong><br>Booking ${escapeHtml(receipt.bookingReference)}<br>Received ${receipt.amount.toLocaleString()} ${escapeHtml(receipt.currency)}<br>Equivalent ${money(receipt.amountCdf)}<br>Operator allocation ${money(receipt.operatorAllocationCdf)}<br>Rescue fund ${money(receipt.rescueAllocationCdf)}<br><strong>${escapeHtml(receipt.status)}</strong>`; $('#receipt-dialog').showModal(); } catch (error) { $('#payment-form-error').textContent = error.message; } finally { button.disabled = false; } });
  $('#refresh-tracking').addEventListener('click',async()=>{try{await loadTracking();toast('Tracking board updated.');}catch(error){toast(error.message);}});
  $('#update-position-button').addEventListener('click',async()=>{try{if(!trackingAssets.length)await loadTracking();$('#position-form').reset();$('#position-form-error').textContent='';$('#position-dialog').showModal();$('#position-asset').focus();}catch(error){toast(error.message);}});
  $('#add-location-button').addEventListener('click',()=>{$('#location-form').reset();$('#location-form-error').textContent='';$('#location-dialog').showModal();$('#location-type').focus();});
  $('#close-position-dialog').addEventListener('click',closePositionDialog);$('#cancel-position-dialog').addEventListener('click',closePositionDialog);$('#close-location-dialog').addEventListener('click',closeLocationDialog);$('#cancel-location-dialog').addEventListener('click',closeLocationDialog);
  $('#position-form').addEventListener('submit',async(event)=>{event.preventDefault();const button=$('#save-position-button');button.disabled=true;$('#position-form-error').textContent='';try{await api('/api/tracking/check-in',{method:'POST',body:JSON.stringify({assetId:$('#position-asset').value,latitude:$('#position-latitude').value,longitude:$('#position-longitude').value,speedKph:$('#position-speed').value,heading:$('#position-heading').value})});closePositionDialog();await loadTracking();toast('GPS position recorded.');}catch(error){$('#position-form-error').textContent=error.message;}finally{button.disabled=false;}});
  $('#location-form').addEventListener('submit',async(event)=>{event.preventDefault();const button=$('#save-location-button');button.disabled=true;$('#location-form-error').textContent='';try{await api('/api/tracking/locations/create',{method:'POST',body:JSON.stringify({type:$('#location-type').value,province:$('#location-province').value,name:$('#location-name').value.trim(),address:$('#location-address').value.trim(),latitude:$('#location-latitude').value,longitude:$('#location-longitude').value,phone:$('#location-phone').value.trim()})});closeLocationDialog();await loadTracking();toast('Service location added.');}catch(error){$('#location-form-error').textContent=error.message;}finally{button.disabled=false;}});
  $('#refresh-alerts').addEventListener('click',async()=>{try{await loadPanicAlerts();toast('Panic alerts updated.');}catch(error){toast(error.message);}});
  $('#panic-alert-list').addEventListener('click',async(event)=>{const button=event.target.closest('[data-ack-alert]');if(!button)return;button.disabled=true;try{await api('/api/alerts/acknowledge',{method:'POST',body:JSON.stringify({alertId:button.dataset.ackAlert})});await Promise.all([loadPanicAlerts(),loadRescueBoard()]);toast('SOS alert acknowledged.');}catch(error){button.disabled=false;toast(error.message);}});
  const closeSosDialog=()=>$('#sos-dialog').close();
  $('#sos-button').addEventListener('click',()=>{$('#sos-form').reset();$('#sos-form-error').textContent='';$('#sos-dialog').showModal();$('#sos-province').focus();});$('#close-sos-dialog').addEventListener('click',closeSosDialog);$('#cancel-sos-dialog').addEventListener('click',closeSosDialog);
  $('#capture-location').addEventListener('click',()=>{if(!navigator.geolocation)return void($('#sos-form-error').textContent='Location services are unavailable in this browser.');$('#capture-location').textContent='Locating…';navigator.geolocation.getCurrentPosition((position)=>{$('#sos-latitude').value=position.coords.latitude.toFixed(7);$('#sos-longitude').value=position.coords.longitude.toFixed(7);$('#capture-location').textContent='Location captured';},(error)=>{$('#sos-form-error').textContent=`Could not capture location: ${error.message}`;$('#capture-location').textContent='Use my current location';},{enableHighAccuracy:true,timeout:10000});});
  $('#sos-form').addEventListener('submit',async(event)=>{event.preventDefault();const button=$('#activate-sos-button');button.disabled=true;$('#sos-form-error').textContent='';try{const{alert}=await api('/api/portal/sos',{method:'POST',body:JSON.stringify({province:$('#sos-province').value,location:$('#sos-location').value.trim(),latitude:$('#sos-latitude').value,longitude:$('#sos-longitude').value,message:$('#sos-message').value.trim()})});closeSosDialog();await loadMyAlerts();toast(`SOS ${alert.code} sent to Mamore HQ.`);}catch(error){$('#sos-form-error').textContent=error.message;}finally{button.disabled=false;}});
  $('#sessions-list').addEventListener('click', async (event) => {
    const button = event.target.closest('[data-session-id]');
    if (!button) return;
    button.disabled = true;
    try { await api('/api/auth/sessions/revoke', { method: 'POST', body: JSON.stringify({ sessionId: button.dataset.sessionId }) }); await loadSessions(); toast('Session revoked.'); }
    catch (error) { button.disabled = false; toast(error.message); }
  });
  Object.assign(Mamore, { api, url, toast, escapeHtml, formatDate, money, switchPanel, refreshAccess, saveTokens, clearTokens });
  document.addEventListener('click', (event) => { const button = event.target.closest('[data-panel]'); if (button) switchPanel(button.dataset.panel); });
  $('#menu-button').addEventListener('click', () => { const open = $('#sidebar').classList.toggle('open'); $('#menu-button').setAttribute('aria-expanded', String(open)); });

  (async () => {
    if (!sessionStorage.getItem(tokenKey)) return showLogin();
    try { const { user } = await api('/api/auth/me'); await showApp(user); }
    catch (error) { showLogin(error.message); }
  })();
})();
