<?php

declare(strict_types=1);

use Mamore\Auth\AuthService;
use Mamore\Auth\AuthException;
use Mamore\Auth\PortalAuthService;
use Mamore\Admin\UserAdminService;
use Mamore\Core\Database;
use Mamore\Core\Request;
use Mamore\Core\Response;
use Mamore\Core\Router;
use Mamore\Core\ServerClock;
use Mamore\Core\Migrator;
use Mamore\Core\AppShell;
use Mamore\Core\Theme;
use Mamore\Core\Navigation;
use Mamore\Core\Translator;
use Mamore\Core\Session;
use Mamore\Core\Env;
use Mamore\Finance\ExchangeRateService;

/**
 * The currency a request wants its monetary figures presented in.
 *
 * Resolution: explicit ?display=, then the stored session, then the cookie, then
 * USD. The cookie matters for the same reason the locale cookie does: it lets the
 * server-rendered login screen show a correctly-labelled price before any
 * JavaScript runs.
 *
 * This resolves a PRESENTATION choice only. It reads and writes a preference,
 * and there is deliberately no path from here to a financial table.
 */
function mamore_display_currency(Request $request): string
{
    $query = [];
    parse_str((string) parse_url($request->uri, PHP_URL_QUERY), $query);

    foreach ([
        $query['display'] ?? null,
        $_SESSION['mamore_display_currency'] ?? null,
        $_COOKIE['mamore_display_currency'] ?? null,
    ] as $candidate) {
        if (is_string($candidate) && in_array(strtoupper(trim($candidate)), ExchangeRateService::SUPPORTED, true)) {
            return strtoupper(trim($candidate));
        }
    }

    return ExchangeRateService::USD;
}
use Mamore\Dashboard\DashboardService;
use Mamore\Dashboard\ExecutiveService;
use Mamore\Rescue\RescueService;
use Mamore\SmartBus\SmartBusService;
use Mamore\SmartBus\RescueCodeService;
use Mamore\SmartBus\ManifestService;
use Mamore\SmartBus\JourneySafetyService;
use Mamore\SmartBus\SmartBusIncidentService;
use Mamore\SmartBus\TripNotificationService;
use Mamore\SmartBus\PilotAnalyticsService;
use Mamore\Rescue\ControlCenterService;
use Mamore\Rescue\DispatchAdvisor;
use Mamore\Rescue\RescueCoverageService;
use Mamore\PrivateVehicle\PrivateVehicleService;
use Mamore\TruckCargo\TruckService;
use Mamore\Vip\VipSubscriberService;
use Mamore\Support\GlobalSearch;
use Mamore\Tracking\TrackingIngestionService;
use Mamore\Finance\FinanceService;
use Mamore\Portal\CustomerPortalService;
use Mamore\Tracking\TrackingService;
use Mamore\Alerts\PanicService;
use Mamore\Alerts\NotificationService;
use Mamore\Core\AuditLog;
use Mamore\Subscription\SubscriptionService;
use Mamore\Finance\SubscriptionPaymentService;
use Mamore\Finance\ReceiptService;
use Mamore\Core\View;

require dirname(__DIR__) . '/bootstrap.php';

$router = new Router();
$router->get('/', static function (Request $_): array {
    $file = __DIR__ . '/app.html';
    if (!is_file($file)) {
        return Response::html('<h1>Mamore is starting</h1>', 503);
    }

    return Response::html(AppShell::render((string) file_get_contents($file)));
});
$router->get('/health', static fn (Request $_): array => Response::json([
    'status' => 'ok',
    'service' => 'mamore-php-api',
    'time' => gmdate(DATE_ATOM),
]));
$router->get('/ready', static function (Request $_): array {
    try {
        Database::connection()->query('SELECT 1');
        // Clock skew is reported because stored timestamps are written by MySQL:
        // a host whose clock disagrees with the database would silently expire
        // one-time codes and report live GPS as stale.
        $database = Database::connection();
        $skew = ServerClock::skewSeconds($database);
        $migrations = (new Migrator($database, dirname(__DIR__) . '/database/migrations'))->status();

        return Response::json([
            'status' => 'ready',
            'database' => 'ok',
            'migrations' => $migrations,
            'clock' => [
                'serverEpoch' => ServerClock::epoch($database),
                'skewSeconds' => $skew,
                'consistent' => abs($skew) <= 5,
            ],
        ]);
    } catch (Throwable) {
        return Response::json(['status' => 'not_ready', 'database' => 'unavailable'], 503);
    }
});

$router->post('/api/auth/login', static function (Request $request): array {
    try {
        $auth = new AuthService(Database::connection());
        $email = is_string($request->body['email'] ?? null) ? $request->body['email'] : '';
        $password = is_string($request->body['password'] ?? null) ? $request->body['password'] : '';
        if ($email === '' || $password === '') return Response::json(['error' => 'Email and password are required.'], 422);
        return Response::json($auth->login($email, $password, $request));
    } catch (AuthException $error) {
        return Response::json(['error' => $error->getMessage()], $error->status);
    }
});
$router->get('/api/theme', static function (Request $request): array {
    $theme = new Theme($request);
    return Response::json([
        'theme' => $theme->resolved(),
        'preference' => $theme->preference(),
        'available' => [Theme::LIGHT, Theme::DARK, Theme::SYSTEM],
    ]);
});
$router->post('/api/theme', static function (Request $request): array {
    $theme = new Theme($request);
    $preference = $request->body['theme'] ?? null;
    if (!is_string($preference)) {
        return Response::json(['error' => 'A theme preference is required.'], 422);
    }
    $theme->persist($preference);
    return Response::json(['theme' => $theme->resolved(), 'preference' => $theme->preference()]);
});
$router->get('/api/executive', static function (Request $request): array {
    try {
        $database = Database::connection();
        $auth = new AuthService($database);
        $actor = $auth->authenticate($request->bearerToken());
        // A cross-domain overview is an analytics-level view, so it is gated the
        // same way /api/analytics/global is. A role that may not see the whole
        // picture gets 403 rather than a quietly-empty dashboard.
        $auth->requirePermission($actor, 'analytics.global_view');

        return Response::json(['executive' => (new ExecutiveService($database))->overview(mamore_query($request), $actor)]);
    } catch (AuthException $error) { return Response::json(['error' => $error->getMessage()], $error->status); }
});
$router->get('/api/currency', static function (Request $request): array {
    // Deliberately unauthenticated, like /api/i18n: the login screen shows a
    // price, and a price without its currency is not a price. No user data is
    // exposed, only the rate board and the caller's display preference.
    $rates = new ExchangeRateService(Database::connection());

    return Response::json($rates->board() + [
        'display' => mamore_display_currency($request),
        'symbols' => ['USD' => '$', 'CDF' => 'FC', 'TZS' => 'TSh'],
        'names' => ['USD' => 'US Dollar', 'CDF' => 'Congolese Franc', 'TZS' => 'Tanzanian Shilling'],
    ]);
});
$router->post('/api/currency', static function (Request $request): array {
    // The display choice is a PRESENTATION preference. It is deliberately not
    // connected to any write: changing it re-renders numbers and nothing else.
    $currency = $request->body['display'] ?? null;
    if (!is_string($currency) || !in_array(strtoupper(trim($currency)), ExchangeRateService::SUPPORTED, true)) {
        return Response::json(['error' => 'A supported display currency is required.'], 422);
    }
    $normalised = strtoupper(trim($currency));

    Session::start();
    $_SESSION['mamore_display_currency'] = $normalised;
    setcookie('mamore_display_currency', $normalised, [
        'expires' => time() + 31536000,
        'path' => '/',
        'secure' => Env::get('APP_ENV', 'local') === 'production',
        'httponly' => true,
        'samesite' => 'Lax',
    ]);

    return Response::json(['display' => $normalised]);
});
$router->get('/api/i18n', static function (Request $request): array {
    // Deliberately unauthenticated: the login screen is the first thing a user
    // reads, and a French speaker should meet a French login form. It carries
    // no user data, only the message catalogue for the resolved locale.
    $translator = Translator::instance();
    $locale = $translator->resolveForRequest($request);

    return Response::json([
        'locale' => $locale,
        'fallback' => Translator::FALLBACK,
        'available' => Translator::supported(),
        'messages' => $translator->catalogue($locale),
    ]);
});
$router->post('/api/i18n', static function (Request $request): array {
    $locale = $request->body['locale'] ?? null;
    // normalise() maps anything unsupported to DEFAULT, which would silently
    // accept a typo like "frnch" and store "en" as the user's language. The
    // request must name a locale that actually exists.
    $normalised = is_string($locale) ? strtolower(trim($locale)) : '';
    if (!in_array($normalised, Translator::supported(), true)) {
        return Response::json(['error' => 'A supported locale is required.'], 422);
    }

    // The session is not started by the router, so writing $_SESSION here would
    // be silently discarded -- exactly the bug this route had. Core\Theme
    // appeared to work because it also set a cookie, which masked the same
    // mistake. Session::start() is idempotent, so calling it explicitly is safe
    // on the authenticated paths that already started it.
    Session::start();
    $_SESSION['mamore_locale'] = $normalised;

    // A cookie as well, so the preference survives a session expiry and the
    // server-rendered login screen is already in the right language before any
    // JavaScript runs.
    setcookie('mamore_locale', $normalised, [
        'expires' => time() + 31536000,
        'path' => '/',
        'secure' => Env::get('APP_ENV', 'local') === 'production',
        'httponly' => true,
        'samesite' => 'Lax',
    ]);

    $translator = Translator::instance($normalised);

    return Response::json([
        'locale' => $normalised,
        'fallback' => Translator::FALLBACK,
        'available' => Translator::supported(),
        'messages' => $translator->catalogue($normalised),
    ]);
});
$router->get('/api/navigation', static function (Request $request): array {
    try {
        $database = Database::connection();
        $auth = new AuthService($database);
        $actor = $auth->authenticate($request->bearerToken());
        $locale = Translator::instance()->resolveForRequest($request);
        return Response::json(['navigation' => (new Navigation($database))->forUser($actor, Translator::instance($locale))]);
    } catch (AuthException $error) { return Response::json(['error' => $error->getMessage()], $error->status); }
});
$router->get('/api/auth/me', 
static function (Request $request): array {
    try { $auth = new AuthService(Database::connection()); return Response::json(['user' => $auth->publicUser($auth->authenticate($request->bearerToken()))]); }
    catch (AuthException $error) { return Response::json(['error' => $error->getMessage()], $error->status); }
});
$router->post('/api/auth/logout', static function (Request $request): array {
    try { $auth = new AuthService(Database::connection()); $user = $auth->authenticate($request->bearerToken()); $auth->logout($user, $request); return Response::json(['status' => 'logged_out']); }
    catch (AuthException $error) { return Response::json(['error' => $error->getMessage()], $error->status); }
});
$router->post('/api/auth/refresh', static function (Request $request): array {
    try {
        $token = is_string($request->body['refreshToken'] ?? null) ? $request->body['refreshToken'] : '';
        if ($token === '') return Response::json(['error' => 'Refresh token is required.'], 422);
        return Response::json((new AuthService(Database::connection()))->refresh($token, $request));
    } catch (AuthException $error) { return Response::json(['error' => $error->getMessage()], $error->status); }
});
$router->get('/api/auth/sessions', static function (Request $request): array {
    try { $auth = new AuthService(Database::connection()); $user = $auth->authenticate($request->bearerToken()); return Response::json(['sessions' => $auth->sessions($user)]); }
    catch (AuthException $error) { return Response::json(['error' => $error->getMessage()], $error->status); }
});
$router->post('/api/auth/sessions/revoke', static function (Request $request): array {
    try {
        $auth = new AuthService(Database::connection()); $user = $auth->authenticate($request->bearerToken());
        $sessionId = is_string($request->body['sessionId'] ?? null) ? $request->body['sessionId'] : '';
        if ($sessionId === '') return Response::json(['error' => 'Session ID is required.'], 422);
        $auth->revokeSession($user, $sessionId, $request); return Response::json(['status' => 'revoked']);
    } catch (AuthException $error) { return Response::json(['error' => $error->getMessage()], $error->status); }
});
$router->get('/api/admin/ping', static function (Request $request): array {
    try { $auth = new AuthService(Database::connection()); $user = $auth->authenticate($request->bearerToken()); $auth->requirePermission($user, 'users.manage'); return Response::json(['status' => 'authorized']); }
    catch (AuthException $error) { return Response::json(['error' => $error->getMessage()], $error->status); }
});
$router->get('/api/admin/dashboard', static function (Request $request): array {
    try {
        $database = Database::connection();
        $auth = new AuthService($database);
        $user = $auth->authenticate($request->bearerToken());
        $auth->requirePermission($user, 'users.manage');
        return Response::json((new DashboardService($database))->snapshot());
    } catch (AuthException $error) {
        return Response::json(['error' => $error->getMessage()], $error->status);
    }
});
$router->get('/api/admin/users', static function (Request $request): array {
    try {
        $database = Database::connection(); $auth = new AuthService($database);
        $user = $auth->authenticate($request->bearerToken()); $auth->requirePermission($user, 'users.manage');
        parse_str((string) parse_url($request->uri, PHP_URL_QUERY), $query);
        $search = is_string($query['search'] ?? null) ? $query['search'] : '';
        $service = new UserAdminService($database);
        return Response::json(['users' => $service->users($search), 'roles' => $service->roles()]);
    } catch (AuthException $error) { return Response::json(['error' => $error->getMessage()], $error->status); }
});
$router->post('/api/admin/users/create', static function (Request $request): array {
    try {
        $database = Database::connection(); $auth = new AuthService($database);
        $actor = $auth->authenticate($request->bearerToken()); $auth->requirePermission($actor, 'users.manage');
        return Response::json(['user' => (new UserAdminService($database))->create($request->body, $actor, $request)], 201);
    } catch (AuthException $error) { return Response::json(['error' => $error->getMessage()], $error->status); }
});
$router->post('/api/admin/users/update', static function (Request $request): array {
    try {
        $database = Database::connection(); $auth = new AuthService($database);
        $actor = $auth->authenticate($request->bearerToken()); $auth->requirePermission($actor, 'users.manage');
        return Response::json(['user' => (new UserAdminService($database))->update($request->body, $actor, $request)]);
    } catch (AuthException $error) { return Response::json(['error' => $error->getMessage()], $error->status); }
});
$router->get('/api/rescue/board', static function (Request $request): array {
    try {
        $database = Database::connection(); $auth = new AuthService($database);
        $actor = $auth->authenticate($request->bearerToken()); $auth->requirePermission($actor, 'rescue.dispatch');
        return Response::json((new RescueService($database))->board());
    } catch (AuthException $error) { return Response::json(['error' => $error->getMessage()], $error->status); }
});
$router->post('/api/rescue/incidents/report', static function (Request $request): array {
    try {
        $database = Database::connection(); $auth = new AuthService($database);
        $actor = $auth->authenticate($request->bearerToken()); $auth->requirePermission($actor, 'rescue.dispatch');
        return Response::json(['incident' => (new RescueService($database))->report($request->body, $actor)], 201);
    } catch (AuthException $error) { return Response::json(['error' => $error->getMessage()], $error->status); }
});
$router->post('/api/rescue/incidents/dispatch', static function (Request $request): array {
    try {
        $database = Database::connection(); $auth = new AuthService($database);
        $actor = $auth->authenticate($request->bearerToken()); $auth->requirePermission($actor, 'rescue.dispatch');
        return Response::json(['incident' => (new RescueService($database))->dispatch($request->body, $actor)]);
    } catch (AuthException $error) { return Response::json(['error' => $error->getMessage()], $error->status); }
});
$router->post('/api/rescue/incidents/transition', static function (Request $request): array {
    try {
        $database = Database::connection(); $auth = new AuthService($database);
        $actor = $auth->authenticate($request->bearerToken()); $auth->requirePermission($actor, 'rescue.dispatch');
        return Response::json(['incident' => (new RescueService($database))->transition($request->body, $actor)]);
    } catch (AuthException $error) { return Response::json(['error' => $error->getMessage()], $error->status); }
});
$router->get('/api/smartbus/board', static function (Request $request): array {
    try {
        $database = Database::connection(); $auth = new AuthService($database);
        $actor = $auth->authenticate($request->bearerToken()); $auth->requirePermission($actor, 'smartbus.manage');
        return Response::json((new SmartBusService($database))->board());
    } catch (AuthException $error) { return Response::json(['error' => $error->getMessage()], $error->status); }
});
$router->post('/api/smartbus/trips/schedule', static function (Request $request): array {
    try {
        $database = Database::connection(); $auth = new AuthService($database);
        $actor = $auth->authenticate($request->bearerToken()); $auth->requirePermission($actor, 'smartbus.manage');
        return Response::json(['trip' => (new SmartBusService($database))->schedule($request->body, $actor)], 201);
    } catch (AuthException $error) { return Response::json(['error' => $error->getMessage()], $error->status); }
});
$router->post('/api/smartbus/bookings/create', static function (Request $request): array {
    try {
        $database = Database::connection(); $auth = new AuthService($database);
        $actor = $auth->authenticate($request->bearerToken()); $auth->requirePermission($actor, 'smartbus.manage');
        return Response::json(['booking' => (new SmartBusService($database))->book($request->body, $actor)], 201);
    } catch (AuthException $error) { return Response::json(['error' => $error->getMessage()], $error->status); }
});
/** Query-string accessor for the Smart Bus v2 routes, matching the existing convention. */
function smart_bus_query(Request $request): array
{
    parse_str((string) parse_url($request->uri, PHP_URL_QUERY), $query);

    return $query;
}

$router->get('/api/smart-bus/trips/manifest', static function (Request $request): array {
    try {
        $database = Database::connection(); $auth = new AuthService($database);
        $actor = $auth->authenticate($request->bearerToken()); $auth->requirePermission($actor, 'smartbus.manifest.view');
        return Response::json((new ManifestService($database))->manifest((string) (smart_bus_query($request)['id'] ?? ''), $actor));
    } catch (AuthException $error) { return Response::json(['error' => $error->getMessage()], $error->status); }
});
$router->post('/api/smart-bus/check-in', static function (Request $request): array {
    try {
        $database = Database::connection(); $auth = new AuthService($database);
        $actor = $auth->authenticate($request->bearerToken()); $auth->requirePermission($actor, 'smartbus.checkin.passenger');
        return Response::json(['checkIn' => (new ManifestService($database))->checkIn($request->body, $actor, $request)]);
    } catch (AuthException $error) { return Response::json(['error' => $error->getMessage()], $error->status); }
});
$router->post('/api/smart-bus/boarding', static function (Request $request): array {
    try {
        $database = Database::connection(); $auth = new AuthService($database);
        $actor = $auth->authenticate($request->bearerToken()); $auth->requirePermission($actor, 'smartbus.board.passenger');
        return Response::json(['boarding' => (new ManifestService($database))->board($request->body, $actor, $request)]);
    } catch (AuthException $error) { return Response::json(['error' => $error->getMessage()], $error->status); }
});
$router->post('/api/smart-bus/notifications/schedule', static function (Request $request): array {
    try {
        $database = Database::connection(); $auth = new AuthService($database);
        $actor = $auth->authenticate($request->bearerToken()); $auth->requirePermission($actor, 'smartbus.manage');
        return Response::json(['schedule' => (new TripNotificationService($database))->scheduleForTrip((string) ($request->body['tripId'] ?? ''), $actor)]);
    } catch (AuthException $error) { return Response::json(['error' => $error->getMessage()], $error->status); }
});
$router->get('/api/smart-bus/trips/notifications', static function (Request $request): array {
    try {
        $database = Database::connection(); $auth = new AuthService($database);
        $actor = $auth->authenticate($request->bearerToken()); $auth->requirePermission($actor, 'smartbus.manage');
        return Response::json((new TripNotificationService($database))->outboxForTrip((string) (smart_bus_query($request)['tripId'] ?? '')));
    } catch (AuthException $error) { return Response::json(['error' => $error->getMessage()], $error->status); }
});
$router->get('/api/smart-bus/trips/safety', static function (Request $request): array {
    try {
        $database = Database::connection(); $auth = new AuthService($database);
        $actor = $auth->authenticate($request->bearerToken()); $auth->requirePermission($actor, 'smartbus.rescue_status.view');
        return Response::json((new JourneySafetyService($database))->tripSafety((string) (smart_bus_query($request)['tripId'] ?? ''), $actor));
    } catch (AuthException $error) { return Response::json(['error' => $error->getMessage()], $error->status); }
});
$router->get('/api/smart-bus/journey/safety', static function (Request $request): array {
    try {
        $database = Database::connection(); $auth = new AuthService($database);
        $actor = $auth->authenticate($request->bearerToken());
        return Response::json((new JourneySafetyService($database))->forPassenger($actor));
    } catch (AuthException $error) { return Response::json(['error' => $error->getMessage()], $error->status); }
});
$router->get('/api/control-center/live-trips', static function (Request $request): array {
    try {
        $database = Database::connection(); $auth = new AuthService($database);
        $actor = $auth->authenticate($request->bearerToken()); $auth->requirePermission($actor, 'rescue.dispatch');
        return Response::json(['trips' => (new JourneySafetyService($database))->liveTrips($actor)]);
    } catch (AuthException $error) { return Response::json(['error' => $error->getMessage()], $error->status); }
});
$router->post('/api/smart-bus/incidents', static function (Request $request): array {
    try {
        $database = Database::connection(); $auth = new AuthService($database);
        $actor = $auth->authenticate($request->bearerToken()); $auth->requirePermission($actor, 'smartbus.incident.create');
        return Response::json(['raised' => (new SmartBusIncidentService($database))->create($request->body, $actor, $request)], 201);
    } catch (AuthException $error) { return Response::json(['error' => $error->getMessage()], $error->status); }
});
$router->get('/api/smart-bus/pilot', static function (Request $request): array {
    try {
        $database = Database::connection(); $auth = new AuthService($database);
        $actor = $auth->authenticate($request->bearerToken()); $auth->requirePermission($actor, 'smartbus.pilot.view');
        $service = new PilotAnalyticsService($database);
        return Response::json([
            'summary' => $service->summary(smart_bus_query($request)),
            'insights' => $service->insights(smart_bus_query($request)),
            'rescueResponse' => $service->rescueResponse(),
        ]);
    } catch (AuthException $error) { return Response::json(['error' => $error->getMessage()], $error->status); }
});
$router->get('/api/rescue-code/mine', static function (Request $request): array {
    try {
        $database = Database::connection(); $auth = new AuthService($database);
        $actor = $auth->authenticate($request->bearerToken());
        return Response::json((new RescueCodeService($database))->forSubscriber($actor));
    } catch (AuthException $error) { return Response::json(['error' => $error->getMessage()], $error->status); }
});
$router->post('/api/rescue-code/verify', static function (Request $request): array {
    try {
        $database = Database::connection();
        return Response::json((new RescueCodeService($database))->verifyPublic((string) ($request->body['code'] ?? ''), $request));
    } catch (AuthException $error) { return Response::json(['error' => $error->getMessage()], $error->status); }
});
$router->post('/api/rescue-code/lookup', static function (Request $request): array {
    try {
        $database = Database::connection(); $auth = new AuthService($database);
        $actor = $auth->authenticate($request->bearerToken()); $auth->requirePermission($actor, 'smartbus.rescue_code.verify');
        return Response::json((new RescueCodeService($database))->lookup((string) ($request->body['code'] ?? ''), $actor, $request));
    } catch (AuthException $error) { return Response::json(['error' => $error->getMessage()], $error->status); }
});
$router->post('/api/rescue-code/issue', static function (Request $request): array {
    try {
        $database = Database::connection(); $auth = new AuthService($database);
        $actor = $auth->authenticate($request->bearerToken()); $auth->requirePermission($actor, 'smartbus.rescue_code.manage');
        return Response::json(['rescueCode' => (new RescueCodeService($database))->issue($request->body, $actor, $request)], 201);
    } catch (AuthException $error) { return Response::json(['error' => $error->getMessage()], $error->status); }
});
$router->post('/api/rescue-code/revoke', static function (Request $request): array {
    try {
        $database = Database::connection(); $auth = new AuthService($database);
        $actor = $auth->authenticate($request->bearerToken()); $auth->requirePermission($actor, 'smartbus.rescue_code.manage');
        return Response::json(['rescueCode' => (new RescueCodeService($database))->revoke($request->body, $actor, $request)]);
    } catch (AuthException $error) { return Response::json(['error' => $error->getMessage()], $error->status); }
});
$router->post('/api/rescue-code/regenerate', static function (Request $request): array {
    try {
        $database = Database::connection(); $auth = new AuthService($database);
        $actor = $auth->authenticate($request->bearerToken()); $auth->requirePermission($actor, 'smartbus.rescue_code.manage');
        return Response::json(['rescueCode' => (new RescueCodeService($database))->regenerate($request->body, $actor, $request)]);
    } catch (AuthException $error) { return Response::json(['error' => $error->getMessage()], $error->status); }
});
/** Query-string accessor for the multi-domain routes. */
function mamore_query(Request $request): array
{
    parse_str((string) parse_url($request->uri, PHP_URL_QUERY), $query);

    return $query;
}

$router->get('/api/control-center/operations', static function (Request $request): array {
    try {
        $database = Database::connection(); $auth = new AuthService($database);
        $actor = $auth->authenticate($request->bearerToken()); $auth->requirePermission($actor, 'incident.global_view');
        $control = new ControlCenterService($database, new DispatchAdvisor($database));
        return Response::json($control->operations(mamore_query($request), $actor));
    } catch (AuthException $error) { return Response::json(['error' => $error->getMessage()], $error->status); }
});
$router->get('/api/analytics/global', static function (Request $request): array {
    try {
        $database = Database::connection(); $auth = new AuthService($database);
        $actor = $auth->authenticate($request->bearerToken()); $auth->requirePermission($actor, 'analytics.global_view');
        $control = new ControlCenterService($database, new DispatchAdvisor($database));
        return Response::json($control->analytics(mamore_query($request)));
    } catch (AuthException $error) { return Response::json(['error' => $error->getMessage()], $error->status); }
});
$router->get('/api/incidents', static function (Request $request): array {
    try {
        $database = Database::connection(); $auth = new AuthService($database);
        $actor = $auth->authenticate($request->bearerToken()); $auth->requirePermission($actor, 'incident.global_view');
        $control = new ControlCenterService($database, new DispatchAdvisor($database));
        $operations = $control->operations(mamore_query($request), $actor);
        return Response::json(['incidents' => $operations['incidents'], 'kpis' => $operations['kpis']]);
    } catch (AuthException $error) { return Response::json(['error' => $error->getMessage()], $error->status); }
});
$router->get('/api/incidents/show', static function (Request $request): array {
    try {
        $database = Database::connection(); $auth = new AuthService($database);
        $actor = $auth->authenticate($request->bearerToken()); $auth->requirePermission($actor, 'incident.global_view');
        $control = new ControlCenterService($database, new DispatchAdvisor($database));
        return Response::json($control->incidentDetail((string) (mamore_query($request)['id'] ?? ''), $actor));
    } catch (AuthException $error) { return Response::json(['error' => $error->getMessage()], $error->status); }
});
$router->get('/api/coverage/check', static function (Request $request): array {
    try {
        $database = Database::connection(); $auth = new AuthService($database);
        $actor = $auth->authenticate($request->bearerToken()); $auth->requirePermission($actor, 'coverage.view');
        $query = mamore_query($request);
        $coverage = new RescueCoverageService($database);
        return Response::json($coverage->check(
            (string) ($query['subjectType'] ?? 'VEHICLE'),
            (string) ($query['subjectId'] ?? ''),
            isset($query['vehicleId']) ? (string) $query['vehicleId'] : null
        ));
    } catch (AuthException $error) { return Response::json(['error' => $error->getMessage()], $error->status); }
});
$router->get('/api/tracking/assets', static function (Request $request): array {
    try {
        $database = Database::connection(); $auth = new AuthService($database);
        $actor = $auth->authenticate($request->bearerToken()); $auth->requirePermission($actor, 'tracking.global_view');
        $control = new ControlCenterService($database, new DispatchAdvisor($database));
        $operations = $control->operations(mamore_query($request), $actor);
        return Response::json(['assets' => $operations['assets'], 'kpis' => $operations['kpis'], 'domains' => $operations['availableDomains']]);
    } catch (AuthException $error) { return Response::json(['error' => $error->getMessage()], $error->status); }
});
$router->post('/api/tracking/ingest', static function (Request $request): array {
    // Device credentials only: this endpoint must never accept a user token as
    // authority, and it is not a user session.
    try {
        $database = Database::connection();
        return Response::json(['position' => (new TrackingIngestionService($database))->ingest($request->body, $request)], 202);
    } catch (AuthException $error) { return Response::json(['error' => $error->getMessage()], $error->status); }
});
$router->post('/api/tracking/devices', static function (Request $request): array {
    try {
        $database = Database::connection(); $auth = new AuthService($database);
        $actor = $auth->authenticate($request->bearerToken()); $auth->requirePermission($actor, 'tracking.device_manage');
        return Response::json(['device' => (new TrackingIngestionService($database))->registerDevice($request->body, $actor)], 201);
    } catch (AuthException $error) { return Response::json(['error' => $error->getMessage()], $error->status); }
});
$router->get('/api/global-search', static function (Request $request): array {
    try {
        $database = Database::connection(); $auth = new AuthService($database);
        $actor = $auth->authenticate($request->bearerToken()); $auth->requirePermission($actor, 'search.global');
        $search = new GlobalSearch($database);
        $permissions = $database->prepare(<<<'SQL'
            SELECT p.code FROM role_permissions rp JOIN permissions p ON p.id = rp.permission_id WHERE rp.role_id = :role
            SQL);
        $permissions->execute(['role' => $actor['role_id']]);
        $codes = ['all' => $permissions->fetchAll(PDO::FETCH_COLUMN)];
        return Response::json($search->search((string) (mamore_query($request)['q'] ?? ''), $search->domainsFor($actor, $codes), $actor));
    } catch (AuthException $error) { return Response::json(['error' => $error->getMessage()], $error->status); }
});

/** Shared construction so the domain services get their collaborators once. */
function mamore_domain_services(PDO $database): array
{
    $coverage = new RescueCoverageService($database);
    $codes = new Mamore\SmartBus\RescueCodeService($database);

    return [
        'vip' => new VipSubscriberService($database, $coverage, $codes),
        'private' => new PrivateVehicleService($database, $coverage, $codes),
        'truck' => new TruckService($database, $coverage),
    ];
}

$router->get('/api/vip/dashboard', static function (Request $request): array {
    try {
        $database = Database::connection(); $auth = new AuthService($database);
        $actor = $auth->authenticate($request->bearerToken()); $auth->requirePermission($actor, 'vip.view');
        return Response::json(mamore_domain_services($database)['vip']->dashboard(mamore_query($request), $actor));
    } catch (AuthException $error) { return Response::json(['error' => $error->getMessage()], $error->status); }
});
$router->get('/api/vip/subscribers/show', static function (Request $request): array {
    try {
        $database = Database::connection(); $auth = new AuthService($database);
        $actor = $auth->authenticate($request->bearerToken()); $auth->requirePermission($actor, 'vip.view');
        return Response::json(mamore_domain_services($database)['vip']->show((string) (mamore_query($request)['id'] ?? ''), $actor));
    } catch (AuthException $error) { return Response::json(['error' => $error->getMessage()], $error->status); }
});
$router->post('/api/vip/subscribers', static function (Request $request): array {
    try {
        $database = Database::connection(); $auth = new AuthService($database);
        $actor = $auth->authenticate($request->bearerToken()); $auth->requirePermission($actor, 'vip.create');
        return Response::json(['vip' => mamore_domain_services($database)['vip']->create($request->body, $actor, $request)], 201);
    } catch (AuthException $error) { return Response::json(['error' => $error->getMessage()], $error->status); }
});
$router->post('/api/vip/subscribers/activate', static function (Request $request): array {
    try {
        $database = Database::connection(); $auth = new AuthService($database);
        $actor = $auth->authenticate($request->bearerToken()); $auth->requirePermission($actor, 'vip.manage_subscription');
        return Response::json(['vip' => mamore_domain_services($database)['vip']->activate($request->body, $actor, $request)]);
    } catch (AuthException $error) { return Response::json(['error' => $error->getMessage()], $error->status); }
});
$router->get('/api/private-vehicles', static function (Request $request): array {
    try {
        $database = Database::connection(); $auth = new AuthService($database);
        $actor = $auth->authenticate($request->bearerToken());
        return Response::json(mamore_domain_services($database)['private']->dashboard($actor));
    } catch (AuthException $error) { return Response::json(['error' => $error->getMessage()], $error->status); }
});
$router->post('/api/private-vehicles', static function (Request $request): array {
    try {
        $database = Database::connection(); $auth = new AuthService($database);
        $actor = $auth->authenticate($request->bearerToken());
        return Response::json(['privateVehicle' => mamore_domain_services($database)['private']->enrol($request->body, $actor, $request)], 201);
    } catch (AuthException $error) { return Response::json(['error' => $error->getMessage()], $error->status); }
});
$router->post('/api/private-vehicles/emergency', static function (Request $request): array {
    try {
        $database = Database::connection(); $auth = new AuthService($database);
        $actor = $auth->authenticate($request->bearerToken());
        return Response::json(['emergency' => mamore_domain_services($database)['private']->requestHelp($request->body, $actor, $request)], 201);
    } catch (AuthException $error) { return Response::json(['error' => $error->getMessage()], $error->status); }
});
$router->get('/api/trucks', static function (Request $request): array {
    try {
        $database = Database::connection(); $auth = new AuthService($database);
        $actor = $auth->authenticate($request->bearerToken()); $auth->requirePermission($actor, 'truck.view');
        return Response::json(mamore_domain_services($database)['truck']->dashboard(mamore_query($request), $actor));
    } catch (AuthException $error) { return Response::json(['error' => $error->getMessage()], $error->status); }
});
$router->post('/api/trucks', static function (Request $request): array {
    try {
        $database = Database::connection(); $auth = new AuthService($database);
        $actor = $auth->authenticate($request->bearerToken()); $auth->requirePermission($actor, 'truck.create');
        return Response::json(['truck' => mamore_domain_services($database)['truck']->createTruck($request->body, $actor, $request)], 201);
    } catch (AuthException $error) { return Response::json(['error' => $error->getMessage()], $error->status); }
});
$router->get('/api/truck-journeys/manifest', static function (Request $request): array {
    try {
        $database = Database::connection(); $auth = new AuthService($database);
        $actor = $auth->authenticate($request->bearerToken()); $auth->requirePermission($actor, 'truck.cargo_view');
        return Response::json(mamore_domain_services($database)['truck']->manifest((string) (mamore_query($request)['id'] ?? ''), $actor));
    } catch (AuthException $error) { return Response::json(['error' => $error->getMessage()], $error->status); }
});
$router->get('/api/private-vehicles/analytics', static function (Request $request): array {
    try {
        $database = Database::connection(); $auth = new AuthService($database);
        $actor = $auth->authenticate($request->bearerToken());
        return Response::json(mamore_domain_services($database)['private']->dashboard($actor));
    } catch (AuthException $error) { return Response::json(['error' => $error->getMessage()], $error->status); }
});
$router->get('/api/truck-cargo/analytics', static function (Request $request): array {
    try {
        $database = Database::connection(); $auth = new AuthService($database);
        $actor = $auth->authenticate($request->bearerToken()); $auth->requirePermission($actor, 'truck.view');
        return Response::json(mamore_domain_services($database)['truck']->dashboard(mamore_query($request), $actor));
    } catch (AuthException $error) { return Response::json(['error' => $error->getMessage()], $error->status); }
});

$router->get('/api/finance/board', static function (Request $request): array {
    try {
        $database = Database::connection(); $auth = new AuthService($database);
        $actor = $auth->authenticate($request->bearerToken()); $auth->requirePermission($actor, 'finance.manage');
        return Response::json((new FinanceService($database))->board());
    } catch (AuthException $error) { return Response::json(['error' => $error->getMessage()], $error->status); }
});
$router->post('/api/finance/payments/receive', static function (Request $request): array {
    try {
        $database = Database::connection(); $auth = new AuthService($database);
        $actor = $auth->authenticate($request->bearerToken()); $auth->requirePermission($actor, 'finance.manage');
        return Response::json(['receipt' => (new FinanceService($database))->receive($request->body, $actor)], 201);
    } catch (AuthException $error) { return Response::json(['error' => $error->getMessage()], $error->status); }
});
$router->get('/api/portal/trips', static function (Request $request): array {
    try {
        $database=Database::connection(); $auth=new AuthService($database);
        $user=$auth->authenticate($request->bearerToken()); $auth->requirePermission($user,'portal.use');
        return Response::json(['trips'=>(new CustomerPortalService($database))->trips()]);
    } catch (AuthException $error) { return Response::json(['error'=>$error->getMessage()],$error->status); }
});
$router->get('/api/portal/bookings', static function (Request $request): array {
    try {
        $database=Database::connection(); $auth=new AuthService($database);
        $user=$auth->authenticate($request->bearerToken()); $auth->requirePermission($user,'portal.use');
        return Response::json(['bookings'=>(new CustomerPortalService($database))->bookings($user)]);
    } catch (AuthException $error) { return Response::json(['error'=>$error->getMessage()],$error->status); }
});
$router->post('/api/portal/bookings/create', static function (Request $request): array {
    try {
        $database=Database::connection(); $auth=new AuthService($database);
        $user=$auth->authenticate($request->bearerToken()); $auth->requirePermission($user,'portal.use');
        return Response::json(['booking'=>(new CustomerPortalService($database))->book($request->body,$user)],201);
    } catch (AuthException $error) { return Response::json(['error'=>$error->getMessage()],$error->status); }
});
$router->get('/api/tracking/board', static function (Request $request): array {
    try {$database=Database::connection();$auth=new AuthService($database);$user=$auth->authenticate($request->bearerToken());$auth->requirePermission($user,'tracking.view');return Response::json((new TrackingService($database))->board());}
    catch(AuthException $error){return Response::json(['error'=>$error->getMessage()],$error->status);}
});
$router->post('/api/tracking/check-in', static function (Request $request): array {
    try {$database=Database::connection();$auth=new AuthService($database);$user=$auth->authenticate($request->bearerToken());$auth->requirePermission($user,'tracking.view');return Response::json(['position'=>(new TrackingService($database))->checkIn($request->body)],201);}
    catch(AuthException $error){return Response::json(['error'=>$error->getMessage()],$error->status);}
});
$router->post('/api/tracking/locations/create', static function (Request $request): array {
    try {$database=Database::connection();$auth=new AuthService($database);$user=$auth->authenticate($request->bearerToken());$auth->requirePermission($user,'tracking.view');return Response::json(['location'=>(new TrackingService($database))->createLocation($request->body)],201);}
    catch(AuthException $error){return Response::json(['error'=>$error->getMessage()],$error->status);}
});
$router->get('/api/tracking/nearest', static function (Request $request): array {
    try {$database=Database::connection();$auth=new AuthService($database);$user=$auth->authenticate($request->bearerToken());$auth->requirePermission($user,'tracking.view');parse_str((string)parse_url($request->uri,PHP_URL_QUERY),$query);$lat=filter_var($query['latitude']??null,FILTER_VALIDATE_FLOAT);$lng=filter_var($query['longitude']??null,FILTER_VALIDATE_FLOAT);if($lat===false||$lng===false)return Response::json(['error'=>'Valid coordinates are required.'],422);return Response::json(['locations'=>(new TrackingService($database))->nearest((float)$lat,(float)$lng)]);}
    catch(AuthException $error){return Response::json(['error'=>$error->getMessage()],$error->status);}
});
$router->post('/api/portal/sos', static function(Request $request):array{
    try{$database=Database::connection();$auth=new AuthService($database);$user=$auth->authenticate($request->bearerToken());$auth->requirePermission($user,'portal.use');return Response::json(['alert'=>(new PanicService($database))->activate($request->body,$user,$request)],201);}catch(AuthException $error){return Response::json(['error'=>$error->getMessage()],$error->status);}
});
$router->get('/api/portal/sos', static function(Request $request):array{
    try{$database=Database::connection();$auth=new AuthService($database);$user=$auth->authenticate($request->bearerToken());$auth->requirePermission($user,'portal.use');return Response::json(['alerts'=>(new PanicService($database))->mine($user)]);}catch(AuthException $error){return Response::json(['error'=>$error->getMessage()],$error->status);}
});
$router->get('/api/alerts/board', static function(Request $request):array{
    try{$database=Database::connection();$auth=new AuthService($database);$user=$auth->authenticate($request->bearerToken());$auth->requirePermission($user,'rescue.dispatch');return Response::json((new PanicService($database))->board());}catch(AuthException $error){return Response::json(['error'=>$error->getMessage()],$error->status);}
});
$router->post('/api/alerts/acknowledge', static function(Request $request):array{
    try{$database=Database::connection();$auth=new AuthService($database);$user=$auth->authenticate($request->bearerToken());$auth->requirePermission($user,'rescue.dispatch');$id=is_string($request->body['alertId']??null)?$request->body['alertId']:'';return Response::json(['alert'=>(new PanicService($database))->acknowledge($id,$user)]);}catch(AuthException $error){return Response::json(['error'=>$error->getMessage()],$error->status);}
});
$router->get('/api/notifications', static function(Request $request):array{
    try{$database=Database::connection();$auth=new AuthService($database);$user=$auth->authenticate($request->bearerToken());return Response::json(['notifications'=>(new NotificationService($database))->list($user)]);}catch(AuthException $error){return Response::json(['error'=>$error->getMessage()],$error->status);}
});
$router->get('/api/notifications/unread-count', static function(Request $request):array{
    try{$database=Database::connection();$auth=new AuthService($database);$user=$auth->authenticate($request->bearerToken());return Response::json(['unread'=>(new NotificationService($database))->unreadCount($user)]);}catch(AuthException $error){return Response::json(['error'=>$error->getMessage()],$error->status);}
});
$router->post('/api/notifications/read', static function(Request $request):array{
    try{$database=Database::connection();$auth=new AuthService($database);$user=$auth->authenticate($request->bearerToken());$id=$request->body['notificationId']??null;if((!is_string($id)&&!is_int($id))||(string)$id==='')return Response::json(['error'=>'Notification ID is required.'],422);return Response::json(['notification'=>(new NotificationService($database))->markRead($user,$id)]);}catch(AuthException $error){return Response::json(['error'=>$error->getMessage()],$error->status);}
});
$router->post('/api/notifications/read-all', static function(Request $request):array{
    try{$database=Database::connection();$auth=new AuthService($database);$user=$auth->authenticate($request->bearerToken());return Response::json((new NotificationService($database))->markAllRead($user));}catch(AuthException $error){return Response::json(['error'=>$error->getMessage()],$error->status);}
});
$router->get('/api/audit', static function (Request $request): array {
    try {
        $database = Database::connection(); $auth = new AuthService($database);
        $actor = $auth->authenticate($request->bearerToken()); $auth->requirePermission($actor, 'audit.view');
        parse_str((string) parse_url($request->uri, PHP_URL_QUERY), $query);
        return Response::json(['audit' => (new AuditLog($database))->list($query)]);
    } catch (AuthException $error) { return Response::json(['error' => $error->getMessage()], $error->status); }
});

$router->get('/api/subscriptions', static function (Request $request): array {
    try {
        $database = Database::connection(); $auth = new AuthService($database);
        $actor = $auth->authenticate($request->bearerToken()); $auth->requirePermission($actor, 'finance.manage');
        $service = new SubscriptionService($database);
        parse_str((string) parse_url($request->uri, PHP_URL_QUERY), $query);
        $id = is_string($query['id'] ?? null) ? $query['id'] : '';
        return Response::json($id === ''
            ? ['subscriptions' => $service->list($query)]
            : ['subscription' => $service->show($id)]);
    } catch (AuthException $error) { return Response::json(['error' => $error->getMessage()], $error->status); }
});
$router->get('/api/subscriptions/quote', static function (Request $request): array {
    try {
        $database = Database::connection(); $auth = new AuthService($database);
        $actor = $auth->authenticate($request->bearerToken()); $auth->requirePermission($actor, 'finance.manage');
        parse_str((string) parse_url($request->uri, PHP_URL_QUERY), $query);
        return Response::json(['quote' => (new SubscriptionService($database))->quote($query)]);
    } catch (AuthException $error) { return Response::json(['error' => $error->getMessage()], $error->status); }
});
$router->post('/api/subscriptions/create', static function (Request $request): array {
    try {
        $database = Database::connection(); $auth = new AuthService($database);
        $actor = $auth->authenticate($request->bearerToken()); $auth->requirePermission($actor, 'finance.manage');
        return Response::json(['subscription' => (new SubscriptionService($database))->create($request->body, $actor, $request)], 201);
    } catch (AuthException $error) { return Response::json(['error' => $error->getMessage()], $error->status); }
});
$router->post('/api/subscriptions/renew', static function (Request $request): array {
    try {
        $database = Database::connection(); $auth = new AuthService($database);
        $actor = $auth->authenticate($request->bearerToken()); $auth->requirePermission($actor, 'finance.manage');
        return Response::json(['subscription' => (new SubscriptionService($database))->renew($request->body, $actor, $request)], 201);
    } catch (AuthException $error) { return Response::json(['error' => $error->getMessage()], $error->status); }
});
$router->post('/api/subscriptions/status', static function (Request $request): array {
    try {
        $database = Database::connection(); $auth = new AuthService($database);
        $actor = $auth->authenticate($request->bearerToken()); $auth->requirePermission($actor, 'finance.manage');
        return Response::json(['subscription' => (new SubscriptionService($database))->updateStatus($request->body, $actor, $request)]);
    } catch (AuthException $error) { return Response::json(['error' => $error->getMessage()], $error->status); }
});
$router->get('/api/subscriptions/expiring', static function (Request $request): array {
    try {
        $database = Database::connection(); $auth = new AuthService($database);
        $actor = $auth->authenticate($request->bearerToken()); $auth->requirePermission($actor, 'finance.manage');
        parse_str((string) parse_url($request->uri, PHP_URL_QUERY), $query);
        $days = isset($query['days']) && is_numeric($query['days']) ? (int) $query['days'] : 30;
        return Response::json(['subscriptions' => (new SubscriptionService($database))->expiringWithin($days)]);
    } catch (AuthException $error) { return Response::json(['error' => $error->getMessage()], $error->status); }
});
$router->get('/api/subscriptions/history', static function (Request $request): array {
    try {
        $database = Database::connection(); $auth = new AuthService($database);
        $actor = $auth->authenticate($request->bearerToken()); $auth->requirePermission($actor, 'finance.manage');
        parse_str((string) parse_url($request->uri, PHP_URL_QUERY), $query);
        $id = is_string($query['id'] ?? null) ? $query['id'] : '';
        return Response::json(['history' => (new SubscriptionService($database))->historyOf($id)]);
    } catch (AuthException $error) { return Response::json(['error' => $error->getMessage()], $error->status); }
});
$router->get('/api/finance/subscription-payments', static function (Request $request): array {
    try {
        $database = Database::connection(); $auth = new AuthService($database);
        $actor = $auth->authenticate($request->bearerToken()); $auth->requirePermission($actor, 'finance.manage');
        parse_str((string) parse_url($request->uri, PHP_URL_QUERY), $query);
        $service = new SubscriptionPaymentService($database);
        $id = is_string($query['id'] ?? null) ? $query['id'] : '';
        return Response::json($id === '' ? ['payments' => $service->list($query)] : ['payment' => $service->show($id)]);
    } catch (AuthException $error) { return Response::json(['error' => $error->getMessage()], $error->status); }
});
$router->post('/api/finance/subscription-payments/receive', static function (Request $request): array {
    try {
        $database = Database::connection(); $auth = new AuthService($database);
        $actor = $auth->authenticate($request->bearerToken()); $auth->requirePermission($actor, 'finance.manage');
        return Response::json(['payment' => (new SubscriptionPaymentService($database))->receive($request->body, $actor, $request)], 201);
    } catch (AuthException $error) { return Response::json(['error' => $error->getMessage()], $error->status); }
});
$router->post('/api/finance/subscription-payments/void', static function (Request $request): array {
    try {
        $database = Database::connection(); $auth = new AuthService($database);
        $actor = $auth->authenticate($request->bearerToken()); $auth->requirePermission($actor, 'finance.manage');
        return Response::json(['payment' => (new SubscriptionPaymentService($database))->void($request->body, $actor, $request)]);
    } catch (AuthException $error) { return Response::json(['error' => $error->getMessage()], $error->status); }
});
$router->get('/api/receipts', static function (Request $request): array {
    try {
        $database = Database::connection(); $auth = new AuthService($database);
        $actor = $auth->authenticate($request->bearerToken()); $auth->requirePermission($actor, 'finance.manage');
        parse_str((string) parse_url($request->uri, PHP_URL_QUERY), $query);
        $service = new ReceiptService($database);
        $id = is_string($query['id'] ?? null) ? $query['id'] : '';
        return Response::json($id === '' ? ['receipts' => $service->list($query)] : ['receipt' => $service->show($id)]);
    } catch (AuthException $error) { return Response::json(['error' => $error->getMessage()], $error->status); }
});
$router->post('/api/receipts/print', static function (Request $request): array {
    try {
        $database = Database::connection(); $auth = new AuthService($database);
        $actor = $auth->authenticate($request->bearerToken()); $auth->requirePermission($actor, 'finance.manage');
        $id = is_string($request->body['receiptId'] ?? null) ? $request->body['receiptId'] : '';
        if ($id === '') { return Response::json(['error' => 'Receipt ID is required.'], 422); }
        return Response::json(['receipt' => (new ReceiptService($database))->markPrinted($id, $actor, $request)]);
    } catch (AuthException $error) { return Response::json(['error' => $error->getMessage()], $error->status); }
});
$router->get('/api/receipts/verify', static function (Request $request): array {
    try {
        parse_str((string) parse_url($request->uri, PHP_URL_QUERY), $query);
        $code = is_string($query['code'] ?? null) ? $query['code'] : '';
        if ($code === '') { return Response::json(['error' => 'A verification code is required.'], 422); }
        return Response::json(['receipt' => (new ReceiptService(Database::connection()))->verify($code)]);
    } catch (AuthException $error) { return Response::json(['error' => $error->getMessage()], $error->status); }
});
$router->get('/receipts/print', static function (Request $request): array {
    try {
        parse_str((string) parse_url($request->uri, PHP_URL_QUERY), $query);
        $code = is_string($query['code'] ?? null) ? $query['code'] : '';
        if ($code === '') { return Response::html('<h1>Receipt</h1><p>A verification code is required.</p>', 422); }
        $receipt = (new ReceiptService(Database::connection()))->verify($code);
        return Response::html(View::render('receipts/print.php', ['receipt' => $receipt]));
    } catch (AuthException $error) {
        return Response::html('<h1>Receipt</h1><p>' . View::esc($error->getMessage()) . '</p>', $error->status);
    }
});
// ---- Portal (subscriber self-service, ownership scoped) ---------------------
$portalSubscriber = static function (PDO $database, array $user): string {
    return (new SubscriptionService($database))->subscriberIdForUser($user);
};
$router->get('/api/portal/subscription/quote', static function (Request $request) use ($portalSubscriber): array {
    try {
        $database = Database::connection(); $auth = new AuthService($database);
        $user = $auth->authenticate($request->bearerToken()); $auth->requirePermission($user, 'portal.use');
        parse_str((string) parse_url($request->uri, PHP_URL_QUERY), $query);
        return Response::json(['quote' => (new SubscriptionService($database))->quote($query)]);
    } catch (AuthException $error) { return Response::json(['error' => $error->getMessage()], $error->status); }
});
$router->get('/api/portal/subscriptions', static function (Request $request) use ($portalSubscriber): array {
    try {
        $database = Database::connection(); $auth = new AuthService($database);
        $user = $auth->authenticate($request->bearerToken()); $auth->requirePermission($user, 'portal.use');
        $service = new SubscriptionService($database);
        $subscriberId = $portalSubscriber($database, $user);
        parse_str((string) parse_url($request->uri, PHP_URL_QUERY), $query);
        // detail=1 adds the fee lines and history the membership screen shows;
        // the plain list stays cheap because a subscriber owns few records.
        $rows = $service->forSubscriber($subscriberId);
        if (($query['detail'] ?? '') === '1') {
            $rows = array_map(static fn (array $row): array => $service->show((string) $row['id']), $rows);
        }
        return Response::json(['subscriptions' => $rows, 'subscriberId' => $subscriberId]);
    } catch (AuthException $error) { return Response::json(['error' => $error->getMessage()], $error->status); }
});
$router->post('/api/portal/subscriptions/create', static function (Request $request) use ($portalSubscriber): array {
    try {
        $database = Database::connection(); $auth = new AuthService($database);
        $user = $auth->authenticate($request->bearerToken()); $auth->requirePermission($user, 'portal.use');
        // The portal never accepts a foreign subscriber: the account decides.
        $body = $request->body;
        unset($body['subscriberId'], $body['subscriber']);
        $body['subscriberId'] = $portalSubscriber($database, $user);
        return Response::json(['subscription' => (new SubscriptionService($database))->create($body, $user, $request)], 201);
    } catch (AuthException $error) { return Response::json(['error' => $error->getMessage()], $error->status); }
});
$router->get('/api/portal/payments', static function (Request $request) use ($portalSubscriber): array {
    try {
        $database = Database::connection(); $auth = new AuthService($database);
        $user = $auth->authenticate($request->bearerToken()); $auth->requirePermission($user, 'portal.use');
        return Response::json(['payments' => (new SubscriptionPaymentService($database))->list([
            'subscriberId' => $portalSubscriber($database, $user),
        ])]);
    } catch (AuthException $error) { return Response::json(['error' => $error->getMessage()], $error->status); }
});
$router->get('/api/portal/receipts', static function (Request $request) use ($portalSubscriber): array {
    try {
        $database = Database::connection(); $auth = new AuthService($database);
        $user = $auth->authenticate($request->bearerToken()); $auth->requirePermission($user, 'portal.use');
        $service = new ReceiptService($database);
        $subscriberId = $portalSubscriber($database, $user);
        parse_str((string) parse_url($request->uri, PHP_URL_QUERY), $query);
        $id = is_string($query['id'] ?? null) ? $query['id'] : '';
        return Response::json($id === ''
            ? ['receipts' => $service->forSubscriber($subscriberId)]
            : ['receipt' => $service->showForSubscriber($id, $subscriberId)]);
    } catch (AuthException $error) { return Response::json(['error' => $error->getMessage()], $error->status); }
});
$router->get('/api/portal/receipts/download', static function (Request $request) use ($portalSubscriber): array {
    try {
        $database = Database::connection(); $auth = new AuthService($database);
        $user = $auth->authenticate($request->bearerToken()); $auth->requirePermission($user, 'portal.use');
        parse_str((string) parse_url($request->uri, PHP_URL_QUERY), $query);
        $id = is_string($query['id'] ?? null) ? $query['id'] : '';
        $receipt = (new ReceiptService($database))->showForSubscriber($id, $portalSubscriber($database, $user));
        // The print page is server rendered; the QR data travels with the receipt.
        return Response::json(['receipt' => $receipt, 'printUrl' => $receipt['qrData']]);
    } catch (AuthException $error) { return Response::json(['error' => $error->getMessage()], $error->status); }
});
// ---- Portal self-service auth (unauthenticated) ---------------------------
// These endpoints create the very first portal account, so they cannot require
// a session; they are throttled and audited instead.
$portalAuth = static fn (Request $request): PortalAuthService => new PortalAuthService(Database::connection());
$router->post('/api/auth/register-subscriber', static function (Request $request) use ($portalAuth): array {
    try {
        $service = $portalAuth($request);
        return Response::json(['subscriber' => $service->registerSubscriber($request->body, $request)], 201);
    } catch (AuthException $error) {
        return Response::json(['error' => $error->getMessage()], $error->status);
    }
});
$router->post('/api/auth/verify-otp', static function (Request $request) use ($portalAuth): array {
    try {
        $service = $portalAuth($request);
        return Response::json(['verification' => $service->verifyOtp($request->body, $request)]);
    } catch (AuthException $error) {
        return Response::json(['error' => $error->getMessage()], $error->status);
    }
});
$router->post('/api/auth/resend-otp', static function (Request $request) use ($portalAuth): array {
    try {
        $service = $portalAuth($request);
        return Response::json(['resend' => $service->resendOtp($request->body, $request)]);
    } catch (AuthException $error) {
        return Response::json(['error' => $error->getMessage()], $error->status);
    }
});
$router->post('/api/auth/forgot-password', static function (Request $request) use ($portalAuth): array {
    try {
        $service = $portalAuth($request);
        return Response::json(['forgot' => $service->forgotPassword($request->body, $request)]);
    } catch (AuthException $error) {
        return Response::json(['error' => $error->getMessage()], $error->status);
    }
});
$router->post('/api/auth/reset-password', static function (Request $request) use ($portalAuth): array {
    try {
        $service = $portalAuth($request);
        return Response::json(['reset' => $service->resetPassword($request->body, $request)]);
    } catch (AuthException $error) {
        return Response::json(['error' => $error->getMessage()], $error->status);
    }
});
$request = Request::capture();

// PHP's built-in server (php -S) hands EVERY request to this script when it is
// used as the router, so without this guard /assets/*.css and /assets/*.js 404
// and the single-page UI never boots. Returning false tells the built-in server
// to serve the file itself. It is a no-op on Apache/Nginx, where the document
// root is handled before PHP is reached at all.
if (PHP_SAPI === 'cli-server') {
    $path = (string) parse_url($request->uri, PHP_URL_PATH);
    if ($path !== '/' && !str_ends_with($path, '.php')) {
        $candidate = __DIR__ . '/' . ltrim(rawurldecode($path), '/');
        if (is_file($candidate)) {
            return false;
        }
    }
}

Response::emit($router->dispatch($request->method, $request->uri, $request->body, $request->headers, $request->ipAddress, $request->userAgent));
