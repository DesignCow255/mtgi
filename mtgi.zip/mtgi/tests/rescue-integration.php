<?php

declare(strict_types=1);

use Mamore\Core\Database;
use Mamore\Rescue\RescueService;

require dirname(__DIR__) . '/bootstrap.php';
require __DIR__ . '/support.php';

$database = Database::connection();
$service = new RescueService($database);
$actor = test_actor('SYSTEM_ADMIN');
$unit = $database->query("SELECT id FROM rescue_units WHERE status = 'AVAILABLE' ORDER BY code LIMIT 1")->fetch();
$failures = [];
$assert = static function (bool $condition, string $message) use (&$failures): void {
    if (!$condition) { $failures[] = $message; fwrite(STDERR, "FAIL: {$message}\n"); return; }
    fwrite(STDOUT, "PASS: {$message}\n");
};

$assert(is_array($actor), 'system administrator is available');
$assert(is_array($unit), 'available rescue unit is configured');
$incident = null;

try {
    $incident = $service->report([
        'source' => 'HQ_MANUAL', 'callerName' => 'Integration Test', 'callerPhone' => '+243000000000',
        'province' => 'HAUT_KATANGA', 'location' => 'Automated test location',
        'description' => 'Integration test incident; safe to remove.', 'priority' => 'HIGH',
    ], $actor);
    $assert($incident['status'] === 'REPORTED', 'incident can be reported');

    $incident = $service->dispatch(['incidentId' => $incident['id'], 'unitId' => $unit['id']], $actor);
    $assert($incident['status'] === 'DISPATCHED', 'available unit can be dispatched');

    foreach (['ACKNOWLEDGED', 'EN_ROUTE', 'ON_SCENE', 'RESOLVED'] as $status) {
        $incident = $service->transition(['incidentId' => $incident['id'], 'status' => $status], $actor);
    }
    $assert($incident['status'] === 'RESOLVED', 'incident follows complete response lifecycle');
    $board = $service->board();
    $assert(isset($board['metrics']['availableUnits']), 'rescue board metrics are available');
} finally {
    if (is_array($incident)) {
        $database->prepare('DELETE FROM rescue_incident_events WHERE incident_id = :id')->execute(['id' => $incident['id']]);
        $database->prepare('DELETE FROM rescue_incidents WHERE id = :id')->execute(['id' => $incident['id']]);
    }
    if (is_array($unit)) $database->prepare("UPDATE rescue_units SET status = 'AVAILABLE' WHERE id = :id")->execute(['id' => $unit['id']]);
}

if ($failures !== []) {
    fwrite(STDERR, count($failures) . " assertion(s) failed.\n");
    exit(1);
}
