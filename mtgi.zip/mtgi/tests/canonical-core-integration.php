<?php

declare(strict_types=1);

/**
 * Canonical Identity + Vehicle Core (phases 03).
 *
 * Proves the multi-domain foundation the other domains depend on: one person per
 * human across the account and membership id spaces, one canonical vehicle per
 * physical vehicle with database-enforced registration uniqueness, and every
 * existing Smart Bus row still resolvable through its own id.
 */

use Mamore\Auth\AuthException;
use Mamore\Core\CanonicalReconciler;
use Mamore\Core\Database;
use Mamore\Core\Request;
use Mamore\Core\Uuid;
use Mamore\SmartBus\SmartBusService;

require dirname(__DIR__) . '/bootstrap.php';
require __DIR__ . '/support.php';

$database = Database::connection();
$bus = new SmartBusService($database);

$failures = [];
$assert = static function (bool $condition, string $message) use (&$failures): void {
    if ($condition) {
        fwrite(STDOUT, "PASS: {$message}\n");
        return;
    }
    $failures[] = $message;
    fwrite(STDERR, "FAIL: {$message}\n");
};
$expectRejection = static function (callable $operation, int $status, string $message) use (&$assert): void {
    try {
        $operation();
    } catch (AuthException $error) {
        $assert($error->status === $status, $message);
        return;
    }
    throw new RuntimeException("Expected rejection failed: {$message}");
};

$probeIds = [];
$plate = 'MD-TEST-' . strtoupper(bin2hex(random_bytes(3)));

try {
    // ---- The core exists --------------------------------------------------
    foreach (['persons', 'organizations', 'vehicles', 'locations', 'vehicle_types', 'location_types'] as $table) {
        $exists = $database->query("SHOW TABLES LIKE '{$table}'")->fetchColumn();
        $assert($exists === $table, "the canonical table {$table} exists");
    }

    $types = $database->query('SELECT code FROM vehicle_types')->fetchAll(PDO::FETCH_COLUMN);
    foreach (['BUS', 'TRUCK', 'PRIVATE_CAR', 'RESCUE_VEHICLE', 'TRAILER', 'AMBULANCE'] as $code) {
        $assert(in_array($code, $types, true), "vehicle type {$code} is configurable data, not code");
    }
    $locationTypes = $database->query('SELECT code FROM location_types')->fetchAll(PDO::FETCH_COLUMN);
    foreach (['HOSPITAL', 'GARAGE', 'FUEL_STATION', 'DEPOT', 'BORDER_POST', 'CHECKPOINT'] as $code) {
        $assert(in_array($code, $locationTypes, true), "location type {$code} is available without a code change");
    }

    // ---- One person per human, across both id spaces -----------------------
    $duplicates = (int) $database->query(
        "SELECT COUNT(*) FROM (SELECT email FROM persons WHERE email IS NOT NULL AND email <> '' GROUP BY email HAVING COUNT(*) > 1) d"
    )->fetchColumn();
    $assert($duplicates === 0, 'no human has two person rows after reconciliation');

    $account = $database->query(
        "SELECT u.id, u.person_id, u.subscriber_id, s.person_id AS subscriber_person
         FROM users u LEFT JOIN subscribers s ON s.id = u.subscriber_id
         WHERE u.subscriber_id IS NOT NULL LIMIT 1"
    )->fetch();
    if (is_array($account)) {
        $assert($account['person_id'] !== null, 'an account resolves to a canonical person');
        $assert(
            $account['subscriber_person'] === $account['person_id'],
            'the membership and the account share ONE person, not two'
        );
    } else {
        $assert(true, 'no linked account/subscriber pair to compare in this fixture set');
    }

    // ---- Every existing vehicle domain row reaches the canonical registry --
    $unlinkedBuses = (int) $database->query(
        'SELECT COUNT(*) FROM smartbus_vehicles v LEFT JOIN vehicles c ON c.id = v.vehicle_id WHERE c.id IS NULL'
    )->fetchColumn();
    $assert($unlinkedBuses === 0, 'every Smart Bus vehicle resolves to a canonical vehicle');
    $unlinkedUnits = (int) $database->query(
        'SELECT COUNT(*) FROM rescue_units u LEFT JOIN vehicles c ON c.id = u.vehicle_id WHERE c.id IS NULL'
    )->fetchColumn();
    $assert($unlinkedUnits === 0, 'every rescue unit resolves to a canonical vehicle');

    $sample = $database->query(
        'SELECT v.code, v.registration_number, c.vehicle_type, c.registration_number AS canonical_plate
         FROM smartbus_vehicles v JOIN vehicles c ON c.id = v.vehicle_id LIMIT 1'
    )->fetch();
    $assert(is_array($sample) && $sample['canonical_plate'] === $sample['registration_number'], 'the canonical vehicle carries the same registration the domain already used');

    // ---- Registration uniqueness is enforced by the database ---------------
    $newVehicleId = Uuid::v4();
    $database->prepare(<<<'SQL'
        INSERT INTO vehicles (id, vehicle_type, registration_number, country_of_registration, make, model)
        VALUES (:id, 'PRIVATE_CAR', :plate, 'CD', 'Toyota', 'Corolla')
        SQL)->execute(['id' => $newVehicleId, 'plate' => $plate]);
    $probeIds[] = $newVehicleId;
    $assert(true, 'a canonical vehicle can be registered');

    $duplicateBlocked = false;
    try {
        $database->prepare(
            "INSERT INTO vehicles (id, vehicle_type, registration_number, country_of_registration) VALUES (:id, 'PRIVATE_CAR', :plate, 'CD')"
        )->execute(['id' => Uuid::v4(), 'plate' => $plate]);
    } catch (PDOException $error) {
        $duplicateBlocked = str_contains($error->getMessage(), 'Duplicate entry');
    }
    $assert($duplicateBlocked, 'the same registration cannot be created twice for one country');

    $database->prepare(
        "INSERT INTO vehicles (id, vehicle_type, registration_number, country_of_registration) VALUES (:id, 'PRIVATE_CAR', :plate, 'TZ')"
    )->execute(['id' => $probeId = Uuid::v4(), 'plate' => $plate]);
    $probeIds[] = $probeId;
    $assert(true, 'the same plate in a different country is a different vehicle');

    // ---- Existing Smart Bus behaviour is untouched -------------------------
    $board = $bus->board();
    $actor = test_actor('BUS_OPERATOR', ['firstName' => 'Core', 'lastName' => 'Operator']);
    $trip = null;
    try {
        $trip = $bus->schedule([
            'routeId' => $board['routes'][0]['id'],
            'vehicleId' => $board['vehicles'][0]['id'],
            'departureAt' => (new DateTimeImmutable('+2 days'))->setTime(8, 30)->format('Y-m-d H:i:s'),
            'usdCdfRate' => 2850,
        ], $actor);
        $booking = $bus->book([
            'tripId' => $trip['id'], 'passengerName' => 'Core Test', 'passengerPhone' => '+243000000333', 'seatNumber' => 6,
        ], $actor);
        $assert($booking['status'] === 'CONFIRMED', 'booking still works with the canonical core in place');
        $assert($booking['totalCdf'] > $booking['fareCdf'], 'the fare plus rescue fee identity is unchanged');
    } finally {
        if (is_array($trip)) {
            $database->prepare('DELETE FROM smartbus_bookings WHERE trip_id = :id')->execute(['id' => $trip['id']]);
            $database->prepare('DELETE FROM smartbus_trips WHERE id = :id')->execute(['id' => $trip['id']]);
        }
    }

    // ---- Reconciliation is idempotent -------------------------------------
    $before = (new CanonicalReconciler($database))->reconcile();
    $second = (new CanonicalReconciler($database))->reconcile();
    $assert($second['persons'] === $before['persons'], 'reconciling twice does not create another person');
    $assert($second['vehicles'] === $before['vehicles'], 'reconciling twice does not create another vehicle');
    $assert($second['duplicatePersons'] === 0, 'reconciliation leaves no duplicate people');
} finally {
    foreach ($probeIds as $vehicleId) {
        $database->prepare('DELETE FROM vehicles WHERE id = :id')->execute(['id' => $vehicleId]);
    }
    $database->exec("DELETE FROM users WHERE first_name = 'Core' AND email LIKE '%@mamore.test'");
}

if ($failures !== []) {
    fwrite(STDERR, count($failures) . " assertion(s) failed.\n");
    exit(1);
}
