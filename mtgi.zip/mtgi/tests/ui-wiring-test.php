<?php

declare(strict_types=1);

/**
 * UI wiring guard.
 *
 * The single-page shell is the only way a human exercises the converted
 * features, so a panel that exists in app.html but never got a loader, or a
 * fetch that points at a route the router does not serve, is a silent break.
 * This test reads the three shipped assets and fails when:
 *
 *  - a panel, nav entry, dialog or portal auth form is missing;
 *  - the feature bundle is not linked from app.html;
 *  - the feature bundle calls an /api/ path that public/index.php never
 *    registers (this is the check that catches renamed/removed endpoints);
 *  - a panel loader is not registered on the shared Mamore registry, or the
 *    panel is missing from the router allow-list used by switchPanel().
 *
 * Written in PHP on purpose: the CI job for this app has no Node runtime.
 */

require dirname(__DIR__) . '/bootstrap.php';
require __DIR__ . '/support.php';

$root = dirname(__DIR__);
$html = (string) file_get_contents($root . '/public/app.html');
$app = (string) file_get_contents($root . '/public/assets/app.js');
$feature = (string) file_get_contents($root . '/public/assets/subscriptions.js');
$router = (string) file_get_contents($root . '/public/index.php');

$failures = [];
$assert = static function (bool $condition, string $message) use (&$failures): void {
    if ($condition) {
        fwrite(STDOUT, "PASS: {$message}\n");
        return;
    }
    $failures[] = $message;
    fwrite(STDERR, "FAIL: {$message}\n");
};

// Panels, navigation entries, dialogs and portal auth forms.
$panels = ['subscriptions', 'receipts', 'audit', 'notifications', 'membership'];
foreach ($panels as $panel) {
    $assert(str_contains($html, 'id="' . $panel . '-panel"'), "the {$panel} panel exists in the shell");
}
// Reachability is asserted against the navigation source above, since the
// navigation is no longer static markup. The panel itself is still checked here.
unset($nav);
// Navigation entries moved out of the markup and into Core\Navigation, because
// the sidebar is now rendered from GET /api/navigation: the server returns only
// the destinations a role may open, which a static list in app.html cannot do.
// The PANELS are still static markup; only the navigation entries moved. This
// assertion therefore checks the data structure, which is a stronger guarantee
// than a string in HTML: it is the same source the server renders from.
$navigation = (string) file_get_contents($root . '/app/Core/Navigation.php');
foreach (['subscriptions', 'receipts', 'audit', 'membership', 'notifications', 'boarding', 'command', 'overview', 'users', 'sessions', 'vip', 'truckcargo', 'privatevehicles', 'analytics', 'finance', 'tracking', 'rescue', 'alerts', 'mobility', 'operations', 'portal', 'mybookings'] as $panel) {
    $assert(
        str_contains($navigation, "'panel' => '{$panel}'"),
        "the {$panel} destination is declared in the navigation source"
    );
}

// Every navigation key must exist in EVERY locale. Navigation labels are
// resolved on the server, so a key missing from one catalogue ships that locale
// a raw dotted key into the sidebar -- the single most visible i18n failure.
preg_match_all("/'key' => '([a-z_]+)', 'icon' =>/", $navigation, $navKeys);
$navCatalogue = require $root . '/resources/lang/en/navigation.php';
foreach (array_unique($navKeys[1]) as $key) {
    $assert(isset($navCatalogue[$key]), "navigation key '{$key}' exists in the English catalogue");
    foreach (['fr', 'sw'] as $locale) {
        $translated = require $root . "/resources/lang/{$locale}/navigation.php";
        $assert(isset($translated[$key]), "navigation key '{$key}' is translated in {$locale}");
    }
}
$assert(str_contains($html, 'data-nav-mount'), 'the shell has a mount point for the rendered navigation');
$assert(str_contains($router, "'/api/navigation'"), 'the router serves /api/navigation');
$assert(str_contains($app, "api('/api/navigation')"), 'the shell fetches its navigation');

// Every destination the navigation declares must also have a real panel, or a
// user would click straight into the "coming soon" placeholder.
preg_match_all("/'panel' => '([a-z]+)'/", $navigation, $declared);
foreach (array_unique($declared[1]) as $panel) {
    $assert(
        str_contains($html, 'id="' . $panel . '-panel"'),
        "the declared destination {$panel} has a panel in the shell"
    );
}

foreach (['register-form', 'verify-form', 'forgot-form', 'reset-form'] as $form) {
    $assert(str_contains($html, 'id="' . $form . '"'), "the portal auth screen {$form} exists");
}
foreach (['subscription-dialog', 'subscription-payment-dialog', 'buy-cover-dialog', 'detail-dialog'] as $dialog) {
    $assert(str_contains($html, 'id="' . $dialog . '"'), "the {$dialog} dialog exists");
}
$assert(str_contains($html, '/assets/subscriptions.js'), 'the feature bundle is linked from the shell');

// Every API path the feature bundle calls must be served by the router.
preg_match_all("#api\('(/api/[^'?]*)#", $feature, $matches);
$endpoints = array_values(array_unique($matches[1]));
$assert($endpoints !== [], 'the feature bundle calls the API');

foreach ($endpoints as $endpoint) {
    $registered = str_contains($router, "'" . $endpoint . "'");
    $assert($registered, "the router serves {$endpoint} (called by the UI)");
}

// Loaders are registered on the shared registry, and the panels are allowed.
$loaders = ['subscriptions' => 'loadSubscriptions', 'receipts' => 'loadReceipts', 'audit' => 'loadAudit',
    'notifications' => 'loadNotifications', 'membership' => 'loadMembership'];
foreach ($loaders as $panel => $function) {
    $assert(str_contains($feature, 'app.loaders.' . $panel . ' = ' . $function), "the {$panel} panel loader is registered");
    $assert(str_contains($app, "'" . $panel . "'"), "the {$panel} panel is in the switcher allow-list");
    $assert(str_contains($app, $panel . ':'), "the {$panel} panel has a page title");
}

// The shared namespace must be published before the bundle consumes it.
$assert(str_contains($app, 'window.Mamore = Mamore'), 'the shell publishes the shared Mamore namespace');
$assert(str_contains($app, 'Object.assign(Mamore'), 'the shared api/auth helpers are exposed to the feature bundle');
$assert(str_contains($feature, 'window.Mamore || null'), 'the feature bundle reads the shared namespace defensively');

// php -S hands every request to the entry script when it is the router, so the
// entry point must fall through to the built-in server for static files. Without
// this, every asset 404s and the UI never boots in local development.
$assert(
    str_contains($router, "PHP_SAPI === 'cli-server'") && str_contains($router, 'return false'),
    'the entry point serves static assets under php -S'
);
foreach (['/assets/app.js', '/assets/subscriptions.js', '/assets/app.css'] as $asset) {
    $assert(str_contains($html, $asset), 'the shell references ' . $asset);
    $assert(is_file($root . '/public' . $asset), $asset . ' exists on disk');
}
// The receipt print view ships its own stylesheet.
$printView = (string) file_get_contents($root . '/resources/views/receipts/print.php');
$assert(str_contains($printView, '/assets/receipt.css'), 'the receipt print view references /assets/receipt.css');
$assert(is_file($root . '/public/assets/receipt.css'), '/assets/receipt.css exists on disk');

// --- Smart Bus v2 surfaces -------------------------------------------------
$assert(str_contains($html, '/assets/smartbus-v2.js'), 'the shell loads the Smart Bus v2 script');
$assert(is_file($root . '/public/assets/smartbus-v2.js'), '/assets/smartbus-v2.js exists on disk');
$assert(str_contains($html, 'id="boarding-panel"'), 'the boarding panel exists in the shell');
$assert(str_contains($html, 'id="command-panel"'), 'the command centre panel exists in the shell');
$assert(str_contains($html, 'id="boarding-body"'), 'the boarding panel has a manifest mount point');
$assert(str_contains($html, 'id="boarding-safety"'), 'the boarding panel has a safety mount point');
$assert(str_contains($html, 'id="command-body"'), 'the command centre has a summary mount point');
$assert(str_contains($html, 'id="command-live"'), 'the command centre has a live trips mount point');

$v2 = (string) file_get_contents($root . '/public/assets/smartbus-v2.js');
foreach (['countdownFrom', 'boardingGrid', 'renderManifest', 'renderSafety', 'renderPilot', 'renderLiveTrips'] as $fn) {
    $assert(str_contains($v2, $fn), 'the v2 script implements ' . $fn);
}
// The server clock, not the browser clock.
$assert(str_contains($v2, 'serverOffsetSeconds'), 'countdowns are corrected by the server clock offset');
$assert(str_contains($v2, 'No data available'), 'the UI renders the no-data message rather than a fake zero');
$assert(str_contains($v2, "escapeHtml"), 'every rendered value is escaped');

$appJs = (string) file_get_contents($root . '/public/assets/app.js');
$assert(str_contains($appJs, "Mamore.loaders.command"), 'the command centre registers its loader');
$assert(str_contains($appJs, "Mamore.loaders.boarding"), 'the boarding panel registers its loader');
$assert(str_contains($appJs, "MamoreSmartBus.renderPilot"), 'the command centre renders through the v2 helpers');
$assert(str_contains($appJs, "'mobility'"), 'the existing Smart mobility panel is preserved');
$assert(str_contains($appJs, 'data-book-trip'), 'the existing book-seat handler is preserved');
$assert(str_contains($appJs, "name === 'command'"), 'switching to the command centre triggers its loader');
$assert(str_contains($appJs, "name === 'boarding'"), 'switching to the boarding panel triggers its loader');

$css = (string) file_get_contents($root . '/public/assets/app.css');
$assert(str_contains($css, '.boarding-grid'), 'the boarding grid is styled');
$assert(str_contains($css, '.badge-row'), 'badges are styled');
$assert(str_contains($css, '.safety-grid'), 'the safety grid is styled');

// No hard-coded business rules in the view layer: the fare engine is not
// recomputed in JavaScript, the API is the only source.
$assert(!str_contains($v2, 'base_fare'), 'the v2 script does not re-implement fare rules');
$assert(!str_contains($v2, 'rescue_fee_usd *'), 'the v2 script does not re-implement the rescue fee conversion');

// --- Multi-domain surfaces -------------------------------------------------
$assert(str_contains($html, '/assets/multi-domain.js'), 'the shell loads the multi-domain script');
$assert(is_file($root . '/public/assets/multi-domain.js'), '/assets/multi-domain.js exists on disk');
foreach (['operations', 'analytics', 'vip', 'truckcargo', 'privatevehicles'] as $panel) {
    $assert(str_contains($html, "id=\"{$panel}-panel\""), "the {$panel} panel exists in the shell");
    // Reachability is now asserted against Core\Navigation (see above), because
    // the navigation is rendered from the server rather than hard-coded.
    $assert(str_contains($navigation, "'panel' => '{$panel}'"), "the {$panel} panel is reachable from navigation");
    $assert(str_contains($appJs, "'{$panel}'"), "the {$panel} panel is registered as a real panel");
}
foreach (['operations-body', 'analytics-body', 'vip-body', 'truck-body', 'private-body'] as $mount) {
    $assert(str_contains($html, "id=\"{$mount}\""), "the {$mount} mount point exists");
}

$domains = (string) file_get_contents($root . '/public/assets/multi-domain.js');
foreach (['renderOperations', 'renderAnalytics', 'renderVip', 'renderPrivate', 'renderTruck'] as $renderer) {
    $assert(str_contains($domains, $renderer), 'the multi-domain script implements ' . $renderer);
}
$assert(str_contains($domains, 'No data available'), 'domain panels render the no-data message, not a fake zero');
$assert(str_contains($domains, 'escapeHtml'), 'every domain value is escaped before rendering');
$assert(str_contains($domains, 'data-domain'), 'the domain switcher filters the operations board');
$assert(str_contains($domains, 'statusPill'), 'status is shown as text, not colour alone');
// The domain view layer must not re-implement domain rules.
$assert(!str_contains($domains, 'rescue_fee_usd'), 'the domain script does not re-implement fee rules');
$assert(!str_contains($domains, 'SUM('), 'the domain script does not aggregate in the browser');

$cssMulti = (string) file_get_contents($root . '/public/assets/app.css');
$assert(str_contains($cssMulti, '.domain-kpis'), 'domain KPI cards are styled');
$assert(str_contains($cssMulti, '.domain-switch'), 'the domain switcher is styled');

// --- Typography and iconography --------------------------------------------
// Poppins is the only typeface in the product and both fonts are self-hosted,
// because this is an intranet app that must render with no third-party origin
// reachable. These checks fail if anyone reintroduces a second family or moves
// the fonts back to a CDN.
$assert(str_contains($cssMulti, '@import url("fonts.css")'), 'app.css pulls in the self-hosted font faces');
$assert(str_contains($cssMulti, '@import url("fontawesome.css")'), 'app.css pulls in the icon font');
$assert(str_contains($cssMulti, '--font: "Poppins"'), 'the font family is declared once as Poppins');
foreach (['Georgia', 'Inter', 'Segoe UI"'] as $retired) {
    $assert(
        !preg_match('~font-family:[^;]*' . preg_quote($retired, '~') . '~', $cssMulti),
        "no competing font family ({$retired}) is declared in app.css"
    );
}
$assert(!str_contains($cssMulti, 'fonts.googleapis'), 'app.css does not depend on the Google Fonts CDN');
$assert(!str_contains($html, 'fonts.googleapis'), 'the shell does not depend on the Google Fonts CDN');

$fontsCss = (string) file_get_contents($root . '/public/assets/fonts.css');
foreach ([400, 500, 600, 700, 800, 900] as $weight) {
    $assert(str_contains($fontsCss, "font-weight: {$weight}"), "Poppins {$weight} is declared");
}
preg_match_all("~url\('(fonts/poppins-[a-z0-9-]+\.woff2)'\)~", $fontsCss, $fontUrls);
$assert($fontUrls[1] !== [], 'the Poppins faces point at local woff2 files');
$missingFonts = [];
foreach ($fontUrls[1] as $url) {
    if (!is_file($root . '/public/assets/' . $url)) {
        $missingFonts[] = $url;
    }
}
$assert($missingFonts === [], 'every Poppins woff2 referenced by fonts.css exists on disk');

// The icon font is a subset, so a name used in the UI but absent from the
// stylesheet renders as an empty box rather than failing loudly. Guard the
// 1:1 relationship between the glyphs the markup asks for and the codepoints
// the subset actually ships.
$iconCss = (string) file_get_contents($root . '/public/assets/fontawesome.css');
$assert(str_contains($iconCss, '@font-face'), 'the icon font face is declared');
preg_match_all('~\.fa-([a-z0-9-]+):before~', $iconCss, $declared);
$declaredIcons = array_unique($declared[1]);
$assert($declaredIcons !== [], 'the icon stylesheet declares named icons');

// Collect icon names from the static shell and from the icon() helper calls in
// the bundles (the runtime-rendered buttons). The pattern matches the fa-solid
// family prefix followed by the icon name, so the family token itself is never
// mistaken for an icon.
$usedIcons = [];
preg_match_all('~class="fa-solid fa-([a-z0-9-]+)"~', $html, $shellIcons);
foreach ($shellIcons[1] as $name) {
    $usedIcons[$name] = true;
}
foreach (['app.js', 'subscriptions.js', 'smartbus-v2.js', 'multi-domain.js'] as $bundle) {
    $code = (string) file_get_contents($root . '/public/assets/' . $bundle);
    if (preg_match_all("~icon\('([a-z0-9-]+)'\)~", $code, $helperIcons) > 0) {
        foreach ($helperIcons[1] as $name) {
            $usedIcons[$name] = true;
        }
    }
}
$assert($usedIcons !== [], 'the interface uses Font Awesome icons');

$unknownIcons = array_values(array_diff(array_keys($usedIcons), $declaredIcons));
$assert(
    $unknownIcons === [],
    'every icon used is present in the icon subset' . ($unknownIcons === [] ? '' : ': ' . implode(', ', $unknownIcons))
);

// Icons are decorative, so each one must be hidden from assistive technology;
// the visible label or the control's aria-label carries the meaning.
$assert(
    !preg_match('~<i class="fa-solid fa-[a-z0-9-]+"(?![^>]*aria-hidden="true")~', $html),
    'every icon in the shell is aria-hidden'
);

fwrite(STDOUT, sprintf("\n%d API paths wired from the UI.\n", count($endpoints)));
fwrite(STDOUT, sprintf("%d distinct icons in use, %d in the subset.\n", count($usedIcons), count($declaredIcons)));

if ($failures !== []) {
    fwrite(STDERR, count($failures) . " assertion(s) failed.\n");
    exit(1);
}
