<?php

declare(strict_types=1);

/**
 * WCAG 2.2 AA contrast verification for the Mamore design tokens.
 *
 * Contrast is not eyeballed. This computes the real WCAG 2.x relative
 * luminance ratio for every foreground/background token pairing that the
 * product actually uses, in BOTH themes, and fails the run when a pairing
 * misses its threshold.
 *
 * The tokens are parsed out of the stylesheets rather than hard-coded here, so
 * this test keeps its value when a token is retuned: edit the token and the
 * test follows it.
 *
 * Thresholds (WCAG 2.2):
 *   - 4.5:1  normal text
 *   - 3.0:1  large text (>= 24px, or >= 18.66px bold)
 *   - 3.0:1  UI component boundaries and meaningful graphics (1.4.11)
 *
 * Usage: php tests/contrast-test.php
 */

require dirname(__DIR__) . '/bootstrap.php';

$root = dirname(__DIR__);
$failures = [];
$checked = 0;

/**
 * Read `--name: value;` declarations out of a rule body.
 *
 * @return array<string,string>
 */
$declarations = static function (string $file, string $selector): array {
    $css = (string) file_get_contents($file);
    // Anchor on the selector being a complete token followed by "{", so it
    // cannot match a selector merely mentioned inside a comment (the ":root"
    // reference in the semantic-defaults note would otherwise match first).
    $pattern = '/(?:^|[\};])\s*(?:\/\*.*?\*\/\s*)*' . preg_quote($selector, '/') . '\s*\{([^}]*)\}/s';
    if (preg_match($pattern, $css, $matches) !== 1) {
        fwrite(STDERR, "Could not find rule '{$selector}' in {$file}\n");
        exit(1);
    }

    $tokens = [];
    foreach (explode(';', $matches[1]) as $declaration) {
        if (preg_match('/(--[a-z0-9-]+)\s*:\s*(.+)/i', $declaration, $token) === 1) {
            $tokens[$token[1]] = trim($token[2]);
        }
    }

    return $tokens;
};

/** Resolve a token value, following var() indirection until a literal remains. */
$resolve = static function (array $tokens, string $name): string {
    $seen = [];
    while (isset($tokens[$name]) && !isset($seen[$name])) {
        $seen[$name] = true;
        $value = trim($tokens[$name]);
        if (preg_match('/^var\(\s*(--[a-z0-9-]+)\s*\)$/i', $value, $inner) === 1) {
            $name = $inner[1];
            continue;
        }

        return $value;
    }

    return '';
};

/** Parse #rgb / #rrggbb / rgb() / rgba() into [r,g,b,alpha]. */
$parse = static function (string $colour): array {
    $colour = trim($colour);
    if (preg_match('/^#([0-9a-f]{3})$/i', $colour, $m) === 1) {
        $colour = '#' . $m[1][0] . $m[1][0] . $m[1][1] . $m[1][1] . $m[1][2] . $m[1][2];
    }
    if (preg_match('/^#([0-9a-f]{6})$/i', $colour, $m) === 1) {
        return [hexdec(substr($m[1], 0, 2)), hexdec(substr($m[1], 2, 2)), hexdec(substr($m[1], 4, 2)), 1.0];
    }
    // Delimiter is "|" rather than "/", because the pattern contains an
    // unescaped slash inside the alpha separator class ([,/\s]). Using "/" as
    // the delimiter would terminate the pattern early ("Unknown modifier").
    if (preg_match('|^rgba?\(\s*([\d.]+)[,\s]+([\d.]+)[,\s]+([\d.]+)(?:[,\s]+([\d.]+%?))?\s*\)$|i', $colour, $m) === 1) {
        $alpha = $m[4] ?? '1';
        if (str_ends_with($alpha, '%')) {
            $alpha = (float) substr($alpha, 0, -1) / 100;
        }

        return [(float) $m[1], (float) $m[2], (float) $m[3], (float) $alpha];
    }

    return [0, 0, 0, 1.0];
};

/** Composite a possibly translucent colour over an opaque backdrop. */
$flatten = static function (array $fg, array $bg): array {
    if ($fg[3] >= 1.0) {
        return $fg;
    }
    $alpha = $fg[3];

    return [
        $fg[0] * $alpha + $bg[0] * (1 - $alpha),
        $fg[1] * $alpha + $bg[1] * (1 - $alpha),
        $fg[2] * $alpha + $bg[2] * (1 - $alpha),
        1.0,
    ];
};

/** WCAG relative luminance. */
$luminance = static function (array $rgb): float {
    $channel = static function (float $value): float {
        $value /= 255;

        return $value <= 0.03928 ? $value / 12.92 : (($value + 0.055) / 1.055) ** 2.4;
    };

    return 0.2126 * $channel($rgb[0]) + 0.7152 * $channel($rgb[1]) + 0.0722 * $channel($rgb[2]);
};

$contrast = static function (array $fg, array $bg) use ($flatten, $luminance): float {
    $a = $luminance($flatten($fg, $bg));
    $b = $luminance($bg);

    return (max($a, $b) + 0.05) / (min($a, $b) + 0.05);
};

// --- Load every token layer -------------------------------------------------
// tokens.css carries the brand, the scale AND the light semantic defaults on
// :root; each theme file then overrides the semantic layer for its attribute.
$baseTokens = $declarations($root . '/public/assets/css/tokens.css', ':root');

$themes = [
    'light' => $declarations($root . '/public/assets/css/themes/light.css', '[data-theme="light"]'),
    'dark' => $declarations($root . '/public/assets/css/themes/dark.css', '[data-theme="dark"]'),
];

/**
 * The pairings the product actually renders, with the threshold each must meet.
 * These are the combinations a reader actually sees, not an exhaustive matrix.
 */
$pairings = [
    // label                       foreground          background           threshold
    ['body text on app',          'text-primary',      'bg-app',             4.5],
    ['body text on surface',      'text-primary',      'surface-1',          4.5],
    ['secondary on surface',      'text-secondary',    'surface-1',          4.5],
    ['muted on surface',          'text-muted',        'surface-1',          4.5],
    ['muted on app',              'text-muted',        'bg-app',             4.5],
    ['muted on sunken',           'text-muted',        'surface-sunken',     4.5],
    ['secondary on sunken',       'text-secondary',    'surface-sunken',     4.5],
    ['link on surface',           'text-link',         'surface-1',          4.5],
    ['inverse on navy sidebar',   'text-inverse',      'surface-nav',        4.5],
    ['on-accent on gold',         'text-on-accent',    'brand-accent',       4.5],
    ['success tone on surface',   'tone-success',      'surface-1',          4.5],
    ['warning tone on surface',   'tone-warning',      'surface-1',          4.5],
    ['danger tone on surface',    'tone-danger',       'surface-1',          4.5],
    ['info tone on surface',      'tone-info',         'surface-1',          4.5],
    ['neutral tone on surface',   'tone-neutral',      'surface-1',          4.5],
    /*
     * WCAG 1.4.11 asks for 3:1 on the boundary of a control the user has to be
     * able to identify -- an input, a select, a toggle. It does NOT ask for
     * that on decorative separators or on the hairline between two panels, so
     * --border-subtle and --border-default are intentionally not asserted here
     * and are allowed to stay subtle. --border-control is the token that MUST
     * clear 3:1, and it is what any real control edge uses.
     */
    ['control border on surface', 'border-control',    'surface-1',          3.0],
    ['control border on sunken',  'border-control',    'surface-sunken',     3.0],
    ['focus ring on surface',     'border-focus',      'surface-1',          3.0],
    ['focus ring on app',         'border-focus',      'bg-app',             3.0],
    ['nav border on sidebar',     'border-nav-strong', 'surface-nav',        3.0],
];

foreach ($themes as $themeName => $themeTokens) {
    $tokens = array_merge($baseTokens, $themeTokens);

    fwrite(STDOUT, "=== {$themeName}\n");
    foreach ($pairings as [$label, $fgToken, $bgToken, $threshold]) {
        $fgValue = $resolve($tokens, '--' . $fgToken);
        $bgValue = $resolve($tokens, '--' . $bgToken);
        $checked++;

        if ($fgValue === '' || $bgValue === '') {
            $failures[] = "{$themeName}: {$label} — missing token (--{$fgToken} or --{$bgToken})";
            fwrite(STDERR, "FAIL: {$themeName} {$label}: missing token\n");
            continue;
        }

        $ratio = $contrast($parse($fgValue), $parse($bgValue));
        $pass = $ratio >= $threshold;

        fwrite(STDOUT, sprintf(
            "%s: %-30s %5.2f:1 (min %.1f)  --%s on --%s\n",
            $pass ? 'PASS' : 'FAIL',
            $label,
            $ratio,
            $threshold,
            $fgToken,
            $bgToken
        ));

        if (!$pass) {
            $failures[] = sprintf('%.2f:1 < %.1f:1 — %s on %s', $ratio, $threshold, $label, $themeName);
        }
    }
    fwrite(STDOUT, "\n");
}

fwrite(STDOUT, sprintf("Checked %d token pairings across %d themes.\n", $checked, count($themes)));

if ($failures !== []) {
    fwrite(STDERR, "\n" . count($failures) . " contrast failure(s):\n");
    foreach ($failures as $failure) {
        fwrite(STDERR, '  - ' . $failure . "\n");
    }
    exit(1);
}

fwrite(STDOUT, "All contrast pairings meet WCAG 2.2 AA.\n");
