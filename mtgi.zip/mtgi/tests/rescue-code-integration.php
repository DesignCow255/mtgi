<?php

declare(strict_types=1);

/**
 * Rescue Codes (Feature Group A) and the signed ticket.
 *
 * Proves the security rules the brief demands: high-entropy human-readable
 * codes that do not leak database ids, public verification that discloses no
 * identity, control-center detail that requires a permission, an audit trail
 * for every access, revocation and controlled regeneration, and a ticket
 * payload that cannot be forged.
 */

use Mamore\Auth\AuthException;
use Mamore\Auth\AuthService;
use Mamore\Core\AuditLog;
use Mamore\Core\Database;
use Mamore\Core\Request;
use Mamore\Finance\SubscriptionPaymentService;
use Mamore\SmartBus\RescueCodeService;
use Mamore\SmartBus\TicketSigner;
use Mamore\Subscription\SubscriptionService;

require dirname(__DIR__) . '/bootstrap.php';
require __DIR__ . '/support.php';

$database = Database::connection();
$codes = new RescueCodeService($database);
$subscriptions = new SubscriptionService($database);
$payments = new SubscriptionPaymentService($database);
$auth = new AuthService($database);

$failures = [];
$assert = static function (bool $condition, string $message) use (&$failures): void {
    if ($condition) {
        fwrite(STDOUT, "PASS: {$message}\n");
        return;
    }
    $failures[] = $message;
    fwrite(STDERR, "FAIL: {$message}\n");
};
$expectRejection = static function (callable $operation, int $status, string $message) use ($assert): void {
    try {
        $operation();
    } catch (AuthException $error) {
        $assert($error->status === $status, $message);
        return;
    }
    throw new RuntimeException("Expected rejection failed: {$message}");
};

$password = 'RescueCodeTest!2026';
$operator = test_actor('HQ_DISPATCHER', ['password' => $password, 'firstName' => 'Control', 'lastName' => 'Center']);
$auditor = test_actor('AUDITOR', ['password' => $password, 'firstName' => 'No', 'lastName' => 'Permission']);
$admin = test_actor('SYSTEM_ADMIN', ['password' => $password, 'firstName' => 'Rescue', 'lastName' => 'Manager']);
$customer = test_actor('CUSTOMER', ['password' => $password, 'firstName' => 'Vip', 'lastName' => 'Subscriber']);
$operatorSession = $auth->authenticate($auth->login((string) $database->query('SELECT email FROM users WHERE id = ' . $database->quote($operator['id']))->fetchColumn(), $password, new Request('POST', '/api/auth/login'))['accessToken']);
$auditorSession = $auth->authenticate($auth->login((string) $database->query('SELECT email FROM users WHERE id = ' . $database->quote($auditor['id']))->fetchColumn(), $password, new Request('POST', '/api/auth/login'))['accessToken']);
$adminSession = $auth->authenticate($auth->login((string) $database->query('SELECT email FROM users WHERE id = ' . $database->quote($admin['id']))->fetchColumn(), $password, new Request('POST', '/api/auth/login'))['accessToken']);
$customerSession = $auth->authenticate($auth->login((string) $database->query('SELECT email FROM users WHERE id = ' . $database->quote($customer['id']))->fetchColumn(), $password, new Request('POST', '/api/auth/login'))['accessToken']);

$request = new Request('POST', '/api/rescue-code/lookup', [], [], '198.51.100.55', 'MamoreRescueCodeTest/1.0');

$subscription = null;
$subscriberId = null;
$issued = null;

try {
    // ---- The subscriber must hold live cover before a code exists --------
    $subscriberId = \Mamore\Core\Uuid::v4();
    $database->prepare(
        'INSERT INTO subscribers (id, membership_number, first_name, last_name, email)
         VALUES (:id, :number, :first, :last, :email)'
    )->execute([
        'id' => $subscriberId, 'number' => 'MEM-RC-TEST-0001', 'first' => 'Vip', 'last' => 'Subscriber',
        'email' => 'vip-rc@mamore.test',
    ]);
    $database->prepare('UPDATE users SET subscriber_id = :subscriber WHERE id = :id')
        ->execute(['subscriber' => $subscriberId, 'id' => $customer['id']]);
    $assert($subscriberId !== '', 'the VIP subscriber profile is provisioned for the test');

    $expectRejection(
        static fn () => $codes->issue(['subscriberId' => $subscriberId], $adminSession, $request),
        422,
        'a code cannot be issued without an active subscription'
    );

    $subscription = $subscriptions->create([
        'productCode' => 'TRUCK_RESCUE',
        'province' => 'HAUT_KATANGA',
        'subscriberId' => $subscriberId,
        'notes' => 'Rescue code test',
    ], $adminSession);
    $payments->receive(['subscriptionId' => $subscription['id'], 'paymentMethod' => 'CASH'], $adminSession, $request);

    // ---- Issue ------------------------------------------------------------
    $issued = $codes->issue(['subscriberId' => $subscriberId], $adminSession, $request);
    $assert(
        preg_match('/^MRC-CD-[0-9]{2}-[0-9A-Z]{6}$/', (string) $issued['code']) === 1,
        'the code is human readable in the documented format'
    );
    $assert($issued['status'] === 'ACTIVE', 'a fresh code is ACTIVE');
    $assert($issued['coverageStatus'] === 'ACTIVE', 'the code reports live coverage');
    $assert(!str_contains((string) $issued['code'], str_replace('-', '', substr((string) $issued['id'], 0, 8))), 'the code does not embed a database id');
    $assert(!str_contains((string) $issued['code'], 'O') && !str_contains((string) $issued['code'], 'I'), 'the code avoids visually ambiguous characters');

    $expectRejection(
        static fn () => $codes->issue(['subscriberId' => $subscriberId], $adminSession, $request),
        409,
        'a subscriber cannot hold two active rescue codes'
    );

    $stored = $database->prepare('SELECT COUNT(*) FROM rescue_codes WHERE code = :code');
    $stored->execute(['code' => $issued['code']]);
    $assert((int) $stored->fetchColumn() === 1, 'the code is stored once and is unique');

    // ---- Public verify discloses nothing ----------------------------------
    $public = $codes->verifyPublic((string) $issued['code'], $request);
    $assert($public['valid'] === true && $public['coverageStatus'] === 'ACTIVE', 'public verification confirms validity and coverage');
    $assert(
        !str_contains(json_encode($public), (string) $subscriberId) && !str_contains(json_encode($public), 'Vip'),
        'public verification returns no subscriber identity'
    );
    $assert(isset($public['identityConfirmation']['membershipSuffix']), 'public verification returns a masked identity hint only');
    $assert(isset($public['instructions'], $public['mamoreEmergencyContact']), 'public verification returns emergency instructions and a contact');

    $unknown = $codes->verifyPublic('MRC-CD-26-ZZZZZZ', $request);
    $assert($unknown['valid'] === false && $unknown['status'] === 'NOT_FOUND', 'an unknown code is reported invalid');
    $assert($unknown['identityConfirmation'] === null, 'an unknown code returns no identity hint');

    // ---- Control center detail requires a permission ----------------------
    $expectRejection(
        static fn () => $codes->lookup((string) $issued['code'], $auditorSession, $request),
        422,
        'a responder without the rescue code permission is refused'
    );
    $expectRejection(
        static fn () => $codes->lookup((string) $issued['code'], $operatorSession, new Request('POST', '/x', ['reason' => ''], [], '198.51.100.55', 't')),
        422,
        'a lookup without a recorded reason is refused'
    );

    $detail = $codes->lookup((string) $issued['code'], $operatorSession, new Request('POST', '/x', ['reason' => 'Passenger collapsed on trip SUB'], [], '198.51.100.55', 't'));
    $assert($detail['valid'] === true && $detail['detail'] === 'JOURNEY', 'an authorised responder gets the journey detail');
    $assert($detail['subscriber']['membershipNumber'] === 'MEM-RC-TEST-0001', 'the responder sees the subscriber profile');
    $assert(array_key_exists('emergencyPhone', $detail['subscriber']), 'the responder sees emergency contacts');
    $assert($detail['rescueCode']['code'] === $issued['code'], 'the responder sees the full code');
    $assert($detail['journey'] === null, 'no active journey is reported when the subscriber is not travelling');

    // ---- Every access is audited -----------------------------------------
    $access = $database->prepare(
        'SELECT access_mode, detail_level, granted, reason, actor_role, ip_address FROM rescue_code_access_log WHERE rescue_code_id = :id ORDER BY id'
    );
    $access->execute(['id' => $issued['id']]);
    $rows = $access->fetchAll();
    $modes = array_column($rows, 'access_mode');
    $assert(in_array(RescueCodeService::MODE_PUBLIC, $modes, true), 'public verification is logged');
    $assert(in_array(RescueCodeService::MODE_CONTROL_CENTER, $modes, true), 'control center lookups are logged');
    $grantedRow = null;
    foreach ($rows as $row) {
        if ($row['access_mode'] === RescueCodeService::MODE_CONTROL_CENTER) {
            $grantedRow = $row;
        }
    }
    $assert($grantedRow !== null && $grantedRow['granted'] === 1, 'the granted lookup records the outcome');
    $assert($grantedRow['reason'] === 'Passenger collapsed on trip SUB', 'the lookup records why it happened');
    $assert($grantedRow['actor_role'] === 'HQ_DISPATCHER' && $grantedRow['ip_address'] === '198.51.100.55', 'the lookup records the responder role and IP');

    $auditRows = (new AuditLog($database))->list([
        'entityType' => 'RescueCode', 'entityId' => (string) $issued['id'], 'action' => 'RESCUE_CODE_ISSUED',
    ]);
    $assert(count($auditRows) === 1, 'issuing a code writes exactly one audit row for that code');
    $assert($auditRows[0]['actorRole'] === 'SYSTEM_ADMIN', 'the issue audit row records the issuing role');
    // ---- Portal self view -------------------------------------------------
    $own = $codes->forSubscriber($customerSession);
    $assert($own['code'] === $issued['code'], 'the subscriber can read their own rescue code');
    $assert($own['status'] === 'ACTIVE', 'their own code is active');

    $notMine = $codes->forSubscriber($operatorSession);
    $assert($notMine['status'] === 'NOT_ISSUED', 'a staff account with no subscriber link has no code');

    // ---- Masking ----------------------------------------------------------
    $masked = RescueCodeService::maskCode((string) $issued['code']);
    $assert($masked === 'MRC-••-' . substr((string) $issued['code'], -9), 'a masked code hides the country and year segments');
    // Assert the country SEGMENT is masked. Searching the whole string for
    // "CD" also matches the random 6-character tail about one run in 200, so
    // it failed on a code that had been masked perfectly correctly.
    $maskedSegments = explode('-', (string) $masked);
    $assert(($maskedSegments[1] ?? '') === '••', 'the masked code does not leak the country segment');

    // ---- Regenerate --------------------------------------------------------
    $regenerated = $codes->regenerate([
        'rescueCodeId' => $issued['id'],
        'reason' => 'Subscriber reported the code on a public stream.',
    ], $adminSession, $request);
    $assert($regenerated['code'] !== $issued['code'], 'regeneration produces a different code');
    $assert($regenerated['generation'] === 2, 'the generation counter increments');
    $assert($regenerated['status'] === 'ACTIVE', 'the replacement code is active');

    $old = $database->prepare('SELECT status, revocation_reason FROM rescue_codes WHERE id = :id');
    $old->execute(['id' => $issued['id']]);
    $oldRow = $old->fetch();
    $assert($oldRow['status'] === 'REVOKED', 'the previous code is revoked');
    $assert(str_contains((string) $oldRow['revocation_reason'], 'Regenerated'), 'the revocation reason records the regeneration');
    $assert($codes->verifyPublic((string) $issued['code'], $request)['valid'] === false, 'a regenerated-away code no longer verifies');

    // ---- Revoke ------------------------------------------------------------
    $revoked = $codes->revoke([
        'rescueCodeId' => $regenerated['id'],
        'reason' => 'Subscription cancelled by the subscriber.',
    ], $adminSession, $request);
    $assert($revoked['status'] === 'REVOKED' && $revoked['coverageStatus'] === 'INACTIVE', 'a revoked code reports no coverage');
    $again = $codes->revoke(['rescueCodeId' => $regenerated['id'], 'reason' => 'x'], $adminSession, $request);
    $assert($again['status'] === 'REVOKED', 'revoking twice is idempotent');
    $expectRejection(
        static fn () => $codes->regenerate(['rescueCodeId' => $regenerated['id'], 'reason' => 'again'], $adminSession, $request),
        409,
        'a revoked code cannot be regenerated'
    );

    // ---- Signed ticket ----------------------------------------------------
    $signed = TicketSigner::payload('MB-DEADBEEF', 'TRP-260101-ABC123', 7);
    $verified = TicketSigner::verify($signed);
    $assert($verified['valid'] === true && $verified['signed'] === true, 'a signed ticket verifies');
    $assert($verified['reference'] === 'MB-DEADBEEF' && $verified['seatNumber'] === 7, 'the signed ticket decodes to its booking and seat');

    $legacy = TicketSigner::verify('MAMORE|MB-DEADBEEF|TRP-260101-ABC123|SEAT-7');
    $assert($legacy['valid'] === true && $legacy['signed'] === false, 'a historical unsigned ticket still verifies but is flagged');

    $tampered = TicketSigner::verify('MAMORE|MB-DEADBEEF|TRP-260101-ABC123|SEAT-9|' . explode('|', $signed)[4]);
    $assert($tampered['valid'] === false && $tampered['reason'] === 'bad_signature', 'a tampered seat fails the signature check');
    $assert(TicketSigner::verify('SOMEBODY|MB-X|TRP-Y|SEAT-1')['valid'] === false, 'a foreign issuer is rejected');
    $assert(TicketSigner::verify('MAMORE|MB-X')['valid'] === false, 'a truncated payload is rejected');

} finally {
    cleanup_rescue_code_fixtures($database);
}

if ($failures !== []) {
    fwrite(STDERR, count($failures) . " assertion(s) failed.\n");
    exit(1);
}

/** Remove the subscriber, its subscription chain and every rescue code row. */
function cleanup_rescue_code_fixtures(PDO $database): void
{
    $subscriberId = (string) $database->query("SELECT id FROM subscribers WHERE membership_number = 'MEM-RC-TEST-0001'")->fetchColumn();
    $subscriptionIds = $subscriberId === ''
        ? []
        : $database->query('SELECT id FROM subscriptions WHERE subscriber_id = ' . $database->quote($subscriberId))->fetchAll(PDO::FETCH_COLUMN);

    foreach ($subscriptionIds as $subscriptionId) {
        $payments = $database->prepare('SELECT id FROM payments WHERE subscription_id = :id');
        $payments->execute(['id' => $subscriptionId]);
        foreach ($payments->fetchAll(PDO::FETCH_COLUMN) as $paymentId) {
            $database->prepare('DELETE FROM ledger_entries WHERE payment_id = :p')->execute(['p' => $paymentId]);
            $database->prepare('DELETE FROM government_taxes WHERE payment_id = :p')->execute(['p' => $paymentId]);
            $database->prepare('DELETE FROM payment_allocations WHERE payment_id = :p')->execute(['p' => $paymentId]);
            $database->prepare('DELETE FROM receipts WHERE payment_id = :p')->execute(['p' => $paymentId]);
            $database->prepare('DELETE FROM audit_logs WHERE entity_id = :p')->execute(['p' => $paymentId]);
        }
        $database->prepare('DELETE FROM payments WHERE subscription_id = :id')->execute(['id' => $subscriptionId]);
        $database->prepare('DELETE FROM subscription_history WHERE subscription_id = :id')->execute(['id' => $subscriptionId]);
        $database->prepare('DELETE FROM subscription_fees WHERE subscription_id = :id')->execute(['id' => $subscriptionId]);
        $database->prepare('DELETE FROM subscriptions WHERE id = :id')->execute(['id' => $subscriptionId]);
    }

    if ($subscriberId !== '') {
        $database->prepare('UPDATE smartbus_bookings SET subscriber_id = NULL, rescue_code_id = NULL WHERE subscriber_id = :s')->execute(['s' => $subscriberId]);
        $database->prepare('UPDATE active_journeys SET subscriber_id = NULL, rescue_code_id = NULL WHERE subscriber_id = :s')->execute(['s' => $subscriberId]);
        $database->prepare('UPDATE users SET subscriber_id = NULL WHERE subscriber_id = :s')->execute(['s' => $subscriberId]);
        $database->prepare('DELETE FROM rescue_codes WHERE subscriber_id = :s')->execute(['s' => $subscriberId]);
        $database->prepare('DELETE FROM subscriber_vehicles WHERE subscriber_id = :s')->execute(['s' => $subscriberId]);
        $database->prepare('DELETE FROM subscriber_history WHERE subscriber_id = :s')->execute(['s' => $subscriberId]);
        $database->prepare('DELETE FROM subscribers WHERE id = :s')->execute(['s' => $subscriberId]);
    }

    $database->exec("DELETE FROM audit_logs WHERE entity_type = 'RescueCode'");
    $database->exec("DELETE FROM users WHERE email = 'vip-rc@mamore.test'");
}
