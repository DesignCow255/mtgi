<?php

declare(strict_types=1);

use Mamore\Core\Database;
use Mamore\Dashboard\DashboardService;

require dirname(__DIR__) . '/bootstrap.php';

$snapshot = (new DashboardService(Database::connection()))->snapshot();

$assert = static function (bool $condition, string $message): void {
    if (!$condition) {
        fwrite(STDERR, "FAIL: {$message}\n");
        exit(1);
    }
    fwrite(STDOUT, "PASS: {$message}\n");
};

$assert(isset($snapshot['metrics']['users']) && is_int($snapshot['metrics']['users']), 'dashboard user metric');
$assert(isset($snapshot['metrics']['activeSessions']) && is_int($snapshot['metrics']['activeSessions']), 'dashboard session metric');
$assert(is_array($snapshot['roles']), 'dashboard role distribution');
$assert(is_array($snapshot['recentLogins']), 'dashboard recent login activity');
