<?php

declare(strict_types=1);

use Mamore\Core\Database;
use Mamore\SmartBus\SmartBusService;

require dirname(__DIR__) . '/bootstrap.php';
require __DIR__ . '/support.php';

$database = Database::connection(); $service = new SmartBusService($database); $board = $service->board();
$actor = test_actor('BUS_OPERATOR');
$failures = [];
$assert=static function(bool $condition,string $message)use(&$failures):void{if(!$condition){$failures[]=$message;fwrite(STDERR,"FAIL: {$message}\n");return;}fwrite(STDOUT,"PASS: {$message}\n");};
$assert(is_array($actor), 'active booking administrator is available');
$assert(count($board['routes']) >= 1 && count($board['vehicles']) >= 1, 'routes and vehicles are configured');
$trip = null;
try {
    $trip = $service->schedule(['routeId' => $board['routes'][0]['id'], 'vehicleId' => $board['vehicles'][0]['id'], 'departureAt' => (new DateTimeImmutable('+2 days'))->format('Y-m-d H:i:s'), 'usdCdfRate' => 2850], $actor);
    $assert($trip['status'] === 'SCHEDULED', 'trip can be scheduled');
    $booking = $service->book(['tripId' => $trip['id'], 'passengerName' => 'Test Passenger', 'passengerPhone' => '+243000000000', 'seatNumber' => 1], $actor);
    $assert($booking['status'] === 'CONFIRMED', 'seat booking is confirmed');
    $assert($booking['rescueFeeUsd'] === 1.5, 'mandatory rescue fee is applied');
    $assert($booking['totalCdf'] > $booking['fareCdf'], 'total includes converted rescue fee');
} finally {
    if (is_array($trip)) {
        $database->prepare('DELETE FROM smartbus_bookings WHERE trip_id = :id')->execute(['id' => $trip['id']]);
        $database->prepare('DELETE FROM smartbus_trips WHERE id = :id')->execute(['id' => $trip['id']]);
    }
}

if ($failures !== []) {
    fwrite(STDERR, count($failures) . " assertion(s) failed.\n");
    exit(1);
}
