<?php

declare(strict_types=1);

require dirname(__DIR__) . '/app/Support/FeeEngine.php';
require dirname(__DIR__) . '/app/Support/Money.php';

use Mamore\Support\FeeEngine;
use Mamore\Support\Money;

$failures = 0;
$check = static function (string $name, bool $ok) use (&$failures): void {
    echo ($ok ? 'PASS' : 'FAIL') . ": {$name}\n";
    if (!$ok) {
        $failures++;
    }
};

// Canonical chargeable semantics: GRO + TAXABLE = 600 (TS chargeableBreakdown).
$check('truck chargeable reconciles to 600.00', FeeEngine::reconciles(FeeEngine::truckBreakdown(), FeeEngine::TRUCK_TOTAL));
$check('truck total is exactly 600.00', FeeEngine::total(FeeEngine::truckBreakdown()) === '600.00');

// Informational subsets must NOT be additive: TAXABLE sub-parts sum to 170, not 600.
$check('truck taxable sub-breakdown sums to 170.00', FeeEngine::total(FeeEngine::truckTaxableSubBreakdown()) === '170.00');
$check('truck unallocated remainder is 89.00', FeeEngine::truckTaxableSubBreakdown()[3]['amount'] === '89.00');

// Private vehicle: OP_COST + TAXABLE = 80; taxable subsets sum to 40.
$check('private chargeable reconciles to 80.00', FeeEngine::reconciles(FeeEngine::privateBreakdown(), FeeEngine::PRIVATE_TOTAL));
$check('private taxable sub-breakdown sums to 40.00', FeeEngine::total(FeeEngine::privateTaxableSubBreakdown()) === '40.00');

// Money formatting and CDF conversion (exact decimal, no float drift).
$check('money format', Money::format('1234.50', 'USD') === 'USD 1,234.50');
$check('money format negative', Money::format('-50.00', 'USD') === '-USD 50.00');
$check('usd->cdf rounds up to 100', Money::usdToCdfRounded('1.50', '2800') === '4200.00');

exit($failures === 0 ? 0 : 1);

