<?php

declare(strict_types=1);

use Mamore\Core\Database;
use Mamore\Finance\FinanceService;
use Mamore\SmartBus\SmartBusService;

require dirname(__DIR__) . '/bootstrap.php';
require __DIR__ . '/support.php';

$database=Database::connection(); $bus=new SmartBusService($database); $finance=new FinanceService($database); $board=$bus->board();
$actor=test_actor('FINANCE_MANAGER');
$failures = [];
$assert=static function(bool $condition,string $message)use(&$failures):void{if(!$condition){$failures[]=$message;fwrite(STDERR,"FAIL: {$message}\n");return;}fwrite(STDOUT,"PASS: {$message}\n");};
$assert(is_array($actor),'active finance administrator is available');
$trip=null; $booking=null;
try {
    $trip=$bus->schedule(['routeId'=>$board['routes'][0]['id'],'vehicleId'=>$board['vehicles'][0]['id'],'departureAt'=>(new DateTimeImmutable('+3 days'))->format('Y-m-d H:i:s'),'usdCdfRate'=>2850],$actor);
    $booking=$bus->book(['tripId'=>$trip['id'],'passengerName'=>'Finance Test','passengerPhone'=>'+243000000001','seatNumber'=>2],$actor);
    $receipt=$finance->receive(['bookingId'=>$booking['id'],'paymentMethod'=>'MOBILE_MONEY','currency'=>'CDF','amount'=>$booking['totalCdf'],'usdCdfRate'=>2850,'externalReference'=>'TEST-ONLY'],$actor);
    $assert($receipt['status']==='RECONCILED','exact payment reconciles');
    $assert($receipt['operatorAllocationCdf']===$booking['fareCdf'],'operator fare is allocated');
    $assert($receipt['rescueAllocationCdf']===$booking['rescueFeeCdf'],'rescue fee is allocated');
    $assert(isset($finance->board()['metrics']['collectedCdf']),'finance board metrics are available');
} finally {
    if(is_array($booking)){$database->prepare('DELETE a FROM finance_allocations a JOIN finance_transactions f ON f.id=a.transaction_id WHERE f.smartbus_booking_id=:id')->execute(['id'=>$booking['id']]);$database->prepare('DELETE FROM finance_transactions WHERE smartbus_booking_id=:id')->execute(['id'=>$booking['id']]);$database->prepare('DELETE FROM smartbus_bookings WHERE id=:id')->execute(['id'=>$booking['id']]);}
    if(is_array($trip))$database->prepare('DELETE FROM smartbus_trips WHERE id=:id')->execute(['id'=>$trip['id']]);
}

if ($failures !== []) {
    fwrite(STDERR, count($failures) . " assertion(s) failed.\n");
    exit(1);
}
