<?php

declare(strict_types=1);

/**
 * The Truck & Cargo domain (phases 10 to 13).
 *
 * Proves the domain rules that protect a real operation: payload cannot exceed
 * the truck's rating, hazardous cargo needs a class and an approved truck, a
 * trailer is assigned per journey with history rather than hard-linked, a driver
 * is a canonical person, and one operator cannot see another's fleet.
 */

use Mamore\Auth\AuthException;
use Mamore\Auth\AuthService;
use Mamore\Core\AuditLog;
use Mamore\Core\Database;
use Mamore\Core\Request;
use Mamore\Core\Uuid;
use Mamore\Rescue\RescueCoverageService;
use Mamore\TruckCargo\TruckService;

require dirname(__DIR__) . '/bootstrap.php';
require __DIR__ . '/support.php';

$database = Database::connection();
$service = new TruckService($database, new RescueCoverageService($database));
$auth = new AuthService($database);

$failures = [];
$assert = static function (bool $condition, string $message) use (&$failures): void {
    if ($condition) {
        fwrite(STDOUT, "PASS: {$message}\n");
        return;
    }
    $failures[] = $message;
    fwrite(STDERR, "FAIL: {$message}\n");
};
$expectRejection = static function (callable $operation, int $status, string $message) use ($assert): void {
    try {
        $operation();
    } catch (AuthException $error) {
        $assert($error->status === $status, $message);
        return;
    }
    throw new RuntimeException("Expected rejection failed: {$message}");
};

$request = new Request('POST', '/api/trucks', [], [], '198.51.100.73', 'TruckCargoTest/1.0');
$password = 'TruckCargoTest!2026';
$admin = test_actor('SYSTEM_ADMIN', ['password' => $password, 'firstName' => 'Truck', 'lastName' => 'Admin']);
$session = static function (array $actor) use ($database, $auth, $password, $request): array {
    $email = (string) $database->query('SELECT email FROM users WHERE id = ' . $database->quote($actor['id']))->fetchColumn();

    return $auth->authenticate($auth->login($email, $password, $request)['accessToken']);
};
$adminSession = $session($admin);

$truckVehicleId = Uuid::v4();
$trailerVehicleId = Uuid::v4();
$operatorId = null;
$truckId = null;

try {
    // ---- Vocabularies are configuration -----------------------------------
    $truckTypes = $database->query('SELECT code FROM truck_types')->fetchAll(PDO::FETCH_COLUMN);
    foreach (['TRACTOR_HEAD', 'RIGID_TRUCK', 'TANKER', 'REFRIGERATED', 'LOWBED'] as $type) {
        $assert(in_array($type, $truckTypes, true), "truck type {$type} is configuration, not code");
    }
    $categories = $database->query('SELECT code FROM cargo_categories')->fetchAll(PDO::FETCH_COLUMN);
    foreach (['GENERAL', 'MINING', 'REFRIGERATED', 'HAZARDOUS', 'OVERSIZED'] as $category) {
        $assert(in_array($category, $categories, true), "cargo category {$category} is configuration");
    }

    // ---- Operator ---------------------------------------------------------
    $operator = $service->createOperator([
        'companyName' => 'Kasongo Freight',
        'region' => 'HAUT_KATANGA',
        'city' => 'Lubumbashi',
        'country' => 'CD',
        'fleetSize' => 12,
    ], $adminSession, $request);
    $operatorId = (string) $operator['id'];
    $assert(str_starts_with((string) $operator['operatorNumber'], 'TRO-'), 'an operator number is allocated');
    $assert($operator['verificationStatus'] === 'PENDING', 'a new operator starts unverified');
    $assert($operator['planId'] !== null, 'the operator is on a configurable truck plan');
    $assert($operator['organizationId'] !== null, 'the operator uses a canonical organization, not a copy');

    // ---- Truck ------------------------------------------------------------
    $database->prepare(
        'INSERT INTO vehicles (id, vehicle_type, registration_number, country_of_registration, make, model)
         VALUES (?, ?, ?, ?, ?, ?)'
    )->execute([$truckVehicleId, 'TRUCK', 'TK-TEST-001', 'CD', 'Volvo', 'FH16']);
    $database->prepare(
        'INSERT INTO vehicles (id, vehicle_type, registration_number, country_of_registration) VALUES (?, ?, ?, ?)'
    )->execute([$trailerVehicleId, 'TRAILER', 'TRL-TEST-001', 'CD']);

    $expectRejection(
        static fn () => $service->createTruck([
            'truckOperatorId' => $operatorId, 'vehicleId' => $truckVehicleId,
            'truckType' => 'RIGID_TRUCK', 'grossVehicleWeightKg' => 10000, 'maximumPayloadKg' => 20000,
        ], $adminSession, $request),
        422,
        'a payload above the gross vehicle weight is refused'
    );
    $expectRejection(
        static fn () => $service->createTruck([
            'truckOperatorId' => $operatorId, 'vehicleId' => $truckVehicleId, 'truckType' => 'HOVERCRAFT',
        ], $adminSession, $request),
        422,
        'an unknown truck type is refused'
    );

    $truck = $service->createTruck([
        'truckOperatorId' => $operatorId,
        'vehicleId' => $truckVehicleId,
        'truckType' => 'TRACTOR_HEAD',
        'axleConfiguration' => '6x4',
        'grossVehicleWeightKg' => 40000,
        'tareWeightKg' => 15000,
        'maximumPayloadKg' => 25000,
        'trailerRequired' => true,
        'crossBorderEnabled' => true,
    ], $adminSession, $request);
    $truckId = (string) $truck['id'];
    $assert($truck['truckType'] === 'TRACTOR_HEAD', 'the truck is registered with its type');
    $assert((float) $truck['maximumPayloadKg'] === 25000.0, 'the payload rating is recorded exactly');
    $assert($truck['registrationNumber'] === 'TK-TEST-001', 'the truck shows the canonical registration');
    $assert($truck['trackedAssetId'] !== null, 'the truck joins the shared tracking core');
    $assert($truck['rescueCoverage']['covered'] === false, 'a new truck is not yet covered');
    $assert($truck['trackingStatus'] === 'NO_DEVICE', 'a truck with no device says NO_DEVICE');

    $expectRejection(
        static fn () => $service->createTruck([
            'truckOperatorId' => $operatorId, 'vehicleId' => $truckVehicleId, 'truckType' => 'RIGID_TRUCK',
        ], $adminSession, $request),
        422,
        'the same vehicle cannot be registered as two trucks'
    );

    // ---- Trailer with history ----------------------------------------------
    $trailer = $service->createTrailer([
        'truckOperatorId' => $operatorId, 'vehicleId' => $trailerVehicleId,
        'trailerType' => 'FLATBED', 'maxLoadKg' => 24000,
    ], $adminSession, $request);
    $trailerId = (string) $trailer['id'];

    $assigned = $service->assignTrailer(['truckId' => $truckId, 'trailerId' => $trailerId, 'reason' => 'Loading for Kolwezi.'], $adminSession, $request);
    $assert($assigned['currentTrailerId'] === $trailerId, 'a trailer is assigned to the truck');

    $otherOperator = $service->createOperator(['companyName' => 'Competitor Freight'], $adminSession, $request);
    $otherTrailer = $service->createTrailer(['truckOperatorId' => (string) $otherOperator['id'], 'trailerType' => 'BOX'], $adminSession, $request);
    $expectRejection(
        static fn () => $service->assignTrailer(['truckId' => $truckId, 'trailerId' => (string) $otherTrailer['id']], $adminSession, $request),
        403,
        'a trailer from another operator cannot be assigned'
    );

    // ---- Drivers are canonical people -------------------------------------
    $driverPersonId = Uuid::v4();
    $database->prepare('INSERT INTO persons (id, first_name, last_name, phone) VALUES (?, ?, ?, ?)')
        ->execute([$driverPersonId, 'Dora', 'Mukendi', '+243000003333']);
    $driver = $service->createDriver([
        'truckOperatorId' => $operatorId, 'personId' => $driverPersonId,
        'licenseNumber' => 'CD-LIC-99887', 'licenseClass' => 'CE', 'crossBorderAuthorized' => true,
    ], $adminSession, $request);
    $assert($driver['personId'] === $driverPersonId, 'the driver is a canonical person, not a new profile');
    $assert(
        (int) $database->query('SELECT COUNT(*) FROM persons WHERE id = ' . $database->quote($driverPersonId))->fetchColumn() === 1,
        'no duplicate person row is created for a driver'
    );

    // ---- Consignment -------------------------------------------------------
    $expectRejection(
        static fn () => $service->createConsignment([
            'cargoCategory' => 'HAZARDOUS', 'hazardous' => true, 'items' => [['description' => 'Fuel drums']],
        ], $adminSession, $request),
        422,
        'a hazardous consignment without a hazard class is refused'
    );

    $consignment = $service->createConsignment([
        'cargoCategory' => 'MINING',
        'originText' => 'Lubumbashi',
        'destinationText' => 'Kolwezi',
        'declaredValue' => 45000.00,
        'declaredCurrency' => 'USD',
        'items' => [
            ['description' => 'Copper cathode', 'quantity' => 400, 'unit' => 'TONS', 'weightKg' => 18000, 'fragile' => false],
            ['description' => 'Cobalt ore', 'quantity' => 20, 'unit' => 'TONS', 'weightKg' => 5000],
        ],
    ], $adminSession, $request);
    $consignmentId = (string) $consignment['id'];
    $assert($consignment['cargoCategory'] === 'MINING', 'the consignment carries its category');
    $assert((float) $consignment['totalWeightKg'] === 23000.0, 'the consignment total weight is the sum of its items');
    $assert(count($consignment['items']) === 2, 'cargo is modelled as items, not a text description');
    $assert($consignment['declaredValue'] === '45000.00', 'the declared value is an exact decimal string');
    $assert($consignment['hazardous'] === false, 'non-hazardous cargo is not flagged hazardous');

    // ---- Journey with payload rules ----------------------------------------
    $journey = $service->createJourney([
        'truckId' => $truckId, 'consignmentId' => $consignmentId,
        'originText' => 'Lubumbashi', 'destinationText' => 'Kolwezi',
        'occupants' => [['driverId' => (string) $driver['id'], 'role' => 'DRIVER']],
    ], $adminSession, $request);
    $assert($journey['status'] === 'PLANNED', 'a truck journey is planned');
    $assert((float) $journey['cargoWeightKg'] === 23000.0, 'the journey carries the cargo weight');
    $assert($journey['trailerId'] === $trailerId, 'the journey picks up the current trailer');
    $assert($journey['rescueCoverage']['covered'] === false, 'the journey reports the real coverage state');

    $manifest = $service->manifest((string) $journey['id'], $adminSession);
    $assert(count($manifest['crew']) === 1, 'the manifest lists the crew');
    $assert($manifest['crew'][0]['name'] === 'Dora Mukendi', 'the manifest names the driver');
    $assert($manifest['crew'][0]['licenseNumber'] === 'CD-LIC-99887', 'the manifest carries the driver licence for a responder');
    $assert(count($manifest['cargo']['items']) === 2, 'the manifest lists the cargo items');
    $assert($manifest['cargo']['hazardous'] === false, 'the manifest states the hazard flag explicitly');
    $assert($manifest['truck']['maximumPayloadKg'] === 25000.0, 'the manifest shows the rating for a recovery decision');

    $overload = $service->createConsignment([
        'cargoCategory' => 'CONSTRUCTION',
        'items' => [['description' => 'Steel beams', 'weightKg' => 40000]],
    ], $adminSession, $request);
    $expectRejection(
        static fn () => $service->createJourney(['truckId' => $truckId, 'consignmentId' => (string) $overload['id']], $adminSession, $request),
        422,
        'a load above the truck rating is refused'
    );

    $expectRejection(
        static fn () => $service->createJourney(['truckId' => $truckId, 'consignmentId' => $consignmentId], $adminSession, $request),
        409,
        'a truck cannot have two open journeys'
    );

    // ---- Journey state machine --------------------------------------------
    $expectRejection(
        static fn () => $service->transitionJourney(['journeyId' => (string) $journey['id'], 'status' => 'COMPLETED'], $adminSession, $request),
        409,
        'a planned journey cannot jump straight to completed'
    );
    $ready = $service->transitionJourney(['journeyId' => (string) $journey['id'], 'status' => 'READY'], $adminSession, $request);
    $moving = $service->transitionJourney(['journeyId' => (string) $journey['id'], 'status' => 'IN_TRANSIT'], $adminSession, $request);
    $assert($ready['status'] === 'READY', 'the journey becomes READY');
    $assert($moving['status'] === 'IN_TRANSIT' && $moving['startedAt'] !== null, 'the journey starts and stamps its start');
    $breakdown = $service->transitionJourney(['journeyId' => (string) $journey['id'], 'status' => 'BREAKDOWN'], $adminSession, $request);
    $assert($breakdown['status'] === 'BREAKDOWN', 'a breakdown is a domain state the Control Center can filter on');
    $service->transitionJourney(['journeyId' => (string) $journey['id'], 'status' => 'IN_TRANSIT'], $adminSession, $request);
    $service->transitionJourney(['journeyId' => (string) $journey['id'], 'status' => 'ARRIVED'], $adminSession, $request);
    $assert(
        $database->query('SELECT status FROM consignments WHERE id = ' . $database->quote($consignmentId))->fetchColumn() === 'DELIVERED',
        'arriving marks the consignment delivered'
    );

    // ---- Operator isolation -------------------------------------------------
    $scoped = test_actor('BUS_OPERATOR', ['password' => $password, 'firstName' => 'Rival', 'lastName' => 'Operator']);
    $database->prepare('UPDATE users SET organization_id = :organization WHERE id = :id')
        ->execute(['organization' => (string) $otherOperator['organizationId'] ?? '', 'id' => $scoped['id']]);
    $scopedSession = $session($scoped);
    $expectRejection(
        static fn () => $service->truck($truckId, $scopedSession),
        403,
        'an operator from another company cannot read this truck'
    );
    $assert($service->truck($truckId, $adminSession)['id'] === $truckId, 'an administrator still can');

    // ---- Dashboard ------------------------------------------------------------
    $board = $service->dashboard([], $adminSession);
    $assert($board['metrics']['fleet'] >= 1, 'the truck dashboard counts the fleet');
    $assert((float) $board['metrics']['cargoWeightInTransitKg'] >= 0, 'cargo weight in transit is a real number');
    $assert($board['message'] === null, 'a fleet with data gets no empty-state message');

    $audits = (new AuditLog($database))->list(['action' => 'TRUCK_JOURNEY_IN_TRANSIT', 'limit' => 5]);
    $assert($audits !== [], 'journey transitions are audited');
} finally {
    if (is_string($truckId) && $truckId !== '') {
        $journeyIds = $database->query('SELECT id FROM truck_journeys WHERE truck_id = ' . $database->quote($truckId))->fetchAll(PDO::FETCH_COLUMN);
        foreach ($journeyIds as $journeyId) {
            $database->exec('DELETE FROM truck_trailer_assignments WHERE journey_id = ' . $database->quote($journeyId));
            $database->exec('DELETE FROM truck_driver_assignments WHERE journey_id = ' . $database->quote($journeyId));
            $database->exec('DELETE FROM truck_journey_consignments WHERE truck_journey_id = ' . $database->quote($journeyId));
            $database->exec('DELETE FROM truck_journey_occupants WHERE truck_journey_id = ' . $database->quote($journeyId));
        }
        $database->exec('DELETE FROM truck_journeys WHERE truck_id = ' . $database->quote($truckId));
        $database->exec('DELETE FROM truck_trailer_assignments WHERE truck_id = ' . $database->quote($truckId));
        $database->exec('DELETE FROM trucks WHERE id = ' . $database->quote($truckId));
    }
    $database->exec("DELETE FROM cargo_items WHERE consignment_id IN (SELECT id FROM consignments WHERE consignment_number LIKE 'CN-%' AND origin_text IN ('Lubumbashi', NULL) AND created_at > DATE_SUB(UTC_TIMESTAMP(6), INTERVAL 1 HOUR))");
    $database->exec("DELETE FROM consignments WHERE origin_text = 'Lubumbashi' AND destination_text = 'Kolwezi' AND created_at > DATE_SUB(UTC_TIMESTAMP(6), INTERVAL 1 HOUR)");
    $database->exec("DELETE FROM truck_drivers WHERE driver_number LIKE 'DRV-%'");
    $database->exec("DELETE FROM trailers WHERE trailer_number LIKE 'TRL-%'");
    $database->exec("DELETE FROM rescue_coverage_links WHERE vehicle_id IN (" . $database->quote($truckVehicleId) . ", " . $database->quote($trailerVehicleId) . ")");
    $database->exec('DELETE FROM tracked_assets WHERE vehicle_id IN (' . $database->quote($truckVehicleId) . ', ' . $database->quote($trailerVehicleId) . ')');
    $database->exec('DELETE FROM vehicles WHERE id IN (' . $database->quote($truckVehicleId) . ', ' . $database->quote($trailerVehicleId) . ')');
    $database->exec("DELETE FROM truck_operators WHERE operator_number LIKE 'TRO-%'");
    $database->exec("DELETE FROM organizations WHERE name IN ('Kasongo Freight', 'Competitor Freight')");
    $database->prepare('DELETE FROM persons WHERE id = :id')->execute(['id' => $driverPersonId]);
    $database->exec("DELETE FROM audit_logs WHERE entity_type IN ('Truck', 'TruckOperator', 'TruckDriver', 'TruckJourney', 'Consignment', 'Trailer')");
    $database->exec("DELETE FROM users WHERE first_name IN ('Truck', 'Rival') AND email LIKE '%@mamore.test'");
}

if ($failures !== []) {
    fwrite(STDERR, count($failures) . " assertion(s) failed.\n");
    exit(1);
}
