<?php

declare(strict_types=1);

/**
 * The cross-domain Control Center and dispatch advice (phases 14, 15 and 17).
 *
 * Proves the claim the whole architecture rests on: buses, trucks, private
 * vehicles and rescue units appear in ONE board, an incident from any domain
 * reaches the same Control Center with the right context, dispatch filters on
 * capability before distance, and nothing is fabricated.
 */

use Mamore\Auth\AuthException;
use Mamore\Auth\AuthService;
use Mamore\Core\AuditLog;
use Mamore\Core\Database;
use Mamore\Core\Request;
use Mamore\Core\Uuid;
use Mamore\Rescue\ControlCenterService;
use Mamore\Rescue\DispatchAdvisor;
use Mamore\Rescue\RescueCoverageService;

require dirname(__DIR__) . '/bootstrap.php';
require __DIR__ . '/support.php';

$database = Database::connection();
$coverage = new RescueCoverageService($database);
$advisor = new DispatchAdvisor($database);
$control = new ControlCenterService($database, $advisor);
$auth = new AuthService($database);

$failures = [];
$assert = static function (bool $condition, string $message) use (&$failures): void {
    if ($condition) {
        fwrite(STDOUT, "PASS: {$message}\n");
        return;
    }
    $failures[] = $message;
    fwrite(STDERR, "FAIL: {$message}\n");
};
$expectRejection = static function (callable $operation, int $status, string $message) use ($assert): void {
    try {
        $operation();
    } catch (AuthException $error) {
        $assert($error->status === $status, $message);
        return;
    }
    throw new RuntimeException("Expected rejection failed: {$message}");
};

$request = new Request('GET', '/api/control-center/operations', [], [], '198.51.100.81', 'ControlCenterTest/1.0');
$password = 'ControlCenter!2026';
$admin = test_actor('SYSTEM_ADMIN', ['password' => $password, 'firstName' => 'Control', 'lastName' => 'Center']);
$email = (string) $database->query('SELECT email FROM users WHERE id = ' . $database->quote($admin['id']))->fetchColumn();
$adminSession = $auth->authenticate($auth->login($email, $password, $request)['accessToken']);

$assetId = Uuid::v4();
$incidentId = Uuid::v4();
$tripVehicleId = Uuid::v4();

try {
    // ---- The board is cross-domain ----------------------------------------
    $board = $control->operations([], $adminSession);
    foreach (['domain', 'kpis', 'assets', 'incidents', 'alerts', 'availableDomains'] as $key) {
        $assert(array_key_exists($key, $board), "the operations board exposes {$key}");
    }
    foreach (['SMART_BUS', 'TRUCK_CARGO', 'PRIVATE_VEHICLE', 'VIP', 'RESCUE'] as $domain) {
        $assert(in_array($domain, $board['availableDomains'], true), "the board can filter by {$domain}");
    }
    $assert($board['kpis']['trackedAssets'] >= 1, 'the board counts tracked assets across domains');
    $assert($board['kpis']['rescueVehiclesAvailable'] >= 1, 'the board counts available rescue vehicles');
    $assert(array_key_exists('openIncidents', $board['kpis']), 'the board counts open incidents');

    // A bus, a truck, a private vehicle and a rescue unit, all live at once.
    $database->prepare(
        'INSERT INTO vehicles (id, vehicle_type, registration_number, country_of_registration, make, model)
         VALUES (?, ?, ?, ?, ?, ?)'
    )->execute([$tripVehicleId, 'TRUCK', 'CC-TEST-TRUCK', 'CD', 'Scania', 'R500']);
    foreach ([
        ['BUS', 'CC-TEST-BUS', 'SMART_BUS'],
        ['TRUCK', 'CC-TEST-TRUCK', 'TRUCK_CARGO'],
        ['PRIVATE_VEHICLE', 'CC-TEST-CAR', 'PRIVATE_VEHICLE'],
    ] as $index => [$type, $plate, $domain]) {
        $vehicleId = $tripVehicleId;
        if ($type !== 'TRUCK') {
            $vehicleId = Uuid::v4();
            $database->prepare(
                'INSERT INTO vehicles (id, vehicle_type, registration_number, country_of_registration) VALUES (?, ?, ?, ?)'
            )->execute([$vehicleId, $type, $plate, 'CD']);
        }
        $id = Uuid::v4();
        $database->prepare(<<<'SQL'
            INSERT INTO tracked_assets (id, asset_type, vehicle_id, asset_code, label, tracking_status, domain, status)
            VALUES (:id, :type, :vehicle, :code, :label, 'ONLINE', :domain, 'ACTIVE')
            SQL)->execute([
            'id' => $id, 'type' => $type, 'vehicle' => $vehicleId, 'code' => $plate,
            'label' => $plate, 'domain' => $domain,
        ]);
        $database->prepare(<<<'SQL'
            INSERT INTO tracked_asset_positions (tracked_asset_id, latitude, longitude, speed_kph, recorded_at)
            VALUES (:asset, -11.6, 27.5, 60, UTC_TIMESTAMP(6))
            SQL)->execute(['asset' => $id]);
        if ($index === 0) {
            $assetId = $id;
        }
    }

    $board = $control->operations([], $adminSession);
    $types = array_values(array_unique(array_column($board['assets'], 'assetType')));
    $assert(in_array('BUS', $types, true) && in_array('TRUCK', $types, true), 'buses and trucks appear on one board');
    $assert(in_array('PRIVATE_VEHICLE', $types, true), 'private vehicles appear on the same board');
    $online = array_filter($board['assets'], static fn (array $asset): bool => $asset['trackingStatus'] === 'ONLINE');
    $assert(count($online) >= 3, 'live assets across three domains are all on the board');
    $assert($online !== [] && $online[array_key_first($online)]['latitude'] !== null, 'a live asset shows a real position');

    $filtered = $control->operations(['domain' => 'TRUCK_CARGO'], $adminSession);
    $assert($filtered['domain'] === 'TRUCK_CARGO', 'the domain filter is echoed');
    $assert(
        array_reduce($filtered['assets'], static fn (bool $carry, array $asset): bool => $carry && $asset['domain'] === 'TRUCK_CARGO', true),
        'the domain filter really filters the asset list'
    );
    $expectRejection(
        static fn () => $control->operations(['domain' => 'SPACESHIP'], $adminSession),
        422,
        'an unknown domain filter is refused'
    );

    // ---- One incident architecture ----------------------------------------
    $database->prepare(<<<'SQL'
        INSERT INTO rescue_incidents
            (id, incident_code, source, domain, incident_type, caller_name, caller_phone, province, location_text,
             latitude, longitude, description, priority, severity, status, reported_by_user_id,
             vehicle_id, tracked_asset_id, cargo_weight_kg, cargo_hazardous)
        VALUES (:id, :code, 'TRUCK_CARGO', 'TRUCK_CARGO', 'BREAKDOWN', 'Dora Mukendi', '+243000003333',
                'HAUT_KATANGA', 'On the Kolwezi road', -11.6, 27.5, 'Engine failure on the main road.',
                'HIGH', 'HIGH', 'REPORTED', :reporter, :vehicle, :asset, 18000, 0)
        SQL)->execute([
        'id' => $incidentId, 'code' => 'TCC-TEST-001', 'reporter' => $admin['id'],
        'vehicle' => $tripVehicleId, 'asset' => $assetId,
    ]);

    $board = $control->operations([], $adminSession);
    $found = null;
    foreach ($board['incidents'] as $incident) {
        if ($incident['id'] === $incidentId) {
            $found = $incident;
        }
    }
    $assert(is_array($found), 'a truck incident appears on the shared board');
    $assert($found['domain'] === 'TRUCK_CARGO', 'the incident is labelled with its domain');
    $assert($found['severity'] === 'HIGH', 'severity is a real value, not derived in the browser');
    $assert($found['hasPosition'] === true, 'the incident reports whether a position is known');

    // ---- Rescue context is assembled, not retyped --------------------------
    $detail = $control->incidentDetail($incidentId, $adminSession);
    $assert($detail['incident']['domain'] === 'TRUCK_CARGO', 'the detail carries the incident');
    $assert($detail['vehicle']['registrationNumber'] === 'CC-TEST-TRUCK', 'the responder is shown the vehicle without typing it');
    $assert($detail['position']['status'] === 'ONLINE', 'the responder is shown the live position');
    $assert($detail['rescueCoverage']['covered'] === false, 'the real coverage state is reported, not assumed');
    // A real location is created so the nearest-asset resolution is proven
    // rather than assumed: with no hospital in the data the answer is null, and
    // that would be correct too.
    $tracking = new Mamore\Tracking\TrackingService($database);
    $hospitalId = $tracking->createLocation([
        'type' => 'HOSPITAL', 'name' => 'CC Test Hospital', 'province' => 'HAUT_KATANGA',
        'latitude' => -11.6, 'longitude' => 27.5,
    ])['id'];
    $withHospital = $control->incidentDetail($incidentId, $adminSession);
    $assert($withHospital['nearest']['hospital'] !== null, 'the nearest hospital is resolved from real data');
    $assert($withHospital['nearest']['hospital']['name'] === 'CC Test Hospital', 'the nearest hospital is the closest real one');
    $assert($withHospital['nearest']['hospital']['distanceBasis'] === DispatchAdvisor::BASIS_GREAT_CIRCLE, 'the hospital distance states its basis');
    $assert(isset($detail['nearest']['basis']), 'the distance basis is stated, so a radius is not mistaken for a route');
    $assert(is_array($detail['candidates']), 'dispatch candidates are offered');

    // ---- Capability is filtered before distance ----------------------------
    $candidates = $detail['candidates'];
    $assert($candidates !== [], 'candidates are found for an available unit');
    $first = $candidates[0];
    $assert($first['requiredCapability'] === 'MECHANICAL', 'a breakdown requires mechanical capability from configuration');
    $assert(
        in_array('MECHANICAL', $first['capabilities'], true),
        'the offered unit actually has the required capability'
    );
    $distances = array_map(static fn (array $candidate): float => (float) $candidate['distanceKm'], $candidates);
    $sorted = $distances;
    sort($sorted);
    $assert($distances === $sorted, 'candidates are ordered by distance within the capability filter');
    $assert($first['distanceBasis'] === DispatchAdvisor::BASIS_GREAT_CIRCLE, 'the basis is recorded when no road distance exists');

    $medicalId = Uuid::v4();
    $database->prepare(<<<'SQL'
        INSERT INTO rescue_incidents
            (id, incident_code, source, domain, incident_type, caller_name, caller_phone, province, location_text,
             latitude, longitude, description, priority, severity, status, reported_by_user_id, vehicle_id)
        VALUES (:id, 'TCC-TEST-MED', 'PRIVATE_VEHICLE', 'PRIVATE_VEHICLE', 'PRIVATE_EMERGENCY', 'Test Caller', '+243000000000',
                'LUALABA', 'On the road', -10.7, 25.4, 'Driver medical emergency.', 'CRITICAL', 'CRITICAL', 'REPORTED', :reporter, NULL)
        SQL)->execute(['id' => $medicalId, 'reporter' => $admin['id']]);
    $medicalCandidates = $advisor->candidates($medicalId);
    $assert($medicalCandidates !== [], 'a medical emergency has candidates');
    $assert(
        in_array('MEDICAL', $medicalCandidates[0]['capabilities'], true),
        'a medical incident is only offered to a medically capable unit'
    );

    $audits = (new AuditLog($database))->list(['action' => 'CONTROL_CENTER_OPERATIONS_VIEWED', 'limit' => 5]);
    $assert($audits !== [], 'viewing the operations board is audited');

    // ---- Cross-domain analytics -------------------------------------------
    $analytics = $control->analytics();
    foreach (['assetsByDomain', 'assetsByType', 'peopleInMovement', 'cargoInMotion', 'incidentsByDomain',
              'incidentsBySeverity', 'rescueCoverage', 'trackingHealth', 'response'] as $key) {
        $assert(array_key_exists($key, $analytics), "global analytics expose {$key}");
    }
    $assert(count($analytics['assetsByType']) >= 3, 'analytics count assets by canonical type across domains');
    $assert($analytics['peopleInMovement']['truckCrew'] >= 0, 'people in movement is a real count');
    $assert(array_key_exists('message', $analytics['response']), 'response times say when there is no data');
    $assert(
        $analytics['response']['avgDispatchMinutes'] === null || is_float($analytics['response']['avgDispatchMinutes']),
        'average dispatch time is a real number or explicitly null'
    );
    $assert(
        array_sum(array_column($analytics['trackingHealth'], 0)) >= 0,
        'tracking health is broken down by state'
    );
} finally {
    $database->exec('DELETE FROM rescue_incident_events WHERE incident_id IN (' . $database->quote($incidentId) . ', ' . $database->quote($medicalId) . ')');
    $database->exec('DELETE FROM rescue_incidents WHERE id IN (' . $database->quote($incidentId) . ', ' . $database->quote($medicalId) . ')');
    $database->exec("DELETE FROM tracking_alerts WHERE domain IN ('PRIVATE_VEHICLE', 'TRUCK_CARGO') AND status = 'NEW' AND opened_at > DATE_SUB(UTC_TIMESTAMP(6), INTERVAL 1 HOUR)");
    $database->exec("DELETE FROM tracked_assets WHERE asset_code LIKE 'CC-TEST-%'");
    $database->exec("DELETE FROM tracked_asset_positions WHERE tracked_asset_id IN (SELECT id FROM tracked_assets WHERE asset_code LIKE 'CC-TEST-%')");
    $database->exec("DELETE FROM vehicles WHERE registration_number LIKE 'CC-TEST-%'");
    if (isset($hospitalId) && is_string($hospitalId) && $hospitalId !== '') {
        $database->prepare('DELETE FROM service_locations WHERE id = :id')->execute(['id' => $hospitalId]);
        $database->prepare('DELETE FROM locations WHERE id = :id')->execute(['id' => $hospitalId]);
    }
    $database->exec("DELETE FROM audit_logs WHERE action = 'CONTROL_CENTER_OPERATIONS_VIEWED'");
    $database->exec("DELETE FROM users WHERE first_name = 'Control' AND email LIKE '%@mamore.test'");
}

if ($failures !== []) {
    fwrite(STDERR, count($failures) . " assertion(s) failed.\n");
    exit(1);
}
