<?php

declare(strict_types=1);

/**
 * Domain dashboard parity guard.
 *
 * The shared renderer in public/assets/app.js is configured with metric keys
 * per domain. Those keys are the ONLY thing standing between the renderer and
 * a screen full of em-dashes: if a service renames a metric, the config goes
 * stale and every KPI silently renders as "unknown" -- which looks deliberate
 * and is not.
 *
 * So this reads the real dashboard() payloads, extracts the keys the config
 * declares, and fails when a configured key is absent from the payload. It
 * also fails when a config points at an endpoint the router does not serve,
 * and when a mount point is missing from the shell.
 *
 * It is the same class of guard as ui-wiring-test.php, aimed at the layer that
 * was previously unwired: the vip, truckcargo and privatevehicles panels had NO
 * loader at all, so opening them left the static placeholder on screen forever
 * and nothing noticed.
 */

require dirname(__DIR__) . '/bootstrap.php';
require __DIR__ . '/support.php';

$root = dirname(__DIR__);
$app = (string) file_get_contents($root . '/public/assets/app.js');
$html = (string) file_get_contents($root . '/public/app.html');
$router = (string) file_get_contents($root . '/public/index.php');

$failures = 0;
$assert = static function (bool $condition, string $message) use (&$failures): void {
    if ($condition) {
        fwrite(STDOUT, "PASS: {$message}\n");
        return;
    }
    $failures++;
    fwrite(STDERR, "FAIL: {$message}\n");
};

/* -- pull the config straight out of the shipped bundle ------------------ */

$start = strpos($app, 'const DOMAIN_DASHBOARDS');
$end = strpos($app, 'Render one domain dashboard');
$assert($start !== false && $end !== false && $end > $start, 'the domain dashboard config is present in app.js');

$config = substr((string) $app, (int) $start, (int) ($end - $start));

// The body of one domain is the text from its own opening brace to the start
// of the NEXT domain key, rather than a non-greedy match that would stop at
// the first nested "}," -- which silently yielded an empty body per domain.
$domains = [];
preg_match_all("/(\w+):\s*\{\s*mount: '#([\w-]+)',\s*endpoint: '([^']+)'/s", $config, $blocks, PREG_SET_ORDER);
foreach ($blocks as $index => $block) {
    $from = strpos($config, $block[0]);
    $to = isset($blocks[$index + 1])
        ? strpos($config, $blocks[$index + 1][0])
        : strlen($config);
    $domains[$block[1]] = [
        'mount' => $block[2],
        'endpoint' => $block[3],
        'body' => substr($config, (int) $from, (int) ($to - $from)),
    ];
}

$assert($domains !== [], 'at least one domain dashboard is configured');
$assert(
    count($domains) >= 3,
    'the vip, truckcargo and privatevehicles domains are all configured'
);

/* -- each config points at a real route and a real mount ---------------- */

foreach ($domains as $name => $definition) {
    $assert(
        str_contains($router, "'" . $definition['endpoint'] . "'"),
        "the {$name} endpoint {$definition['endpoint']} is registered in the router"
    );
    // substr($mount, 1) strips the leading '#', NOT the '#' plus the first
    // character -- which is what this was doing, turning "#vip-body" into
    // "ip-body" and failing on a mount that exists.
    $mountId = ltrim($definition['mount'], '#');
    $assert(
        str_contains($html, 'id="' . $mountId . '"'),
        "the {$name} mount point {$definition['mount']} exists in the shell"
    );
    $assert(
        str_contains($app, "DOMAIN_DASHBOARDS[name]"),
        'switchPanel routes domain panels through the shared loader'
    );
}

/* -- the KPI keys match the real service payloads ----------------------- */

$database = Mamore\Core\Database::connection();
$coverage = new Mamore\Rescue\RescueCoverageService($database);
$codes = new Mamore\SmartBus\RescueCodeService($database);

$services = [
    'vip' => (new Mamore\VIP\VipSubscriberService($database, $coverage, $codes))->dashboard(),
    'truckcargo' => (new Mamore\TruckCargo\TruckService($database, $coverage))->dashboard(),
    'privatevehicles' => (new Mamore\PrivateVehicle\PrivateVehicleService($database, $coverage, $codes))->dashboard(),
];

foreach ($domains as $name => $definition) {
    if (!isset($services[$name])) {
        continue;
    }

    $payload = $services[$name];
    $metrics = is_array($payload['metrics'] ?? null) ? $payload['metrics'] : [];

    // Metric keys declared for this domain in the JS config. Breakdown keys
    // are deliberately NOT matched here: a breakdown is a top-level payload
    // array, not a metric, and conflating the two made the guard report
    // "byStatus is not a metric" as a failure.
    $kpiSection = preg_split("/\n\s*breakdowns?:\s*\[/", $definition['body'])[0];
    preg_match_all("/\{ key: '(\w+)', label: '/", $kpiSection, $declared);
    $assert($declared[1] !== [], "the {$name} config declares at least one KPI");

    foreach ($declared[1] as $key) {
        $assert(
            array_key_exists($key, $metrics),
            "the {$name} KPI '{$key}' exists in the real dashboard payload"
        );
    }

    // A metric the screen never shows must be declared as such. A config that
    // silently drops a metric the service computes is a dashboard quietly
    // withholding information, so the omission has to be written down.
    $secondary = preg_match_all("/secondary:\s*\[\{ key: '(\w+)'/", $definition['body'], $sec)
        ? $sec[1]
        : [];
    $shown = array_merge($declared[1], $secondary);
    preg_match_all("/'(\w+)'/", $definition['body'], $intentional);
    // `notShown` entries are object KEYS, not quoted values, so they are
    // collected separately from the quoted-string sweep above.
    preg_match_all("/notShown:\s*\{([^}]*)\}/s", $definition['body'], $notShown);
    // Each entry is `key: 'reason'`, so the keys are captured directly rather
    // than derived by splitting the blob -- splitting on the wrong separator
    // silently produced an empty list and every metric looked unacknowledged.
    preg_match_all("/(\w+):\s*'/", $notShown[1][0] ?? '', $hiddenKeys);
    $hidden = $hiddenKeys[1];
    $acknowledged = array_values(array_unique(array_merge($shown, $intentional[1], $hidden)));

    foreach (array_keys($metrics) as $key) {
        $assert(
            in_array($key, $acknowledged, true),
            "the {$name} metric '{$key}' is either shown or named as not-shown"
        );
    }
}

/* -- the empty case is declared, not assumed ---------------------------- */

foreach ($services as $name => $payload) {
    if (($payload['message'] ?? null) !== null) {
        $assert(
            str_contains($app, 'payload.message && !Object.keys(metrics).length'),
            "the {$name} empty state is driven by the service's own message, not a guess"
        );
        break;
    }
}

/* -- a mass is never formatted as money --------------------------------- */

$assert(
    str_contains($config, "unit: 'kg'"),
    'cargo weight is declared with a unit, so it cannot be rendered as money'
);
$assert(
    !str_contains($config, "unit: 'CDF'") && !str_contains($config, 'asMoney'),
    'no domain metric claims a money unit it does not have'
);

/* -- the analytics renderer reads only fields the service sends ---------- */

$analytics = (new Mamore\Rescue\ControlCenterService(
    $database,
    new Mamore\Rescue\DispatchAdvisor($database)
))->analytics();

$assert(str_contains($app, 'const renderAnalytics'), 'the analytics renderer exists');
$assert(str_contains($app, 'Mamore.loaders.analytics = loadAnalytics'), 'the analytics panel has a loader');
$assert(str_contains($router, "'/api/analytics/global'"), 'the analytics endpoint is registered');

// Pull the top-level payload keys the renderer dereferences, then confirm each
// is a real key. `response.window` was one of these and is NOT sent by
// ControlCenterService::analytics() -- reading it rendered a window label that
// had no basis in the query.
$analyticsStart = (int) strpos($app, 'const renderAnalytics');
$analyticsEnd = (int) strpos($app, 'const loadAnalytics');
$analyticsSource = substr($app, $analyticsStart, $analyticsEnd - $analyticsStart);

preg_match_all('/payload\.(\w+)/', $analyticsSource, $topLevel);
foreach (array_unique($topLevel[1]) as $key) {
    $assert(
        array_key_exists($key, $analytics),
        "the analytics renderer reads payload.{$key}, which the service sends"
    );
}

foreach (['avgDispatchMinutes', 'avgArriveMinutes', 'avgResolveMinutes', 'incidents'] as $key) {
    $assert(
        array_key_exists($key, $analytics['response'] ?? []),
        "the analytics renderer reads response.{$key}, which the service sends"
    );
}

foreach (['online', 'delayedSignal', 'offline', 'noDevice'] as $key) {
    $assert(
        array_key_exists($key, $analytics['trackingHealth'] ?? []),
        "the analytics renderer reads trackingHealth.{$key}, which the service sends"
    );
}

// The one that bit: the window is described by the incident count, not by a
// field this service omits.
$assert(
    !str_contains($analyticsSource, 'response.window'),
    'the analytics renderer does not read a window field the service omits'
);

// A null average must not become a zero on the screen that judges health.
$assert(
    str_contains($analyticsSource, "value === null || value === undefined ? 'No data'"),
    'a null response average renders as "no data", never as zero minutes'
);

fwrite(STDOUT, $failures === 0 ? "\nPASS: domain dashboards match their services\n" : "\nFAILURES: {$failures}\n");
exit($failures === 0 ? 0 : 1);
