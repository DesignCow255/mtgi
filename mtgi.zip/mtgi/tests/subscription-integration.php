<?php

declare(strict_types=1);

/**
 * Subscription money path: quote -> create -> pay -> receipt -> renew -> void.
 *
 * The test drives the real services against the migrated database and asserts
 * the canonical fee shape at every step: GRO 430 + TAXABLE 170 = 600 chargeable,
 * 51 + 15 + 15 + 89 = 170 informational subset, ledger debits equal credits,
 * taxes recorded once per province, receipt verifiable, and void reverting the
 * subscription to PENDING.
 */

use Mamore\Auth\AuthException;
use Mamore\Core\Database;
use Mamore\Finance\ReceiptService;
use Mamore\Finance\SubscriptionPaymentService;
use Mamore\Subscription\SubscriptionService;

require dirname(__DIR__) . '/bootstrap.php';
require __DIR__ . '/support.php';

$database = Database::connection();
$subscriptions = new SubscriptionService($database);
$payments = new SubscriptionPaymentService($database);
$receipts = new ReceiptService($database);
$actor = test_actor('FINANCE_MANAGER');

$assert = static function (bool $condition, string $message) use (&$failures): void {
    if ($condition) {
        fwrite(STDOUT, "PASS: {$message}\n");
        return;
    }
    $failures[] = $message;
    fwrite(STDERR, "FAIL: {$message}\n");
};
$expectRejection = static function (callable $operation, int $status, string $message) use ($assert): void {
    try {
        $operation();
    } catch (AuthException $error) {
        $assert($error->status === $status, $message);
        return;
    }
    // Abort through an exception (not exit) so the cleanup block still runs.
    throw new RuntimeException("Expected rejection failed: {$message}");
};

$createdSubscriptions = [];
$createdSubscribers = [];
$failures = [];
$plate = 'IT-' . strtoupper(bin2hex(random_bytes(3)));
$idempotencyKey = 'itest-' . bin2hex(random_bytes(8));

try {
    // ---- Quote -----------------------------------------------------------
    $quote = $subscriptions->quote(['productCode' => 'TRUCK', 'province' => 'HAUT_KATANGA']);
    $assert($quote['totals']['chargeableUsd'] === '600.00', 'truck quote charges exactly 600.00 USD');
    $assert($quote['totals']['reconciles'] === true, 'truck quote reconciles against the catalog total');
    $assert($quote['chargeable'][0]['key'] === 'GRO' && $quote['chargeable'][0]['amount'] === '430.00', 'truck quote first line is GRO 430.00');
    $assert($quote['chargeable'][1]['amount'] === '170.00', 'truck quote second line is the 170.00 taxable container');
    $assert($quote['totals']['subsetTotalUsd'] === '170.00', 'informational subsets sum to the 170.00 container');

    $private = $subscriptions->quote(['productCode' => 'PRIVATE_VEHICLE', 'province' => 'LUALABA']);
    $assert($private['totals']['chargeableUsd'] === '80.00', 'private vehicle quote charges exactly 80.00 USD');
    $assert($private['durationMonths'] === 1, 'monthly product defaults to a one month term');

    // ---- Create ----------------------------------------------------------
    $subscription = $subscriptions->create([
        'productCode' => 'TRUCK_RESCUE',
        'province' => 'HAUT_KATANGA',
        'subscriber' => ['firstName' => 'Integration', 'lastName' => 'Subscriber', 'phone' => '+243' . random_int(100000000, 999999999)],
        'vehicles' => [['plateNumber' => $plate, 'vehicleMake' => 'Volvo', 'vehicleModel' => 'FH16', 'vehicleYear' => 2019, 'cargoCategory' => 'HEAVY']],
        'notes' => 'Automated subscription test; safe to remove.',
    ], $actor);
    $createdSubscriptions[] = $subscription['id'];
    $createdSubscribers[] = $subscription['subscriberId'];

    $assert($subscription['status'] === 'PENDING', 'new subscription starts PENDING until it is paid');
    $assert($subscription['totalAmount'] === '600.00', 'subscription stores the 600.00 catalog total');
    $assert($subscription['taxableAmount'] === '170.00', 'subscription stores the 170.00 taxable container');
    $assert(count($subscription['fees']['chargeable']) === 2, 'subscription carries two chargeable fee lines');
    $assert(count($subscription['fees']['subsets']) === 4, 'subscription carries four informational subset lines');
    $assert($subscription['history'][0]['action'] === 'CREATED', 'subscription history records the CREATED event');

    $vehicleCount = $database->prepare('SELECT COUNT(*) FROM subscriber_vehicles WHERE plate_number = :plate');
    $vehicleCount->execute(['plate' => $plate]);
    $assert((int) $vehicleCount->fetchColumn() === 1, 'declared vehicle is registered on the subscriber');
    // ---- Pay -------------------------------------------------------------
    $payment = $payments->receive([
        'subscriptionId' => $subscription['id'],
        'paymentMethod' => 'MOBILE_MONEY',
        'amount' => '600.00',
        'usdCdfRate' => 2850,
        'idempotencyKey' => $idempotencyKey,
        'location' => 'Lubumbashi HQ',
        'narration' => 'Integration test payment',
    ], $actor);

    $assert($payment['status'] === 'COMPLETED', 'payment is recorded as COMPLETED');
    $assert($payment['amount'] === '600.00', 'payment amount equals the catalog total');
    $assert($payment['provider'] === 'Mobile Money' && $payment['channel'] === 'MOBILE_MONEY', 'payment records the provider channel');
    $assert($payment['amountCdf'] === '1710000.00', 'USD total converts to CDF rounded up to 100');

    $allocationTotal = '0.00';
    $allocationAccounts = [];
    foreach ($payment['allocations'] as $allocation) {
        $allocationTotal = bcadd($allocationTotal, $allocation['amount'], 2);
        $allocationAccounts[$allocation['key']] = $allocation['ledgerAccount'];
    }
    $assert($allocationTotal === '600.00', 'allocations reconcile to the paid amount');
    $assert($allocationAccounts === ['GRO' => 'GRO_REVENUE', 'TAXABLE' => 'TAX_REVENUE'], 'allocations post to the GRO and TAX ledgers');

    $debits = '0.00';
    $credits = '0.00';
    foreach ($payment['ledger'] as $entry) {
        $entry['type'] === 'DEBIT'
            ? $debits = bcadd($debits, $entry['amount'], 2)
            : $credits = bcadd($credits, $entry['amount'], 2);
    }
    $assert($debits === '600.00' && $credits === '600.00', 'ledger posting balances at 600.00 debit and credit');

    $taxTotal = '0.00';
    $taxKeys = [];
    foreach ($payment['taxes'] as $tax) {
        $taxTotal = bcadd($taxTotal, $tax['amount'], 2);
        $taxKeys[$tax['key']] = $tax['province'];
    }
    ksort($taxKeys);
    $assert($taxTotal === '66.00', 'DGI 51.00 plus the 15.00 provincial PDC are recorded as tax');
    $assert($taxKeys === ['DGI_TAX' => 'HAUT_KATANGA', 'PDC_HAUT_KATANGA' => 'HAUT_KATANGA'], 'taxes are attributed to the collecting province only');

    $paid = $subscriptions->show($subscription['id']);
    $assert($paid['status'] === 'ACTIVE' && $paid['membershipStatus'] === 'ACTIVE', 'paying the subscription activates the membership');
    $assert($paid['history'][count($paid['history']) - 1]['action'] === 'ACTIVATED', 'activation is written to the subscription history');

    $receipt = $payment['receipt'];
    $assert($receipt['status'] === 'ISSUED', 'receipt is issued with the payment');
    $assert($receipt['amount'] === '600.00' && $receipt['amountFormatted'] === 'USD 600.00', 'receipt shows the paid total');
    $assert($receipt['breakdown']['chargeable'][0]['formatted'] === 'USD 430.00', 'receipt breakdown formats GRO exactly');
    $assert($receipt['breakdown']['subsets'][3]['key'] === 'UNALLOCATED', 'receipt keeps the UNALLOCATED remainder visible');
    $assert($receipts->verify($receipt['verificationNumber'])['id'] === $receipt['id'], 'receipt verifies by its verification number');
    $assert($receipts->showForSubscriber($receipt['id'], $subscription['subscriberId'])['id'] === $receipt['id'], 'subscriber can read their own receipt');

    $firstPrint = $receipts->markPrinted($receipt['id'], $actor);
    $secondPrint = $receipts->markPrinted($receipt['id'], $actor);
    $assert($firstPrint['status'] === 'ISSUED' && $firstPrint['printCount'] === 1, 'the first print keeps the receipt ISSUED');
    $assert($secondPrint['status'] === 'REPRINTED' && $secondPrint['printCount'] === 2, 'later prints are tracked as REPRINTED');

    $expectRejection(
        static fn () => $receipts->showForSubscriber($receipt['id'], '00000000-0000-4000-8000-0000000000ff'),
        404,
        'another subscriber cannot read the receipt'
    );

    $notifications = $database->prepare("SELECT COUNT(*) FROM user_notifications WHERE notification_type = 'PAYMENT_SUCCESS' AND entity_id = :receipt");
    $notifications->execute(['receipt' => $receipt['id']]);
    $assert((int) $notifications->fetchColumn() === 0, 'no portal user is linked yet, so no notification is queued');

    // ---- Idempotency -----------------------------------------------------
    $retry = $payments->receive([
        'subscriptionId' => $subscription['id'],
        'paymentMethod' => 'MOBILE_MONEY',
        'idempotencyKey' => $idempotencyKey,
    ], $actor);
    $assert(($retry['idempotent'] ?? false) === true, 'replaying the same idempotency key is recognised');
    $assert($retry['id'] === $payment['id'] && $retry['receipt']['id'] === $receipt['id'], 'replay returns the original payment and receipt');
    $paymentCount = $database->prepare('SELECT COUNT(*) FROM payments WHERE subscription_id = :id');
    $paymentCount->execute(['id' => $subscription['id']]);
    $assert((int) $paymentCount->fetchColumn() === 1, 'retrying created no duplicate payment');

    $expectRejection(
        static fn () => $payments->receive(['subscriptionId' => $subscription['id'], 'paymentMethod' => 'CASH'], $actor),
        409,
        'paying an already paid subscription is refused'
    );
    $expectRejection(
        static fn () => $payments->receive(['subscriptionId' => $subscription['id'], 'paymentMethod' => 'CASH', 'amount' => '100.00'], $actor),
        409,
        'the amount can never override the catalog total'
    );
    // ---- Renew -----------------------------------------------------------
    $renewal = $subscriptions->renew(['subscriptionId' => $subscription['id'], 'province' => 'LUALABA'], $actor);
    $createdSubscriptions[] = $renewal['id'];
    $assert($renewal['renewalCount'] === 1 && $renewal['renewedFromId'] === $subscription['id'], 'renewal links back to the previous subscription');
    $assert($renewal['status'] === 'PENDING' && $renewal['totalAmount'] === '600.00', 'renewal re-quotes the catalog price');
    $assert($subscriptions->show($subscription['id'])['status'] === 'RENEWED', 'the previous subscription is marked RENEWED');
    $assert($renewal['province'] === 'LUALABA', 'a renewal can move the membership to another province');

    $listed = $payments->list(['subscriberId' => $subscription['subscriberId']]);
    $assert(count($listed) === 1 && $listed[0]['id'] === $payment['id'], 'payment listing is scoped to the subscriber');
    $assert(count($subscriptions->forSubscriber($subscription['subscriberId'])) === 2, 'subscriber sees both their subscriptions');

    // ---- Expiry sweep ----------------------------------------------------
    $renewalPayment = $payments->receive(['subscriptionId' => $renewal['id'], 'paymentMethod' => 'BANK_TRANSFER'], $actor);
    $assert($renewalPayment['amount'] === '600.00', 'the renewal is charged the same catalog price');
    $assert($renewalPayment['provider'] === 'Bank Transfer', 'the renewal records its own provider channel');
    $renewalTaxKeys = array_map(static fn (array $tax): string => $tax['key'], $renewalPayment['taxes']);
    $assert($renewalTaxKeys === ['DGI_TAX', 'PDC_LUALABA'], 'a Lualaba membership records the Lualaba PDC instead of Haut-Katanga');
    $assert($renewalPayment['taxes'][1]['province'] === 'LUALABA', 'provincial tax is booked to the province of collection');

    $lapsed = $subscriptions->create([
        'productCode' => 'PRIVATE_VEHICLE_RESCUE',
        'province' => 'HAUT_KATANGA',
        'subscriberId' => $subscription['subscriberId'],
        'startDate' => gmdate('Y-m-d', strtotime('-15 months')),
        'durationMonths' => 12,
    ], $actor);
    $createdSubscriptions[] = $lapsed['id'];
    $lapsedPayment = $payments->receive(['subscriptionId' => $lapsed['id'], 'paymentMethod' => 'CASH'], $actor);
    $assert($lapsedPayment['amount'] === '80.00', 'private vehicle subscription charges 80.00 USD');
    $assert($lapsedPayment['allocations'][0]['key'] === 'OP_COST', 'private vehicle allocation starts with the 40.00 operating cost');
    $assert(in_array($lapsed['subscriptionNo'], $subscriptions->expireDue(), true), 'the expiry sweep picks up the lapsed membership');
    $assert($subscriptions->show($lapsed['id'])['status'] === 'EXPIRED', 'a lapsed membership ends up EXPIRED');
    $assert(
        in_array($renewal['subscriptionNo'], array_column($subscriptions->expiringWithin(500), 'subscriptionNo'), true),
        'a paid renewal shows up in the expiring window'
    );

    // ---- Void ------------------------------------------------------------
    $voided = $payments->void(['paymentId' => $lapsedPayment['id'], 'reason' => 'Integration test void'], $actor);
    $assert($voided['status'] === 'VOIDED' && $voided['voidReason'] === 'Integration test void', 'payment is voided with its reason');
    $assert($voided['receipt']['status'] === 'VOID', 'the receipt of a voided payment is marked VOID');
    $assert($subscriptions->show($lapsed['id'])['status'] === 'PENDING', 'voiding the payment returns the subscription to PENDING');
    $assert(count(array_filter($voided['taxes'], static fn (array $tax): bool => $tax['status'] === 'VOIDED')) === 2, 'recorded taxes are voided too');

    $contraDebits = '0.00';
    $contraCredits = '0.00';
    foreach ($voided['ledger'] as $entry) {
        $entry['type'] === 'DEBIT'
            ? $contraDebits = bcadd($contraDebits, $entry['amount'], 2)
            : $contraCredits = bcadd($contraCredits, $entry['amount'], 2);
    }
    $assert($contraDebits === '160.00' && $contraCredits === '160.00', 'void posts balancing contra entries beside the original ones');
    $assert($payments->show($payment['id'])['status'] === 'COMPLETED', 'voiding one payment leaves the other payment untouched');
    $assert(($payments->void(['paymentId' => $lapsedPayment['id'], 'reason' => 'again'], $actor)['idempotent'] ?? false) === true, 'voiding twice is idempotent');
} finally {
    cleanup_subscription_fixtures($database, $createdSubscriptions, $createdSubscribers);
}

if ($failures !== []) {
    fwrite(STDERR, count($failures) . " assertion(s) failed.\n");
    exit(1);
}

/**
 * Remove every row the subscription test created, in FK-safe order.
 *
 * @param list<string> $subscriptionIds
 * @param list<string> $subscriberIds
 */
function cleanup_subscription_fixtures(PDO $database, array $subscriptionIds, array $subscriberIds): void
{
    $paymentChildren = [
        'DELETE FROM ledger_entries WHERE payment_id = :payment',
        'DELETE FROM government_taxes WHERE payment_id = :payment',
        'DELETE FROM payment_allocations WHERE payment_id = :payment',
        "DELETE FROM user_notifications WHERE entity_type = 'Receipt' AND entity_id IN (SELECT id FROM receipts WHERE payment_id = :payment)",
        'DELETE FROM receipts WHERE payment_id = :payment',
    ];

    foreach ($subscriptionIds as $subscriptionId) {
        $payments = $database->prepare('SELECT id FROM payments WHERE subscription_id = :id');
        $payments->execute(['id' => $subscriptionId]);
        foreach ($payments->fetchAll(PDO::FETCH_COLUMN) as $paymentId) {
            foreach ($paymentChildren as $sql) {
                $database->prepare($sql)->execute(['payment' => $paymentId]);
            }
        }
        $database->prepare('DELETE FROM payments WHERE subscription_id = :id')->execute(['id' => $subscriptionId]);
        $database->prepare('DELETE FROM subscription_history WHERE subscription_id = :id')->execute(['id' => $subscriptionId]);
        $database->prepare('DELETE FROM subscription_fees WHERE subscription_id = :id')->execute(['id' => $subscriptionId]);
        $database->prepare('UPDATE subscriptions SET renewed_from_id = NULL WHERE renewed_from_id = :id')->execute(['id' => $subscriptionId]);
        $database->prepare('DELETE FROM subscriptions WHERE id = :id')->execute(['id' => $subscriptionId]);
    }

    foreach ($subscriberIds as $subscriberId) {
        $database->prepare('DELETE FROM subscriber_vehicles WHERE subscriber_id = :id')->execute(['id' => $subscriberId]);
        $database->prepare('DELETE FROM subscriber_history WHERE subscriber_id = :id')->execute(['id' => $subscriberId]);
        $database->prepare('UPDATE users SET subscriber_id = NULL WHERE subscriber_id = :id')->execute(['id' => $subscriberId]);
        $database->prepare('DELETE FROM subscribers WHERE id = :id')->execute(['id' => $subscriberId]);
    }
}
