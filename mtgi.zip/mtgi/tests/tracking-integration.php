<?php

declare(strict_types=1);

use Mamore\Core\Database;
use Mamore\Tracking\TrackingService;

require dirname(__DIR__) . '/bootstrap.php';

$database=Database::connection();$service=new TrackingService($database);$board=$service->board();
$failures = [];
$assert=static function(bool $condition,string $message)use(&$failures):void{if(!$condition){$failures[]=$message;fwrite(STDERR,"FAIL: {$message}\n");return;}fwrite(STDOUT,"PASS: {$message}\n");};
$assert(count($board['assets'])>=1,'rescue and bus assets are registered for tracking');
$asset=$board['assets'][0];$location=null;
try{
    $position=$service->checkIn(['assetId'=>$asset['id'],'latitude'=>-11.6647,'longitude'=>27.4794,'speedKph'=>35,'heading'=>270]);
    $assert($position['latitude']===-11.6647,'GPS check-in is recorded');
    $location=$service->createLocation(['type'=>'COMMAND_STATION','name'=>'Integration Test Station','province'=>'HAUT_KATANGA','latitude'=>-11.6650,'longitude'=>27.4800]);
    $nearest=$service->nearest(-11.6647,27.4794);
    $assert(count($nearest)>=1&&$nearest[0]['distanceKm']<1,'nearest service location is calculated');
    $updated=$service->board();$match=array_values(array_filter($updated['assets'],static fn(array $row):bool=>$row['id']===$asset['id']));
    $assert($match[0]['signalStatus']==='LIVE','fresh position reports live signal');
}finally{
    $database->prepare('DELETE FROM tracking_positions WHERE asset_id=:id')->execute(['id'=>$asset['id']]);
    if(is_array($location))$database->prepare('DELETE FROM service_locations WHERE id=:id')->execute(['id'=>$location['id']]);
}

if ($failures !== []) {
    fwrite(STDERR, count($failures) . " assertion(s) failed.\n");
    exit(1);
}
