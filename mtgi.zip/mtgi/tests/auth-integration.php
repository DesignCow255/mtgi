<?php

declare(strict_types=1);

use Mamore\Auth\AuthException;
use Mamore\Auth\AuthService;
use Mamore\Core\Database;
use Mamore\Core\Request;
use Mamore\Core\Uuid;

require dirname(__DIR__) . '/bootstrap.php';

$database = Database::connection();
$auth = new AuthService($database);
$userId = Uuid::v4();
$email = 'auth-test-' . bin2hex(random_bytes(4)) . '@example.test';
$password = 'Temporary_Test_123!';
$request = new Request('POST', '/test', [], [], '127.0.0.1', 'MamoreAuthTest/1.0');
$failures = [];
$assert = static function (string $name, bool $condition) use (&$failures): void {
    if (!$condition) { $failures[] = $name; fwrite(STDERR, "FAIL: {$name}\n"); return; }
    fwrite(STDOUT, "PASS: {$name}\n");
};

try {
    $databaseTimezone = $database->query('SELECT @@session.time_zone')->fetchColumn();
    $assert('database session uses UTC', $databaseTimezone === '+00:00');
    $roleId = $database->query("SELECT id FROM roles WHERE code = 'SYSTEM_ADMIN'")->fetchColumn();
    $insert = $database->prepare("INSERT INTO users (id, role_id, first_name, last_name, email, password_hash, status, email_verified_at) VALUES (:id, :role, 'Auth', 'Test', :email, :hash, 'ACTIVE', CURRENT_TIMESTAMP(6))");
    $insert->execute(['id' => $userId, 'role' => $roleId, 'email' => $email, 'hash' => password_hash($password, PASSWORD_DEFAULT)]);

    $login = $auth->login($email, $password, $request);
    $assert('login returns access token', is_string($login['accessToken']) && strlen($login['accessToken']) >= 40);
    $assert('access token authenticates', $auth->authenticate($login['accessToken'])['id'] === $userId);
    $auth->requirePermission($auth->authenticate($login['accessToken']), 'users.manage');
    $assert('administrator permission passes', true);

    $rotated = $auth->refresh($login['refreshToken'], $request);
    try { $auth->refresh($login['refreshToken'], $request); $oldRefreshRejected = false; }
    catch (AuthException) { $oldRefreshRejected = true; }
    $assert('old refresh token rejected after rotation', $oldRefreshRejected);
    $assert('rotated access token authenticates', $auth->authenticate($rotated['accessToken'])['id'] === $userId);

    $current = $auth->authenticate($rotated['accessToken']);
    $auth->logout($current, $request);
    try { $auth->authenticate($rotated['accessToken']); $revokedRejected = false; }
    catch (AuthException) { $revokedRejected = true; }
    $assert('logout revokes access token', $revokedRejected);
} finally {
    $database->prepare('DELETE FROM audit_logs WHERE actor_user_id = :id')->execute(['id' => $userId]);
    $database->prepare('DELETE FROM login_history WHERE user_id = :id')->execute(['id' => $userId]);
    $database->prepare('DELETE FROM user_sessions WHERE user_id = :id')->execute(['id' => $userId]);
    $database->prepare('DELETE FROM users WHERE id = :id')->execute(['id' => $userId]);
}

if ($failures !== []) {
    fwrite(STDERR, count($failures) . " assertion(s) failed.\n");
    exit(1);
}
