<?php

declare(strict_types=1);

/**
 * Audit trail completeness (risk register item 7) and the notification centre.
 *
 * The audit assertions are deliberately picky: a payment must leave behind one
 * row that names the actor, the actor's role, the session, the IP, the user
 * agent, the previous and new state, and the request id. The role check also
 * proves the role is FROZEN at write time, so a later role change cannot
 * rewrite what a past operator did.
 */

use Mamore\Alerts\NotificationService;
use Mamore\Auth\AuthException;
use Mamore\Auth\AuthService;
use Mamore\Core\AuditLog;
use Mamore\Core\Database;
use Mamore\Core\Request;
use Mamore\Core\Router;
use Mamore\Finance\SubscriptionPaymentService;
use Mamore\Subscription\SubscriptionService;

require dirname(__DIR__) . '/bootstrap.php';
require __DIR__ . '/support.php';

$database = Database::connection();
$audit = new AuditLog($database);
$subscriptions = new SubscriptionService($database);
$payments = new SubscriptionPaymentService($database);
$notifications = new NotificationService($database);
$auth = new AuthService($database);

$failures = [];
$assert = static function (bool $condition, string $message) use (&$failures): void {
    if ($condition) {
        fwrite(STDOUT, "PASS: {$message}\n");
        return;
    }
    $failures[] = $message;
    fwrite(STDERR, "FAIL: {$message}\n");
};
$expectRejection = static function (callable $operation, int $status, string $message) use ($assert): void {
    try {
        $operation();
    } catch (AuthException $error) {
        $assert($error->status === $status, $message);
        return;
    }
    throw new RuntimeException("Expected rejection failed: {$message}");
};
$emailOf = static fn (string $userId): string => (string) Database::connection()
    ->query('SELECT email FROM users WHERE id = ' . Database::connection()->quote($userId))
    ->fetchColumn();

// A real login so the audit row can be expected to carry role + session + IP.
$password = 'AuditTrailPassword!2026';
$staff = test_actor('FINANCE_MANAGER', ['password' => $password, 'firstName' => 'Audit', 'lastName' => 'Officer']);
$loginRequest = new Request('POST', '/api/auth/login', [], [], '203.0.113.9', 'MamoreAuditTest/1.0');
$login = $auth->login($emailOf((string) $staff['id']), $password, $loginRequest);
$actor = $auth->authenticate($login['accessToken']);
$assert(is_string($actor['role_code'] ?? null) && $actor['role_code'] === 'FINANCE_MANAGER', 'the acting session resolves the operator role');
$assert(is_string($actor['session_id'] ?? null) && $actor['session_id'] !== '', 'the acting session id is available for the audit trail');

$createdSubscriptions = [];
$createdSubscribers = [];
$payment = null;
$subscription = null;
$frozenUserId = null;
$frozenRoleId = null;

try {
    $request = new Request('POST', '/api/subscriptions/create', [], [], '203.0.113.9', 'MamoreAuditTest/1.0');

    // ---- Subscription audit ---------------------------------------------
    $subscription = $subscriptions->create([
        'productCode' => 'TRUCK_RESCUE',
        'province' => 'HAUT_KATANGA',
        'subscriber' => ['firstName' => 'Audit', 'lastName' => 'Subscriber'],
    ], $actor, $request);
    $createdSubscriptions[] = $subscription['id'];
    $createdSubscribers[] = $subscription['subscriberId'];

    $created = $audit->list(['entityType' => 'Subscription', 'entityId' => $subscription['id'], 'action' => 'SUBSCRIPTION_CREATED']);
    $assert(count($created) === 1, 'creating a subscription writes exactly one audit row');
    $row = $created[0];
    $assert($row['actorUserId'] === $actor['id'], 'the audit row names the acting user');
    $assert($row['actorRole'] === 'FINANCE_MANAGER', 'the audit row freezes the acting role');
    $assert($row['sessionId'] === $actor['session_id'], 'the audit row names the acting session');
    $assert($row['ipAddress'] === '203.0.113.9', 'the audit row captures the client IP');
    $assert($row['userAgent'] === 'MamoreAuditTest/1.0', 'the audit row captures the user agent');
    $assert($row['newData']['totalAmount'] === '600.00' && $row['newData']['taxableAmount'] === '170.00', 'the audit row records the new money state');
    $assert($row['previousData'] === null, 'a creation has no previous state');
    $assert($row['metadata']['subscriberId'] === $subscription['subscriberId'], 'the audit row links the subscriber in metadata');
    $assert(is_string($row['requestId']) && $row['requestId'] !== '', 'every audit row carries a request id for correlation');

    $suspended = $subscriptions->updateStatus(
        ['subscriptionId' => $subscription['id'], 'status' => 'SUSPENDED', 'reason' => 'Audit trail check'],
        $actor,
        $request
    );
    $assert($suspended['status'] === 'SUSPENDED', 'a subscription can be suspended');
    $statusRows = $audit->list(['entityType' => 'Subscription', 'entityId' => $subscription['id'], 'action' => 'SUBSCRIPTION_STATUS_CHANGED']);
    $assert(count($statusRows) === 1 && $statusRows[0]['previousData']['status'] === 'PENDING' && $statusRows[0]['newData']['status'] === 'SUSPENDED', 'a status change records before and after');
    $assert($statusRows[0]['metadata']['reason'] === 'Audit trail check', 'a status change records why');

    // ---- Payment audit ---------------------------------------------------
    $payment = $payments->receive([
        'subscriptionId' => $subscription['id'],
        'paymentMethod' => 'MOBILE_MONEY',
        'usdCdfRate' => 2850,
    ], $actor, $request);

    $paymentRows = $audit->list(['entityType' => 'Payment', 'entityId' => $payment['id']]);
    $assert(count($paymentRows) === 1, 'receiving a payment writes one audit row');
    $row = $paymentRows[0];
    $assert($row['action'] === 'PAYMENT_RECEIVED' && $row['actorRole'] === 'FINANCE_MANAGER', 'the payment audit row names action and role');
    $assert($row['sessionId'] === $actor['session_id'] && $row['ipAddress'] === '203.0.113.9', 'the payment audit row carries session and IP');
    $assert($row['newData']['amount'] === '600.00' && $row['newData']['amountCdf'] === '1710000.00', 'the payment audit row records the money it moved');
    $assert($row['newData']['receiptNumber'] === $payment['receipt']['receiptNumber'], 'the payment audit row records the receipt it issued');
    $assert(
        array_column($row['newData']['allocations'], 'amount') === ['430.00', '170.00'],
        'the payment audit row records the allocations it posted'
    );
    $assert($row['previousData']['status'] === 'PENDING', 'the payment audit row records the subscription state it replaced');
    $assert($row['metadata']['subscriptionNo'] === $subscription['subscriptionNo'], 'the payment audit row links the subscription');

    $voided = $payments->void(['paymentId' => $payment['id'], 'reason' => 'Audit trail check'], $actor, $request);
    $voidRows = $audit->list(['entityType' => 'Payment', 'entityId' => $payment['id'], 'action' => 'PAYMENT_VOIDED']);
    $assert(count($voidRows) === 1, 'voiding a payment writes one audit row');
    $assert(
        $voidRows[0]['previousData']['status'] === 'COMPLETED' && $voidRows[0]['newData']['status'] === 'VOIDED',
        'the void audit row records the reversal'
    );
    $assert($voidRows[0]['newData']['voidReason'] === 'Audit trail check', 'the void audit row records the reason');
    $assert($voided['status'] === 'VOIDED', 'the payment is voided');

    // ---- Audit is append-only -------------------------------------------
    $assert(!method_exists(AuditLog::class, 'update') && !method_exists(AuditLog::class, 'delete'), 'the audit writer exposes no update or delete');
    $router = new Router();
    foreach (['PUT', 'PATCH', 'DELETE'] as $method) {
        $assert($router->dispatch($method, '/api/audit')['status'] === 404, "the router has no {$method} route, so audit rows cannot be edited over HTTP");
    }
    $before = $audit->list(['entityId' => $payment['id']]);
    $assert($audit->list(['entityId' => $payment['id']]) == $before, 'reading the trail twice does not change it');

    // ---- The recorded role is frozen, not looked up later ----------------
    // Authenticate BOTH sessions before the probe mutates the frozen user's
    // role. Authenticating the stranger afterwards would silently hand it a
    // SYSTEM_ADMIN session, and the ownership checks below would then be
    // proving something weaker than they look.
    $frozen = test_actor('AUDITOR', ['password' => $password, 'firstName' => 'Frozen', 'lastName' => 'Role']);
    $frozenEmail = $emailOf((string) $frozen['id']);
    $frozenActor = $auth->authenticate($auth->login($frozenEmail, $password, $loginRequest)['accessToken']);
    $frozenRoleId = (string) $frozen['role_id'];
    $frozenUserId = (string) $frozen['id'];

    $audit->write('ROLE_FREEZE_PROBE', 'Probe', 'probe-1', $frozenActor, $request, ['status' => 'A'], ['status' => 'B']);
    $database->prepare('UPDATE users SET role_id = (SELECT id FROM roles WHERE code = :code) WHERE id = :id')
        ->execute(['code' => 'SYSTEM_ADMIN', 'id' => $frozen['id']]);
    $probe = $audit->list(['entityType' => 'Probe', 'entityId' => 'probe-1']);
    $assert(count($probe) === 1 && $probe[0]['actorRole'] === 'AUDITOR', 'a later role change does not rewrite the recorded role');
    $assert($probe[0]['actorEmail'] === $frozenEmail, 'the audit reader joins the current email for convenience');

    // ---- Audit reader filters -------------------------------------------
    $assert($audit->countFor('Payment', (string) $payment['id']) === 2, 'both the payment and the void are on record');
    $assert(count($audit->list(['from' => gmdate('Y-m-d'), 'to' => gmdate('Y-m-d'), 'limit' => 200])) >= 2, 'the timeline can be filtered by day');
    $assert(count($audit->list(['from' => gmdate('Y-m-d', strtotime('+5 days'))])) === 0, 'a future window matches nothing');
    $expectRejection(static fn () => $audit->list(['from' => 'not-a-date']), 422, 'an invalid timeline date is rejected');
    // createFromFormat() returns a valid object for an out-of-range date and
    // silently rolls it over: '2026-13-45' becomes 2027-02-14. Without the
    // round-trip guard a typo becomes a filter for a completely different day.
    $expectRejection(static fn () => $audit->list(['from' => '2026-13-45']), 422, 'an out-of-range date is rejected, not silently rolled into another day');
    $expectRejection(static fn () => $audit->list(['limit' => 'all']), 422, 'a non-numeric limit is rejected instead of silently returning one row');

    // An inclusive day bound must reach the last microsecond of the day:
    // occurred_at is TIMESTAMP(6), and a 23:59:59 bound dropped the final
    // fraction of the day from the report.
    $database->prepare('UPDATE audit_logs SET occurred_at = :at WHERE entity_type = :type AND entity_id = :id')
        ->execute(['at' => gmdate('Y-m-d 23:59:59.750000'), 'type' => 'Probe', 'id' => 'probe-1']);
    $assert(
        count($audit->list(['entityType' => 'Probe', 'entityId' => 'probe-1', 'to' => gmdate('Y-m-d')])) === 1,
        'a "to = today" filter includes an event in the final fractional second of the day'
    );

    // ...and the lower bound has to open at the first microsecond, not at 23:59.
    $database->prepare('UPDATE audit_logs SET occurred_at = :at WHERE entity_type = :type AND entity_id = :id')
        ->execute(['at' => gmdate('Y-m-d 00:00:00.250000'), 'type' => 'Probe', 'id' => 'probe-1']);
    $assert(
        count($audit->list(['entityType' => 'Probe', 'entityId' => 'probe-1', 'from' => gmdate('Y-m-d')])) === 1,
        'a "from = today" filter starts at the first microsecond of the day'
    );

    // ---- Notification centre --------------------------------------------
    $owner = $actor;
    $stranger = $frozenActor;

    $insert = $database->prepare(
        'INSERT INTO user_notifications (user_id, notification_type, title, message, entity_type, entity_id)
         VALUES (:user, :type, :title, :message, :entityType, :entity)'
    );
    $insert->execute(['user' => $owner['id'], 'type' => 'PAYMENT_SUCCESS', 'title' => 'Audit notification', 'message' => 'Body', 'entityType' => 'Receipt', 'entity' => null]);
    $mine = (int) $database->lastInsertId();
    $insert->execute(['user' => $owner['id'], 'type' => 'PANIC_ALERT', 'title' => 'Second audit notification', 'message' => 'Body', 'entityType' => null, 'entity' => null]);
    $insert->execute(['user' => $stranger['id'], 'type' => 'PANIC_ALERT', 'title' => 'Someone else notification', 'message' => 'Body', 'entityType' => null, 'entity' => null]);
    $theirs = (int) $database->lastInsertId();

    $assert($notifications->unreadCount($owner) === 2, 'unread count reflects the caller own queue');
    $assert($notifications->unreadCount($stranger) === 1, 'unread count is per user');
    $assert(count($notifications->list($owner)) === 2, 'the list returns the caller own notifications');
    $assert($notifications->list($owner, 50, true) !== [] && count($notifications->list($owner, 50, true)) === 2, 'unread-only listing works');
    $read = $notifications->markRead($owner, $mine);
    $assert($read['read'] === true && $read['readAt'] !== null, 'marking a notification read stamps read_at');
    $assert($notifications->unreadCount($owner) === 1, 'the unread count drops after reading');
    $assert($notifications->markRead($owner, (string) $mine)['read'] === true, 'reading an already read notification is idempotent');
    $assert($notifications->markRead($owner, (int) $mine)['read'] === true, 'a numeric notification id is accepted, the column is a BIGINT');

    $expectRejection(
        static fn () => $notifications->markRead($owner, (string) $theirs),
        404,
        'a notification belonging to another user is not found, not forbidden'
    );
    $assert($notifications->unreadCount($stranger) === 1, 'a failed cross-user read leaves the other queue untouched');

    $all = $notifications->markAllRead($owner);
    $assert($all === ['markedRead' => 1, 'unreadRemaining' => 0], 'read-all reports exactly what it changed');
    $assert($notifications->markAllRead($owner)['markedRead'] === 0, 'read-all is idempotent when nothing is unread');
    $assert($notifications->unreadCount($stranger) === 1, 'read-all only touches the caller own queue');
} finally {
    // The role-freeze probe promotes a real user to SYSTEM_ADMIN on purpose.
    // Put the original role back before anything else can observe it, so a
    // failed run cannot leave a live administrator behind on a shared database.
    if ($frozenUserId !== null) {
        $database->prepare('UPDATE users SET role_id = :role WHERE id = :id')
            ->execute(['role' => $frozenRoleId, 'id' => $frozenUserId]);
    }
    cleanup_audit_fixtures($database, $createdSubscriptions, $createdSubscribers);
}

if ($failures !== []) {
    fwrite(STDERR, count($failures) . " assertion(s) failed.\n");
    exit(1);
}

/**
 * Remove the rows this test created, in FK-safe order.
 *
 * @param list<string> $subscriptionIds
 * @param list<string> $subscriberIds
 */
function cleanup_audit_fixtures(PDO $database, array $subscriptionIds, array $subscriberIds): void
{
    $database->exec("DELETE FROM user_notifications WHERE title LIKE 'Audit notification' OR title LIKE 'Second audit notification' OR title LIKE 'Someone else notification'");

    $paymentChildren = [
        'DELETE FROM ledger_entries WHERE payment_id = :payment',
        'DELETE FROM government_taxes WHERE payment_id = :payment',
        'DELETE FROM payment_allocations WHERE payment_id = :payment',
        'DELETE FROM receipts WHERE payment_id = :payment',
    ];

    foreach ($subscriptionIds as $subscriptionId) {
        $payments = $database->prepare('SELECT id FROM payments WHERE subscription_id = :id');
        $payments->execute(['id' => $subscriptionId]);
        foreach ($payments->fetchAll(PDO::FETCH_COLUMN) as $paymentId) {
            foreach ($paymentChildren as $sql) {
                $database->prepare($sql)->execute(['payment' => $paymentId]);
            }
            $database->prepare('DELETE FROM audit_logs WHERE entity_id = :id')->execute(['id' => $paymentId]);
        }
        $database->prepare('DELETE FROM payments WHERE subscription_id = :id')->execute(['id' => $subscriptionId]);
        $database->prepare('DELETE FROM subscription_history WHERE subscription_id = :id')->execute(['id' => $subscriptionId]);
        $database->prepare('DELETE FROM subscription_fees WHERE subscription_id = :id')->execute(['id' => $subscriptionId]);
        $database->prepare('UPDATE subscriptions SET renewed_from_id = NULL WHERE renewed_from_id = :id')->execute(['id' => $subscriptionId]);
        $database->prepare('DELETE FROM audit_logs WHERE entity_id = :id')->execute(['id' => $subscriptionId]);
        $database->prepare('DELETE FROM subscriptions WHERE id = :id')->execute(['id' => $subscriptionId]);
    }

    foreach ($subscriberIds as $subscriberId) {
        $database->prepare('DELETE FROM subscriber_vehicles WHERE subscriber_id = :id')->execute(['id' => $subscriberId]);
        $database->prepare('DELETE FROM subscriber_history WHERE subscriber_id = :id')->execute(['id' => $subscriberId]);
        $database->prepare('UPDATE users SET subscriber_id = NULL WHERE subscriber_id = :id')->execute(['id' => $subscriberId]);
        $database->prepare('DELETE FROM subscribers WHERE id = :id')->execute(['id' => $subscriberId]);
    }

    $database->exec("DELETE FROM audit_logs WHERE entity_type = 'Probe' AND entity_id = 'probe-1'");
}
