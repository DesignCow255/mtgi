<?php

declare(strict_types=1);

/**
 * Characterisation of the CURRENT Smart Bus behaviour.
 *
 * Written before the v2 work so that every later change is provably
 * backward compatible: these assertions describe what the existing
 * board/schedule/book/ticket contract does today and must keep doing.
 */

use Mamore\Auth\AuthException;
use Mamore\Core\Database;
use Mamore\SmartBus\SmartBusService;

require dirname(__DIR__) . '/bootstrap.php';
require __DIR__ . '/support.php';

$database = Database::connection();
$service = new SmartBusService($database);
$actor = test_actor('BUS_OPERATOR');
$board = $service->board();

$failures = [];
$assert = static function (bool $condition, string $message) use (&$failures): void {
    if ($condition) {
        fwrite(STDOUT, "PASS: {$message}\n");
        return;
    }
    $failures[] = $message;
    fwrite(STDERR, "FAIL: {$message}\n");
};
$expectRejection = static function (callable $operation, int $status, string $message) use ($assert): void {
    try {
        $operation();
    } catch (AuthException $error) {
        $assert($error->status === $status, $message);
        return;
    }
    throw new RuntimeException("Expected rejection failed: {$message}");
};

$trips = [];
$assert(count($board['routes']) >= 1, 'the board exposes at least one route');
$assert(count($board['vehicles']) >= 1, 'the board exposes at least one vehicle');
$assert(count($board['operators']) >= 1, 'the board exposes at least one operator');

$trip = null;
$booking = null;

try {
    // ---- Board payload shape --------------------------------------------
    $scheduled = $service->schedule([
        'routeId' => $board['routes'][0]['id'],
        'vehicleId' => $board['vehicles'][0]['id'],
        'departureAt' => (new DateTimeImmutable('+2 days'))->format('Y-m-d H:i:s'),
        'usdCdfRate' => 2850,
    ], $actor);
    $trips[] = $scheduled['id'];

    foreach (['id', 'code', 'routeCode', 'origin', 'destination', 'vehicleCode', 'operatorName', 'capacity',
              'bookedSeats', 'occupiedSeats', 'departureAt', 'fareCdf', 'rescueFeeUsd', 'usdCdfRate', 'status'] as $key) {
        $assert(array_key_exists($key, $scheduled), "the trip payload still exposes {$key}");
    }
    $assert(str_starts_with((string) $scheduled['code'], 'TRP-'), 'trip codes keep the TRP- prefix');
    $assert($scheduled['status'] === 'SCHEDULED', 'a new trip is SCHEDULED');

    // ---- Booking contract -----------------------------------------------
    $booking = $service->book([
        'tripId' => $scheduled['id'],
        'passengerName' => 'Characterisation Passenger',
        'passengerPhone' => '+243000000000',
        'seatNumber' => 2,
    ], $actor);

    foreach (['id', 'reference', 'tripCode', 'seatNumber', 'passengerName', 'fareCdf', 'rescueFeeUsd',
              'rescueFeeCdf', 'totalCdf', 'qrPayload', 'status'] as $key) {
        $assert(array_key_exists($key, $booking), "the booking payload still exposes {$key}");
    }
    $assert(preg_match('/^MB-[0-9A-F]{8}$/', (string) $booking['reference']) === 1, 'booking references keep the MB-XXXXXXXX form');
    $assert($booking['status'] === 'CONFIRMED', 'a new booking is CONFIRMED');
    $assert(
        (float) $booking['totalCdf'] === round((float) $booking['fareCdf'] + (float) $booking['rescueFeeCdf'], 2),
        'the total is still the fare plus the converted rescue fee'
    );

    // The QR payload is the existing ticket format and must keep validating.
    $parts = explode('|', (string) $booking['qrPayload']);
    $assert(count($parts) === 4, 'the QR payload keeps its four segments');
    $assert($parts[0] === 'MAMORE' && $parts[1] === $booking['reference'], 'the QR payload identifies the booking');
    $assert($parts[2] === $booking['tripCode'], 'the QR payload identifies the trip');
    $assert($parts[3] === 'SEAT-' . $booking['seatNumber'], 'the QR payload identifies the seat');

    $stored = $database->prepare('SELECT * FROM smartbus_bookings WHERE id = :id');
    $stored->execute(['id' => $booking['id']]);
    $row = $stored->fetch();
    $assert($row['status'] === 'CONFIRMED', 'the stored booking status is CONFIRMED');
    $assert($row['qr_payload'] === $booking['qrPayload'], 'the stored QR payload matches the response');
    $assert((float) $row['total_cdf'] === (float) $booking['totalCdf'], 'the stored total matches the response exactly');

    // ---- Rules that must keep holding ------------------------------------
    $expectRejection(
        static fn () => $service->book([
            'tripId' => $scheduled['id'], 'passengerName' => 'Second', 'passengerPhone' => '+243000000001', 'seatNumber' => 2,
        ], $actor),
        409,
        'the same seat cannot be sold twice'
    );
    $expectRejection(
        static fn () => $service->book([
            'tripId' => $scheduled['id'], 'passengerName' => 'Too High', 'passengerPhone' => '+243000000002',
            'seatNumber' => (int) $scheduled['capacity'] + 1,
        ], $actor),
        422,
        'a seat beyond the vehicle capacity is refused'
    );
    $expectRejection(
        static fn () => $service->book([
            'tripId' => $scheduled['id'], 'passengerName' => '', 'passengerPhone' => '+243000000003', 'seatNumber' => 3,
        ], $actor),
        422,
        'a booking without a passenger name is refused'
    );
    $expectRejection(
        static fn () => $service->schedule([
            'routeId' => $board['routes'][0]['id'], 'vehicleId' => $board['vehicles'][0]['id'],
            'departureAt' => (new DateTimeImmutable('-1 day'))->format('Y-m-d H:i:s'), 'usdCdfRate' => 2850,
        ], $actor),
        422,
        'a departure in the past is refused'
    );

    // ---- Board reflects the booking ---------------------------------------
    $reloaded = null;
    foreach ($service->board()['trips'] as $candidate) {
        if ($candidate['id'] === $scheduled['id']) {
            $reloaded = $candidate;
        }
    }
    $assert(is_array($reloaded), 'a scheduled trip appears on the board');
    $assert((int) $reloaded['bookedSeats'] === 1, 'the board counts the booking');
    $assert(in_array(2, $reloaded['occupiedSeats'], true), 'the board reports the occupied seat');
} finally {
    foreach ($trips as $tripId) {
        $database->prepare('DELETE FROM smartbus_bookings WHERE trip_id = :id')->execute(['id' => $tripId]);
        $database->prepare('DELETE FROM smartbus_trips WHERE id = :id')->execute(['id' => $tripId]);
    }
}

if ($failures !== []) {
    fwrite(STDERR, count($failures) . " assertion(s) failed.\n");
    exit(1);
}
