<?php

declare(strict_types=1);

/**
 * Shared rescue coverage engine (phase 05).
 *
 * One service answers "is this covered?" for a person, a vehicle or a journey.
 * These assertions pin that it is explicit about unknowns, that a plan drives
 * the answer, and that suspending or revoking cover is as available as granting
 * it - a fleet's cover must be removable, not just addable.
 */

use Mamore\Auth\AuthException;
use Mamore\Auth\AuthService;
use Mamore\Core\AuditLog;
use Mamore\Core\Database;
use Mamore\Core\Request;
use Mamore\Core\Uuid;
use Mamore\Rescue\RescueCoverageService;

require dirname(__DIR__) . '/bootstrap.php';
require __DIR__ . '/support.php';

$database = Database::connection();
$coverage = new RescueCoverageService($database);
$auth = new AuthService($database);

$failures = [];
$assert = static function (bool $condition, string $message) use (&$failures): void {
    if ($condition) {
        fwrite(STDOUT, "PASS: {$message}\n");
        return;
    }
    $failures[] = $message;
    fwrite(STDERR, "FAIL: {$message}\n");
};
$expectRejection = static function (callable $operation, int $status, string $message) use ($assert): void {
    try {
        $operation();
    } catch (AuthException $error) {
        $assert($error->status === $status, $message);
        return;
    }
    throw new RuntimeException("Expected rejection failed: {$message}");
};

$request = new Request('POST', '/api/coverage/grant', [], [], '198.51.100.88', 'CoverageTest/1.0');
$admin = test_actor('SYSTEM_ADMIN', ['password' => 'CoverTest!2026', 'firstName' => 'Cov', 'lastName' => 'Admin']);
$adminSession = $auth->authenticate($auth->login(
    (string) $database->query('SELECT email FROM users WHERE id = ' . $database->quote($admin['id']))->fetchColumn(),
    'CoverTest!2026',
    $request
)['accessToken']);

$vehicleId = Uuid::v4();
$personId = Uuid::v4();
$planId = null;
$coverageIds = [];

try {
    // ---- Plans are configuration, not code -------------------------------
    $plans = $database->query('SELECT plan_code, domain, coverage_type, currency, base_fee FROM service_plans ORDER BY plan_code')->fetchAll();
    $assert(count($plans) >= 5, 'configurable service plans exist across domains');
    $domains = array_values(array_unique(array_column($plans, 'domain')));
    foreach (['VIP', 'SMART_BUS', 'TRUCK', 'PRIVATE_VEHICLE'] as $domain) {
        $assert(in_array($domain, $domains, true), "the {$domain} domain has a configurable plan");
    }
    $planId = (string) $database->query("SELECT id FROM service_plans WHERE plan_code = 'TRUCK-ROAD-ASSIST'")->fetchColumn();
    $assert($planId !== '', 'a truck plan resolves by its configuration code');
    $assert(
        $database->query("SELECT currency FROM service_plans WHERE id = " . $database->quote($planId))->fetchColumn() === 'USD',
        'plan fees carry an explicit currency'
    );

    $database->prepare(
        'INSERT INTO vehicles (id, vehicle_type, registration_number, country_of_registration, make, model) VALUES (?, ?, ?, ?, ?, ?)'
    )->execute([$vehicleId, 'TRUCK', 'COV-TEST-001', 'CD', 'Volvo', 'FH16']);
    $database->prepare('INSERT INTO persons (id, first_name, last_name) VALUES (?, ?, ?)')->execute([$personId, 'Cover', 'Tester']);

    // ---- Unknown coverage is explicit, never optimistic -------------------
    $unknown = $coverage->check('VEHICLE', $vehicleId);
    $assert($unknown['covered'] === false, 'a vehicle with no coverage record is not covered');
    $assert($unknown['status'] === 'UNCOVERED', 'the status says UNCOVERED, not a hopeful value');
    $assert($unknown['source'] === 'NONE', 'the source says where the answer came from');
    $assert(str_contains($unknown['reason'], 'No active rescue coverage'), 'the reason explains the absence');
    $expectRejection(
        static fn () => $coverage->check('SPACESHIP', $vehicleId),
        422,
        'an unknown subject type is refused'
    );

    // ---- Granting coverage -----------------------------------------------
    $granted = $coverage->grant([
        'subjectType' => 'VEHICLE',
        'subjectId' => $vehicleId,
        'vehicleId' => $vehicleId,
        'servicePlanId' => $planId,
        'coverageType' => 'ROAD_ASSISTANCE',
    ], $adminSession);
    $assert($granted['covered'] === true, 'granting a plan makes the vehicle covered');
    $assert($granted['status'] === 'ACTIVE', 'the coverage status is ACTIVE');
    $assert($granted['plan']['code'] === 'TRUCK-ROAD-ASSIST', 'the answer names the plan that provides cover');
    $assert($granted['plan']['responseTargetMinutes'] === 60, 'the plan carries its response target');
    $assert(str_contains((string) $granted['vehicle'], 'COV-TEST-001'), 'the answer identifies the covered vehicle');
    $assert($granted['startsAt'] !== null, 'the coverage window has a start');

    $vehicleCheck = $coverage->forVehicle($vehicleId);
    $assert($vehicleCheck['covered'] === true, 'the vehicle-level shortcut returns the same answer');

    $audits = (new AuditLog($database))->list(['entityType' => 'RescueCoverage', 'action' => 'RESCUE_COVERAGE_GRANTED', 'limit' => 5]);
    $assert($audits !== [], 'granting coverage is audited');

    // ---- A missing subject is caught ---------------------------------------
    $expectRejection(
        static fn () => $coverage->grant([
            'subjectType' => 'VEHICLE', 'subjectId' => Uuid::v4(), 'coverageType' => 'ROAD_ASSISTANCE',
        ], $adminSession),
        404,
        'coverage cannot be granted for a vehicle that does not exist'
    );

    // ---- Expiry ------------------------------------------------------------
    // A separate vehicle, so this proves expiry on its own rather than competing
    // with the live link above.
    $expiredVehicleId = Uuid::v4();
    $database->prepare(
        'INSERT INTO vehicles (id, vehicle_type, registration_number, country_of_registration) VALUES (?, ?, ?, ?)'
    )->execute([$expiredVehicleId, 'TRUCK', 'COV-TEST-EXP', 'CD']);
    $expired = $coverage->grant([
        'subjectType' => 'VEHICLE',
        'subjectId' => $expiredVehicleId,
        'vehicleId' => $expiredVehicleId,
        'servicePlanId' => $planId,
        'coverageType' => 'ROAD_ASSISTANCE',
        'endsAt' => gmdate('Y-m-d H:i:s', time() - 3600),
    ], $adminSession);
    $assert($expired['covered'] === false, 'coverage that ended in the past is not active');
    $assert($expired['status'] === 'EXPIRED', 'an ended window reports EXPIRED');

    $database->prepare('DELETE FROM vehicles WHERE id = :id')->execute(['id' => $expiredVehicleId]);

    // ---- Suspension and revocation -----------------------------------------
    $linkId = (string) $database->query(
        'SELECT id FROM rescue_coverage_links WHERE subject_id = ' . $database->quote($vehicleId) . " AND status = 'ACTIVE' LIMIT 1"
    )->fetchColumn();
    $coverageIds[] = $linkId;
    $suspended = $coverage->revoke(['coverageId' => $linkId, 'status' => 'SUSPENDED', 'reason' => 'Awaiting insurance renewal.'], $adminSession, $request);
    $assert($suspended['covered'] === false, 'suspended coverage stops being covered');
    $assert($suspended['status'] === 'SUSPENDED', 'suspension is explicit');
    $assert(str_contains($suspended['reason'], 'suspended'), 'the reason explains the suspension');

    $changeAudits = (new AuditLog($database))->list(['entityType' => 'RescueCoverage', 'action' => 'RESCUE_COVERAGE_CHANGED', 'limit' => 5]);
    $assert($changeAudits !== [], 'changing coverage is audited');
    $assert(
        str_contains((string) json_encode($changeAudits[0]['newData']), 'SUSPENDED'),
        'the audit records the new state'
    );

    $expectRejection(
        static fn () => $coverage->revoke(['coverageId' => $linkId, 'status' => 'ACTIVE', 'reason' => 'x'], $adminSession, $request),
        422,
        'coverage can only be suspended or revoked, never silently re-activated here'
    );
    $expectRejection(
        static fn () => $coverage->revoke(['coverageId' => $linkId, 'status' => 'REVOKED', 'reason' => ''], $adminSession, $request),
        422,
        'a coverage change requires a reason'
    );

    // ---- Restrictions travel with the answer ------------------------------
    $restricted = $coverage->grant([
        'subjectType' => 'VEHICLE',
        'subjectId' => $vehicleId,
        'vehicleId' => $vehicleId,
        'servicePlanId' => $planId,
        'coverageType' => 'ROAD_ASSISTANCE',
        'restrictions' => ['maxDistanceKm' => 150, 'excludedRegions' => ['BORDER_POST_KASUMBALESA']],
    ], $adminSession);
    $assert(($restricted['restrictions']['maxDistanceKm'] ?? null) === 150, 'plan restrictions travel with the coverage answer');
    $assert(
        in_array('BORDER_POST_KASUMBALESA', $restricted['restrictions']['excludedRegions'] ?? [], true),
        'excluded regions are reported to the responder'
    );

    // ---- A person and a vehicle can both be covered separately -------------
    $personCoverage = $coverage->grant([
        'subjectType' => 'PERSON', 'subjectId' => $personId, 'coverageType' => 'MEDICAL',
    ], $adminSession);
    $assert($personCoverage['covered'] === true, 'a person can be covered independently of their vehicle');
    $assert($personCoverage['plan'] === null, 'coverage without a plan reports no plan rather than inventing one');
} finally {
    foreach ($coverageIds as $coverageId) {
        if (is_string($coverageId) && $coverageId !== '') {
            $database->prepare('DELETE FROM rescue_coverage_links WHERE id = :id')->execute(['id' => $coverageId]);
        }
    }
    $database->exec("DELETE FROM rescue_coverage_links WHERE vehicle_id = " . $database->quote($vehicleId));
    $database->exec("DELETE FROM rescue_coverage_links WHERE subject_id = " . $database->quote($personId));
    $database->prepare('DELETE FROM vehicles WHERE id = :id')->execute(['id' => $vehicleId]);
    $database->prepare('DELETE FROM persons WHERE id = :id')->execute(['id' => $personId]);
    $database->exec("DELETE FROM audit_logs WHERE entity_type = 'RescueCoverage'");
    $database->exec("DELETE FROM users WHERE first_name = 'Cov' AND email LIKE '%@mamore.test'");
}

if ($failures !== []) {
    fwrite(STDERR, count($failures) . " assertion(s) failed.\n");
    exit(1);
}
