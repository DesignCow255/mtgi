<?php

declare(strict_types=1);

/**
 * Currency contract.
 *
 * The single most important assertion here is the LAST one: that a full
 * conversion round-trip leaves every financial table byte-identical. Everything
 * else in this file is arithmetic; that one is the product's financial
 * integrity, and no amount of correct formatting matters if the display choice
 * can move money.
 *
 * Covered: all six conversion directions, the original-amount invariant, the
 * unavailable-rate fallback, staleness reporting, rounding, and rate
 * reciprocals. See the header of docs/ui-v2/CURRENCY_ARCHITECTURE.md.
 *
 * Usage: php tests/currency-integration.php
 */

require dirname(__DIR__) . '/bootstrap.php';

use Mamore\Core\Database;
use Mamore\Finance\ExchangeRateService;
use Mamore\Support\Money;

$failures = [];
$assert = static function (bool $condition, string $message) use (&$failures): void {
    if ($condition) {
        fwrite(STDOUT, "PASS: {$message}\n");
        return;
    }
    $failures[] = $message;
    fwrite(STDERR, "FAIL: {$message}\n");
};

$database = Database::connection();
$rates = new ExchangeRateService($database);

// --- 1. all six directions ----------------------------------------------------
$pairs = [
    ['USD', 'CDF', '600.00'],
    ['USD', 'TZS', '600.00'],
    ['CDF', 'USD', '1740000.00'],
    ['CDF', 'TZS', '1740000.00'],
    ['TZS', 'USD', '600.00'],
    ['TZS', 'CDF', '600.00'],
];

foreach ($pairs as [$from, $to, $amount]) {
    $shown = Money::display($amount, $from, $to, $rates);

    $assert(
        preg_match('/^[A-Z]{3} -?[\d,]+\.\d{2}$/', $shown) === 1,
        "{$from}->{$to} is a well-formed 2-decimal money string ({$shown})"
    );
    $assert(
        str_contains($shown, $to) || str_contains($shown, $from),
        "{$from} {$amount} is presented with a stated currency ({$shown})"
    );
}

// --- 2. identity is not a conversion ------------------------------------------
$identity = Money::presentation('600.00', 'USD', 'USD', $rates);
$assert($identity['converted'] === false, 'same-currency display is not reported as a conversion');
$assert($identity['amount'] === '600.00', 'same-currency display preserves the amount exactly');

// --- 3. unavailable rate: the ORIGINAL, never a zero -------------------------
foreach ([['USD', 'EUR'], ['XXX', 'USD'], ['USD', '']] as [$from, $to]) {
    $result = Money::presentation('600.00', $from, $to, $rates);

    $assert($result['converted'] === false, "no rate for {$from}->{$to} means no conversion happens");
    $assert($result['amount'] === '600.00', "no rate for {$from}->{$to} shows the ORIGINAL amount");
    $assert($result['amount'] !== '0.00', "no rate for {$from}->{$to} never renders as zero");
}

// A missing rate service must behave the same way rather than throwing.
$withoutRates = Money::presentation('600.00', 'USD', 'CDF', null);
$assert($withoutRates['converted'] === false, 'a missing rate service degrades rather than throwing');
$assert($withoutRates['currency'] === 'USD', 'a missing rate service keeps the source currency');

// --- 4. staleness is reported, and unavailable carries no number ------------
$board = $rates->board();
$assert(
    in_array($board['status'], ['live', 'cached', 'stale', 'unavailable'], true),
    'the rate board reports a known status (' . $board['status'] . ')'
);
$assert(count($board['rates']) === 6, 'the board carries all six pairs');
$assert($board['supported'] === ['USD', 'CDF', 'TZS'], 'USD, CDF and TZS are the supported currencies');

foreach ($board['rates'] as $entry) {
    // unavailable must NOT come with a number: that combination is exactly how a
    // stale rate ends up being presented as if it were usable.
    if ($entry['status'] === 'unavailable') {
        $assert(
            $entry['rate'] === null,
            "{$entry['pair']} is unavailable and therefore offers no number"
        );
    }
}

// --- 5. rounding --------------------------------------------------------------
$assert(
    Money::ceilToCdfHundred('1000.01') === '1100.00',
    'a CDF settlement rounds UP to the next 100 (1000.01 -> 1100.00)'
);
$assert(
    Money::ceilToCdfHundred('1000.00') === '1000.00',
    'a CDF settlement already on a hundred is left alone'
);
$assert(
    Money::usdToCdfRounded('1.00', '2900') === '2900.00',
    'the pre-existing ceil-to-100 convention is preserved'
);
$assert(
    Money::format('1234.5', 'USD') === 'USD 1,234.50',
    'a bare amount pads to two decimals'
);
$assert(
    Money::format('-1234.5', 'USD') === '-USD 1,234.50',
    'a negative amount keeps its sign'
);

// --- 6. rates are reciprocals, cross rates agree -----------------------------
$usdCdf = $rates->getRate('USD', 'CDF');
$cdfUsd = $rates->getRate('CDF', 'USD');

if ($usdCdf['rate'] !== null && $cdfUsd['rate'] !== null) {
    $product = bcmul($usdCdf['rate'], $cdfUsd['rate'], 8);
    // Tolerance, not exact equality. 1/2900 is 0.000344827586..., which no
    // fixed-point rate can hold exactly, so a reciprocal pair is checked to be
    // within 1e-8 of unity -- four orders of magnitude tighter than a cent on
    // any amount this platform handles, and deliberately NOT tightened to
    // bccomp(..., 0), which would fail on a correctly-implemented service.
    $assert(
        bcsub($product, '1', 12) !== '0.000000000000' && bccomp(bcsub($product, '1', 12), '0.00000001', 12) <= 0,
        "USD/CDF and CDF/USD are reciprocals to 1e-8 ({$usdCdf['rate']} x {$cdfUsd['rate']} = {$product})"
    );
} else {
    $assert(true, 'no rate available, reciprocal check skipped rather than faked');
}

$usdTzs = $rates->getRate('USD', 'TZS');
$cdfTzs = $rates->getRate('CDF', 'TZS');

if ($usdTzs['rate'] !== null && $usdCdf['rate'] !== null && $cdfTzs['rate'] !== null) {
    $expected = bcdiv($usdTzs['rate'], $usdCdf['rate'], 6);
    // Same tolerance reasoning as the reciprocal check: 12dp fixed point, so
    // agreement is asserted to 1e-8 rather than bit-for-bit. bcabs() does not
    // exist in PHP, so the magnitude is taken by subtracting a negative delta.
    $delta = bcsub($expected, $cdfTzs['rate'], 12);
    $magnitude = bccomp($delta, '0', 12) < 0 ? bcsub('0', $delta, 12) : $delta;

    $assert(
        bccomp($magnitude, '0.00000001', 12) <= 0,
        "CDF->TZS derives from USD->TZS and USD->CDF ({$cdfTzs['rate']} vs {$expected}, delta {$delta})"
    );
} else {
    $assert(true, 'no rate available, cross-rate check skipped rather than faked');
}

// --- 7. TZS is a real currency, not a display-only fiction --------------------
$assert(
    in_array('TZS', ExchangeRateService::SUPPORTED, true),
    'TZS is supported'
);
$constraint = $database->query(<<<'SQL'
    SELECT COUNT(*) FROM information_schema.table_constraints
    WHERE constraint_schema = DATABASE() AND constraint_name = 'ck_payments_currency'
    SQL)->fetchColumn();
$assert((int) $constraint === 1, 'the payments currency constraint still exists');

/*
 * ============================================================================
 * THE INVARIANT
 *
 * Everything above is arithmetic. This is the part that matters: a display
 * currency is a PRESENTATION choice, and choosing one must not be capable of
 * moving money.
 *
 * The proof is a checksum over every financial table, taken before and after a
 * full conversion round-trip through all six pairs. If any amount, currency,
 * rate or settlement column were rewritten, the two hashes differ.
 * ============================================================================
 */
$fingerprint = static function (PDO $database): string {
    $tables = ['payments', 'receipts', 'subscriptions', 'finance_transactions', 'ledger_entries', 'revenue_ledgers'];

    $parts = [];
    foreach ($tables as $table) {
        // The table name cannot be bound, so it is quoted after being checked
        // against a fixed allow-list above. Nothing user-supplied reaches SQL.
        $exists = $database->query(
            'SELECT COUNT(*) FROM information_schema.tables WHERE table_schema = DATABASE() AND table_name = '
            . $database->quote($table)
        )->fetchColumn();

        if ((int) $exists !== 1) {
            continue;
        }

        // Checksum every column of every row, order-independent. This is
        // deliberately broader than "check the amount column": any write at all
        // changes it, including one nobody thought to assert on.
        $columns = $database->query('SHOW COLUMNS FROM `' . $table . '`')->fetchAll(PDO::FETCH_ASSOC);
        $expressions = array_map(
            static fn (array $column): string => "COALESCE(CAST(`{$column['Field']}` AS CHAR), '~')",
            $columns
        );

        $sql = 'SELECT COUNT(*) AS n, COALESCE(SUM(CRC32(CONCAT_WS("|", '
            . implode(', ', $expressions) . '))), 0) AS h FROM `' . $table . '`';
        $row = $database->query($sql)->fetch(PDO::FETCH_ASSOC);

        $parts[] = $table . ':' . $row['n'] . ':' . $row['h'];
    }

    return md5(implode(';', $parts));
};

$before = $fingerprint($database);

// Exercise the whole display surface the way the interface does: every
// conversion direction, the unavailable path, and a settlement rounding.
foreach ($pairs as [$from, $to, $amount]) {
    Money::display($amount, $from, $to, $rates);
    Money::display($amount, $from, $to, $rates, true);
    Money::presentation($amount, $from, $to, $rates);
    Money::convert($amount, $from, $to, $rates);
}
Money::display('600.00', 'USD', 'EUR', $rates);          // unavailable
Money::display('600.00', 'USD', 'CDF', null);            // no service at all
Money::ceilToCdfHundred('1740000.01');                   // settlement rounding
$rates->board();

$after = $fingerprint($database);

$assert(
    $before === $after,
    'a full conversion round-trip leaves every financial table byte-identical'
);
if ($before !== $after) {
    fwrite(STDERR, "  before: {$before}\n  after:  {$after}\n");
}

fwrite(STDOUT, "\n");
if ($failures !== []) {
    fwrite(STDERR, count($failures) . " failure(s):\n");
    foreach ($failures as $failure) {
        fwrite(STDERR, '  - ' . $failure . "\n");
    }
    exit(1);
}

fwrite(STDOUT, "All currency assertions passed.\n");

