<?php

declare(strict_types=1);

/**
 * Localisation contract.
 *
 * The audit found the product had no i18n layer at all, so this asserts the
 * properties the brief demands and that are easy to break silently:
 *
 *   1. Every locale defines every key the English catalogue defines. A gap means
 *      that language silently falls back, which is acceptable to a user but
 *      invisible to a developer, so it must fail the build.
 *   2. No locale defines a key English does not, because an unreachable key is
 *      dead weight that looks like coverage.
 *   3. A missing key never returns a raw key to a user.
 *   4. Category A data (names, plates, references) is never translated.
 *   5. Category B data (status codes) resolves to a different string per locale
 *      and never to a raw code.
 *   6. Locale negotiation and fallback behave as documented.
 *
 * Usage: php tests/i18n-integration.php
 */

require dirname(__DIR__) . '/bootstrap.php';

use Mamore\Core\Translator;
use Mamore\Support\DisplayTranslator;

$failures = [];
$assert = static function (bool $condition, string $message) use (&$failures): void {
    if ($condition) {
        fwrite(STDOUT, "PASS: {$message}\n");
        return;
    }
    $failures[] = $message;
    fwrite(STDERR, "FAIL: {$message}\n");
};

$locales = Translator::supported();
$assert($locales === ['en', 'fr', 'sw'], 'the three required locales exist: ' . implode(', ', $locales));

// --- 1 & 2. catalogue parity ------------------------------------------------
$catalogues = [];
foreach ($locales as $locale) {
    $catalogues[$locale] = Translator::instance($locale)->catalogue($locale);
}

$english = array_keys($catalogues['en']);
$assert(count($english) > 100, 'the English catalogue is non-trivial (' . count($english) . ' keys)');

foreach ($locales as $locale) {
    if ($locale === 'en') {
        continue;
    }

    $missing = array_values(array_diff($english, array_keys($catalogues[$locale])));
    $assert(
        $missing === [],
        "{$locale} defines every English key (" . count($catalogues[$locale]) . '/' . count($english) . ')'
            . ($missing === [] ? '' : '; missing: ' . implode(', ', array_slice($missing, 0, 8)))
    );

    $extra = array_values(array_diff(array_keys($catalogues[$locale]), $english));
    $assert(
        $extra === [],
        "{$locale} defines no key English does not"
            . ($extra === [] ? '' : '; extra: ' . implode(', ', array_slice($extra, 0, 8)))
    );
}


// --- 4 & 5. data classification --------------------------------------------
Translator::reset();
$display = new DisplayTranslator(Translator::instance('fr'));

$categoryA = [
    ['field' => 'first_name', 'value' => 'Jean-Pierre', 'label' => 'a given name'],
    ['field' => 'passenger_name', 'value' => 'Marie Kabange', 'label' => 'a passenger name'],
    ['field' => 'plate', 'value' => '1234-ABC', 'label' => 'a registration plate'],
    ['field' => 'email', 'value' => 'user@example.com', 'label' => 'an email address'],
    ['field' => 'phone', 'value' => '+243 810 000 001', 'label' => 'a phone number'],
    ['field' => 'reference', 'value' => 'T123-ABC', 'label' => 'a ticket reference'],
    ['field' => 'latitude', 'value' => '-11.66120', 'label' => 'a coordinate'],
];

foreach ($categoryA as $case) {
    $assert(
        $display->display($case['field'], $case['value']) === $case['value'],
        "Category A is untouched: {$case['label']} ({$case['value']})"
    );
    $assert(
        !$display->isTranslatable($case['field']),
        "{$case['field']} is classified as never-translatable"
    );
}

// Category A must win even when the value happens to look like a status code.
// The classification is a property of the FIELD, not of the value, so it cannot
// be decided by what the data looks like on one row.
$assert(
    $display->display('plate', 'ONLINE') === 'ONLINE',
    'Category A wins even when the value looks like a status code'
);

foreach (['IN_TRANSIT', 'CRITICAL', 'PENDING_PAYMENT', 'ONLINE'] as $code) {
    $french = $display->status($code, 'fr');
    $english = $display->status($code, 'en');

    $assert($french !== $code, "Category B {$code} is translated in French ({$french})");
    $assert($english !== $code, "Category B {$code} is translated in English ({$english})");
    $assert($french !== $english, "Category B {$code} differs between English and French");
}

// The Translator is deliberately a shared singleton: one request, one locale.
// This asserts the trap is visible rather than surprising later.
$handle = Translator::instance('fr');
Translator::instance('en');
$assert(
    $handle->locale() === 'en',
    'a captured Translator handle follows the shared locale (documented, not accidental)'
);
$assert(
    $handle->t('status.ONLINE', [], 'fr') === 'En ligne',
    'an explicit locale argument bypasses the shared state for comparisons'
);

// A status added to the backend after this catalogue was written must still read
// as words rather than shouting a code at an operator.
$assert(
    $display->status('PENDING_REVIEW') === 'Pending review',
    'an unmapped status degrades to readable text, not a raw code'
);
$assert($display->status('') === '', 'an empty status renders as empty, not as a key');
$assert($display->number(null) === '0', 'a null number renders as zero, not as a placeholder');
$assert($display->number('1234.5') === '1235', 'numbers are formatted, never translated');

// --- 6. locale negotiation --------------------------------------------------
$assert(Translator::normalise('fr-FR') === 'fr', 'a regional tag resolves to its base locale');
$assert(Translator::normalise('SW_KE') === 'sw', 'an underscored tag resolves to its base locale');
$assert(Translator::normalise('de') === 'en', 'an unsupported language falls back to English');
$assert(Translator::normalise('evilmachine') === 'en', 'a nonsense tag falls back to English');

$request = static fn (string $uri, array $headers = []) => new Mamore\Core\Request('GET', $uri, [], $headers);

Translator::reset();
$assert(
    Translator::instance()->resolveForRequest($request('/?lang=fr')) === 'fr',
    'an explicit ?lang= wins'
);

Translator::reset();
$_SESSION['mamore_locale'] = 'sw';
$assert(
    Translator::instance()->resolveForRequest($request('/')) === 'sw',
    'the stored session preference is used when no explicit choice is given'
);
unset($_SESSION['mamore_locale']);

Translator::reset();
$assert(
    Translator::instance()->resolveForRequest($request('/', ['accept-language' => 'fr-FR,fr;q=0.9'])) === 'fr',
    'Accept-Language is honoured'
);

Translator::reset();
$assert(
    Translator::instance()->resolveForRequest($request('/', ['accept-language' => 'de-DE,de;q=0.9'])) === 'en',
    'an unsupported Accept-Language falls back to English, not to a partial match'
);

Translator::reset();

// --- 7. no empty values -----------------------------------------------------
foreach ($locales as $locale) {
    $empty = array_keys(array_filter(
        Translator::instance($locale)->catalogue($locale),
        static fn ($value): bool => is_string($value) && trim($value) === ''
    ));
    $assert(
        $empty === [],
        "{$locale} has no empty translation values" . ($empty === [] ? '' : ': ' . implode(', ', $empty))
    );
}

Translator::reset();

fwrite(STDOUT, "\n");
if ($failures !== []) {
    fwrite(STDERR, count($failures) . " failure(s):\n");
    foreach ($failures as $failure) {
        fwrite(STDERR, '  - ' . $failure . "\n");
    }
    exit(1);
}

fwrite(STDOUT, "All localisation assertions passed.\n");

// --- 3. a missing key never reaches a user ----------------------------------
foreach ($locales as $locale) {
    Translator::reset();
    $translator = Translator::instance($locale);

    $assert(
        $translator->t('definitely.not.a.real.key') === 'definitely.not.a.real.key',
        "{$locale}: an unknown key is surfaced so the gap can be found"
    );
    $assert(
        in_array('definitely.not.a.real.key', $translator->missing(), true),
        "{$locale}: the missing key is recorded for development"
    );
}
