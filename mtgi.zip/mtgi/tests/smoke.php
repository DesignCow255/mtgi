<?php

declare(strict_types=1);

use Mamore\Core\Response;
use Mamore\Core\Request;
use Mamore\Core\Router;

require dirname(__DIR__) . '/bootstrap.php';

$router = new Router();
$router->get('/health', static fn (Request $_): array => Response::json(['status' => 'ok']));

$health = $router->dispatch('GET', '/health?probe=1');
$missing = $router->dispatch('GET', '/missing');

$assertions = [
    'health status' => $health['status'] === 200,
    'health body' => json_decode($health['body'], true, 512, JSON_THROW_ON_ERROR)['status'] === 'ok',
    'missing status' => $missing['status'] === 404,
];

foreach ($assertions as $name => $passed) {
    if (!$passed) {
        fwrite(STDERR, "FAIL: {$name}\n");
        exit(1);
    }
    fwrite(STDOUT, "PASS: {$name}\n");
}
