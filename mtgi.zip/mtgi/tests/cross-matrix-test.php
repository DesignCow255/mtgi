<?php

declare(strict_types=1);

/**
 * Cross-language, cross-currency, cross-theme matrix (Phase 28).
 *
 * The plan asks for EN/SW/FR x USD/TZS/CDF x light/dark = 18 combinations to be
 * verified. Rendering all 18 needs a browser, so what this does is check the
 * thing that actually breaks in them: a key that exists in English and not in
 * French, a catalogue that is missing a file, a currency the switcher does not
 * offer, a theme that is not scoped.
 *
 * It is exhaustive where it can be, and says plainly where it cannot. The
 * combination count is asserted so the matrix cannot quietly shrink from 18 to
 * 12 because a currency or a language was dropped.
 *
 * The long-translation risk the plan registers is checked too: a value that
 * grows a lot in French is flagged, because that is what breaks a fixed-height
 * row, and a flag is more useful than a silent pass.
 */

require dirname(__DIR__) . '/bootstrap.php';

use Mamore\Core\Translator;
use Mamore\Support\Money;

$root = dirname(__DIR__);
$failures = 0;
$assert = static function (bool $condition, string $message) use (&$failures): void {
    if ($condition) {
        fwrite(STDOUT, "PASS: {$message}\n");
        return;
    }
    $failures++;
    fwrite(STDERR, "FAIL: {$message}\n");
};

$locales = ['en', 'sw', 'fr'];
$currencies = ['USD', 'TZS', 'CDF'];
$themes = ['light', 'dark'];

/* -- the matrix is the size the plan asked for -------------------------- */

$assert(
    count($locales) * count($currencies) * count($themes) === 18,
    'the cross-matrix is 3 languages x 3 currencies x 2 themes = 18 combinations'
);

/* -- catalogues are complete and structurally identical ------------------ */

$englishKeys = [];
foreach (glob($root . '/resources/lang/en/*.php') ?: [] as $file) {
    foreach (array_keys((array) require $file) as $key) {
        $englishKeys[basename($file, '.php') . '.' . $key] = true;
    }
}
$assert($englishKeys !== [], 'the English catalogue is not empty');

foreach ($locales as $locale) {
    $keys = [];
    foreach (glob($root . "/resources/lang/{$locale}/*.php") ?: [] as $file) {
        foreach (array_keys((array) require $file) as $key) {
            $keys[basename($file, '.php') . '.' . $key] = true;
        }
    }
    $missing = array_diff(array_keys($englishKeys), array_keys($keys));
    $assert(
        $missing === [],
        "the {$locale} catalogue defines every English key"
    ) or fwrite(STDERR, '     missing: ' . implode(', ', array_slice($missing, 0, 8)) . "\n");
    $assert(
        count(array_diff(array_keys($keys), array_keys($englishKeys))) === 0,
        "the {$locale} catalogue defines no key English does not"
    );
}

/* -- every locale actually resolves, with no silent fallback ------------ */

foreach ($locales as $locale) {
    $translator = Translator::instance($locale, $root . '/resources/lang');
    $resolved = 0;
    foreach (array_keys($englishKeys) as $dotted) {
        [$group, $key] = explode('.', $dotted, 2);
        if ($translator->has("{$group}.{$key}", $locale)) {
            $resolved++;
        }
    }
    $assert(
        $resolved === count($englishKeys),
        "every key resolves in {$locale} without falling back"
    );
}

/* -- translations are actually translated, not copied -------------------- */

$english = [];
foreach (glob($root . '/resources/lang/en/*.php') ?: [] as $file) {
    $english = array_merge($english, (array) require $file);
}

// The real defect is a catalogue COPIED wholesale, not an individual cognate.
// French legitimately shares Normal, Attention, Services, Administration and
// Maintenance with English -- those are the correct French words. So this is
// measured as a PROPORTION per file: a file where nearly everything matches is
// a file that was never translated, and a handful of matches elsewhere is just
// good linguistics.
foreach (['sw', 'fr'] as $locale) {
    foreach (glob($root . "/resources/lang/{$locale}/*.php") ?: [] as $file) {
        $name = basename($file, '.php');
        $translated = (array) require $file;

        $comparable = 0;
        $identical = 0;
        foreach ($english as $key => $value) {
            // Short values are excluded: a 3-letter word matching is noise.
            if (!is_string($value) || mb_strlen($value) <= 3) {
                continue;
            }
            if (!array_key_exists($key, $translated)) {
                continue;
            }
            $comparable++;
            if ($translated[$key] === $value) {
                $identical++;
            }
        }

        $ratio = $comparable === 0 ? 0 : $identical / $comparable;
        $assert(
            $ratio <= 0.5,
            "the {$locale}/{$name} file is translated rather than copied ({$identical}/{$comparable} match)"
        ) or fwrite(STDERR, "     {$locale}/{$name}: {$identical} of {$comparable} values are still English\n");
    }
}

/* -- long translations are flagged, not silently shipped ---------------- */

// French runs roughly 15-20% longer than English. Anything far beyond that is
// what overflows a fixed-height row.
$flagged = [];
foreach (glob($root . '/resources/lang/fr/*.php') ?: [] as $file) {
    $translated = (array) require $file;
    foreach ($english as $key => $value) {
        if (!isset($translated[$key]) || !is_string($value) || mb_strlen($value) < 8) {
            continue;
        }
        $growth = mb_strlen((string) $translated[$key]) / mb_strlen($value);
        if ($growth > 1.9) {
            $flagged[] = "{$key} (x" . round($growth, 2) . ')';
        }
    }
}
$assert(
    $flagged === [],
    'no French translation grows past 1.9x its English, which would overflow a row'
) or fwrite(STDERR, '     long: ' . implode(', ', array_slice($flagged, 0, 6)) . "\n");

/* -- every currency in the matrix is real and distinct ------------------ */

$database = Mamore\Core\Database::connection();
$rates = new Mamore\Finance\ExchangeRateService($database);

foreach ($currencies as $currency) {
    $board = $rates->board();
    $known = false;
    foreach ((array) ($board['currencies'] ?? $board['supported'] ?? []) as $entry) {
        $code = is_array($entry) ? ($entry['code'] ?? '') : (string) $entry;
        if ($code === $currency) {
            $known = true;
            break;
        }
    }
    $assert($known, "the {$currency} currency is offered by the rate service");
}

// A conversion between two of them must actually produce a number, and must
// not alter the amount it was given.
$converted = Money::convert('1000.00', 'USD', 'CDF', $rates);
$assert(($converted['converted'] ?? false) === true, 'USD converts to CDF');
$assert(($converted['currency'] ?? '') === 'CDF', 'the conversion reports the target currency');
$assert($converted['amount'] !== '1000.00', 'the converted amount is not the original');
$assert(
    in_array($converted['status'] ?? '', ['live', 'cached', 'stale'], true),
    'the conversion reports a freshness state a UI can colour'
);

/* -- the switcher offers exactly the matrix currencies ------------------- */

$html = (string) file_get_contents($root . '/public/app.html');
foreach ($currencies as $currency) {
    $assert(
        str_contains($html, 'data-currency-option="' . $currency . '"'),
        "the navbar currency switcher offers {$currency}"
    );
}

/* -- both themes are reachable and scoped -------------------------------- */

foreach ($themes as $theme) {
    $path = $root . "/public/assets/css/themes/{$theme}.css";
    $assert(is_file($path), "the {$theme} theme stylesheet ships");
    if (!is_file($path)) {
        continue;
    }
    $css = (string) file_get_contents($path);
    $assert(
        str_contains($css, "data-theme=\"{$theme}\""),
        "the {$theme} theme is scoped to its attribute"
    );
    // Every semantic token the theme overrides must actually be defined in the
    // base, or the override is a no-op that looks like it works.
    preg_match_all('/^\s*(--[\w-]+):/m', $css, $defined);
    $tokens = (string) file_get_contents($root . '/public/assets/css/tokens.css');
    $unknown = [];
    foreach (array_unique($defined[1]) as $token) {
        if (!str_contains($tokens, $token . ':')) {
            $unknown[] = $token;
        }
    }
    $assert(
        $unknown === [],
        "the {$theme} theme only overrides tokens the base layer defines"
    ) or fwrite(STDERR, '     unknown: ' . implode(', ', array_slice($unknown, 0, 6)) . "\n");
}

fwrite(STDOUT, $failures === 0 ? "\nPASS: the 18-combination matrix holds at the data layer\n" : "\nFAILURES: {$failures}\n");
exit($failures === 0 ? 0 : 1);
