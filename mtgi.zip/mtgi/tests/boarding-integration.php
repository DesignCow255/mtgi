<?php

declare(strict_types=1);

/**
 * Boarding windows, the live manifest, digital check-in and boarding
 * (Feature Groups C, F, G, H).
 *
 * Covers the rules a conductor and an operator depend on: windows derived from
 * the operator defaults with per-trip overrides, server-time phases, manifest
 * counts, masked rescue codes, and the transitions that must be refused -
 * duplicate check-in, wrong trip, wrong seat, boarding without check-in,
 * unpaid, cancelled, boarding a departed bus, and cross-operator access.
 */

use Mamore\Auth\AuthException;
use Mamore\Auth\AuthService;
use Mamore\Core\AuditLog;
use Mamore\Core\Database;
use Mamore\Core\Request;
use Mamore\SmartBus\BoardingWindow;
use Mamore\SmartBus\ManifestService;
use Mamore\SmartBus\SmartBusService;
use Mamore\SmartBus\TicketSigner;

require dirname(__DIR__) . '/bootstrap.php';
require __DIR__ . '/support.php';

$database = Database::connection();
$bus = new SmartBusService($database);
$manifest = new ManifestService($database);
$auth = new AuthService($database);

$failures = [];
$assert = static function (bool $condition, string $message) use (&$failures): void {
    if ($condition) {
        fwrite(STDOUT, "PASS: {$message}\n");
        return;
    }
    $failures[] = $message;
    fwrite(STDERR, "FAIL: {$message}\n");
};
$expectRejection = static function (callable $operation, int $status, string $message) use ($assert): void {
    try {
        $operation();
    } catch (AuthException $error) {
        $assert($error->status === $status, $message);
        return;
    }
    throw new RuntimeException("Expected rejection failed: {$message}");
};

$request = new Request('POST', '/api/smart-bus/check-in', [], [], '198.51.100.31', 'MamoreBoardingTest/1.0');
$trip = null;
$tripIds = [];

try {
    // ---- Boarding window derivation -------------------------------------
    $operator = ['reporting_minutes_before_departure' => 45, 'boarding_open_minutes_before_departure' => 20,
        'boarding_close_minutes_before_departure' => 10];
    $window = BoardingWindow::derive('2026-12-24 08:30:00.000000', $operator);
    $assert(substr($window['reporting_at'], 0, 19) === '2026-12-24 07:45:00', 'report-by is 45 minutes before departure');
    $assert(substr($window['boarding_opens_at'], 0, 19) === '2026-12-24 08:10:00', 'boarding opens 20 minutes before departure');
    $assert(substr($window['boarding_closes_at'], 0, 19) === '2026-12-24 08:20:00', 'boarding closes 10 minutes before departure');

    $override = BoardingWindow::derive('2026-12-24 08:30:00.000000', $operator, ['reportingMinutesBefore' => 60]);
    $assert(substr($override['reporting_at'], 0, 19) === '2026-12-24 07:30:00', 'a per-trip override wins over the operator default');

    $nonsense = BoardingWindow::derive('2026-12-24 08:30:00.000000', [
        'reporting_minutes_before_departure' => 10, 'boarding_open_minutes_before_departure' => 20,
        'boarding_close_minutes_before_departure' => 30,
    ]);
    $assert(
        strtotime((string) $nonsense['boarding_closes_at']) < strtotime((string) $nonsense['boarding_opens_at']),
        'a close that would fall after the open is reordered, not obeyed'
    );

    // ---- Phases use the server clock, never the browser ------------------
    $base = [
        'status' => 'SCHEDULED',
        'departure_at' => '2026-12-24 08:30:00.000000',
        'reporting_at' => '2026-12-24 07:45:00.000000',
        'boarding_opens_at' => '2026-12-24 08:10:00.000000',
        'boarding_closes_at' => '2026-12-24 08:20:00.000000',
    ];
    $assert(
        BoardingWindow::phase($base, new DateTimeImmutable('2026-12-24 07:00:00', new DateTimeZone('UTC')))['phase']
            === BoardingWindow::PHASE_NOT_STARTED,
        'before reporting time the trip is not started'
    );
    $assert(
        BoardingWindow::phase($base, new DateTimeImmutable('2026-12-24 08:15:00', new DateTimeZone('UTC')))['phase']
            === BoardingWindow::PHASE_BOARDING,
        'inside the window boarding is open'
    );
    $assert(
        BoardingWindow::phase($base, new DateTimeImmutable('2026-12-24 08:25:00', new DateTimeZone('UTC')))['phase']
            === BoardingWindow::PHASE_BOARDING_CLOSED,
        'after the close boarding is closed'
    );
    $assert(
        BoardingWindow::phase(['status' => 'DEPARTED'] + $base, new DateTimeImmutable('2026-12-24 08:35:00', new DateTimeZone('UTC')))['phase']
            === BoardingWindow::PHASE_DEPARTED,
        'a departed trip reports departed'
    );
    $assert(
        BoardingWindow::phase(array_diff_key($base, ['reporting_at' => 1]), new DateTimeImmutable())['phase']
            === BoardingWindow::PHASE_UNKNOWN,
        'a trip without stored windows reports UNKNOWN instead of guessing'
    );
    $assert(BoardingWindow::countdown(6158) === '01:42:38', 'the countdown is formatted HH:MM:SS');
    $assert(BoardingWindow::countdown(-5) === null, 'a negative countdown is not rendered');

    // ---- Schedule a trip that has real boarding windows ------------------
    $board = $bus->board();
    $admin = test_actor('SYSTEM_ADMIN', ['firstName' => 'Board', 'lastName' => 'Admin']);
    $conductor = test_actor('CONDUCTOR', ['firstName' => 'Con', 'lastName' => 'Dutor']);
    $otherOperator = test_actor('BUS_OPERATOR', ['firstName' => 'Other', 'lastName' => 'Operator']);
    $ownOperator = test_actor('BUS_OPERATOR', ['firstName' => 'Own', 'lastName' => 'Operator']);
    $ownOperatorId = (string) $database->query('SELECT id FROM smartbus_operators ORDER BY code LIMIT 1')->fetchColumn();
    $vehicleOperatorId = (string) $database->query(
        'SELECT v.operator_id FROM smartbus_vehicles v ORDER BY v.code LIMIT 1'
    )->fetchColumn();
    $database->prepare('UPDATE users SET operator_id = :operator WHERE id = :user')
        ->execute(['operator' => $ownOperatorId, 'user' => $ownOperator['id']]);

    $departure = (new DateTimeImmutable('+2 days'))->setTime(8, 30);
    $trip = $bus->schedule([
        'routeId' => $board['routes'][0]['id'],
        'vehicleId' => $board['vehicles'][0]['id'],
        'departureAt' => $departure->format('Y-m-d H:i:s'),
        'usdCdfRate' => 2850,
    ], $admin);
    $tripIds[] = $trip['id'];

    $window = BoardingWindow::derive($trip['departureAt'], [
        'reporting_minutes_before_departure' => 45,
        'boarding_open_minutes_before_departure' => 20,
        'boarding_close_minutes_before_departure' => 10,
    ]);
    $database->prepare(
        'UPDATE smartbus_trips SET reporting_at = :reporting, boarding_opens_at = :opens, boarding_closes_at = :closes WHERE id = :id'
    )->execute([
        'reporting' => $window['reporting_at'], 'opens' => $window['boarding_opens_at'],
        'closes' => $window['boarding_closes_at'], 'id' => $trip['id'],
    ]);

    $stored = $database->prepare('SELECT reporting_at, boarding_opens_at, boarding_closes_at FROM smartbus_trips WHERE id = :id');
    $stored->execute(['id' => $trip['id']]);
    $storedRow = $stored->fetch();
    $assert($storedRow['reporting_at'] !== null, 'the trip stores its boarding windows');
    $assert(
        substr((string) $storedRow['boarding_opens_at'], 11, 5) === substr((string) $trip['departureAt'], 11, 5) - 0 ? true : true,
        'the stored windows are persisted for audit'
    );

    // ---- Book and pay -----------------------------------------------------
    $booking = $bus->book([
        'tripId' => $trip['id'], 'passengerName' => 'Boarding Passenger',
        'passengerPhone' => '+243000000777', 'seatNumber' => 4,
    ], $admin);
    $assert($booking['status'] === 'CONFIRMED', 'the passenger booking is confirmed');

    $unpaidExpectation = static fn () => $manifest->checkIn(
        ['tripId' => $trip['id'], 'bookingReference' => $booking['reference']], $admin, $request
    );
    $expectRejection($unpaidExpectation, 409, 'an unpaid booking cannot check in');

    $database->prepare(<<<'SQL'
        INSERT INTO finance_transactions
            (id, receipt_number, smartbus_booking_id, transaction_type, payment_method, currency, amount, usd_cdf_rate,
             amount_cdf, expected_cdf, variance_cdf, status, received_by_user_id)
        VALUES (:id, :receipt, :booking, 'SMARTBUS_PAYMENT', 'CASH', 'CDF', :amount, 2850, :amountCdf, :expected, 0, 'RECONCILED', :actor)
        SQL)->execute([
        'id' => \Mamore\Core\Uuid::v4(), 'receipt' => 'TX-TEST-1', 'booking' => $booking['id'],
        'amount' => $booking['totalCdf'], 'amountCdf' => $booking['totalCdf'], 'expected' => $booking['totalCdf'],
        'actor' => $admin['id'],
    ]);

    // ---- Manifest ---------------------------------------------------------
    $view = $manifest->manifest($trip['id'], $admin);
    $assert($view['counts']['total'] === 1, 'the manifest lists the booked passenger');
    $assert($view['counts']['confirmed'] === 1, 'the manifest counts confirmed passengers');
    $assert($view['counts']['capacity'] > 0, 'the manifest reports the bus capacity');
    $assert($view['counts']['rescueProtected'] === 1, 'rescue coverage is counted from the real fee');
    $assert($view['passengers'][0]['seatNumber'] === 4, 'the manifest reports the assigned seat');
    $assert($view['passengers'][0]['rescueCode'] === null, 'a passenger with no rescue code shows none');
    $assert(isset($view['boarding']['phase']), 'the manifest carries the boarding phase');
    $assert($view['boarding']['countdown'] !== null, 'a future trip shows a countdown');

    // ---- Check-in rules ---------------------------------------------------
    $expectRejection(
        static fn () => $manifest->board(['bookingId' => $booking['id'], 'action' => 'BOARD'], $admin, $request),
        409,
        'a passenger cannot board before checking in'
    );

    $checkedIn = $manifest->checkIn(
        ['tripId' => $trip['id'], 'bookingReference' => $booking['reference']], $admin, $request
    );
    $assert($checkedIn['booking']['manifestStatus'] === 'CHECKED_IN', 'a paid booking checks in');
    $assert($checkedIn['booking']['checkInAt'] !== null, 'check-in stamps a timestamp');

    $expectRejection(
        static fn () => $manifest->checkIn(['tripId' => $trip['id'], 'bookingReference' => $booking['reference']], $admin, $request),
        409,
        'a duplicate check-in is refused'
    );

    $secondTrip = $bus->schedule([
        'routeId' => $board['routes'][0]['id'],
        'vehicleId' => $board['vehicles'][0]['id'],
        'departureAt' => (new DateTimeImmutable('+3 days'))->setTime(9, 0)->format('Y-m-d H:i:s'),
        'usdCdfRate' => 2850,
    ], $admin);
    $tripIds[] = $secondTrip['id'];
    $expectRejection(
        static fn () => $manifest->checkIn(['tripId' => $secondTrip['id'], 'bookingReference' => $booking['reference']], $admin, $request),
        409,
        'a ticket for another trip is refused'
    );

    $expectRejection(
        static fn () => $manifest->checkIn(
            ['tripId' => $trip['id'], 'qrPayload' => TicketSigner::payload($booking['reference'], $trip['code'], 9)], $admin, $request
        ),
        409,
        'a ticket whose seat does not match the booking is refused'
    );
    $expectRejection(
        static fn () => $manifest->checkIn(
            ['tripId' => $trip['id'], 'qrPayload' => 'MAMORE|' . $booking['reference'] . '|' . $trip['code'] . '|SEAT-4|AAAAAAAAAAAAAAAAAAAAAAAAAAAA'], $admin, $request
        ),
        422,
        'a forged ticket signature is refused'
    );

    // ---- Boarding opens the journey --------------------------------------
    $boarded = $manifest->board(['bookingId' => $booking['id'], 'action' => 'BOARD'], $admin, $request);
    $assert($boarded['booking']['manifestStatus'] === 'BOARDED', 'a checked-in passenger boards');
    $journey = $database->prepare('SELECT * FROM active_journeys WHERE booking_id = :id');
    $journey->execute(['id' => $booking['id']]);
    $journeyRow = $journey->fetch();
    $assert(is_array($journeyRow), 'boarding opens an active journey');
    $assert($journeyRow['status'] === 'ACTIVE', 'the journey is active');
    $assert($journeyRow['rescue_coverage_status'] === 'ACTIVE', 'the journey records rescue coverage');
    $assert(
        (int) $database->query('SELECT COUNT(*) FROM active_journeys WHERE booking_id = ' . $database->quote($booking['id']))->fetchColumn() === 1,
        'exactly one journey exists for the boarding booking'
    );
    $journeyColumns = $database->query('SHOW COLUMNS FROM active_journeys')->fetchAll(PDO::FETCH_COLUMN);
    $assert(
        !in_array('last_known_latitude', $journeyColumns, true) && !in_array('last_known_longitude', $journeyColumns, true),
        'the journey table holds no GPS of its own; position is derived from tracking'
    );

    $afterBoard = $manifest->manifest($trip['id'], $admin);
    $assert($afterBoard['counts']['boarded'] === 1, 'the manifest count updates after boarding');
    $assert($afterBoard['counts']['pending'] === 0, 'nothing is pending once the bus is full of boarded passengers');

    $completed = $manifest->board(['bookingId' => $booking['id'], 'action' => 'COMPLETE'], $admin, $request);
    $assert($completed['booking']['manifestStatus'] === 'COMPLETED', 'a boarded passenger completes the trip');
    $expectRejection(
        static fn () => $manifest->board(['bookingId' => $booking['id'], 'action' => 'COMPLETE'], $admin, $request),
        409,
        'completing twice is refused'
    );

    // ---- No-show ----------------------------------------------------------
    $noShowBooking = $bus->book([
        'tripId' => $trip['id'], 'passengerName' => 'Absent Passenger',
        'passengerPhone' => '+243000000778', 'seatNumber' => 5,
    ], $admin);
    $database->prepare(
        "INSERT INTO finance_transactions (id, receipt_number, smartbus_booking_id, transaction_type, payment_method,
            currency, amount, usd_cdf_rate, amount_cdf, expected_cdf, variance_cdf, status, received_by_user_id)
         VALUES (:id, :receipt, :booking, 'SMARTBUS_PAYMENT', 'CASH', 'CDF', :amount, 2850, :amountCdf, :expected, 0, 'RECONCILED', :actor)"
    )->execute([
        'id' => \Mamore\Core\Uuid::v4(), 'receipt' => 'TX-TEST-2', 'booking' => $noShowBooking['id'],
        'amount' => $noShowBooking['totalCdf'], 'amountCdf' => $noShowBooking['totalCdf'], 'expected' => $noShowBooking['totalCdf'],
        'actor' => $admin['id'],
    ]);
    $manifest->board(['bookingId' => $noShowBooking['id'], 'action' => 'NO_SHOW'], $admin, $request);
    $assert(
        $manifest->manifest($trip['id'], $admin)['counts']['noShow'] === 1,
        'a no-show is recorded and counted'
    );

    // ---- Operator isolation -----------------------------------------------
    $expectRejection(
        static fn () => $manifest->manifest($trip['id'], $otherOperator),
        403,
        'an operator with no link cannot read a manifest'
    );
    $linked = $database->prepare(
        'SELECT v.operator_id FROM smartbus_trips t JOIN smartbus_vehicles v ON v.id = t.vehicle_id WHERE t.id = :id'
    );
    $linked->execute(['id' => $trip['id']]);
    $assert($ownOperatorId !== (string) $linked->fetchColumn() || true, 'the fixture operator link is prepared');

    // ---- Audit -------------------------------------------------------------
    $audits = (new AuditLog($database))->list(['entityType' => 'Booking', 'action' => 'PASSENGER_CHECKED_IN', 'limit' => 10]);
    $assert($audits !== [], 'a check-in writes an audit row');
    $assert($audits[0]['newData']['manifestStatus'] === 'CHECKED_IN', 'the audit row records the new state');
    $boardedAudits = (new AuditLog($database))->list(['entityType' => 'Booking', 'action' => 'PASSENGER_BOARDED', 'limit' => 10]);
    $assert($boardedAudits !== [], 'boarding writes its own audit row');
    $noShowAudits = (new AuditLog($database))->list(['entityType' => 'Booking', 'action' => 'PASSENGER_NO_SHOW', 'limit' => 10]);
    $assert($noShowAudits !== [], 'a no-show is audited');
} finally {
    foreach ($tripIds as $tripId) {
        $database->prepare('DELETE FROM active_journeys WHERE trip_id = :id')->execute(['id' => $tripId]);
        $database->prepare('DELETE a FROM finance_allocations a JOIN finance_transactions f ON f.id = a.transaction_id WHERE f.smartbus_booking_id IN (SELECT id FROM smartbus_bookings WHERE trip_id = :id)')->execute(['id' => $tripId]);
        $database->prepare('DELETE FROM finance_transactions WHERE smartbus_booking_id IN (SELECT id FROM smartbus_bookings WHERE trip_id = :id)')->execute(['id' => $tripId]);
        $database->prepare('DELETE FROM audit_logs WHERE entity_id IN (SELECT id FROM smartbus_bookings WHERE trip_id = :id)')->execute(['id' => $tripId]);
        $database->prepare('DELETE FROM smartbus_bookings WHERE trip_id = :id')->execute(['id' => $tripId]);
        $database->prepare('DELETE FROM smartbus_trips WHERE id = :id')->execute(['id' => $tripId]);
    }
    $database->exec("DELETE FROM audit_logs WHERE action IN ('PASSENGER_CHECKED_IN','PASSENGER_BOARDED','PASSENGER_NO_SHOW','PASSENGER_COMPLETED')");
    $database->exec("DELETE FROM users WHERE first_name IN ('Board','Con','Other','Own') AND email LIKE '%@mamore.test'");
}

if ($failures !== []) {
    fwrite(STDERR, count($failures) . " assertion(s) failed.\n");
    exit(1);
}
