<?php

declare(strict_types=1);

/**
 * The private vehicle domain (phases 08 and 09).
 *
 * Walks the brief's flow: enrol a car, activate cover, authorize a second
 * driver, start a protected journey, report an emergency, and see the incident
 * reach the shared Control Center with position, vehicle, journey and coverage
 * attached. It also proves a subscriber cannot see or drive somebody else's car.
 */

use Mamore\Auth\AuthException;
use Mamore\Auth\AuthService;
use Mamore\Core\AuditLog;
use Mamore\Core\Database;
use Mamore\Core\Request;
use Mamore\Core\Uuid;
use Mamore\PrivateVehicle\PrivateVehicleService;
use Mamore\Rescue\RescueCoverageService;
use Mamore\SmartBus\RescueCodeService;
use Mamore\Tracking\TrackingIngestionService;

require dirname(__DIR__) . '/bootstrap.php';
require __DIR__ . '/support.php';

$database = Database::connection();
$coverage = new RescueCoverageService($database);
$codes = new RescueCodeService($database);
$ingest = new TrackingIngestionService($database);
$service = new PrivateVehicleService($database, $coverage, $codes);
$auth = new AuthService($database);

$failures = [];
$assert = static function (bool $condition, string $message) use (&$failures): void {
    if ($condition) {
        fwrite(STDOUT, "PASS: {$message}\n");
        return;
    }
    $failures[] = $message;
    fwrite(STDERR, "FAIL: {$message}\n");
};
$expectRejection = static function (callable $operation, int $status, string $message) use ($assert): void {
    try {
        $operation();
    } catch (AuthException $error) {
        $assert($error->status === $status, $message);
        return;
    }
    throw new RuntimeException("Expected rejection failed: {$message}");
};

$request = new Request('POST', '/api/private-vehicles/emergency', [], [], '198.51.100.64', 'PrivateVehicleTest/1.0');
$password = 'PrivateVehicle!2026';
$admin = test_actor('SYSTEM_ADMIN', ['password' => $password, 'firstName' => 'Pv', 'lastName' => 'Admin']);
$owner = test_actor('CUSTOMER', ['password' => $password, 'firstName' => 'Peter', 'lastName' => 'Owner']);
$intruder = test_actor('CUSTOMER', ['password' => $password, 'firstName' => 'Ivan', 'lastName' => 'Other']);
$session = static function (array $actor) use ($database, $auth, $password, $request): array {
    $email = (string) $database->query('SELECT email FROM users WHERE id = ' . $database->quote($actor['id']))->fetchColumn();

    return $auth->authenticate($auth->login($email, $password, $request)['accessToken']);
};
$adminSession = $session($admin);
$ownerSession = $session($owner);
$intruderSession = $session($intruder);

$vehicleId = Uuid::v4();
$enrolmentId = null;

try {
    // The customer must have a real membership record to own a vehicle.
    $subscriberId = (string) $database->query(
        'SELECT subscriber_id FROM users WHERE id = ' . $database->quote($owner['id'])
    )->fetchColumn();
    if ($subscriberId === '') {
        $subscriberId = Uuid::v4();
        $personId = Uuid::v4();
        $database->prepare(
            'INSERT INTO persons (id, first_name, last_name) VALUES (?, ?, ?)'
        )->execute([$personId, 'Peter', 'Owner']);
        $database->prepare(
            'INSERT INTO subscribers (id, person_id, membership_number, first_name, last_name, phone)
             VALUES (?, ?, ?, ?, ?, ?)'
        )->execute([$subscriberId, $personId, 'MEM-PV-TEST-0001', 'Peter', 'Owner', '+243000002222']);
        $database->prepare('UPDATE users SET subscriber_id = :subscriber, person_id = :person WHERE id = :id')
            ->execute(['subscriber' => $subscriberId, 'person' => $personId, 'id' => $owner['id']]);
        $ownerSession = $session($owner);
    }

    $database->prepare(
        'INSERT INTO vehicles (id, vehicle_type, registration_number, country_of_registration, make, model, year)
         VALUES (?, ?, ?, ?, ?, ?, ?)'
    )->execute([$vehicleId, 'PRIVATE_CAR', 'PV-TEST-001', 'CD', 'Toyota', 'Corolla', 2022]);

    // The intruder gets a real membership too, so the ownership rule is what is
    // under test rather than a missing membership.
    $intruderSubscriberId = Uuid::v4();
    $intruderPersonId = Uuid::v4();
    $database->prepare('INSERT INTO persons (id, first_name, last_name) VALUES (?, ?, ?)')
        ->execute([$intruderPersonId, 'Ivan', 'Other']);
    $database->prepare(
        'INSERT INTO subscribers (id, person_id, membership_number, first_name, last_name)
         VALUES (?, ?, ?, ?, ?)'
    )->execute([$intruderSubscriberId, $intruderPersonId, 'MEM-PV-TEST-0002', 'Ivan', 'Other']);
    $database->prepare('UPDATE users SET subscriber_id = :subscriber, person_id = :person WHERE id = :id')
        ->execute(['subscriber' => $intruderSubscriberId, 'person' => $intruderPersonId, 'id' => $intruder['id']]);
    $intruderSession = $session($intruder);

    // ---- Enrol ------------------------------------------------------------
    $enrolled = $service->enrol(['vehicleId' => $vehicleId], $ownerSession, $request);
    $enrolmentId = (string) $enrolled['id'];
    $assert($enrolled['subscriptionStatus'] === 'PENDING', 'a new enrolment starts PENDING');
    $assert($enrolled['rescueCoverage']['covered'] === false, 'a pending enrolment is not covered');
    $assert($enrolled['trackingStatus'] === 'NO_DEVICE', 'no device means NO_DEVICE, not a false ONLINE');
    $assert($enrolled['position']['status'] === 'NO_POSITION', 'a vehicle with no position says NO_POSITION');
    $assert(count($enrolled['drivers']) === 1, 'the owner is recorded as the primary driver');

    $expectRejection(
        static fn () => $service->enrol(['vehicleId' => $vehicleId], $intruderSession, $request),
        403,
        'a different subscriber cannot enrol somebody else vehicle'
    );
    $expectRejection(
        static fn () => $service->enrol(['vehicleId' => $vehicleId], $ownerSession, $request),
        409,
        'the same vehicle cannot be enrolled twice'
    );

    // ---- Activate ---------------------------------------------------------
    $activated = $service->activate([
        'privateVehicleId' => $enrolmentId,
        'expiresAt' => gmdate('Y-m-d H:i:s', time() + 86400 * 30),
    ], $ownerSession, $request);
    $assert($activated['subscriptionStatus'] === 'ACTIVE', 'activation moves the enrolment to ACTIVE');
    $assert($activated['rescueCoverage']['covered'] === true, 'the shared coverage engine grants the cover');
    $assert($activated['rescueCoverage']['plan']['code'] === 'PRIVATE-ROAD-ASSIST', 'coverage names the private vehicle plan');
    $assert($activated['trackedAssetId'] !== null, 'the vehicle joins the shared tracking core');

    $asset = $database->query(
        'SELECT domain, asset_type FROM tracked_assets WHERE id = ' . $database->quote((string) $activated['trackedAssetId'])
    )->fetch();
    $assert($asset['domain'] === 'PRIVATE_VEHICLE', 'the tracked asset is typed for this domain');
    $assert($asset['asset_type'] === 'PRIVATE_VEHICLE', 'the asset type is canonical, not a private label');

    // ---- Authorized driver ------------------------------------------------
    $driverPersonId = (string) $database->query('SELECT person_id FROM subscribers WHERE id = ' . $database->quote($subscriberId))->fetchColumn();
    $spouseId = Uuid::v4();
    $database->prepare('INSERT INTO persons (id, first_name, last_name) VALUES (?, ?, ?)')->execute([$spouseId, 'Sara', 'Owner']);
    $authorized = $service->authorizeDriver([
        'privateVehicleId' => $enrolmentId, 'personId' => $spouseId, 'relationship' => 'SPOUSE',
    ], $ownerSession, $request);
    $assert(count($authorized['drivers']) === 2, 'a second driver is authorized');
    $assert($authorized['drivers'][0]['isPrimary'] === true, 'the primary driver is kept first');
    $assert($authorized['drivers'][1]['relationship'] === 'SPOUSE', 'the relationship is recorded');

    // ---- Protected journey ------------------------------------------------
    $journey = $service->startJourney([
        'privateVehicleId' => $enrolmentId,
        'originText' => 'Lubumbashi',
        'destinationText' => 'Kolwezi',
        'passengerCount' => 2,
        'passengers' => [['personId' => $spouseId, 'relationship' => 'SPOUSE', 'rescueCovered' => true]],
    ], $ownerSession, $request);
    $assert($journey['status'] === 'ACTIVE', 'a protected journey starts ACTIVE');
    $assert($journey['passengerCount'] === 2, 'the journey records its passenger count');
    $assert(count($journey['passengers']) === 1, 'recorded occupants are listed');
    $assert($journey['rescueCoverage']['covered'] === true, 'the journey carries the coverage state');
    $expectRejection(
        static fn () => $service->startJourney(['privateVehicleId' => $enrolmentId, 'destinationText' => 'Kasumbalesa'], $ownerSession, $request),
        409,
        'a vehicle cannot have two open journeys at once'
    );

    // A device reports a position, so the emergency carries real context.
    $deviceToken = 'tok_' . bin2hex(random_bytes(8));
    $deviceUid = 'PV-DEV-' . strtoupper(bin2hex(random_bytes(3)));
    $device = $ingest->registerDevice([
        'deviceUid' => $deviceUid, 'deviceToken' => $deviceToken,
        'trackedAssetId' => (string) $activated['trackedAssetId'],
    ], $adminSession);
    $ingest->ingest([
        'deviceUid' => $deviceUid, 'deviceToken' => $deviceToken,
        'latitude' => -10.7167, 'longitude' => 25.4667, 'speedKph' => 0, 'ignitionStatus' => 'ON',
    ], $request);
    $assert(
        $service->show($enrolmentId, $ownerSession)['trackingStatus'] === 'ONLINE',
        'tracking state is derived at read time, so a fresh position shows immediately'
    );

    // ---- Emergency request ------------------------------------------------
    $expectRejection(
        static fn () => $service->requestHelp([
            'privateVehicleId' => $enrolmentId, 'description' => 'I am stuck on the highway.',
        ], $ownerSession, $request),
        422,
        'an emergency must be confirmed before it is sent'
    );
    $expectRejection(
        static fn () => $service->requestHelp([
            'privateVehicleId' => $enrolmentId, 'description' => 'x', 'confirmed' => true,
        ], $intruderSession, $request),
        403,
        'a subscriber cannot raise an emergency for somebody else vehicle'
    );

    $help = $service->requestHelp([
        'privateVehicleId' => $enrolmentId,
        'description' => 'I am stuck on the highway and the car will not start.',
        'confirmed' => true,
        'province' => 'HAUT_KATANGA',
    ], $ownerSession, $request);
    $assert($help['status'] === 'REPORTED', 'the emergency reaches the Control Center as a reported incident');
    $assert($help['dispatchStatus'] === 'PENDING_DISPATCH', 'the caller is told the response is pending, not that help has arrived');
    $assert($help['position']['status'] === 'ONLINE', 'the incident context carries the live position');
    $assert(abs((float) $help['position']['latitude'] + 10.7167) < 0.001, 'the latitude is the real last known position');
    $assert($help['vehicle']['registrationNumber'] === 'PV-TEST-001', 'the incident identifies the vehicle');
    $assert($help['coverage']['covered'] === true, 'the incident reports the real coverage state');
    $assert($help['journeyId'] === $journey['id'], 'the incident is linked to the open journey');

    $incident = $database->query(
        'SELECT * FROM rescue_incidents WHERE id = ' . $database->quote((string) $help['incidentId'])
    )->fetch();
    $assert($incident['domain'] === 'PRIVATE_VEHICLE', 'the incident is classified for its domain');
    $assert($incident['vehicle_id'] === $vehicleId, 'the incident carries the canonical vehicle');
    $assert($incident['tracked_asset_id'] === $activated['trackedAssetId'], 'the incident carries the tracked asset');
    $assert($incident['subscriber_id'] === $subscriberId, 'the incident carries the subscriber');
    $assert((int) $incident['passenger_count'] === 2, 'the incident carries the passenger count automatically');
    $assert($incident['source_latitude'] !== null, 'the incident records the source position automatically');
    $assert($incident['journey_id'] === $journey['id'], 'the incident is linked to the journey');

    $journeyAfter = $service->journey($journey['id'], $ownerSession);
    $assert($journeyAfter['status'] === 'INCIDENT', 'the open journey moves to INCIDENT when help is requested');

    $alert = $database->query(
        "SELECT * FROM tracking_alerts WHERE incident_id = " . $database->quote((string) $help['incidentId'])
    )->fetch();
    $assert(is_array($alert) && $alert['alert_code'] === 'EMERGENCY_REQUEST', 'an emergency alert is raised for the Control Center');
    $assert($alert['severity'] === 'CRITICAL', 'a private emergency is critical by configuration, not by the caller');

    // ---- Closing the journey ----------------------------------------------
    $closed = $service->transitionJourney(['journeyId' => $journey['id'], 'status' => 'ARRIVED'], $ownerSession, $request);
    $assert($closed['status'] === 'ARRIVED', 'the journey can be closed out');
    $expectRejection(
        static fn () => $service->transitionJourney(['journeyId' => $journey['id'], 'status' => 'PLANNED'], $ownerSession, $request),
        409,
        'a journey cannot be reopened after arrival'
    );

    // ---- Dashboard ----------------------------------------------------------
    $result = $service->dashboard($ownerSession);
    $assert($result['metrics']['vehicles'] >= 1, 'the subscriber dashboard lists their vehicle');
    $assert($result['metrics']['covered'] >= 1, 'the dashboard counts covered vehicles');
    $assert($result['metrics']['activeIncidents'] >= 1, 'the dashboard counts the open incident');
    $assert($result['message'] === null, 'a subscriber with vehicles gets no empty-state message');

    $empty = $service->dashboard($intruderSession);
    $assert($empty['metrics']['vehicles'] === 0, 'another subscriber sees no vehicles');
    $assert($empty['message'] === 'No data available.', 'an empty customer dashboard says so');

    $audits = (new AuditLog($database))->list(['action' => 'PRIVATE_EMERGENCY_REQUESTED', 'limit' => 5]);
    $assert($audits !== [], 'an emergency request is audited');
} finally {
    if (is_string($enrolmentId) && $enrolmentId !== '') {
        $database->exec('DELETE FROM rescue_incident_events WHERE incident_id IN (SELECT id FROM rescue_incidents WHERE vehicle_id = ' . $database->quote($vehicleId) . ')');
        $database->exec('DELETE FROM tracking_alerts WHERE incident_id IN (SELECT id FROM rescue_incidents WHERE vehicle_id = ' . $database->quote($vehicleId) . ')');
        $database->exec('DELETE FROM rescue_incidents WHERE vehicle_id = ' . $database->quote($vehicleId));
        $database->exec('DELETE FROM rescue_coverage_links WHERE vehicle_id = ' . $database->quote($vehicleId));
        $database->exec('DELETE FROM location_history WHERE tracked_asset_id IN (SELECT id FROM tracked_assets WHERE vehicle_id = ' . $database->quote($vehicleId) . ')');
        $database->exec('DELETE FROM tracked_asset_positions WHERE tracked_asset_id IN (SELECT id FROM tracked_assets WHERE vehicle_id = ' . $database->quote($vehicleId) . ')');
        $database->exec('DELETE FROM private_vehicles WHERE id = ' . $database->quote($enrolmentId));
        $database->exec('DELETE FROM tracked_assets WHERE vehicle_id = ' . $database->quote($vehicleId));
        $database->exec('DELETE FROM vehicles WHERE id = ' . $database->quote($vehicleId));
    }
    $database->exec("DELETE FROM tracking_devices WHERE device_uid LIKE 'PV-DEV-%'");
    $database->exec("DELETE FROM persons WHERE first_name = 'Sara'");
    $database->exec("DELETE FROM audit_logs WHERE entity_type IN ('PrivateVehicle', 'PrivateVehicleJourney', 'RescueCoverage', 'TrackedAsset', 'Incident')");
    $database->exec("DELETE FROM users WHERE first_name IN ('Pv', 'Peter', 'Ivan') AND email LIKE '%@mamore.test'");
    $database->exec("DELETE FROM subscribers WHERE membership_number IN ('MEM-PV-TEST-0001', 'MEM-PV-TEST-0002')");
}

if ($failures !== []) {
    fwrite(STDERR, count($failures) . " assertion(s) failed.\n");
    exit(1);
}
