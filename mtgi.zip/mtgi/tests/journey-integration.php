<?php

declare(strict_types=1);

/**
 * Journey safety status (I), Control Center live trips (J), active journey
 * context (K) and incident-from-trip (W).
 *
 * The point of these assertions is that nothing is invented: GPS comes from the
 * existing tracking asset, nearest assets from a real distance query, manifest
 * counts from the bookings, and every unknown state reports UNKNOWN/OFFLINE
 * rather than a reassuring default.
 */

use Mamore\Auth\AuthException;
use Mamore\Core\AuditLog;
use Mamore\Core\Database;
use Mamore\Core\Request;
use Mamore\SmartBus\JourneySafetyService;
use Mamore\SmartBus\ManifestService;
use Mamore\SmartBus\SmartBusIncidentService;
use Mamore\SmartBus\SmartBusService;
use Mamore\SmartBus\TicketSigner;

require dirname(__DIR__) . '/bootstrap.php';
require __DIR__ . '/support.php';

$database = Database::connection();
$bus = new SmartBusService($database);
$safety = new JourneySafetyService($database);
$incidents = new SmartBusIncidentService($database);
$manifest = new ManifestService($database);

$failures = [];
$assert = static function (bool $condition, string $message) use (&$failures): void {
    if ($condition) {
        fwrite(STDOUT, "PASS: {$message}\n");
        return;
    }
    $failures[] = $message;
    fwrite(STDERR, "FAIL: {$message}\n");
};
$expectRejection = static function (callable $operation, int $status, string $message) use ($assert): void {
    try {
        $operation();
    } catch (AuthException $error) {
        $assert($error->status === $status, $message);
        return;
    }
    throw new RuntimeException("Expected rejection failed: {$message}");
};

$request = new Request('POST', '/api/smart-bus/incidents', [], [], '198.51.100.44', 'MamoreJourneyTest/1.0');
$tripIds = [];
$assetId = null;

try {
    $admin = test_actor('SYSTEM_ADMIN', ['firstName' => 'Journey', 'lastName' => 'Admin']);
    $dispatcher = test_actor('HQ_DISPATCHER', ['firstName' => 'J', 'lastName' => 'Dispatcher']);
    $customer = test_actor('CUSTOMER', ['password' => 'JourneyTest!2026', 'firstName' => 'Rider', 'lastName' => 'Passenger']);
    $customerSession = $database->prepare('SELECT * FROM users WHERE id = :id');
    $customerSession->execute(['id' => $customer['id']]);
    $customerRow = $customerSession->fetch();

    $board = $bus->board();
    $vehicle = $board['vehicles'][0];

    // A vehicle with a live tracking asset, the integration point for GPS.
    $database->prepare('UPDATE smartbus_vehicles SET verification_status = :status, gps_enabled = 1 WHERE id = :id')
        ->execute(['status' => 'VERIFIED', 'id' => $vehicle['id']]);
    $asset = $database->prepare("SELECT * FROM tracking_assets WHERE asset_type = 'SMARTBUS_VEHICLE' AND reference_id = :id");
    $asset->execute(['id' => $vehicle['id']]);
    $assetRow = $asset->fetch();
    $assert(is_array($assetRow), 'the vehicle already has a tracking asset to derive GPS from');
    $assetId = (string) $assetRow['id'];

    $trip = $bus->schedule([
        'routeId' => $board['routes'][0]['id'],
        'vehicleId' => $vehicle['id'],
        'departureAt' => (new DateTimeImmutable('+1 day'))->setTime(8, 0)->format('Y-m-d H:i:s'),
        'usdCdfRate' => 2850,
    ], $admin);
    $tripIds[] = $trip['id'];

    $booking = $bus->book([
        'tripId' => $trip['id'], 'passengerName' => 'Rider Passenger',
        'passengerPhone' => '+243000000999', 'seatNumber' => 3,
    ], $admin);
    $database->prepare('UPDATE smartbus_bookings SET user_id = :user, vip_at_booking = 1 WHERE id = :id')
        ->execute(['user' => $customer['id'], 'id' => $booking['id']]);

    // ---- Safety before any GPS exists ------------------------------------
    $status = $safety->tripSafety($trip['id'], $admin);
    $assert($status['gps']['status'] === 'OFFLINE', 'a trip with no position reports OFFLINE, not a guess');
    $assert($status['nearest']['basis'] === 'NO_POSITION', 'nearest assets are unknown without a position');
    $assert($status['nearest']['hospital']['status'] === 'UNKNOWN', 'the nearest hospital is UNKNOWN with no position');
    $assert($status['status'] !== 'NORMAL', 'a trip with no GPS is never reported as fully NORMAL');
    $assert(in_array($status['status'], ['DEGRADED', 'WARNING', 'CRITICAL', 'UNKNOWN'], true), 'the overall level is a real value');

    // ---- A live position makes the real facts available --------------------
    $database->prepare(
        'INSERT INTO tracking_positions (asset_id, latitude, longitude, speed_kph, heading_degrees, recorded_at)
         VALUES (:asset, -11.6647, 27.4794, 62.5, 180, UTC_TIMESTAMP(6))'
    )->execute(['asset' => $assetId]);

    $live = $safety->tripSafety($trip['id'], $admin);
    $assert($live['gps']['status'] === 'ONLINE', 'a fresh position reports ONLINE');
    $assert(abs((float) $live['gps']['latitude'] + 11.6647) < 0.001, 'the latitude comes from the tracking record');
    $assert($live['gps']['speedKph'] === 62.5, 'the speed comes from the tracking record');
    $assert($live['nearest']['basis'] === 'LIVE_POSITION', 'nearest assets are computed from the live position');
    $assert($live['components']['bus'] === 'VERIFIED', 'a verified vehicle reports VERIFIED');
    $assert($live['components']['driver'] === 'UNKNOWN', 'an unassigned driver reports UNKNOWN, never "fine"');
    $assert($live['components']['manifest'] === 'SYNCED', 'the manifest component reports synced once passengers exist');
    $assert($live['components']['rescueCoverage'] === 'ACTIVE', 'rescue coverage is active for a covered trip');
    $assert($live['manifest']['total'] === 1 && $live['manifest']['vip'] === 1, 'manifest and VIP counts are real');
    $assert($live['nearest']['rescueUnit']['status'] === 'AVAILABLE', 'an available rescue unit is found within range');
    $assert(is_float($live['nearest']['rescueUnit']['distanceKm']), 'the nearest unit reports a real distance');
    $assert(isset($live['components']['routeStatus']), 'the route status is reported');
    $assert(!in_array($live['status'], ['OFFLINE'], true) || $live['gps']['status'] === 'OFFLINE', 'a level is only OFFLINE when GPS is');

    // ---- Boarding opens the passenger journey -----------------------------
    $database->prepare(
        "INSERT INTO finance_transactions (id, receipt_number, smartbus_booking_id, transaction_type, payment_method,
            currency, amount, usd_cdf_rate, amount_cdf, expected_cdf, variance_cdf, status, received_by_user_id)
         VALUES (:id, :receipt, :booking, 'SMARTBUS_PAYMENT', 'CASH', 'CDF', :amount, 2850, :cdf, :expected, 0, 'RECONCILED', :actor)"
    )->execute([
        'id' => \Mamore\Core\Uuid::v4(), 'receipt' => 'TX-J-1', 'booking' => $booking['id'],
        'amount' => $booking['totalCdf'], 'cdf' => $booking['totalCdf'], 'expected' => $booking['totalCdf'],
        'actor' => $admin['id'],
    ]);
    $manifest->checkIn(['tripId' => $trip['id'], 'bookingReference' => $booking['reference']], $admin, $request);
    $manifest->board(['bookingId' => $booking['id'], 'action' => 'BOARD'], $admin, $request);

    $passengerView = $safety->forPassenger($customerRow);
    $assert($passengerView['active'] === true, 'the passenger sees an active journey');
    $assert($passengerView['tripCode'] === $trip['code'], 'the passenger journey names the trip');
    $assert($passengerView['gps']['status'] === 'ONLINE', 'the passenger sees the live position of their bus');

    $noJourney = $safety->forPassenger($admin);
    $assert($noJourney['active'] === false, 'a staff account has no passenger journey');

    // ---- Control Center live trips ---------------------------------------
    $boardView = $safety->liveTrips($dispatcher);
    $found = null;
    foreach ($boardView as $entry) {
        if ($entry['tripId'] === $trip['id']) {
            $found = $entry;
        }
    }
    $assert(is_array($found), 'an active Smart Bus trip appears on the Control Center board');
    $assert($found['passengers'] === 1 && $found['boarded'] === 1, 'the board shows live passenger and boarding counts');
    $assert($found['vipPassengers'] === 1, 'the board counts VIP passengers');
    $assert($found['rescueCoverage'] === 'ACTIVE', 'the board shows rescue coverage');
    $assert($found['gpsStatus'] === 'ONLINE', 'the board shows GPS status');
    $assert(isset($found['nearest']['rescueUnit']), 'the board offers nearest response assets');
    $assert(count((new AuditLog($database))->list(['entityType' => 'SmartBus', 'action' => 'CONTROL_CENTER_LIVE_TRIPS_VIEWED', 'limit' => 5])) >= 1, 'viewing the board is audited');

    // ---- Incident from an active bus -------------------------------------
    $created = $incidents->create([
        'tripId' => $trip['id'],
        'description' => 'Passenger collapsed in aisle 3 during the journey.',
        'priority' => 'CRITICAL',
    ], $admin, $request);
    $assert($created['incident']['status'] === 'REPORTED', 'the incident is reported through the existing rescue flow');
    $assert($created['context']['passengers'] === 1 && $created['context']['vipPassengers'] === 1, 'the incident response echoes the trip context');
    $assert($created['context']['gps']['status'] === 'ONLINE', 'the incident context carries the live position');

    $stored = $database->prepare(
        'SELECT smartbus_trip_id, smartbus_vehicle_id, smartbus_operator_id, passenger_count, vip_passenger_count, source_latitude
         FROM rescue_incidents WHERE id = :id'
    );
    $stored->execute(['id' => $created['incident']['id']]);
    $row = $stored->fetch();
    $assert($row['smartbus_trip_id'] === $trip['id'], 'the incident is linked to the trip');
    $assert($row['smartbus_vehicle_id'] !== null, 'the incident is linked to the bus');
    $assert($row['smartbus_operator_id'] !== null, 'the incident is linked to the operator');
    $assert((int) $row['passenger_count'] === 1, 'the incident records the passenger count automatically');
    $assert($row['source_latitude'] !== null, 'the incident records the source position automatically');

    $linked = $incidents->forTrip($trip['id']);
    $assert(count($linked) === 1 && $linked[0]['incidentCode'] === $created['incident']['code'], 'the trip shows its incidents');
    $assert($safety->tripSafety($trip['id'], $admin)['incidentCount'] === 1, 'the safety status counts the incident');

    $expectRejection(
        static fn () => $incidents->create(['tripId' => $trip['id'], 'priority' => 'HIGH'], $admin, $request),
        422,
        'an incident without a description is refused'
    );
    $expectRejection(
        static fn () => $incidents->create(['tripId' => $trip['id'], 'description' => 'x', 'priority' => 'NOPE'], $admin, $request),
        422,
        'an incident with an invalid priority is refused'
    );
    $second = $incidents->create([
        'tripId' => $trip['id'],
        'description' => 'Minor coolant leak reported by the driver.',
        'priority' => 'LOW',
    ], $admin, $request);
    $assert(
        $second['incident']['id'] !== $created['incident']['id'],
        'a trip can carry more than one incident'
    );
    $assert(count($incidents->forTrip($trip['id'])) === 2, 'the trip lists both incidents');
    $assert(
        $safety->tripSafety($trip['id'], $admin)['incidentCount'] === 2,
        'the safety status counts every incident on the trip'
    );
} finally {
    foreach ($tripIds as $tripId) {
        $database->prepare('DELETE FROM rescue_incident_events WHERE incident_id IN (SELECT id FROM rescue_incidents WHERE smartbus_trip_id = :t)')->execute(['t' => $tripId]);
        $database->prepare('DELETE FROM rescue_incidents WHERE smartbus_trip_id = :t')->execute(['t' => $tripId]);
        $database->prepare('DELETE FROM active_journeys WHERE trip_id = :t')->execute(['t' => $tripId]);
        $database->prepare('DELETE a FROM finance_allocations a JOIN finance_transactions f ON f.id = a.transaction_id WHERE f.smartbus_booking_id IN (SELECT id FROM smartbus_bookings WHERE trip_id = :t)')->execute(['t' => $tripId]);
        $database->prepare('DELETE FROM finance_transactions WHERE smartbus_booking_id IN (SELECT id FROM smartbus_bookings WHERE trip_id = :t)')->execute(['t' => $tripId]);
        $database->prepare('DELETE FROM audit_logs WHERE entity_id IN (SELECT id FROM smartbus_bookings WHERE trip_id = :t)')->execute(['t' => $tripId]);
        $database->prepare('DELETE FROM smartbus_bookings WHERE trip_id = :t')->execute(['t' => $tripId]);
        $database->prepare('DELETE FROM smartbus_trips WHERE id = :t')->execute(['t' => $tripId]);
    }
    if (is_string($assetId) && $assetId !== '') {
        $database->prepare('DELETE FROM tracking_positions WHERE asset_id = :a')->execute(['a' => $assetId]);
    }
    $database->exec("DELETE FROM audit_logs WHERE action IN ('SMARTBUS_INCIDENT_CREATED','CONTROL_CENTER_LIVE_TRIPS_VIEWED')");
    $database->exec("DELETE FROM users WHERE first_name IN ('Journey','J','Rider') AND email LIKE '%@mamore.test'");
}

if ($failures !== []) {
    fwrite(STDERR, count($failures) . " assertion(s) failed.\n");
    exit(1);
}
