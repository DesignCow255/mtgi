<?php

declare(strict_types=1);

use Mamore\Core\Database;
use Mamore\Dashboard\ExecutiveService;

require dirname(__DIR__) . '/bootstrap.php';

/*
 * Executive dashboard guard.
 *
 * The audit recorded two failures this test exists to prevent from coming back:
 *
 *  1. FABRICATION. The old overview answered "what is Mamore doing" with
 *     authentication telemetry, and the replacement must not fix that by
 *     inventing plausible numbers. So: every headline figure is re-derived from
 *     the database here and compared to what the service returned. If someone
 *     hard-codes a KPI, this fails.
 *
 *  2. THE SILENT ZERO. A failed query, a missing baseline and a genuine zero are
 *     three different facts. The service must return null/unavailable where it
 *     has no data and must never report a trend it could not compute.
 *
 * It also pins the response-time sample sizes, which is where a real bug was
 * found: AVG() ignores NULLs, so arrival times were being averaged over only
 * the incidents that had been dispatched.
 */

$database = Database::connection();
$failures = 0;
$assert = static function (bool $condition, string $message) use (&$failures): void {
    if ($condition) {
        fwrite(STDOUT, "PASS: {$message}\n");
        return;
    }
    $failures++;
    fwrite(STDERR, "FAIL: {$message}\n");
};

$service = new ExecutiveService($database);
$overview = $service->overview();

$assert(isset($overview['summary'], $overview['summaryBasis']), 'the overview carries a generated summary and its basis');
$assert(
    is_string($overview['summary']['sentence']) && trim($overview['summary']['sentence']) !== '',
    'the summary sentence is populated'
);
$assert(
    in_array($overview['summary']['state'], ['ok', 'attention', 'critical'], true),
    'the summary declares one of its three states'
);

/* -- 1. nothing is fabricated -------------------------------------------- */

$count = static fn (string $sql): int => (int) $database->query($sql)->fetchColumn();

$assert(
    $overview['summaryBasis']['trackedAssets'] === $count("SELECT COUNT(*) FROM tracked_assets WHERE status = 'ACTIVE'"),
    'tracked assets matches a direct count'
);
$assert(
    $overview['summaryBasis']['openIncidents'] === $count('SELECT COUNT(*) FROM rescue_incidents WHERE resolved_at IS NULL'),
    'open incidents matches a direct count'
);
// Priority, not severity. RescueService::report() writes `priority` on intake
// and never writes `severity`, so severity sits at its MEDIUM default for every
// row. The executive KPI originally counted on severity and was therefore
// structurally incapable of ever reporting a critical incident: it read 0
// while 5 were open, and the rescue board correctly showed 5.
$assert(
    $overview['summaryBasis']['criticalIncidents'] === $count(
        "SELECT COUNT(*) FROM rescue_incidents WHERE resolved_at IS NULL AND priority = 'CRITICAL'"
    ),
    'critical incidents matches a direct count on priority'
);

// The two screens must never disagree about how many critical incidents exist.
$rescueBoard = (new Mamore\Rescue\RescueService($database))->board();
$assert(
    $overview['summaryBasis']['criticalIncidents'] === $rescueBoard['metrics']['critical'],
    'the executive board and the rescue board agree on the critical incident count'
);

// A critical incident must escalate the summary, not sit in a warning tone.
$assert(
    $overview['summaryBasis']['criticalIncidents'] > 0
        ? $overview['summary']['state'] === 'critical'
        : $overview['summary']['state'] !== 'critical',
    'the summary escalates to critical only when a critical incident is actually open'
);

// The detail queue is ranked by priority. Ordering on the dead severity column
// made every incident tie and the queue was not ranked at all.
$ranks = ['critical' => 0, 'high' => 1, 'medium' => 2, 'low' => 3];
$lastRank = -1;
foreach ($overview['attention']['incidents']['rows'] ?? [] as $row) {
    $rank = $ranks[$row['severity']] ?? 99;
    $assert($rank >= $lastRank, 'the incident detail queue is ordered by priority');
    $lastRank = $rank;
}
$assert(
    $overview['summaryBasis']['gpsOffline'] === $count("SELECT COUNT(*) FROM tracked_assets WHERE tracking_status = 'OFFLINE'"),
    'offline devices matches a direct count'
);

$kpis = [];
foreach ($overview['kpis'] as $kpi) {
    $kpis[$kpi['key']] = $kpi;
}

$assert(isset($kpis['trackedAssets']), 'a tracked-asset KPI is present');
$assert(
    $kpis['trackedAssets']['value'] === $count("SELECT COUNT(*) FROM tracked_assets WHERE status = 'ACTIVE'"),
    'the tracked-asset KPI value is a real count, not a placeholder'
);
$assert(
    $kpis['revenue']['value'] === $overview['revenue']['collectedToday'],
    'the revenue KPI and the revenue block agree'
);
$assert(
    isset($kpis['revenue']['currency']) && $kpis['revenue']['currency'] !== '',
    'the revenue KPI names its source currency rather than assuming one'
);

/* -- 2. no silent zeros --------------------------------------------------- */

$assert(
    $kpis['revenue']['value'] === $overview['revenue']['collectedToday'],
    'revenue is never silently nulled'
);

foreach ($overview['kpis'] as $kpi) {
    $assert(isset($kpi['state']), "the {$kpi['key']} KPI declares a state");
    $assert(
        array_key_exists('comparison', $kpi),
        "the {$kpi['key']} KPI states whether a comparison exists"
    );
}

// A comparison is either null or carries a real delta over a stated baseline.
// A comparison of 0 with no previous value would be a fabricated trend.
foreach ($overview['kpis'] as $kpi) {
    $comparison = $kpi['comparison'] ?? null;
    if ($comparison === null) {
        continue;
    }
    $assert(
        is_numeric($comparison['value']) && ($comparison['previous'] ?? 0) > 0,
        "the {$kpi['key']} comparison is computed from a non-zero baseline"
    );
    $assert(
        isset($comparison['label']) && trim((string) $comparison['label']) !== '',
        "the {$kpi['key']} comparison names its period"
    );
}

/* -- 3. response times keep their sample sizes ---------------------------- */

$response = $overview['response'];

$assert(
    $response['incidents'] === $count(
        'SELECT COUNT(*) FROM rescue_incidents WHERE reported_at >= DATE_SUB(UTC_DATE(), INTERVAL 30 DAY)'
    ),
    'the response window counts its own incidents'
);

foreach (['avgDispatchMinutes' => 'dispatched', 'avgArriveMinutes' => 'arrived'] as $metric => $sample) {
    if ($response[$metric] === null) {
        $assert(
            $response[$sample] === 0,
            "a null {$metric} corresponds to zero samples, not to a missing one"
        );
        continue;
    }
    $assert(
        $response[$sample] > 0,
        "a reported {$metric} declares how many incidents it was measured from"
    );
}

$assert(
    $response['arrived'] <= $response['dispatched'],
    'arrival samples cannot exceed dispatch samples'
);

/* -- 4. the Action Center is actionable and ranked ------------------------ */

$order = ['critical' => 0, 'high' => 1, 'medium' => 2, 'low' => 3];
$previousRank = -1;

foreach ($overview['actionCenter'] as $row) {
    $assert(($row['count'] ?? 0) > 0, "the {$row['key']} action row reports a real count above zero");
    $assert(
        ($row['panel'] ?? '') !== '',
        "the {$row['key']} action row names the workflow it opens"
    );
    $assert(
        isset($order[$row['severity']]),
        "the {$row['key']} action row uses a known severity"
    );
    $rank = $order[$row['severity']];
    $assert($rank >= $previousRank, "action rows are ordered by severity, {$row['key']} is out of order");
    $previousRank = $rank;
}

// Nothing in the Action Center may contradict the basis it was built from.
$assert(
    count(array_filter($overview['actionCenter'], static fn (array $r): bool => $r['key'] === 'criticalIncidents')) <= 1,
    'critical incidents appear at most once in the Action Center'
);

/* -- 5. the pulse reports unknown rather than guessing -------------------- */

$pulse = [];
foreach ($overview['pulse'] as $row) {
    $pulse[$row['key']] = $row;
}

$assert(isset($pulse['response']), 'the pulse includes a response row');
$assert(
    ($pulse['response']['state'] ?? '') === 'unknown'
        || is_numeric($pulse['response']['measurement'] ?? null),
    'the response pulse is either unknown or a real measurement'
);
$assert(
    ($pulse['response']['measurement'] ?? null) === $response['avgDispatchMinutes'],
    'the response pulse reports the same number as the response block'
);

if ($response['avgDispatchMinutes'] === null) {
    $assert(
        $pulse['response']['state'] === 'unknown',
        'with no incidents the response pulse says unknown instead of showing a time'
    );
}

/* -- 6. the trend is real, and empty days are real zeros ----------------- */

$trend = $overview['trend'];
$dates = $trend['dates'];
$days = count($dates);

$assert($days > 1, 'the trend declares a date spine');
$assert(
    $dates === array_values(array_unique($dates)) && $dates === array_values($dates),
    'the trend spine is ordered and free of duplicates'
);
$assert(
    $dates[array_key_last($dates)] === gmdate('Y-m-d'),
    'the trend spine ends today rather than lagging behind'
);

foreach ($trend['series'] as $series) {
    $assert(
        count($series['values']) === $days,
        "the {$series['key']} series has one value per declared date"
    );
    $assert(
        count(array_filter($series['values'], static fn ($v): bool => !is_int($v) && !ctype_digit((string) $v))) === 0,
        "the {$series['key']} series is entirely numeric"
    );
}

// The point of the whole layer: a day with no activity is a ZERO in the
// series, not a missing entry. If the series were sparse, a quiet fortnight
// would rescale into a spike when drawn.
$total = 0;
foreach ($trend['series'] as $series) {
    $total += array_sum($series['values']);
}
$assert(
    $trend['hasHistory'] === ($total > 0),
    'hasHistory agrees with whether the series actually contains events'
);
$assert(
    $trend['totalEvents'] === $total,
    'the declared event total equals the sum of the plotted series'
);

/* -- 8. the rescue queue is actually triage-ordered ---------------------- */

// An emergency board exists to answer "what is worst and still open". This
// pins the ordering, because two plausible-looking orderings were both wrong:
//
//   (status, priority) -- a LOW reported incident outranks a CRITICAL that
//                         already has a unit on the way
//   (priority, status) -- a RESOLVED critical outranks an open LOW, so the top
//                         of the board is closed work
//
// The correct key is open-vs-closed, then severity, then progress.
$board = (new Mamore\Rescue\RescueService($database))->board();
$incidents = $board['incidents'];

$assert($incidents !== [], 'the rescue board returns incidents to order');

$closedSeen = false;
$previousRank = -1;
$ranks = ['CRITICAL' => 0, 'HIGH' => 1, 'MEDIUM' => 2, 'LOW' => 3];

foreach ($incidents as $incident) {
    $isClosed = in_array($incident['status'], ['RESOLVED', 'CANCELLED'], true);

    if ($closedSeen && !$isClosed) {
        $assert(false, 'no open incident appears after a closed one in the queue');
        break;
    }
    if ($isClosed) {
        $closedSeen = true;
    }
    // Severity must not go backwards within the open band.
    if (!$isClosed) {
        $rank = $ranks[$incident['priority']] ?? 99;
        if ($rank < $previousRank) {
            $assert(false, 'the open queue is not ranked by severity');
            break;
        }
        $previousRank = max($previousRank, $rank);
    }
}

$assert(
    !str_contains(
        (string) file_get_contents($root ?? dirname(__DIR__) . '/app/Rescue/RescueService.php'),
        "FIELD(i.status IN ("
    ),
    'the queue does not use FIELD() on a boolean, which returns a constant index'
);

/* -- 7. detail rows cannot exceed their count ---------------------------- */

foreach ($overview['attention'] as $group => $data) {
    $assert(
        $data['shown'] === count($data['rows']),
        "the {$group} detail list reports the same number of rows as it returns"
    );
    $assert(
        $data['shown'] <= $data['count'],
        "the {$group} detail list never shows more rows than the count it claims"
    );
    $assert(
        $data['shown'] <= 8,
        "the {$group} detail list is capped, so a dashboard is not a report"
    );

    foreach ($data['rows'] as $row) {
        $assert(($row['id'] ?? '') !== '', "each {$group} row carries an id for drilldown");
        $assert(($row['reference'] ?? '') !== '', "each {$group} row carries a human reference");
        $assert(
            !isset($row['amount']) || ($row['currency'] ?? '') !== '',
            'a monetary detail row declares the currency its amount is stored in'
        );
    }
}

fwrite(STDOUT, $failures === 0 ? "\nPASS: executive dashboard contract holds\n" : "\nFAILURES: {$failures}\n");
exit($failures === 0 ? 0 : 1);
