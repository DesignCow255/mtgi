<?php

declare(strict_types=1);

/**
 * Fee catalog parity: the seeded `rescue_products` / `rescue_product_rules`
 * rows must be byte-for-byte equivalent to FeeEngine::catalog().
 *
 * Money is never invented in SQL, and the engine is never allowed to drift
 * from what the database charges: whichever side changes first, this test
 * fails until both agree.
 */

use Mamore\Core\Database;
use Mamore\Support\FeeEngine;

require dirname(__DIR__) . '/bootstrap.php';
require __DIR__ . '/support.php';

$database = Database::connection();

$products = [];
foreach ($database->query('SELECT * FROM rescue_products ORDER BY code')->fetchAll() as $row) {
    $products[$row['code']] = $row;
}

foreach (FeeEngine::catalog() as $code => $product) {
    if (!isset($products[$code])) {
        test_fail("product {$code} is missing from rescue_products; run php bin/migrate.php");
    }

    $row = $products[$code];
    $checks = [
        "{$code} total_fee matches engine" => bcadd((string) $row['total_fee'], '0', 2) === $product['totalFee'],
        "{$code} base_fee matches engine" => bcadd((string) $row['base_fee'], '0', 2) === $product['baseFee'],
        "{$code} billing_frequency matches engine" => $row['billing_frequency'] === $product['billingFrequency'],
        "{$code} product_type matches engine" => $row['product_type'] === $product['productType'],
        "{$code} vehicle_type matches engine" => $row['vehicle_type'] === $product['vehicleType'],
        "{$code} currency is {$product['currency']}" => $row['currency'] === $product['currency'],
        "{$code} applicable provinces match engine" => json_decode((string) $row['applicable_provinces'], true) === $product['provinces'],
    ];

    foreach ($checks as $name => $passed) {
        if (!$passed) {
            test_fail($name);
        }
        fwrite(STDOUT, "PASS: {$name}\n");
    }

    $rules = [];
    $statement = $database->prepare('SELECT * FROM rescue_product_rules WHERE product_id = :product ORDER BY display_order');
    $statement->execute(['product' => $row['id']]);
    foreach ($statement->fetchAll() as $rule) {
        $rules[$rule['component_key']] = $rule;
    }

    $engineRules = FeeEngine::rules($code);
    if (count($rules) !== count($engineRules)) {
        test_fail("{$code} rule count is " . count($rules) . ', engine declares ' . count($engineRules));
    }

    foreach ($engineRules as $rule) {
        $key = $rule['key'];
        if (!isset($rules[$key])) {
            test_fail("{$code} rule {$key} is missing from rescue_product_rules");
        }

        $stored = $rules[$key];
        $ruleChecks = [
            "{$code}.{$key} amount matches engine" => bcadd((string) $stored['amount'], '0', 2) === $rule['amount'],
            "{$code}.{$key} allocation_role matches engine" => $stored['allocation_role'] === $rule['role'],
            "{$code}.{$key} ledger_account matches engine" => $stored['ledger_account'] === $rule['ledgerAccount'],
            "{$code}.{$key} category matches engine" => $stored['category'] === $rule['category'],
            "{$code}.{$key} component_type matches engine" => $stored['component_type'] === $rule['componentType'],
            "{$code}.{$key} taxable flag matches engine" => (bool) $stored['is_taxable'] === $rule['isTaxable'],
            "{$code}.{$key} province matches engine" => ($stored['province'] ?: null) === $rule['province'],
        ];

        foreach ($ruleChecks as $name => $passed) {
            if (!$passed) {
                test_fail($name);
            }
        }
    }
    fwrite(STDOUT, "PASS: {$code} rules match the engine (" . count($engineRules) . " lines)\n");

    $chargeable = FeeEngine::total(FeeEngine::chargeableBreakdown($code));
    if ($chargeable !== $product['totalFee']) {
        test_fail("{$code} chargeable lines sum to {$chargeable}, expected {$product['totalFee']}");
    }
    fwrite(STDOUT, "PASS: {$code} chargeable lines reconcile to {$product['totalFee']}\n");

    $subsets = FeeEngine::subsetTotal($code);
    $taxable = FeeEngine::taxableContainer($code);
    if ($subsets !== $taxable) {
        test_fail("{$code} subset lines sum to {$subsets}, taxable container is {$taxable}");
    }
    fwrite(STDOUT, "PASS: {$code} subset lines reconcile to the {$taxable} taxable container\n");
}

// Every ledger account referenced by the catalog must exist in revenue_ledgers.
$ledgerAccount = $database->prepare('SELECT COUNT(*) FROM revenue_ledgers WHERE name = :name');
$referenced = [];
foreach (FeeEngine::catalog() as $code => $product) {
    foreach ($product['rules'] as $rule) {
        $referenced[$rule['ledgerAccount']] = true;
    }
}
foreach (array_keys($referenced) as $account) {
    $ledgerAccount->execute(['name' => $account]);
    if ((int) $ledgerAccount->fetchColumn() !== 1) {
        test_fail("ledger account {$account} is missing from revenue_ledgers");
    }
}
fwrite(STDOUT, 'PASS: all ' . count($referenced) . " catalog ledger accounts exist\n");
exit(0);
