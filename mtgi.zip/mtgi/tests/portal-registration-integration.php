<?php

declare(strict_types=1);

/**
 * Portal self-service auth: register -> verify -> sign in -> reset.
 *
 * Also pins the security behaviour that is easy to regress: the account stays
 * unusable until verified, wrong codes burn attempts and die at the cap, a
 * resend is blocked by the cooldown, forgot-password cannot be used to discover
 * which emails have accounts, and a reset revokes every existing session.
 */

use Mamore\Auth\AuthException;
use Mamore\Auth\AuthService;
use Mamore\Auth\OtpService;
use Mamore\Auth\PortalAuthService;
use Mamore\Core\Database;
use Mamore\Core\PasswordPolicy;
use Mamore\Core\Request;

require dirname(__DIR__) . '/bootstrap.php';
require __DIR__ . '/support.php';

$database = Database::connection();
$portal = new PortalAuthService($database);
$auth = new AuthService($database);
$otps = new OtpService($database);

$failures = [];
$assert = static function (bool $condition, string $message) use (&$failures): void {
    if ($condition) {
        fwrite(STDOUT, "PASS: {$message}\n");
        return;
    }
    $failures[] = $message;
    fwrite(STDERR, "FAIL: {$message}\n");
};
$expectRejection = static function (callable $operation, int $status, string $message) use ($assert): void {
    try {
        $operation();
    } catch (AuthException $error) {
        $assert($error->status === $status, $message);
        return;
    }
    throw new RuntimeException("Expected rejection failed: {$message}");
};
$uniquePhone = static fn (): string => '+243' . random_int(100000000, 999999999);
$uniqueEmail = static fn (): string => 'portal-' . bin2hex(random_bytes(5)) . '@mamore.test';
// The service throttles per IP, so every negative case arrives from its own
// "client": otherwise the rejection would be the throttle rather than the rule
// under test.
$call = 0;
$fromNewClient = static function () use (&$call): Request {
    $call++;

    return new Request('POST', '/api/auth/register-subscriber', [], [], '198.51.100.' . (10 + $call), 'MamorePortalTest/1.0');
};

$request = $fromNewClient();
$email = $uniqueEmail();
$phone = $uniquePhone();
$password = 'PortalSignUp!2026';

// This environment has no SMS/email gateway, so the flow is only completable
// end to end when the service is explicitly allowed to echo the code back.
putenv('OTP_DEBUG_CODES=1');

// Audit rows written before a session exists (registration, throttled resends,
// unknown-account resets) have a NULL actor on purpose, so cleanup cannot find
// them by actor. Track the id floor instead and remove exactly the rows this run
// appended. Captured before the try block: finally must not depend on the body
// having reached its first statement.
$auditFloor = (int) $database->query('SELECT COALESCE(MAX(id), 0) FROM audit_logs')->fetchColumn();

try {

    // ---- Password policy is one rule, shared -----------------------------
    $assert(PasswordPolicy::isStrong($password), 'the shared policy accepts a mixed 12+ character password');
    $expectRejection(static fn () => PasswordPolicy::assert('short1!A'), 422, 'the policy rejects a short password');
    $expectRejection(static fn () => PasswordPolicy::assert('alllowercaseletters'), 422, 'the policy rejects a single character class');

    // ---- Register --------------------------------------------------------
    $registration = $portal->registerSubscriber([
        'firstName' => 'Portal', 'lastName' => 'Starter', 'email' => $email, 'phone' => $phone,
        'password' => $password, 'acceptTerms' => true, 'acceptPrivacy' => true,
    ], $request);

    $assert($registration['emailVerified'] === false, 'a new registration is not verified yet');
    $assert(str_starts_with((string) $registration['membershipNumber'], 'MEM-'), 'a membership number is issued at registration');
    $assert(isset($registration['debugCode']), 'outside production the code is returned so the flow can be completed');
    $assert(preg_match('/^\d{6}$/', (string) $registration['debugCode']) === 1, 'the issued code is six digits');

    $user = $database->prepare('SELECT * FROM users WHERE id = :id');
    $user->execute(['id' => $registration['id']]);
    $row = $user->fetch();
    $assert($row['status'] === 'PENDING' && $row['email_verified_at'] === null, 'the account starts PENDING and unverified');
    $assert($row['subscriber_id'] === $registration['subscriberId'], 'the account is linked to its subscriber profile');
    $assert($row['password_hash'] !== $password && password_verify($password, $row['password_hash']), 'the password is stored hashed');

    $stored = $database->prepare('SELECT code_hash FROM otp_codes WHERE user_id = :user');
    $stored->execute(['user' => $registration['id']]);
    $hash = (string) $stored->fetchColumn();
    $assert($hash !== $registration['debugCode'] && strlen($hash) === 64, 'the code is stored as a hash, never in clear text');

    $expectRejection(
        static fn () => $auth->login($email, $password, $request),
        401,
        'an unverified account cannot sign in'
    );

    $payload = static function (string $email, string $phone, string $password, array $overrides = []): array {
        return array_merge([
            'firstName' => 'Guard', 'lastName' => 'Case', 'email' => $email, 'phone' => $phone,
            'password' => $password, 'acceptTerms' => true, 'acceptPrivacy' => true,
        ], $overrides);
    };

    // ---- The code never leaks unless it is explicitly opted in -----------
    // The gate is OTP_DEBUG_CODES, not "not production": an environment that
    // simply never set APP_ENV used to receive a live password-reset code over
    // HTTP, because the missing variable defaulted to the permissive value.
    putenv('OTP_DEBUG_CODES=0');
    $sealed = $portal->registerSubscriber($payload($uniqueEmail(), $uniquePhone(), $password), $fromNewClient());
    $assert(!isset($sealed['debugCode']), 'with the debug flag off the issued code is not returned to the caller');
    $sealedStored = $database->prepare('SELECT COUNT(*) FROM otp_codes WHERE user_id = :user');
    $sealedStored->execute(['user' => $sealed['id']]);
    $assert(
        (int) $sealedStored->fetchColumn() === 1,
        'the code is still issued and stored, it is simply never echoed back'
    );
    $sealedRow = $database->prepare('SELECT status, email_verified_at FROM users WHERE id = :id');
    $sealedRow->execute(['id' => $sealed['id']]);
    $sealedAccount = $sealedRow->fetch();
    $assert(
        $sealedAccount !== false && $sealedAccount['status'] === 'PENDING' && $sealedAccount['email_verified_at'] === null,
        'the account is still created and pending - the flag withholds the code, it does not skip registration'
    );
    putenv('OTP_DEBUG_CODES=1');

    // ---- Registration guards ---------------------------------------------
    $expectRejection(
        static fn () => $portal->registerSubscriber($payload($uniqueEmail(), $uniquePhone(), 'passwordpassword'), $fromNewClient()),
        422,
        'registration enforces the shared password policy'
    );
    $expectRejection(
        static fn () => $portal->registerSubscriber(
            $payload($uniqueEmail(), $uniquePhone(), $password, ['acceptPrivacy' => false]),
            $fromNewClient()
        ),
        422,
        'registration requires accepting the privacy policy'
    );
    $expectRejection(
        static fn () => $portal->registerSubscriber($payload('not-an-email', $uniquePhone(), $password), $fromNewClient()),
        422,
        'registration rejects an invalid email address'
    );
    $expectRejection(
        static fn () => $portal->registerSubscriber($payload($email, $uniquePhone(), $password), $fromNewClient()),
        409,
        'registering the same email twice is refused'
    );
    $expectRejection(
        static fn () => $portal->registerSubscriber($payload($uniqueEmail(), $phone, $password), $fromNewClient()),
        409,
        'registering the same phone twice is refused'
    );

    // ---- Code verification -----------------------------------------------
    $expectRejection(
        static fn () => $portal->verifyOtp(['email' => $email, 'code' => '000000'], $fromNewClient()),
        422,
        'a wrong code is rejected with the generic message'
    );
    $expectRejection(
        static fn () => $portal->verifyOtp(['email' => $uniqueEmail(), 'code' => '123456'], $fromNewClient()),
        422,
        'an unknown email gets the same generic rejection as a wrong code'
    );

    $attempts = $database->prepare('SELECT attempts FROM otp_codes WHERE user_id = :user ORDER BY created_at DESC LIMIT 1');
    $attempts->execute(['user' => $registration['id']]);
    $assert((int) $attempts->fetchColumn() === 1, 'a wrong code burns one attempt');

    // ---- Expiry and the attempt cap are enforced -------------------------
    // Regression guard: otp_codes columns are TIMESTAMP(6), and parsing those
    // values wrongly made every code look expired (or never expire).
    $expiryEmail = $uniqueEmail();
    $expiring = $portal->registerSubscriber($payload($expiryEmail, $uniquePhone(), $password), $fromNewClient());
    $database->prepare('UPDATE otp_codes SET created_at = UTC_TIMESTAMP(6) - INTERVAL 20 MINUTE,
                             expires_at = UTC_TIMESTAMP(6) - INTERVAL 10 MINUTE
             WHERE user_id = :user')
        ->execute(['user' => $expiring['id']]);
    $expectRejection(
        static fn () => $portal->verifyOtp(['email' => $expiryEmail, 'code' => $expiring['debugCode']], $fromNewClient()),
        422,
        'a code past its expiry is rejected'
    );
    $stillPending = $database->prepare('SELECT status FROM users WHERE id = :id');
    $stillPending->execute(['id' => $expiring['id']]);
    $assert($stillPending->fetchColumn() === 'PENDING', 'an expired code cannot activate the account');

    $capEmail = $uniqueEmail();
    $capped = $portal->registerSubscriber($payload($capEmail, $uniquePhone(), $password), $fromNewClient());
    for ($attempt = 0; $attempt < 5; $attempt++) {
        $otps->verify($capped['id'], '000000', OtpService::PURPOSE_EMAIL_VERIFICATION);
    }
    $cappedResult = $otps->verify($capped['id'], (string) $capped['debugCode'], OtpService::PURPOSE_EMAIL_VERIFICATION);
    $assert(
        $cappedResult['valid'] === false && $cappedResult['reason'] === 'attempts_exhausted',
        'the attempt cap kills a code even when the right code finally arrives'
    );

    // ---- Resend is cooldown protected ------------------------------------
    $expectRejection(
        static fn () => $portal->resendOtp(['email' => $email], $request),
        429,
        'a resend inside the cooldown window is refused'
    );

    $verified = $portal->verifyOtp(['email' => $email, 'code' => $registration['debugCode']], $request);
    $assert($verified['status'] === 'ACTIVE' && $verified['verified'] === true, 'the right code activates the account');
    $expectRejection(
        static fn () => $portal->verifyOtp(['email' => $email, 'code' => $registration['debugCode']], $fromNewClient()),
        422,
        'a code cannot be used twice'
    );

    $user->execute(['id' => $registration['id']]);
    $row = $user->fetch();
    $assert($row['status'] === 'ACTIVE' && $row['email_verified_at'] !== null, 'verification stamps email_verified_at');

    $login = $auth->login($email, $password, $request);
    $assert(isset($login['accessToken']), 'a verified subscriber can sign in');
    $session = $auth->authenticate($login['accessToken']);
    $assert($session['subscriber_id'] === $registration['subscriberId'], 'the session carries the subscriber link');

    // ---- Password reset ---------------------------------------------------
    $forgot = $portal->forgotPassword(['email' => $email], $request);
    $assert($forgot['sent'] === true, 'forgot-password accepts the request');
    $unknown = $portal->forgotPassword(['email' => $uniqueEmail()], $fromNewClient());
    $assert(
        $unknown['sent'] === $forgot['sent'] && $unknown['message'] === $forgot['message'],
        'forgot-password answers identically for unknown emails, so it cannot enumerate accounts'
    );
    $assert(!isset($unknown['debugCode']), 'an unknown email gets no code at all');

    $newPassword = 'PortalReset!2027';
    $expectRejection(
        static fn () => $portal->resetPassword(['email' => $email, 'code' => '000000', 'password' => $newPassword], $fromNewClient()),
        422,
        'resetting with a wrong code is rejected'
    );
    $expectRejection(
        static fn () => $portal->resetPassword(['email' => $email, 'code' => $forgot['debugCode'], 'password' => 'weak'], $fromNewClient()),
        422,
        'resetting with a weak password is rejected before the code is consumed'
    );

    $reset = $portal->resetPassword(['email' => $email, 'code' => $forgot['debugCode'], 'password' => $newPassword], $request);
    $assert($reset['reset'] === true && $reset['sessionsRevoked'] >= 1, 'the reset succeeds and revokes existing sessions');

    // The audit actor is now the real user row so the role can be frozen with
    // it. That row carries password_hash, so pin down that the audit writer
    // still records only what it needs and never the secret.
    $resetAudit = $database->prepare(
        'SELECT previous_data, new_data, metadata FROM audit_logs WHERE action = :action ORDER BY id DESC LIMIT 1'
    );
    $resetAudit->execute(['action' => 'PORTAL_PASSWORD_RESET']);
    $resetRow = $resetAudit->fetch();
    $serialised = is_array($resetRow)
        ? implode(' ', array_map('strval', $resetRow))
        : '';
    $user->execute(['id' => $registration['id']]);
    $storedHash = (string) ($user->fetch()['password_hash'] ?? '');
    $assert($serialised !== '', 'the password reset is on the audit record');
    $assert(
        !str_contains($serialised, $newPassword) && !str_contains($serialised, $storedHash),
        'the audit row carries neither the new password nor its hash'
    );
    $expectRejection(
        static fn () => $auth->authenticate($login['accessToken']),
        401,
        'the token issued before the reset no longer works'
    );
    $expectRejection(
        static fn () => $auth->login($email, $password, $request),
        401,
        'the old password no longer signs in'
    );
    $fresh = $auth->login($email, $newPassword, $request);
    $assert(isset($fresh['accessToken']), 'the new password signs in');
    $expectRejection(
        static fn () => $portal->resetPassword(['email' => $email, 'code' => $forgot['debugCode'], 'password' => $newPassword], $fromNewClient()),
        422,
        'a reset code cannot be replayed'
    );
} finally {
    cleanup_portal_fixtures($database, $auditFloor);
}

if ($failures !== []) {
    fwrite(STDERR, count($failures) . " assertion(s) failed.\n");
    exit(1);
}

/** Remove every account this test created, children first. */
function cleanup_portal_fixtures(PDO $database, int $auditFloor): void
{
    $users = $database->query(
        "SELECT id FROM users WHERE email LIKE 'portal-%@mamore.test' OR email LIKE 'not-an-email%'"
    )->fetchAll();
    foreach ($users as $row) {
        $id = (string) $row['id'];
        $database->prepare('DELETE FROM otp_codes WHERE user_id = :id')->execute(['id' => $id]);
        $database->prepare('DELETE FROM audit_logs WHERE actor_user_id = :id')->execute(['id' => $id]);
        $database->prepare('DELETE FROM user_sessions WHERE user_id = :id')->execute(['id' => $id]);
        $database->prepare('DELETE FROM login_history WHERE user_id = :id')->execute(['id' => $id]);
        $database->prepare('DELETE FROM user_notifications WHERE user_id = :id')->execute(['id' => $id]);
        $database->prepare('UPDATE users SET subscriber_id = NULL WHERE id = :id')->execute(['id' => $id]);
        $database->prepare('DELETE FROM users WHERE id = :id')->execute(['id' => $id]);
    }

    $subscribers = $database->query("SELECT id FROM subscribers WHERE email LIKE 'portal-%@mamore.test'")->fetchAll();
    foreach ($subscribers as $row) {
        $id = (string) $row['id'];
        $database->prepare('DELETE FROM subscriber_vehicles WHERE subscriber_id = :id')->execute(['id' => $id]);
        $database->prepare('DELETE FROM subscriber_history WHERE subscriber_id = :id')->execute(['id' => $id]);
        $database->prepare('DELETE FROM subscribers WHERE id = :id')->execute(['id' => $id]);
    }

    $database->exec("DELETE FROM audit_logs WHERE metadata LIKE '%portal-%@mamore.test%'");
    // Everything this run appended, including the deliberately actor-less rows.
    $database->prepare('DELETE FROM audit_logs WHERE id > :floor')->execute(['floor' => $auditFloor]);
}
