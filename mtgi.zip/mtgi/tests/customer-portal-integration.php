<?php

declare(strict_types=1);

use Mamore\Core\Database;
use Mamore\Core\Uuid;
use Mamore\Portal\CustomerPortalService;
use Mamore\SmartBus\SmartBusService;

require dirname(__DIR__) . '/bootstrap.php';
require __DIR__ . '/support.php';

$database=Database::connection(); $bus=new SmartBusService($database); $board=$bus->board();
$admin=test_actor('SYSTEM_ADMIN');
$role=$database->query("SELECT id FROM roles WHERE code='CUSTOMER' LIMIT 1")->fetch();
$failures = [];
$assert=static function(bool $condition,string $message)use(&$failures):void{if(!$condition){$failures[]=$message;fwrite(STDERR,"FAIL: {$message}\n");return;}fwrite(STDOUT,"PASS: {$message}\n");};
$assert(is_array($admin)&&is_array($role),'portal test identities are available');
$customerId=Uuid::v4(); $trip=null; $booking=null;
try {
    $database->prepare("INSERT INTO users(id,role_id,first_name,last_name,email,phone,password_hash,status,email_verified_at) VALUES(:id,:role,'Portal','Test',:email,:phone,:password,'ACTIVE',UTC_TIMESTAMP(6))")->execute(['id'=>$customerId,'role'=>$role['id'],'email'=>'portal-'.bin2hex(random_bytes(4)).'@mamore.test','phone'=>'+243'.random_int(100000000,999999999),'password'=>password_hash('PortalTestPassword!2026',PASSWORD_DEFAULT)]);
    $customer=$database->prepare('SELECT * FROM users WHERE id=:id'); $customer->execute(['id'=>$customerId]); $customer=$customer->fetch();
    $trip=$bus->schedule(['routeId'=>$board['routes'][0]['id'],'vehicleId'=>$board['vehicles'][0]['id'],'departureAt'=>(new DateTimeImmutable('+4 days'))->format('Y-m-d H:i:s'),'usdCdfRate'=>2850],$admin);
    $portal=new CustomerPortalService($database); $assert(count($portal->trips())>=1,'customer can browse available trips');
    $booking=$portal->book(['tripId'=>$trip['id'],'seatNumber'=>3],$customer);
    $assert($booking['status']==='CONFIRMED','customer can book an available seat');
    $mine=$portal->bookings($customer); $assert(count($mine)===1&&$mine[0]['reference']===$booking['reference'],'customer sees personal booking only');
} finally {
    if(is_array($booking))$database->prepare('DELETE FROM smartbus_bookings WHERE id=:id')->execute(['id'=>$booking['id']]);
    if(is_array($trip))$database->prepare('DELETE FROM smartbus_trips WHERE id=:id')->execute(['id'=>$trip['id']]);
    $database->prepare('DELETE FROM users WHERE id=:id')->execute(['id'=>$customerId]);
}

if ($failures !== []) {
    fwrite(STDERR, count($failures) . " assertion(s) failed.\n");
    exit(1);
}
