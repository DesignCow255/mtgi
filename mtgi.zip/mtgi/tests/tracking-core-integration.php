<?php

declare(strict_types=1);

/**
 * Shared tracking core: devices, ingestion, current position, history, geofences
 * and alerts (phase 04).
 *
 * The security cases matter more than the happy path here: an anonymous or
 * misassigned write must fail, a replayed position must not be stored twice, and
 * a map must read the current-position table rather than the history.
 */

use Mamore\Auth\AuthException;
use Mamore\Core\AuditLog;
use Mamore\Core\Database;
use Mamore\Core\Request;
use Mamore\Core\ServerClock;
use Mamore\Core\Uuid;
use Mamore\Tracking\TrackingIngestionService;

require dirname(__DIR__) . '/bootstrap.php';
require __DIR__ . '/support.php';

$database = Database::connection();
$ingest = new TrackingIngestionService($database);

$failures = [];
$assert = static function (bool $condition, string $message) use (&$failures): void {
    if ($condition) {
        fwrite(STDOUT, "PASS: {$message}\n");
        return;
    }
    $failures[] = $message;
    fwrite(STDERR, "FAIL: {$message}\n");
};
$expectRejection = static function (callable $operation, int $status, string $message) use ($assert): void {
    try {
        $operation();
    } catch (AuthException $error) {
        $assert($error->status === $status, $message);
        return;
    }
    throw new RuntimeException("Expected rejection failed: {$message}");
};

$request = new Request('POST', '/api/tracking/ingest', [], [], '198.51.100.77', 'MamoreDevice/1.0');
$admin = test_actor('SYSTEM_ADMIN', ['firstName' => 'Track', 'lastName' => 'Admin']);
$assetId = null;
$deviceUid = 'DEV-TEST-' . strtoupper(bin2hex(random_bytes(4)));
$deviceToken = 'tok_' . bin2hex(random_bytes(16));

try {
    // ---- A typed tracked asset over an existing Smart Bus vehicle ----------
    $vehicleId = (string) $database->query(
        'SELECT vehicle_id FROM smartbus_vehicles WHERE vehicle_id IS NOT NULL LIMIT 1'
    )->fetchColumn();
    $assert($vehicleId !== '', 'the migration linked a Smart Bus vehicle to the canonical registry');

    $assetId = $database->query("SELECT id FROM tracked_assets WHERE asset_type = 'BUS' LIMIT 1")->fetchColumn();
    $assert(is_string($assetId) && $assetId !== '', 'the existing Smart Bus tracking asset has a canonical tracked asset');
    $assert(
        $database->query('SELECT vehicle_id FROM tracked_assets WHERE id = ' . $database->quote($assetId))->fetchColumn() === $vehicleId,
        'the tracked asset points at the canonical vehicle with a real foreign key'
    );
    // The bridge is one-way: a legacy tracking_assets row must resolve to a
    // canonical tracked_asset. The reverse does not hold and must not be
    // asserted - TruckService creates canonical-only assets (tracking_status
    // NO_DEVICE) for trucks, so counting canonical rows that have no legacy
    // counterpart fails as soon as the truck domain is used.
    $assert(
        (int) $database->query('SELECT COUNT(*) FROM tracking_assets t LEFT JOIN tracked_assets a ON a.id = t.tracked_asset_id WHERE a.id IS NULL')->fetchColumn() === 0,
        'every legacy tracking asset is bridged to the canonical model'
    );
    $assert(
        (int) $database->query("SELECT COUNT(*) FROM tracked_assets WHERE asset_type NOT IN (SELECT code FROM asset_types)")->fetchColumn() === 0,
        'asset types are reference data, not free text'
    );

    // ---- Device registration and assignment -------------------------------
    $registered = $ingest->registerDevice([
        'deviceUid' => $deviceUid, 'deviceToken' => $deviceToken, 'trackedAssetId' => $assetId,
        'imei' => '35' . random_int(100000000, 999999999), 'provider' => 'MamoreTelematics', 'model' => 'GT-100',
    ], $admin);
    $assert(($registered['status'] ?? '') === 'ACTIVE', 'a device can be registered and assigned');
    $expectRejection(
        static fn () => $ingest->registerDevice(['deviceUid' => 'DEV-2', 'deviceToken' => 'x', 'trackedAssetId' => $assetId], $admin),
        409,
        'an asset cannot have two active devices at once'
    );

    $storedHash = $database->query('SELECT device_token_hash FROM tracking_devices WHERE id = ' . $database->quote($registered['deviceId']))->fetchColumn();
    $assert($storedHash === hash('sha256', $deviceToken), 'the device token is stored only as a hash');
    $assert($storedHash !== $deviceToken, 'the raw token is never stored');

    // ---- Authentication is required --------------------------------------
    $base = ['deviceUid' => $deviceUid, 'latitude' => -11.6, 'longitude' => 27.5];
    $expectRejection(
        static fn () => $ingest->ingest(['deviceUid' => $deviceUid, 'latitude' => -11.6, 'longitude' => 27.5], $request),
        401,
        'a position without a device token is refused'
    );
    $expectRejection(
        static fn () => $ingest->ingest(array_merge($base, ['deviceToken' => 'wrong-token']), $request),
        401,
        'a position with the wrong device token is refused'
    );
    $expectRejection(
        static fn () => $ingest->ingest(['deviceUid' => 'NO-SUCH-DEVICE', 'deviceToken' => $deviceToken, 'latitude' => -11.6, 'longitude' => 27.5], $request),
        401,
        'an unknown device is refused'
    );

    // ---- Payload validation ----------------------------------------------
    $expectRejection(
        static fn () => $ingest->ingest(array_merge($base, ['deviceToken' => $deviceToken, 'latitude' => 95]), $request),
        422,
        'an out-of-range latitude is refused'
    );
    $expectRejection(
        static fn () => $ingest->ingest(array_merge($base, ['deviceToken' => $deviceToken, 'latitude' => 0, 'longitude' => 0]), $request),
        422,
        'the null island position is refused'
    );
    $expectRejection(
        static fn () => $ingest->ingest(array_merge($base, ['deviceToken' => $deviceToken, 'speedKph' => 900]), $request),
        422,
        'an impossible speed is refused'
    );
    $expectRejection(
        static fn () => $ingest->ingest(array_merge($base, ['deviceToken' => $deviceToken, 'recordedAt' => gmdate('Y-m-d H:i:s', time() + 4000)]), $request),
        422,
        'a timestamp far in the future is refused'
    );
    $expectRejection(
        static fn () => $ingest->ingest(array_merge($base, ['deviceToken' => $deviceToken, 'recordedAt' => gmdate('Y-m-d H:i:s', time() - 60 * 86400)]), $request),
        422,
        'a timestamp older than the retention window is refused'
    );

    // ---- A valid position -------------------------------------------------
    $now = ServerClock::epoch($database);
    $accepted = $ingest->ingest(array_merge($base, [
        'deviceToken' => $deviceToken, 'speedKph' => 62.5, 'headingDegrees' => 180,
        'accuracyMeters' => 6, 'ignitionStatus' => 'ON', 'devicePositionId' => 'P-1',
    ]), $request);
    $assert($accepted['assetId'] === $assetId, 'a valid position is accepted for the assigned asset');
    $assert($accepted['vehicleId'] === $vehicleId, 'the response reports the canonical vehicle');

    $position = $database->prepare('SELECT * FROM tracked_asset_positions WHERE tracked_asset_id = :id');
    $position->execute(['id' => $assetId]);
    $row = $position->fetch();
    $assert(is_array($row) && abs((float) $row['latitude'] + 11.6) < 0.001, 'the current position holds the new coordinates');
    $assert((float) $row['speed_kph'] === 62.5, 'the current position holds the reported speed');
    $assert($row['ignition_status'] === 'ON', 'the current position holds the ignition flag');
    $assert(
        (int) $database->query('SELECT COUNT(*) FROM tracked_asset_positions WHERE tracked_asset_id = ' . $database->quote($assetId))->fetchColumn() === 1,
        'there is exactly one current-position row per asset, so a map never scans history'
    );
    $assert(
        (int) $database->query('SELECT COUNT(*) FROM location_history WHERE tracked_asset_id = ' . $database->quote($assetId))->fetchColumn() >= 1,
        'the position is appended to the history'
    );
    $assert(
        $database->query("SELECT tracking_status FROM tracked_assets WHERE id = " . $database->quote($assetId))->fetchColumn() === 'ONLINE',
        'the asset is marked online'
    );

    // ---- Replay protection -------------------------------------------------
    $expectRejection(
        static fn () => $ingest->ingest(array_merge($base, ['deviceToken' => $deviceToken, 'devicePositionId' => 'P-1']), $request),
        409,
        'a replayed position id is refused'
    );
    $assert(
        (int) $database->query("SELECT COUNT(*) FROM location_history WHERE device_position_id = 'P-1'")->fetchColumn() === 1,
        'the replayed position was not stored twice'
    );

    // ---- Device removal keeps history -------------------------------------
    $removed = $ingest->removeDevice(['deviceId' => $registered['deviceId'], 'reason' => 'Device replaced after a fault.'], $admin, $request);
    $assert($removed['status'] === 'REMOVED', 'a device can be removed with a reason');
    $expectRejection(
        static fn () => $ingest->ingest(array_merge($base, ['deviceToken' => $deviceToken]), $request),
        401,
        'a removed device can no longer report'
    );
    $assert(
        (int) $database->query('SELECT COUNT(*) FROM location_history WHERE tracked_asset_id = ' . $database->quote($assetId))->fetchColumn() >= 1,
        'position history survives device removal'
    );
    $assert(
        (int) $database->query('SELECT COUNT(*) FROM tracking_device_assignments WHERE device_id = ' . $database->quote($registered['deviceId']) . ' AND unassigned_at IS NOT NULL')->fetchColumn() === 1,
        'the assignment history records the unassignment'
    );

    // ---- Geofence transitions ---------------------------------------------
    $fenceId = Uuid::v4();
    $database->prepare(<<<'SQL'
        INSERT INTO geofences (id, geofence_type, name, center_latitude, center_longitude, radius_meters,
                               alert_on_enter, alert_on_exit, created_by_user_id)
        VALUES (:id, 'CORRIDOR', 'Test corridor', -11.6, 27.5, 2000, TRUE, TRUE, :actor)
        SQL)->execute(['id' => $fenceId, 'actor' => $admin['id']]);

    // The ingestion path refuses a position within 5 s of the last one, so the
    // fixture spaces its reports rather than weakening the rule.
    $database->prepare(
        'UPDATE tracked_asset_positions SET recorded_at = DATE_SUB(UTC_TIMESTAMP(6), INTERVAL 60 SECOND)
         WHERE tracked_asset_id = :asset'
    )->execute(['asset' => $assetId]);

    $fenceToken = 'tok_' . bin2hex(random_bytes(8));
    $device = $ingest->registerDevice([
        'deviceUid' => $deviceUid . 'B', 'deviceToken' => $fenceToken, 'trackedAssetId' => $assetId,
    ], $admin);
    $payload = ['deviceUid' => $deviceUid . 'B', 'deviceToken' => $fenceToken];
    $inside = $ingest->ingest($payload + ['latitude' => -11.6, 'longitude' => 27.5], $request);
    $assert(
        ($inside['geofenceEvents'][0]['code'] ?? '') === 'GEOFENCE_ENTER',
        'entering a geofence raises exactly one alert'
    );
    $assert(
        (int) $database->query("SELECT COUNT(*) FROM tracking_alerts WHERE alert_code = 'GEOFENCE_ENTER'")->fetchColumn() === 1,
        'staying inside the same geofence does not raise it again'
    );

    $database->prepare('DELETE FROM geofences WHERE id = :id')->execute(['id' => $fenceId]);
    $database->prepare('DELETE FROM tracking_devices WHERE id = :id')->execute(['id' => $device['deviceId']]);

    $audits = (new AuditLog($database))->list(['entityType' => 'TrackedAsset', 'action' => 'TRACKING_DEVICE_ASSIGNED', 'limit' => 5]);
    $assert($audits !== [], 'assigning a device is audited');
} finally {
    if (is_string($assetId) && $assetId !== '') {
        $database->prepare('DELETE FROM tracking_alerts WHERE tracked_asset_id = :a')->execute(['a' => $assetId]);
        $database->prepare('DELETE FROM location_history WHERE tracked_asset_id = :a')->execute(['a' => $assetId]);
        $database->prepare('DELETE FROM tracked_asset_positions WHERE tracked_asset_id = :a')->execute(['a' => $assetId]);
    }
    $database->exec("DELETE FROM tracking_devices WHERE device_uid LIKE 'DEV-TEST-%'");
    $database->exec("DELETE FROM audit_logs WHERE action LIKE 'TRACKING_DEVICE_%'");
    $database->exec("DELETE FROM users WHERE first_name = 'Track' AND email LIKE '%@mamore.test'");
}

if ($failures !== []) {
    fwrite(STDERR, count($failures) . " assertion(s) failed.\n");
    exit(1);
}
