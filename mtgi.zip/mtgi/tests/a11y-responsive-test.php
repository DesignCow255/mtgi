<?php

declare(strict_types=1);

/**
 * Accessibility, responsive and performance guard (Phases 24, 25, 26).
 *
 * These three phases are usually verified by opening a browser and looking.
 * This test cannot render, so it checks the things that are CHECKABLE in the
 * shipped source, and fails on the regressions that are invisible until a
 * screen reader or a narrow window finds them:
 *
 *  - every interactive control has an accessible name
 *  - icon-only buttons are labelled, since an icon is not a name
 *  - every dialog has a heading and a close control
 *  - the skip link exists and points at a real target
 *  - both themes are scoped to their attribute and never to a bare :root
 *  - breakpoints are declared, and the grid collapses rather than overflowing
 *  - focus-visible and prefers-reduced-motion are honoured
 *  - no inline style or script attribute that a strict CSP would block
 *
 * It does NOT claim to replace visual QA. Phase 27 needs a browser.
 */

$root = dirname(__DIR__);
$html = (string) file_get_contents($root . '/public/app.html');
$js = (string) file_get_contents($root . '/public/assets/app.js');

$css = '';
foreach (glob($root . '/public/assets/css/*.css') ?: [] as $file) {
    $css .= (string) file_get_contents($file);
}
foreach (glob($root . '/public/assets/css/themes/*.php') ?: [] as $file) {
    $css .= (string) file_get_contents($file);
}
foreach (glob($root . '/public/assets/css/themes/*.css') ?: [] as $file) {
    $css .= (string) file_get_contents($file);
}
$css .= (string) file_get_contents($root . '/public/assets/app.css');

$failures = 0;
$assert = static function (bool $condition, string $message) use (&$failures): void {
    if ($condition) {
        fwrite(STDOUT, "PASS: {$message}\n");
        return;
    }
    $failures++;
    fwrite(STDERR, "FAIL: {$message}\n");
};

/* -- 25. accessible names ---------------------------------------------- */

// Icon-only buttons must carry an aria-label or a visually hidden label. An
// icon glyph is not a name, and "button, button, button" is what a screen
// reader actually announces.
// The WHOLE element, not just its opening tag: matching "<button ...>" alone
// reported seven perfectly-labelled buttons as unlabelled, because the text
// lives in the element's body and the regex stopped at the first ">".
preg_match_all('/<button\b[^>]*>.*?<\/button>/is', $html, $buttons);
$unlabelled = [];
foreach ($buttons[0] as $button) {
    $text = strip_tags(preg_replace('/<i\b[^>]*>.*?<\/i>/is', '', $button) ?? '');
    // An icon glyph is not a name, so it is removed before the emptiness test.
    $hasText = trim($text) !== '';
    $hasLabel = str_contains($button, 'aria-label')
        || str_contains($button, 'aria-labelledby')
        || str_contains($button, 'title=');
    // A button whose label lives in a data-* attribute is filled in by JS;
    // those are checked separately.
    if ($hasText || $hasLabel) {
        continue;
    }
    if (preg_match('/data-[a-z-]*label/i', $button) === 1) {
        continue;
    }
    $unlabelled[] = substr($button, 0, 90);
}
$assert($unlabelled === [], 'every static button has an accessible name')
    or fwrite(STDERR, '     unlabelled: ' . implode("\n                 ", $unlabelled) . "\n");

// The icon buttons created in JS carry a label too.
preg_match_all("/class=\"icon-button[^\"]*\"[^>]*/i", $js, $jsButtons);
$assert(
    $jsButtons[0] === [] || str_contains($js, 'aria-label'),
    'icon-only buttons rendered by JS carry an aria-label'
);

/* -- dialogs are dialogs ------------------------------------------------ */

preg_match_all('/<dialog\b[^>]*>/i', $html, $dialogs);
$assert($dialogs[0] !== [], 'the shell uses real <dialog> elements');
$assert(
    substr_count($html, '<dialog') === substr_count($html, '</dialog>'),
    'every <dialog> is closed'
);
$assert(
    str_contains($html, 'class="dialog-header"'),
    'dialogs have a header region for their title'
);
$assert(
    str_contains($css, 'dialog::backdrop'),
    'the dialog backdrop is styled, so the modal boundary is visible'
);

/* -- skip link ---------------------------------------------------------- */

$assert(str_contains($html, 'skip'), 'a skip link is present in the shell');
$assert(
    preg_match('/href="#([\w-]+)"/', $html, $skip) === 1
        && str_contains($html, 'id="' . $skip[1] . '"'),
    'the skip link points at an element that exists'
);
$assert(str_contains($css, 'sr-only'), 'the visually-hidden utility is defined');

/* -- 25. focus and motion ----------------------------------------------- */

$assert(str_contains($css, 'focus-visible'), 'focus is visible for keyboard users');
$assert(str_contains($css, 'prefers-reduced-motion'), 'reduced-motion is honoured');

/* -- 04. themes stay scoped --------------------------------------------- */

// A bare :root in a theme file lets one theme override the other by load
// order, which is a silent, intermittent bug that only shows up on reload.
foreach (['light', 'dark'] as $theme) {
    $path = $root . "/public/assets/css/themes/{$theme}.css";
    if (!is_file($path)) {
        continue;
    }
    $contents = (string) file_get_contents($path);
    $assert(
        str_contains($contents, "[data-theme=\"{$theme}\"]"),
        "the {$theme} theme is scoped to its data-theme attribute"
    );
    $assert(
        preg_match('/(^|\})\s*:root\s*\{/m', $contents) !== 1,
        "the {$theme} theme does not declare a bare :root that could win by load order"
    );
}

/* -- 24. responsive ----------------------------------------------------- */

$assert(str_contains($css, '@media (min-width: 768px)'), 'a tablet breakpoint is declared');
$assert(str_contains($css, '@media (min-width: 1280px)'), 'a desktop breakpoint is declared');
$assert(str_contains($css, 'grid-template-columns'), 'the grid defines its columns');
$assert(
    str_contains($css, 'minmax(0, 1fr)'),
    'grid tracks use minmax(0, 1fr) so long content cannot force a horizontal scrollbar'
);
$assert(str_contains($css, 'overflow-x'), 'horizontal overflow is handled somewhere in the layer');
$assert(
    str_contains($css, 'max-width: 767px') || str_contains($css, 'max-width: 767'),
    'a small-screen branch exists'
);
$assert(
    str_contains($html, 'name="viewport"'),
    'the viewport meta tag is present, without a user-scalable=no lock'
);
$assert(
    !str_contains($html, 'user-scalable=no'),
    'pinch zoom is not disabled'
);

/* -- 26. performance budget --------------------------------------------- */

$assert(!str_contains($html, 'http://'), 'no plaintext http asset origins, which would be mixed content');
$assert(
    !preg_match('/<script(?![^>]*\bsrc=)/i', $html),
    'there are no inline <script> blocks, which the strict CSP would block anyway'
);
$assert(str_contains($html, 'rel="preload"'), 'critical fonts are preloaded rather than discovered late');
$assert(
    substr_count($html, '<link rel="stylesheet"') <= 10,
    'the stylesheet count stays inside the performance budget'
);

// Lazy images, if any images exist at all.
preg_match_all('/<img\b[^>]*>/i', $html, $images);
foreach ($images[0] as $image) {
    $assert(
        str_contains($image, 'loading="lazy"') || str_contains($image, 'alt='),
        'images declare alt text or lazy loading'
    );
}

/* -- panel cells and the values that fill them must agree ---------------- */

// The v1 tracking panel had four cells and the renderer produced five values,
// because it summed two distinct tracking states into one cell. Nothing caught
// it: the extra value was silently dropped and "never signalled" was reported
// as "stale". Counting both sides removes the possibility.
foreach (['tracking-metrics', 'rescue-metrics', 'alert-metrics'] as $mount) {
    if (!str_contains($html, 'id="' . $mount . '"')) {
        continue;
    }
    preg_match('/id="' . preg_quote($mount, '/') . '"[^>]*>(.*?)<\/div>\s*<\/div>/s', $html, $block);
    $cells = substr_count($block[1] ?? '', '<div>');

    // The JS source literally reads $$('#tracking-metrics strong'). Building
    // this as a double-quoted regex escaped the $ twice and matched nothing,
    // so the needle is assembled literally and quoted once.
    $needle = "$$('#" . $mount . " strong')";
    $pattern = '/' . preg_quote($needle, '/') . '/';
    $assert(
        preg_match($pattern, $js) === 1,
        "the {$mount} cells are filled by an indexed renderer"
    );
    // The values array that feeds this mount must be the same length as the
    // cells it fills. The v1 bug was exactly this: five values into four cells,
    // so one state was dropped without any error being raised.
    if (preg_match('/values\s*=\s*\[([^\]]*)\]/', $js, $values) !== 1) {
        continue;
    }
    // Only compare against the array nearest this mount's renderer, so two
    // panels with different shapes do not get compared to each other.
    $mountPosition = strpos($js, $needle);
    $arrayPosition = strrpos(substr($js, 0, max(0, (int) $mountPosition)), 'values=[');
    if ($arrayPosition === false) {
        continue;
    }
    $start = strpos($js, '[', $arrayPosition);
    $depth = 0;
    $end = $start;
    for ($i = (int) $start; $i < strlen($js); $i++) {
        if ($js[$i] === '[') {
            $depth++;
        } elseif ($js[$i] === ']') {
            $depth--;
            if ($depth === 0) {
                $end = $i;
                break;
            }
        }
    }
    $expected = substr_count(substr($js, $start, $end - $start), ',') + 1;
    $assert(
        $cells === $expected,
        "the {$mount} has {$cells} cells and its renderer supplies {$expected} values"
    );
}

// The specific regression: three tracking states, three cells.
preg_match('/id="tracking-metrics"[^>]*>(.*?)<\/div>\s*<\/div>/s', $html, $tracking);
$assert(
    substr_count($tracking[1] ?? '', '<div>') === 5,
    'the tracking panel has one cell per tracking state, not a merged one'
);
$assert(
    str_contains($js, 'data.metrics.stale,data.metrics.noSignal'),
    'the tracking renderer passes stale and never-signalled separately'
);
$assert(
    !str_contains($js, 'data.metrics.stale+data.metrics.noSignal'),
    'the tracking renderer no longer merges two distinct tracking states'
);

fwrite(STDOUT, $failures === 0 ? "\nPASS: accessibility, responsive and performance guards hold\n" : "\nFAILURES: {$failures}\n");
exit($failures === 0 ? 0 : 1);
