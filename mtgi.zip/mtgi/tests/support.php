<?php

declare(strict_types=1);

/**
 * Shared integration-test fixtures.
 *
 * Integration tests must never depend on rows created by hand through the
 * admin console or a one-off seed: every run provisions the identities it
 * needs and removes them again at shutdown, so an empty (migrated) database
 * behaves exactly like a populated one. Reference data such as roles,
 * permissions, rescue units, Smart Bus operators, routes and vehicles is
 * inserted by the migrations themselves and is therefore always present.
 */

use Mamore\Core\Database;
use Mamore\Core\Uuid;

/**
 * Create an ACTIVE user for the given role and return the stored row.
 *
 * The account is deleted again when the test process exits, together with the
 * identity-scoped rows a test may have produced (sessions, login history,
 * audit entries, notifications, panic alerts). Domain rows created by the test
 * itself stay the test's responsibility, matching the existing "finally"
 * cleanup blocks.
 */
function test_actor(string $roleCode = 'SYSTEM_ADMIN', array $overrides = []): array
{
    $database = Database::connection();

    $roleStatement = $database->prepare('SELECT id, code FROM roles WHERE code = :code');
    $roleStatement->execute(['code' => $roleCode]);
    $role = $roleStatement->fetch();
    if (!is_array($role)) {
        test_fail("role {$roleCode} is missing; run php bin/migrate.php first");
    }

    $id = $overrides['id'] ?? Uuid::v4();
    $email = $overrides['email'] ?? sprintf('%s-%s@mamore.test', strtolower($roleCode), bin2hex(random_bytes(5)));
    $phone = $overrides['phone'] ?? null;

    $database->prepare(
        'INSERT INTO users (id, role_id, first_name, last_name, email, phone, password_hash, status, email_verified_at)
         VALUES (:id, :role, :firstName, :lastName, :email, :phone, :password, :status, UTC_TIMESTAMP(6))'
    )->execute([
        'id' => $id,
        'role' => $role['id'],
        'firstName' => $overrides['firstName'] ?? 'Fixture',
        'lastName' => $overrides['lastName'] ?? ucfirst(strtolower($roleCode)),
        'email' => $email,
        'phone' => $phone,
        'password' => password_hash($overrides['password'] ?? 'FixturePassword!2026', PASSWORD_DEFAULT),
        'status' => $overrides['status'] ?? 'ACTIVE',
    ]);

    test_track_fixture_user($id);

    $statement = $database->prepare('SELECT * FROM users WHERE id = :id');
    $statement->execute(['id' => $id]);
    $actor = $statement->fetch();
    if (!is_array($actor)) {
        test_fail('fixture actor could not be reloaded');
    }

    return $actor;
}

/**
 * Register a fixture user for shutdown cleanup.
 */
function test_track_fixture_user(string $userId): void
{
    static $registered = false;

    $GLOBALS['mamore_test_fixture_users'][] = $userId;
    if ($registered) {
        return;
    }
    $registered = true;

    register_shutdown_function(static function (): void {
        try {
            $database = Database::connection();
        } catch (Throwable) {
            return;
        }

        $cleanup = [
            'DELETE FROM user_notifications WHERE user_id = :id',
            'DELETE FROM user_sessions WHERE user_id = :id',
            'DELETE FROM login_history WHERE user_id = :id',
            'DELETE FROM audit_logs WHERE actor_user_id = :id',
            'DELETE FROM panic_alerts WHERE subscriber_user_id = :id',
            'DELETE FROM users WHERE id = :id',
        ];

        foreach (array_reverse($GLOBALS['mamore_test_fixture_users'] ?? []) as $id) {
            foreach ($cleanup as $sql) {
                try {
                    $database->prepare($sql)->execute(['id' => $id]);
                } catch (Throwable) {
                    // Foreign keys owned by the test body (incidents, trips,
                    // finance rows) may still reference the fixture: leave those
                    // rows for the test's own cleanup instead of failing here.
                }
            }
        }
    });
}

/**
 * Abort the current test with an explicit failure reason.
 */
function test_fail(string $message): never
{
    fwrite(STDERR, "FAIL: {$message}\n");
    exit(1);
}
