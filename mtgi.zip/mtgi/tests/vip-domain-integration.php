<?php

declare(strict_types=1);

/**
 * The VIP domain (phases 06 and 07).
 *
 * Walks the brief's VIP flow end to end: create a profile on a canonical person,
 * activate it, have a rescue code issued by the shared service and a coverage
 * link by the shared engine, link a vehicle, add a dependant, keep the emergency
 * profile separate, and prove that another subscriber cannot read any of it.
 */

use Mamore\Auth\AuthException;
use Mamore\Auth\AuthService;
use Mamore\Core\AuditLog;
use Mamore\Core\Database;
use Mamore\Core\Request;
use Mamore\Core\Uuid;
use Mamore\SmartBus\RescueCodeService;
use Mamore\Rescue\RescueCoverageService;
use Mamore\Vip\VipSubscriberService;

require dirname(__DIR__) . '/bootstrap.php';
require __DIR__ . '/support.php';

$database = Database::connection();
$coverage = new RescueCoverageService($database);
$codes = new RescueCodeService($database);
$vipService = new VipSubscriberService($database, $coverage, $codes);
$auth = new AuthService($database);

$failures = [];
$assert = static function (bool $condition, string $message) use (&$failures): void {
    if ($condition) {
        fwrite(STDOUT, "PASS: {$message}\n");
        return;
    }
    $failures[] = $message;
    fwrite(STDERR, "FAIL: {$message}\n");
};
$expectRejection = static function (callable $operation, int $status, string $message) use ($assert): void {
    try {
        $operation();
    } catch (AuthException $error) {
        $assert($error->status === $status, $message);
        return;
    }
    throw new RuntimeException("Expected rejection failed: {$message}");
};

$request = new Request('POST', '/api/vip/subscribers', [], [], '198.51.100.91', 'VipDomainTest/1.0');
$password = 'VipDomainTest!2026';
$admin = test_actor('SYSTEM_ADMIN', ['password' => $password, 'firstName' => 'Vip', 'lastName' => 'Admin']);
$intruder = test_actor('CUSTOMER', ['password' => $password, 'firstName' => 'Other', 'lastName' => 'Customer']);
$session = static function (array $actor) use ($database, $auth, $password, $request): array {
    $email = (string) $database->query('SELECT email FROM users WHERE id = ' . $database->quote($actor['id']))->fetchColumn();

    return $auth->authenticate($auth->login($email, $password, $request)['accessToken']);
};
$adminSession = $session($admin);
$intruderSession = $session($intruder);

$personId = Uuid::v4();
$vehicleId = Uuid::v4();
$dependantPersonId = Uuid::v4();
$vipId = null;

try {
    // ---- Membership types are configuration -------------------------------
    $types = [];
    foreach ($database->query('SELECT code, allows_dependants FROM vip_membership_types')->fetchAll() as $row) {
        $types[(string) $row['code']] = (int) $row['allows_dependants'];
    }
    $assert(
        isset($types['INDIVIDUAL'], $types['FAMILY'], $types['CORPORATE'], $types['FLEET_OWNER']),
        'VIP membership types are reference data, not code'
    );
    $assert($types['FAMILY'] === 1 && $types['INDIVIDUAL'] === 0, 'dependant support is a property of the membership type, not code');
    $priorities = $database->query('SELECT code FROM vip_priority_levels')->fetchAll(PDO::FETCH_COLUMN);
    foreach (['STANDARD', 'PRIORITY', 'EXECUTIVE', 'CRITICAL'] as $level) {
        $assert(in_array($level, $priorities, true), "priority level {$level} is configurable");
    }

    $database->prepare(
        'INSERT INTO persons (id, first_name, last_name, phone, email) VALUES (?, ?, ?, ?, ?)'
    )->execute([$personId, 'Vine', 'Kasongo', '+243000001234', 'vip-domain@mamore.test']);
    $database->prepare(
        'INSERT INTO persons (id, first_name, last_name) VALUES (?, ?, ?)'
    )->execute([$dependantPersonId, 'Junior', 'Kasongo']);
    $database->prepare(
        'INSERT INTO vehicles (id, vehicle_type, registration_number, country_of_registration, make, model) VALUES (?, ?, ?, ?, ?, ?)'
    )->execute([$vehicleId, 'PRIVATE_CAR', 'VIP-TEST-001', 'CD', 'Toyota', 'Land Cruiser']);

    // ---- Create ------------------------------------------------------------
    $vip = $vipService->create([
        'personId' => $personId,
        'membershipType' => 'FAMILY',
        'priorityLevel' => 'EXECUTIVE',
        'servicePlanId' => (string) $database->query("SELECT id FROM service_plans WHERE plan_code = 'VIP-FULL-PROTECT'")->fetchColumn(),
        'homeRegion' => 'HAUT_KATANGA',
        'homeCity' => 'Lubumbashi',
    ], $adminSession, $request);
    $vipId = (string) $vip['id'];
    $assert(str_starts_with((string) $vip['membershipNumber'], 'VIP-'), 'a VIP membership number is allocated');
    $assert($vip['status'] === 'PENDING', 'a new VIP profile starts PENDING');
    $assert($vip['rescueCoverage']['covered'] === false, 'a pending VIP is not yet covered');
    $assert($vip['plan']['code'] === 'VIP-FULL-PROTECT', 'the VIP carries its configured plan');
    $assert($vip['person']['name'] === 'Vine Kasongo', 'the VIP is a profile on a canonical person, not a copy');

    $expectRejection(
        static fn () => $vipService->create(['personId' => $personId], $adminSession, $request),
        422,
        'the same person cannot hold two VIP profiles'
    );
    $expectRejection(
        static fn () => $vipService->create(['personId' => $personId, 'membershipType' => 'ROYALTY'], $adminSession, $request),
        422,
        'an unknown membership type is refused'
    );
    $expectRejection(
        static fn () => $vipService->create(['personId' => $personId, 'servicePlanId' => (string) $database->query("SELECT id FROM service_plans WHERE plan_code = 'TRUCK-ROAD-ASSIST'")->fetchColumn()], $adminSession, $request),
        422,
        'a plan from another domain is refused'
    );

    // ---- A VIP without a membership record still activates, honestly -------
    $activated = $vipService->activate(['vipSubscriberId' => $vipId, 'expiresAt' => gmdate('Y-m-d H:i:s', time() + 86400)], $adminSession, $request);
    $assert($activated['status'] === 'ACTIVE', 'activating a VIP moves it to ACTIVE');
    $assert($activated['rescueCodeStatus'] === 'NOT_ISSUED', 'with no membership record no code is invented');
    $assert($activated['rescueCoverage']['covered'] === true, 'the shared coverage engine grants the cover');
    $assert($activated['rescueCoverage']['plan']['code'] === 'VIP-FULL-PROTECT', 'coverage names the VIP plan');
    $assert($activated['rescueCoverage']['expiresAt'] !== null, 'the coverage window ends when the membership ends');

    // ---- Vehicles ----------------------------------------------------------
    $withVehicle = $vipService->linkVehicle([
        'vipSubscriberId' => $vipId, 'vehicleId' => $vehicleId, 'relationship' => 'OWNER', 'isPrimary' => true,
    ], $adminSession, $request);
    $assert(count($withVehicle['vehicles']) === 1, 'a vehicle links to the VIP');
    $assert($withVehicle['vehicles'][0]['isPrimary'] === true, 'the primary vehicle is recorded');
    $assert($withVehicle['vehicles'][0]['coverageStatus'] === 'ACTIVE', 'a linked vehicle inherits the membership coverage');
    $assert($withVehicle['vehicles'][0]['trackingStatus'] === 'NO_DEVICE', 'a vehicle with no device says NO_DEVICE, not ONLINE');
    $assert($withVehicle['vehicles'][0]['lastKnownPosition'] === null, 'a vehicle with no position has no position, not a stale one');

    $secondVehicleId = Uuid::v4();
    $database->prepare(
        'INSERT INTO vehicles (id, vehicle_type, registration_number, country_of_registration) VALUES (?, ?, ?, ?)'
    )->execute([$secondVehicleId, 'PRIVATE_CAR', 'VIP-TEST-002', 'CD']);
    $twoVehicles = $vipService->linkVehicle(['vipSubscriberId' => $vipId, 'vehicleId' => $secondVehicleId], $adminSession, $request);
    $assert(count($twoVehicles['vehicles']) === 2, 'a family membership may cover more than one vehicle');
    $thirdVehicleId = Uuid::v4();
    $database->prepare(
        'INSERT INTO vehicles (id, vehicle_type, registration_number, country_of_registration) VALUES (?, ?, ?, ?)'
    )->execute([$thirdVehicleId, 'PRIVATE_CAR', 'VIP-TEST-003', 'CD']);
    $expectRejection(
        static fn () => $vipService->linkVehicle([
            'vipSubscriberId' => $vipId, 'vehicleId' => $thirdVehicleId, 'isPrimary' => true,
        ], $adminSession, $request),
        422,
        'a second primary vehicle is refused'
    );
    $expectRejection(
        static fn () => $vipService->linkVehicle([
            'vipSubscriberId' => $vipId, 'vehicleId' => $secondVehicleId,
        ], $adminSession, $request),
        409,
        'linking the same vehicle twice is refused'
    );

    // ---- Dependants --------------------------------------------------------
    $withDependant = $vipService->addDependant([
        'vipSubscriberId' => $vipId, 'personId' => $dependantPersonId, 'relationship' => 'CHILD', 'rescueCovered' => true,
    ], $adminSession, $request);
    $assert(count($withDependant['dependants']) === 1, 'a dependant is added');
    $assert($withDependant['dependants'][0]['rescueCovered'] === true, 'dependant coverage is explicit');
    $assert($withDependant['dependants'][0]['name'] === 'Junior Kasongo', 'the dependant is a linked person, not a copy');

    // ---- Emergency profile is separate and flagged -------------------------
    $withProfile = $vipService->updateEmergencyProfile([
        'vipSubscriberId' => $vipId,
        'insuranceProvider' => 'Sonarwa',
        'accessibilityRequirements' => 'Wheelchair accessible transfer',
        'criticalNotes' => 'Travelling with oxygen concentrator.',
    ], $adminSession, $request);
    $assert($withProfile['emergencyProfileComplete'] === true, 'a completed emergency profile is flagged');
    $assert(
        !array_key_exists('criticalNotes', $withProfile),
        'health-adjacent detail is not spread across every VIP summary payload'
    );
    $stored = $database->prepare(
        'SELECT critical_notes, accessibility_requirements FROM vip_emergency_profiles WHERE vip_subscriber_id = :id'
    );
    $stored->execute(['id' => $vipId]);
    $profileRow = $stored->fetch();
    $assert($profileRow['critical_notes'] === 'Travelling with oxygen concentrator.', 'the detail is stored in the dedicated profile');

    // ---- Ownership ---------------------------------------------------------
    $expectRejection(
        static fn () => $vipService->show($vipId, $intruderSession),
        403,
        'an unrelated subscriber cannot read another VIP profile'
    );

    // ---- The VIP's own view ------------------------------------------------
    $owner = test_actor('CUSTOMER', ['password' => $password, 'firstName' => 'Vine', 'lastName' => 'Owner']);
    $database->prepare('UPDATE users SET person_id = :person WHERE id = :id')
        ->execute(['person' => $personId, 'id' => $owner['id']]);
    $ownView = $vipService->forSubscriber($session($owner));
    $assert($ownView['membership'] === true, 'a subscriber linked to the VIP sees their own membership');
    $assert(count($ownView['vehicles']) === 2, 'they see their covered vehicles');
    $assert($ownView['rescueCoverage']['covered'] === true, 'they see their real coverage state');

    // ---- Dashboard ---------------------------------------------------------
    $board = $vipService->dashboard([], $adminSession);
    $assert($board['metrics']['total'] >= 1, 'the VIP dashboard counts the profile');
    $assert($board['metrics']['active'] >= 1, 'the dashboard counts it as active');
    $assert($board['metrics']['covered'] >= 1, 'the dashboard counts it as covered');
    $assert($board['metrics']['coveredVehicles'] >= 1, 'the dashboard counts covered vehicles');
    $assert(is_array($board['byType']) && $board['byType'] !== [], 'the dashboard breaks VIPs down by membership type');
    $assert(is_array($board['byStatus']) && $board['byStatus'] !== [], 'the dashboard breaks VIPs down by status');

    $empty = $vipService->dashboard(['membershipType' => 'DRIVER'], $adminSession);
    $assert($empty['metrics']['total'] === 0, 'a filter that matches nothing reports zero');
    $assert($empty['message'] === 'No data available.', 'an empty result says so rather than implying zero is normal');

    // ---- Audit -------------------------------------------------------------
    $audits = (new AuditLog($database))->list(['entityType' => 'VipSubscriber', 'limit' => 10]);
    $actions = array_column($audits, 'action');
    foreach (['VIP_SUBSCRIBER_CREATED', 'VIP_ACTIVATED', 'VIP_VEHICLE_LINKED', 'VIP_DEPENDANT_ADDED'] as $action) {
        $assert(in_array($action, $actions, true), "the {$action} action is audited");
    }
} finally {
    if (is_string($vipId) && $vipId !== '') {
        $database->prepare(
            'DELETE FROM rescue_code_links WHERE rescue_code_id IN (SELECT rescue_code_id FROM vip_subscribers WHERE id = :id)'
        )->execute(['id' => $vipId]);
        $database->prepare('DELETE FROM rescue_coverage_links WHERE subscriber_id IN (SELECT id FROM subscribers WHERE person_id = :p)')
            ->execute(['p' => $personId]);
        $database->prepare('DELETE FROM rescue_coverage_links WHERE subject_id = :p')->execute(['p' => $personId]);
        $database->prepare('DELETE FROM rescue_codes WHERE subscriber_id IN (SELECT id FROM subscribers WHERE person_id = :p)')
            ->execute(['p' => $personId]);
        $database->prepare('DELETE FROM subscribers WHERE person_id = :p')->execute(['p' => $personId]);
        $database->exec("DELETE FROM vip_subscribers WHERE id = " . $database->quote($vipId));
    }
    $database->exec('DELETE FROM rescue_coverage_links WHERE vehicle_id = ' . $database->quote($vehicleId));
    $database->prepare('DELETE FROM vehicles WHERE id = :id')->execute(['id' => $vehicleId]);
    $database->exec("DELETE FROM vehicles WHERE registration_number LIKE 'VIP-TEST-%'");
    $database->prepare('DELETE FROM persons WHERE id = :id')->execute(['id' => $dependantPersonId]);
    $database->prepare('DELETE FROM persons WHERE id = :id')->execute(['id' => $personId]);
    $database->exec("DELETE FROM audit_logs WHERE entity_type IN ('VipSubscriber', 'RescueCode', 'RescueCoverage')");
    $database->exec("DELETE FROM users WHERE first_name IN ('Vip','Other','Vine') AND email LIKE '%@mamore.test'");
}

if ($failures !== []) {
    fwrite(STDERR, count($failures) . " assertion(s) failed.\n");
    exit(1);
}
