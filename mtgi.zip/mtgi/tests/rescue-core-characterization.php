<?php

declare(strict_types=1);

/**
 * Characterisation of the CURRENT rescue, tracking and incident behaviour.
 *
 * Written before the multi-domain work so every later change is provably
 * backward compatible. This pins the contract that the VIP, Truck and Private
 * Vehicle domains must extend rather than replace: the tracking board shape, the
 * position write path, the incident lifecycle, dispatch preconditions and the
 * nearest-asset maths.
 */

use Mamore\Auth\AuthException;
use Mamore\Core\AuditLog;
use Mamore\Core\Database;
use Mamore\Core\Request;
use Mamore\Rescue\RescueService;
use Mamore\Tracking\TrackingService;

require dirname(__DIR__) . '/bootstrap.php';
require __DIR__ . '/support.php';

$database = Database::connection();
$tracking = new TrackingService($database);
$rescue = new RescueService($database);

$failures = [];
$assert = static function (bool $condition, string $message) use (&$failures): void {
    if ($condition) {
        fwrite(STDOUT, "PASS: {$message}\n");
        return;
    }
    $failures[] = $message;
    fwrite(STDERR, "FAIL: {$message}\n");
};
$expectRejection = static function (callable $operation, int $status, string $message) use ($assert): void {
    try {
        $operation();
    } catch (AuthException $error) {
        $assert($error->status === $status, $message);
        return;
    }
    throw new RuntimeException("Expected rejection failed: {$message}");
};

$actor = test_actor('HQ_DISPATCHER', ['firstName' => 'Char', 'lastName' => 'Dispatch']);
$asset = $database->query("SELECT * FROM tracking_assets WHERE asset_type = 'SMARTBUS_VEHICLE' LIMIT 1")->fetch();
$assert(is_array($asset), 'a Smart Bus tracking asset exists');
$incidentIds = [];

try {
    // ---- Tracking board contract ----------------------------------------
    $board = $tracking->board();
    foreach (['metrics', 'assets', 'locations'] as $key) {
        $assert(array_key_exists($key, $board), "the tracking board still exposes {$key}");
    }
    foreach (['assets', 'live', 'stale', 'noSignal', 'locations'] as $key) {
        $assert(array_key_exists($key, $board['metrics']), "the tracking metrics still expose {$key}");
    }
    $assert(isset($board['assets'][0]['signalStatus']), 'each asset still reports a signal status');
    $assert(
        in_array($board['assets'][0]['signalStatus'], ['LIVE', 'STALE', 'NO_SIGNAL'], true),
        'signal status is still one of LIVE, STALE or NO_SIGNAL'
    );

    // ---- Position write contract ----------------------------------------
    $before = (int) $database->query('SELECT COUNT(*) FROM tracking_positions WHERE asset_id = ' . $database->quote($asset['id']))->fetchColumn();
    $position = $tracking->checkIn([
        'assetId' => $asset['id'],
        'latitude' => -11.6,
        'longitude' => 27.5,
        'speedKph' => 55,
        'heading' => 90,
        'accuracyMeters' => 8,
    ]);
    foreach (['assetId', 'latitude', 'longitude', 'speedKph', 'recordedAt'] as $key) {
        $assert(array_key_exists($key, $position), "a position write still returns {$key}");
    }
    $after = (int) $database->query('SELECT COUNT(*) FROM tracking_positions WHERE asset_id = ' . $database->quote($asset['id']))->fetchColumn();
    $assert($after === $before + 1, 'a valid position is appended to the history');
    $assert($position['latitude'] === -11.6 && $position['longitude'] === 27.5, 'the stored coordinates are returned exactly');

    $expectRejection(
        static fn () => $tracking->checkIn(['assetId' => $asset['id'], 'latitude' => 91, 'longitude' => 27.5]),
        422,
        'a latitude above 90 is refused'
    );
    $expectRejection(
        static fn () => $tracking->checkIn(['assetId' => $asset['id'], 'latitude' => -11.6, 'longitude' => -181]),
        422,
        'a longitude below -180 is refused'
    );
    $expectRejection(
        static fn () => $tracking->checkIn(['assetId' => $asset['id'], 'latitude' => -11.6, 'longitude' => 27.5, 'speedKph' => 400]),
        422,
        'a speed above the accepted maximum is refused'
    );
    $expectRejection(
        static fn () => $tracking->checkIn(['assetId' => '00000000-0000-4000-8000-000000000000', 'latitude' => -11.6, 'longitude' => 27.5]),
        404,
        'a position for an unknown asset is refused'
    );

    // ---- Nearest asset maths ---------------------------------------------
    $nearest = $tracking->nearest(-11.6647, 27.4794);
    $assert(is_array($nearest) && array_is_list($nearest), 'nearest() still returns a flat, ordered list');
    if ($nearest !== []) {
        $first = $nearest[0];
        foreach (['id', 'type', 'name', 'province', 'latitude', 'longitude', 'distanceKm'] as $key) {
            $assert(array_key_exists($key, $first), "each near result still exposes {$key}");
        }
        $assert((float) $first['distanceKm'] >= 0, 'distances are never negative');
        $assert($nearest[0]['distanceKm'] <= $nearest[count($nearest) - 1]['distanceKm'], 'results stay sorted by distance');
    } else {
        $assert(
            (int) $database->query("SELECT COUNT(*) FROM service_locations WHERE status='ACTIVE'")->fetchColumn() === 0,
            'an empty nearest result matches an empty active location table'
        );
    }

    // ---- Incident lifecycle contract -------------------------------------
    $reported = $rescue->report([
        'callerPhone' => '+243000000123',
        'callerName' => 'Characterisation Caller',
        'province' => 'HAUT_KATANGA',
        'location' => 'Near the Kasumbalesa border post',
        'description' => 'Characterisation incident for the rescue core contract.',
        'priority' => 'HIGH',
        'source' => 'PHONE',
    ], $actor);
    $incidentIds[] = $reported['id'];

    foreach (['id', 'code', 'status', 'priority', 'province', 'reportedAt'] as $key) {
        $assert(array_key_exists($key, $reported), "an incident still exposes {$key}");
    }
    $assert($reported['status'] === 'REPORTED', 'a new incident is REPORTED');
    $assert(str_starts_with((string) $reported['code'], 'INC-'), 'incident codes keep the INC- prefix');
    $assert($reported['unitId'] === null, 'a new incident has no unit assigned');

    $event = $database->prepare('SELECT * FROM rescue_incident_events WHERE incident_id = :id');
    $event->execute(['id' => $reported['id']]);
    $assert($event->fetch() !== false, 'reporting writes an incident event');

    $expectRejection(
        static fn () => $rescue->transition(['incidentId' => $reported['id'], 'status' => 'NONSENSE'], $actor),
        422,
        'an unknown incident status is refused'
    );

    // ---- Dispatch preconditions -------------------------------------------
    $unit = $database->query("SELECT * FROM rescue_units WHERE status = 'AVAILABLE' LIMIT 1")->fetch();
    $refused = false;
    try {
        $rescue->dispatch(['incidentId' => $reported['id'], 'unitId' => '00000000-0000-4000-8000-000000000000'], $actor);
    } catch (AuthException $error) {
        $refused = true;
    }
    $assert($refused, 'dispatching an unknown unit is refused');
    $stillReported = $database->query(
        'SELECT status, assigned_unit_id FROM rescue_incidents WHERE id = ' . $database->quote($reported['id'])
    )->fetch();
    $assert($stillReported['status'] === 'REPORTED' && $stillReported['assigned_unit_id'] === null, 'a refused dispatch leaves the incident untouched');

    $dispatched = $rescue->dispatch(['incidentId' => $reported['id'], 'unitId' => $unit['id']], $actor);
    $assert($dispatched['status'] === 'DISPATCHED', 'a reported incident can be dispatched');
    $assert($dispatched['unitCode'] === $unit['code'], 'the dispatched unit is returned with the incident');

    $unitStatus = $database->prepare('SELECT status FROM rescue_units WHERE id = :id');
    $unitStatus->execute(['id' => $unit['id']]);
    $assert($unitStatus->fetchColumn() === 'DISPATCHED', 'the dispatched unit is marked as such');

    $expectRejection(
        static fn () => $rescue->dispatch(['incidentId' => $reported['id'], 'unitId' => $unit['id']], $actor),
        409,
        'the same incident cannot be dispatched twice'
    );

    $expectRejection(
        static fn () => $rescue->transition(['incidentId' => $reported['id'], 'status' => 'RESOLVED'], $actor),
        409,
        'an incident cannot jump straight from DISPATCHED to RESOLVED'
    );

    foreach (['ACKNOWLEDGED', 'EN_ROUTE', 'ON_SCENE'] as $step) {
        $advanced = $rescue->transition(['incidentId' => $reported['id'], 'status' => $step], $actor);
        $assert($advanced['status'] === $step, "the incident advances to {$step}");
    }
    $resolved = $rescue->transition(['incidentId' => $reported['id'], 'status' => 'RESOLVED', 'notes' => 'Characterisation complete.'], $actor);
    $assert($resolved['status'] === 'RESOLVED', 'an incident on scene can be resolved');
    $assert($resolved['resolvedAt'] !== null, 'resolving stamps a timestamp');
    $expectRejection(
        static fn () => $rescue->transition(['incidentId' => $reported['id'], 'status' => 'EN_ROUTE'], $actor),
        409,
        'a resolved incident is terminal'
    );

    $events = $database->query(
        'SELECT event_type FROM rescue_incident_events WHERE incident_id = ' . $database->quote($reported['id']) . ' ORDER BY occurred_at ASC, id ASC'
    )->fetchAll(PDO::FETCH_COLUMN);
    $assert(count($events) >= 6, 'the incident event log records every lifecycle transition');
    $assert(in_array('UNIT_DISPATCHED', $events, true), 'the dispatch event is recorded');

    // ---- Audit ------------------------------------------------------------
    $audits = (new AuditLog($database))->list(['entityType' => 'Incident', 'limit' => 5]);
    $assert(is_array($audits), 'incidents remain auditable through the shared audit log');
} finally {
    foreach ($incidentIds as $incidentId) {
        $database->prepare('DELETE FROM rescue_incident_events WHERE incident_id = :id')->execute(['id' => $incidentId]);
        $database->prepare('DELETE FROM rescue_incidents WHERE id = :id')->execute(['id' => $incidentId]);
    }
    $database->exec("UPDATE rescue_units SET status = 'AVAILABLE' WHERE status = 'DISPATCHED'");
    $database->exec("DELETE FROM users WHERE first_name = 'Char' AND email LIKE '%@mamore.test'");
}

if ($failures !== []) {
    fwrite(STDERR, count($failures) . " assertion(s) failed.\n");
    exit(1);
}
