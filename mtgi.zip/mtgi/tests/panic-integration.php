<?php

declare(strict_types=1);

use Mamore\Alerts\PanicService;
use Mamore\Core\Database;
use Mamore\Core\Request;
use Mamore\Core\Uuid;

require dirname(__DIR__).'/bootstrap.php';
require __DIR__.'/support.php';
$database=Database::connection();$service=new PanicService($database);$role=$database->query("SELECT id FROM roles WHERE code='CUSTOMER'")->fetch();$admin=test_actor('HQ_DISPATCHER');
$failures = [];
$assert=static function(bool $condition,string $message)use(&$failures):void{if(!$condition){$failures[]=$message;fwrite(STDERR,"FAIL: {$message}\n");return;}fwrite(STDOUT,"PASS: {$message}\n");};
$id=Uuid::v4();$alert=null;$subscriberPhone='+243'.random_int(100000000,999999999);$database->prepare("INSERT INTO users(id,role_id,first_name,last_name,email,phone,password_hash,status,email_verified_at) VALUES(:id,:role,'SOS','Test',:email,:phone,:password,'ACTIVE',UTC_TIMESTAMP(6))")->execute(['id'=>$id,'role'=>$role['id'],'email'=>'sos-'.bin2hex(random_bytes(4)).'@mamore.test','phone'=>$subscriberPhone,'password'=>password_hash('PanicTestPassword!2026',PASSWORD_DEFAULT)]);$customer=$database->prepare('SELECT * FROM users WHERE id=:id');$customer->execute(['id'=>$id]);$customer=$customer->fetch();
try{$alert=$service->activate(['province'=>'HAUT_KATANGA','location'=>'Integration test location','latitude'=>-11.6647,'longitude'=>27.4794,'message'=>'Automated emergency test.'],$customer,new Request('POST','/api/portal/sos'));
$assert($alert['status']==='ACTIVE','subscriber can activate SOS');$board=$service->board();$assert($board['metrics']['active']>=1,'HQ receives active panic alert');$ack=$service->acknowledge($alert['id'],$admin);$assert($ack['status']==='ACKNOWLEDGED','dispatcher can acknowledge SOS');}
finally{if(is_array($alert)){$database->prepare("DELETE FROM user_notifications WHERE entity_type='PanicAlert' AND entity_id=:id")->execute(['id'=>$alert['id']]);$row=$database->prepare('SELECT rescue_incident_id FROM panic_alerts WHERE id=:id');$row->execute(['id'=>$alert['id']]);$incident=$row->fetchColumn();$database->prepare('DELETE FROM panic_alerts WHERE id=:id')->execute(['id'=>$alert['id']]);if($incident){$database->prepare('DELETE FROM rescue_incident_events WHERE incident_id=:id')->execute(['id'=>$incident]);$database->prepare('DELETE FROM rescue_incidents WHERE id=:id')->execute(['id'=>$incident]);}}$database->prepare('DELETE FROM users WHERE id=:id')->execute(['id'=>$id]);}

if ($failures !== []) {
    fwrite(STDERR, count($failures) . " assertion(s) failed.\n");
    exit(1);
}
