<?php

declare(strict_types=1);

/**
 * Contract test for the v2 core UI modules.
 *
 * The audit's most consequential defect was that a failed request rendered as a
 * zero ("Number(value || 0)" over a rejected fetch), which makes a dead endpoint
 * indistinguishable from a genuinely empty metric. Phase 05/06 fixes that in
 * assets/js/core/states.js and status.js, so the contract is asserted here
 * rather than trusted.
 *
 * There is no Node runtime in this project's CI, so these checks assert the
 * SHAPE and the ORDERING of the modules against the real database vocabulary
 * and the documented cascade, which are exactly the two things that silently
 * rot.
 *
 * What is asserted:
 *   1. The status tone table covers the statuses the schema actually uses, so
 *      no live status renders as "unknown".
 *   2. Freshness thresholds are ordered per domain, and "Live" is only ever
 *      used when a timestamp proves it.
 *   3. The four-state contract exists, and the error branch cannot fall through
 *      to a value.
 *   4. The shell loads the v2 layers in the documented cascade order.
 *
 * Usage: php tests/ui-v2-core-test.php
 */

require dirname(__DIR__) . '/bootstrap.php';

$root = dirname(__DIR__);
$failures = [];
$assert = static function (bool $condition, string $message) use (&$failures): void {
    if ($condition) {
        fwrite(STDOUT, "PASS: {$message}\n");
        return;
    }
    $failures[] = $message;
    fwrite(STDERR, "FAIL: {$message}\n");
};

$status = (string) file_get_contents($root . '/public/assets/js/core/status.js');
$states = (string) file_get_contents($root . '/public/assets/js/core/states.js');
$components = (string) file_get_contents($root . '/public/assets/css/components.css');
$html = (string) file_get_contents($root . '/public/app.html');

// --------------------------------------- 1. tone table covers real statuses ----
/**
 * Statuses that genuinely occur in the schema (CHECK constraints and enum
 * columns), not invented ones. A value missing from the table would still
 * render, as `unknown`, but would lose its colour semantics.
 */
$liveStatuses = [
    'ONLINE', 'OFFLINE', 'ACTIVE', 'INACTIVE', 'AVAILABLE', 'DISPATCHED',
    'EN_ROUTE', 'RESOLVED', 'CLOSED', 'ACKNOWLEDGED', 'CRITICAL',
    'HIGH', 'MEDIUM', 'LOW', 'PENDING', 'EXPIRED', 'SUSPENDED',
    'CANCELLED', 'RENEWED', 'PAID', 'UNPAID', 'VOID', 'IN_TRANSIT', 'IDLE',
    'NO_DEVICE', 'NO_POSITION', 'DELAYED', 'SCHEDULED', 'BOARDING', 'DEPARTED',
    'COMPLETED', 'COVERED', 'READY', 'DEGRADED', 'STALE',
];

$assert(str_contains($status, 'const TONES'), 'status.js declares a single TONES lookup');
$assert(str_contains($status, "|| 'unknown'"), 'an unmapped status falls through to unknown rather than vanishing');

$missingTones = [];
foreach ($liveStatuses as $value) {
    if (preg_match('/\b' . preg_quote($value, '/') . "\s*:\s*'(?:success|info|warning|danger|neutral)'/", $status) !== 1) {
        $missingTones[] = $value;
    }
}

$assert(
    $missingTones === [],
    'every live database status has a tone (' . (count($liveStatuses) - count($missingTones)) . '/' . count($liveStatuses) . ')'
        . ($missingTones === [] ? '' : '; missing: ' . implode(', ', array_unique($missingTones)))
);

// ------------------------------------------------- 2. freshness thresholds ----
$assert(str_contains($status, 'FRESHSESS_NOT_A_TOKEN') === false, 'no placeholder left in the freshness table');
$assert(str_contains($status, 'FRESHNESS_BY_DOMAIN'), 'freshness thresholds are per-domain, not guessed per screen');
$assert(str_contains($status, 'const FRESHNESS = {'), 'a default freshness table exists');

// live < delayed < stale must hold for every domain, otherwise a value could be
// classified as stale before it was ever "delayed".
preg_match_all('/(\w+):\s*\{\s*live:\s*(\d+),\s*delayed:\s*(\d+),\s*stale:\s*(\d+)/', $status, $limits, PREG_SET_ORDER);
$assert($limits !== [], 'the freshness limits are machine-readable');

$ordered = true;
foreach ($limits as $row) {
    if (!((int) $row[2] < (int) $row[3] && (int) $row[3] < (int) $row[4])) {
        $ordered = false;
        fwrite(STDERR, "  unordered: {$row[1]} live={$row[2]} delayed={$row[3]} stale={$row[4]}\n");
    }
}
$assert($ordered, 'every domain orders live < delayed < stale');

$assert(
    str_contains($status, "state === 'live'"),
    'the Live label is gated on the computed state, not asserted by markup'
);

// Comments legitimately discuss the old hard-coded badges, so the check counts
// "Live" in CODE only. The assertion is that the string literal appears exactly
// once, inside the ternary -- a second occurrence would be an unconditional
// badge, which is the defect this module exists to remove.
$statusCode = (string) preg_replace('!/\*.*?\*/!s', '', $status);
$statusCode = (string) preg_replace('!^\s*//.*$!m', '', $statusCode);
$assert(
    substr_count($statusCode, '`Live · ${label}`') === 1,
    'the string "Live" appears exactly once, in the state-gated template'
);
$assert(
    preg_match("/['\"]Live['\"]/", $statusCode) !== 1,
    'there is no bare "Live" string literal that could render unconditionally'
);

// --------------------------------------------- 3. the four-state contract ----
foreach (['skeleton', 'empty', 'error', 'ready'] as $state) {
    $assert(str_contains($states, "const {$state} ="), "states.js implements the {$state} state");
}
$assert(str_contains($states, "case 'error'"), 'render() handles the error state explicitly');
$assert(str_contains($states, 'isObject(payload) ? payload'), 'an error payload overrides the default copy');
$assert(
    strpos($states, "case 'error'") < strpos($states, "case 'ready'"),
    'the error branch precedes ready, so a failure cannot fall through to a value'
);

// A failure must never emit a figure that could be read as a value.
$assert(
    preg_match('/error-state__title">\s*[\d,.]/', $states) !== 1,
    'the error state never renders a number as its title'
);

// Comments are allowed to name the banned phrases in order to explain why they
// are banned, so the check runs against code with comments stripped.
$statesCode = (string) preg_replace('!/\*.*?\*/!s', '', $states);
$statesCode = (string) preg_replace('!^\s*//.*$!m', '', $statesCode);

foreach (['No data available', 'No Data', 'N/A'] as $banned) {
    $assert(
        stripos($statesCode, $banned) === false,
        sprintf('the empty state never emits the banned phrase "%s"', $banned)
    );
}
$assert(
    str_contains($statesCode, "title = options.title || 'Nothing here yet'"),
    'the empty state always states what the area is, rather than defaulting to a shrug'
);

foreach (['.skeleton', '.empty-state', '.error-state', '.metric', '.card', '.btn--danger', '.action-center', '.pulse'] as $component) {
    $assert(str_contains($components, $component), "components.css defines {$component}");
}

// Status colour must be semantic: no component hard-codes a status colour.
preg_match_all('/#[0-9a-f]{3,8}\b/i', $components, $hexes);
$hardCoded = array_values(array_filter(
    array_map('strtolower', $hexes[0]),
    static fn (string $hex): bool => !in_array($hex, ['#fff', '#ffffff'], true)
));
$assert(
    $hardCoded === [],
    'components.css hard-codes no colours beyond white-on-brand text'
        . ($hardCoded === [] ? '' : '; found: ' . implode(', ', array_unique($hardCoded)))
);

// --------------------------------------------------- 4. cascade order ----
/**
 * The order is load-bearing and is asserted explicitly, because reversing
 * tokens.css and app.css silently breaks the legacy alias layer and nothing
 * would fail visibly at runtime.
 */
$order = [
    '/assets/css/base.css',
    '/assets/css/typography.css',
    '/assets/app.css',
    '/assets/css/tokens.css',
    '/assets/css/themes/light.css',
    '/assets/css/themes/dark.css',
    '/assets/css/layout.css',
    '/assets/css/components.css',
    '/assets/css/utilities.css',
];

$positions = [];
$last = -1;
$ordered = true;
foreach ($order as $href) {
    $position = strpos($html, $href);
    if ($position === false || $position < $last) {
        $ordered = false;
        fwrite(STDERR, "  out of order or missing: {$href}\n");
        break;
    }
    $positions[$href] = $position;
    $last = $position;
}
$assert($ordered, 'the shell loads the v2 layers in the documented cascade order');

$assert(
    $positions['/assets/app.css'] < $positions['/assets/css/tokens.css'],
    'tokens.css loads AFTER app.css so the legacy alias block wins the cascade'
);
$assert(
    $positions['/assets/css/utilities.css'] > $positions['/assets/css/components.css'],
    'utilities.css is last so a utility beats a component rule'
);

// Theme files must not use a bare :root, or link order would decide the theme.
foreach (['light', 'dark'] as $theme) {
    $css = (string) file_get_contents($root . "/public/assets/css/themes/{$theme}.css");
    $assert(
        preg_match('/(?:^|[\};])\s*:root\s*[,{]/m', $css) !== 1,
        "themes/{$theme}.css binds to [data-theme], not a bare :root"
    );
}

// The new core modules must be linked from the shell.
foreach (['/assets/js/core/theme.js', '/assets/js/core/status.js', '/assets/js/core/states.js'] as $script) {
    $assert(str_contains($html, $script), "the shell loads {$script}");
}

// ------------------------------------------------------------- summary ----
fwrite(STDOUT, "\n");
if ($failures !== []) {
    fwrite(STDERR, count($failures) . " failure(s):\n");
    foreach ($failures as $failure) {
        fwrite(STDERR, '  - ' . $failure . "\n");
    }
    exit(1);
}

fwrite(STDOUT, "All v2 core UI assertions passed.\n");
