<?php

declare(strict_types=1);

use Mamore\Admin\UserAdminService;
use Mamore\Core\Database;
use Mamore\Core\Request;

require dirname(__DIR__) . '/bootstrap.php';
require __DIR__ . '/support.php';

$database = Database::connection();
$service = new UserAdminService($database);
$roles = $service->roles();
$failures = [];
$assert = static function (bool $condition, string $message) use (&$failures): void {
    if (!$condition) { $failures[] = $message; fwrite(STDERR, "FAIL: {$message}\n"); return; }
    fwrite(STDOUT, "PASS: {$message}\n");
};

$assert(count($roles) >= 1, 'roles are available');
$actor = test_actor('SYSTEM_ADMIN');
$assert(is_array($actor), 'active actor is available');

$database->beginTransaction();
try {
    $request = new Request('POST', '/api/admin/users/create', [], [], '127.0.0.1', 'Mamore integration test');
    $email = 'integration-' . bin2hex(random_bytes(5)) . '@mamore.test';
    $created = $service->create([
        'firstName' => 'Test', 'lastName' => 'Operator', 'email' => $email,
        'password' => 'SafeTestPassword!2026', 'roleId' => $roles[0]['id'], 'status' => 'ACTIVE',
    ], $actor, $request);
    $assert($created['email'] === $email, 'administrator can create user');

    $updated = $service->update([
        'userId' => $created['id'], 'roleId' => $roles[0]['id'], 'status' => 'SUSPENDED',
    ], $actor, $request);
    $assert($updated['status'] === 'SUSPENDED', 'administrator can change user status');
    $assert(count($service->users($email)) === 1, 'user search returns expected account');
} finally {
    $database->rollBack();
}

if ($failures !== []) {
    fwrite(STDERR, count($failures) . " assertion(s) failed.\n");
    exit(1);
}
