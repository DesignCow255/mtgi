<?php

declare(strict_types=1);

/**
 * Trip notifications (M, N) and pilot analytics (Y, Z).
 *
 * Two promises are under test: messages are never reported as sent when no
 * provider exists, and no analytic figure is ever invented - an empty data set
 * must answer "No data available" rather than a plausible zero.
 */

use Mamore\Auth\AuthException;
use Mamore\Core\Database;
use Mamore\Core\ServerClock;
use Mamore\SmartBus\PilotAnalyticsService;
use Mamore\SmartBus\SmartBusService;
use Mamore\SmartBus\TripNotificationService;

require dirname(__DIR__) . '/bootstrap.php';
require __DIR__ . '/support.php';

$database = Database::connection();
$bus = new SmartBusService($database);
$notifications = new TripNotificationService($database);
$analytics = new PilotAnalyticsService($database);

$failures = [];
$assert = static function (bool $condition, string $message) use (&$failures): void {
    if ($condition) {
        fwrite(STDOUT, "PASS: {$message}\n");
        return;
    }
    $failures[] = $message;
    fwrite(STDERR, "FAIL: {$message}\n");
};
$expectRejection = static function (callable $operation, int $status, string $message) use ($assert): void {
    try {
        $operation();
    } catch (AuthException $error) {
        $assert($error->status === $status, $message);
        return;
    }
    throw new RuntimeException("Expected rejection failed: {$message}");
};

$admin = test_actor('SYSTEM_ADMIN', ['firstName' => 'Pilot', 'lastName' => 'Admin']);
$auditor = test_actor('AUDITOR', ['firstName' => 'Pilot', 'lastName' => 'Auditor']);
$passenger = test_actor('CUSTOMER', ['firstName' => 'Pilot', 'lastName' => 'Rider']);
$tripIds = [];

try {
    // ---- Empty platform answers honestly ---------------------------------
    $empty = $analytics->summary(['from' => gmdate('Y-m-d', strtotime('-1 day')), 'to' => gmdate('Y-m-d', strtotime('-1 day'))]);
    $assert($empty['metrics']['bookings'] === 0, 'a window with no activity reports zero bookings');
    $assert($empty['rates']['paymentSuccessRate'] === null, 'a rate with no denominator is null, not zero');
    $assert($empty['occupancy']['message'] === 'No data available.', 'occupancy says "No data available" with no trips');
    $assert($empty['revenue']['totalCdf'] === '0.00', 'revenue totals are exact decimals');

    $rescue = $analytics->rescueResponse();
    $assert($rescue['message'] === null || $rescue['incidents'] >= 0, 'rescue response reports a count');
    $assert(
        $rescue['avgDispatchMinutes'] === null || is_float($rescue['avgDispatchMinutes']),
        'average dispatch time is null or a real number, never a placeholder'
    );

    foreach ($analytics->insights() as $name => $report) {
        $assert(is_array($report) && array_key_exists('message', $report), "the {$name} insight reports an explicit message");
        $assert(is_array($report['rows']), "the {$name} insight returns rows or an empty set");
    }

    $expectRejection(
        static fn () => $analytics->summary(['from' => 'not-a-date']),
        422,
        'an invalid filter date is rejected rather than silently ignored'
    );

    // ---- Real trip produces real numbers ---------------------------------
    // The suite runs with demo data present, so every figure below is asserted
    // as a DELTA against this baseline, never as an absolute total.
    $baseline = $analytics->summary();
    $baseline['insights'] = $analytics->insights();
    $board = $bus->board();
    $departure = (new DateTimeImmutable('+2 days'))->setTime(8, 30);
    $trip = $bus->schedule([
        'routeId' => $board['routes'][0]['id'],
        'vehicleId' => $board['vehicles'][0]['id'],
        'departureAt' => $departure->format('Y-m-d H:i:s'),
        'usdCdfRate' => 2850,
    ], $admin);
    $tripIds[] = $trip['id'];

    $window = Mamore\SmartBus\BoardingWindow::derive($trip['departureAt'], [
        'reporting_minutes_before_departure' => 45,
        'boarding_open_minutes_before_departure' => 20,
        'boarding_close_minutes_before_departure' => 10,
    ]);
    $database->prepare(
        'UPDATE smartbus_trips SET reporting_at = :r, boarding_opens_at = :o, boarding_closes_at = :c, delay_minutes = 22 WHERE id = :id'
    )->execute([
        'r' => $window['reporting_at'], 'o' => $window['boarding_opens_at'],
        'c' => $window['boarding_closes_at'], 'id' => $trip['id'],
    ]);

    $booking = $bus->book([
        'tripId' => $trip['id'], 'passengerName' => 'Pilot Rider',
        'passengerPhone' => '+243000000555', 'seatNumber' => 2,
    ], $admin);
    $database->prepare('UPDATE smartbus_bookings SET user_id = :user, vip_at_booking = 1 WHERE id = :id')
        ->execute(['user' => $passenger['id'], 'id' => $booking['id']]);
    $database->prepare(
        "INSERT INTO finance_transactions (id, receipt_number, smartbus_booking_id, transaction_type, payment_method,
            currency, amount, usd_cdf_rate, amount_cdf, expected_cdf, variance_cdf, status, received_by_user_id)
         VALUES (:id, :receipt, :booking, 'SMARTBUS_PAYMENT', 'MOBILE_MONEY', 'CDF', :amount, 2850, :cdf, :expected, 0,
                 'RECONCILED', :actor)"
    )->execute([
        'id' => \Mamore\Core\Uuid::v4(), 'receipt' => 'TX-PILOT-1', 'booking' => $booking['id'],
        'amount' => $booking['totalCdf'], 'cdf' => $booking['totalCdf'], 'expected' => $booking['totalCdf'],
        'actor' => $admin['id'],
    ]);

    // ---- Notification schedule is derived from the trip's own times ------
    $schedule = $notifications->scheduleForBooking($booking['id']);
    $assert(count($schedule['messages']) === 7, 'the reminder ladder has the seven scheduled steps');
    $assert($schedule['board']['phase'] !== '', 'the booking carries the boarding phase');
    $events = array_column($schedule['messages'], 'event');
    $assert(in_array('REPORT_AT_STATION', $events, true), 'the ladder includes the reporting-time message');
    $assert(in_array('BOARDING_OPEN', $events, true), 'the ladder includes boarding open');
    $assert(in_array('BOARDING_CLOSING_SOON', $events, true), 'the ladder includes the closing warning');
    $assert(in_array('TRIP_REMINDER_24H', $events, true), 'the ladder starts with the 24 hour reminder');
    $interpolated = array_values(array_filter(array_column($schedule['messages'], 'body'), static fn ($body): bool => is_string($body) && !str_contains($body, '{{')));
    $assert($interpolated !== [], 'template placeholders are filled with real values');

    // Nothing is due yet (departure is two days out), so only the immediate slot queues.
    $queued = $notifications->scheduleForTrip($trip['id'], $admin);
    $assert($queued['provider']['configured'] === false, 'the message provider is honestly reported as not configured');
    $assert($queued['provider']['status'] === 'NOT_CONFIGURED', 'the provider status is explicit');
    $assert($queued['queued'] === [], 'no future reminder is queued before it is due');

    // Backdate the trip so the whole ladder is due.
    // Move the entire schedule back so every reminder is genuinely due; leaving
    // the boarding windows in the future would (correctly) queue nothing.
    $database->prepare(<<<'SQL'
        UPDATE smartbus_trips SET departure_at = DATE_SUB(UTC_TIMESTAMP(6), INTERVAL 10 MINUTE),
                                 reporting_at = DATE_SUB(UTC_TIMESTAMP(6), INTERVAL 55 MINUTE),
                                 boarding_opens_at = DATE_SUB(UTC_TIMESTAMP(6), INTERVAL 30 MINUTE),
                                 boarding_closes_at = DATE_SUB(UTC_TIMESTAMP(6), INTERVAL 20 MINUTE)
        WHERE id = :id
        SQL)->execute(['id' => $trip['id']]);
    $due = $notifications->scheduleForTrip($trip['id'], $admin);
    $assert(count($due['queued']) === 7, 'every due reminder is queued once the trip is imminent');
    $assert(in_array('BOARDING_OPEN', $due['queued'], true), 'boarding open is queued when due');

    $again = $notifications->scheduleForTrip($trip['id'], $admin);
    $assert($again['queued'] === [], 're-running the schedule queues nothing twice');
    $assert(count($again['skippedAsAlreadyQueued']) === 7, 'already queued messages are reported as skipped');

    $outbox = $notifications->outboxForTrip($trip['id']);
    $sent = array_filter($outbox['messages'], static fn (array $message): bool => $message['status'] === 'SENT');
    $assert($sent === [], 'no message is marked SENT while no provider exists');
    $assert(count($outbox['messages']) === 7, 'the outbox holds the whole ladder');
    $assert($outbox['messages'][0]['bookingReference'] === $booking['reference'], 'each message is tied to its booking');
    $assert(
        $database->query("SELECT COUNT(*) FROM user_notifications WHERE notification_type = 'BOARDING_OPEN'")->fetchColumn() >= 0,
        'in-app notifications are written for the working channel'
    );

    // ---- Analytics now report the real activity --------------------------
    $after = $analytics->summary();
    $assert(
        $after['metrics']['bookings'] === $baseline['metrics']['bookings'] + 1,
        'the new booking is counted (a delta of one against the baseline)'
    );
    $assert(
        $after['metrics']['boarded'] === $baseline['metrics']['boarded'],
        'nobody has boarded yet, so the boarding count is unchanged'
    );
    $assert(
        $after['metrics']['vipPassengers'] === $baseline['metrics']['vipPassengers'] + 1,
        'the VIP passenger is counted'
    );
    $assert(
        $after['metrics']['delayedTrips'] === $baseline['metrics']['delayedTrips'] + 1,
        'the delayed trip is counted'
    );
    $assert(
        bccomp($after['revenue']['totalCdf'], $baseline['revenue']['totalCdf'], 2) > 0,
        'revenue increased by the real booking amount'
    );
    $assert($after['message'] === null, 'with data present there is no "no data available" message');
    $assert($after['generatedAt'] !== '', 'the summary is timestamped from the server clock');
    $assert(is_float($after['rates']['boardRate']) || $after['rates']['boardRate'] === null, 'rates are real numbers or explicitly null');

    $insights = $analytics->insights();
    $assert($insights['busiestRoutes']['count'] >= 1, 'the busiest-route insight finds routes with passengers');
    $sum = static function (array $rows): int {
        return array_sum(array_map(static fn (array $row): int => (int) $row['passengers'], $rows));
    };
    $assert(
        $sum($insights['busiestRoutes']['rows']) === $sum($baseline['insights']['busiestRoutes']['rows']) + 1,
        'the route passenger total grows by exactly this booking'
    );
    $assert($insights['lateTrips']['count'] >= 1, 'the delayed-trip insight sees the delay');
    $assert($insights['weakRescueCoverage']['count'] >= 1, 'rescue coverage by route is answered from real assets');
    $assert($insights['gpsHealth']['count'] >= 1, 'GPS health per operator is answered from the fleet records');

    // Filters must actually filter.
    $narrow = $analytics->summary(['from' => gmdate('Y-m-d', strtotime('-3 days')), 'to' => gmdate('Y-m-d', strtotime('-2 days'))]);
    $assert($narrow['metrics']['trips'] === 0, 'a window with no departures reports no trips');
    $assert($narrow['rates']['paymentSuccessRate'] === null, 'a window with no bookings has no success rate');
    $assert(
        $narrow['metrics']['bookings'] <= $after['metrics']['bookings'],
        'a narrower window cannot report more bookings than the full one'
    );
} finally {
    foreach ($tripIds as $tripId) {
        $database->prepare('DELETE FROM user_notifications WHERE entity_id = :id')->execute(['id' => $tripId]);
        $database->prepare('DELETE FROM message_outbox WHERE related_type = :type AND related_id = :id')->execute(['type' => 'TRIP', 'id' => $tripId]);
        $database->prepare('DELETE FROM audit_logs WHERE entity_id = :id')->execute(['id' => $tripId]);
        $database->prepare('DELETE a FROM finance_allocations a JOIN finance_transactions f ON f.id = a.transaction_id WHERE f.smartbus_booking_id IN (SELECT id FROM smartbus_bookings WHERE trip_id = :t)')->execute(['t' => $tripId]);
        $database->prepare('DELETE FROM finance_transactions WHERE smartbus_booking_id IN (SELECT id FROM smartbus_bookings WHERE trip_id = :t)')->execute(['t' => $tripId]);
        $database->prepare('DELETE FROM smartbus_bookings WHERE trip_id = :t')->execute(['t' => $tripId]);
        $database->prepare('DELETE FROM smartbus_trips WHERE id = :t')->execute(['t' => $tripId]);
    }
    $database->exec("DELETE FROM user_notifications WHERE notification_type IN ('BOARDING_OPEN','TRIP_STARTED')");
    $database->exec("DELETE FROM audit_logs WHERE action = 'TRIP_NOTIFICATIONS_SCHEDULED'");
    $database->exec("DELETE FROM users WHERE first_name = 'Pilot' AND email LIKE '%@mamore.test'");
}

if ($failures !== []) {
    fwrite(STDERR, count($failures) . " assertion(s) failed.\n");
    exit(1);
}
