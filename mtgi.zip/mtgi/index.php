<?php

declare(strict_types=1);

/**
 * Front controller for deployments that serve the project from a sub-directory.
 *
 * The application itself is written against a "public/" document root, which is
 * what the built-in server (`php -S ... -t public`) and a dedicated vhost use.
 * MAMP instead publishes /Applications/MAMP/htdocs, so the project is reached
 * at /mtgi/ and the document root is the project directory rather than public/.
 *
 * This file bridges the two: it is the entry point Apache rewrites to, and it
 * hands straight over to the real front controller, which reads its routes and
 * its app.html from public/ exactly as it always has.
 */

require __DIR__ . '/public/index.php';
