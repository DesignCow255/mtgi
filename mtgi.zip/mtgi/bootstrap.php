<?php

declare(strict_types=1);

use Mamore\Core\Env;

spl_autoload_register(static function (string $class): void {
    $prefix = 'Mamore\\';
    if (!str_starts_with($class, $prefix)) {
        return;
    }

    $relative = substr($class, strlen($prefix));
    $path = __DIR__ . '/app/' . str_replace('\\', '/', $relative) . '.php';
    if (is_file($path)) {
        require $path;
    }
});

Env::load(__DIR__ . '/.env');
date_default_timezone_set(Env::get('APP_TIMEZONE', 'Africa/Lubumbashi'));
Env::validateProduction();
