# Mamore — Screen Inventory

Every surface a human can reach today, with its data source and the loader that
fills it. **Preservation status** marks what must keep working identically.

---

## 1. Authentication surface (5 forms, one shell)

`#login-view` is a 2-column split: a navy brand story panel (left) and the form
stack (right). Forms swap in place via `hidden`; there are no routes.

| # | Form | Purpose | Loader |
| --- | --- | --- | --- |
| 1 | `#login-form` | Staff + customer sign-in, email/password | `app.js` |
| 2 | `#register-form` | Subscriber self-registration | `subscriptions.js` |
| 3 | `#verify-form` | 6-digit email OTP activation, 10-min expiry | `subscriptions.js` |
| 4 | `#forgot-form` | Request a password reset code | `subscriptions.js` |
| 5 | `#reset-form` | Set a new password from a reset code | `subscriptions.js` |

Backend: `POST /api/auth/{login,register-subscriber,verify-otp,resend-otp,
forgot-password,reset-password}`.

## 2. Staff application shell

`#app-view` = CSS grid `16rem / 1fr`: a sticky navy `.sidebar` + `.workspace`
containing `.topbar` and `#main.content`.

The **topbar** currently holds: page title `#page-title`, an account block
(`#user-name`, `#account-role`), a logout button, and a refresh button. Nothing
else — no search, no language, no currency, no theme, no notification bell
(the Notifications *panel* exists but has no topbar affordance).

Sidebar = 18 staff buttons in 3 groups, 6 customer buttons in 1 group, toggled
by `.admin-only` / `.customer-only` on `showApp()`. State is **not** in the URL.

## 3. Staff panels (19)

| Panel id | Label today | Domain | Loader | Notes |
| --- | --- | --- | --- | --- |
| `overview` | Overview | Dash | `loadDashboard` | 4 metrics + users-by-role + logins. **Auth counts, not operations.** |
| `sessions` | Security & sessions | Auth | `loadSessions` | Active device list, revoke |
| `users` | User administration | Adm | `loadUsers` | Create/edit, role + status |
| `rescue` | Rescue operations | Rescue | `loadRescue` | 4 KPIs, incident board, unit board, dispatch dialog |
| `alerts` | Panic alerts | Alerts | `loadPanicAlerts` | SOS intake, acknowledge |
| `tracking` | Live tracking | Tracking | `loadTracking` | **A `<dl>` of coordinates, not a map** |
| `mobility` | Smart mobility | SmartBus | `loadMobility` | Operators, trips, booking dialog |
| `boarding` | Boarding & manifest | SmartBus | `loaders.boarding` | Check-in / board / complete / no-show |
| `command` | Command centre (Pilot) | SmartBus | `loaders.command` | Pilot analytics + live trips |
| `finance` | Smart Bus finance | Finance | `loadFinance` | Collected, rescue fund, variance, unpaid |
| `subscriptions` | Rescue subscriptions | Subs | `loaders.subscriptions` | USD-only fee catalog, quote, renew |
| `receipts` | Receipts | Finance | `loaders.receipts` | List + public verification code |
| `audit` | Audit trail | Audit | `loaders.audit` | Filter by action/entity |
| `notifications` | Notifications | Alerts | `loaders.notifications` | Read / read-all |
| `operations` | **Rescue operations** (dup) | Rescue | `loaders.operations` | Control Center board — duplicate label |
| `analytics` | Operational intelligence | Analytics | `loaders.analytics` | Cross-domain, `.domain-bars` only |
| `vip` | VIP subscribers | VIP | `loaders.vip` | KPIs, activity, plan mix |
| `truckcargo` | Truck & cargo | Truck | `loaders.truckcargo` | Fleet, journeys, consignments, cargo |
| `privatevehicles` | My vehicles | Private | `loaders.privatevehicles` | Subscriber vehicle list |
| `coming` | — | — | none | Empty placeholder panel |

## 4. Customer portal panels (5)

`customer-only`, shown when `user.role === 'CUSTOMER'`.

| Panel id | Purpose | Loader |
| --- | --- | --- |
| `portal` | Browse trips, book a seat | `loadPortalTrips` |
| `mybookings` | Own tickets, seats, payment, rescue cover | `loadMyBookings` |
| `membership` | Own rescue subscriptions, buy cover | `loaders.membership` |
| `privatevehicles` | Own private vehicles, raise an emergency | `loaders.privatevehicles` |
| `sessions` / `notifications` | Shared with staff | as above |

Ownership is enforced server-side by `SubscriberOwnershipPolicy`.

## 5. Overlays (15 `<dialog>` + 1 toast)

All are native `<dialog>` elements — good, they give focus trapping and Esc for
free. **All open with a single click and none ask for confirmation.**

| Dialog | Purpose | Danger? |
| --- | --- | --- |
| `incident-dialog` | Emergency intake: source, priority, caller, location, lat/lng | — |
| `dispatch-dialog` | Assign a rescue unit to an incident | yes (irreversible) |
| `user-dialog` | Create / edit a user, role + status | **yes (privilege escalation)** |
| `subscription-dialog` | Open a cover subscription (multi-field) | yes (billing) |
| `subscription-payment-dialog` | Record a payment, optional USD/CDF rate | **yes (financial)** |
| `payment-dialog` | Receive a Smart Bus payment | **yes (financial)** |
| `buy-cover-dialog` | Customer self-service cover purchase | yes (billing) |
| `receipt-dialog` | Post-payment receipt summary | — |
| `ticket-dialog` | Issued ticket + QR payload | — |
| `booking-dialog` | Seat selection for a trip | — |
| `trip-dialog` | Schedule a trip | — |
| `position-dialog` | Manual GPS check-in | — |
| `location-dialog` | Add a service location (station/hospital/garage) | — |
| `sos-dialog` | Customer emergency request | — |
| `detail-dialog` | Generic record preview + print link | — |
| `#toast` | Single transient message, 2 800 ms, no queue, no variants | — |

## 6. Print surfaces (2)

- `/receipts/print?code=` — public, verification-code gated, `receipt.css` has
  the only `@media print` block in the product.
- `resources/views/receipts/print.php` — server-rendered receipt.

These are the only genuinely server-rendered HTML in the application. The layout
at `resources/views/layouts/app.php` is a 13-line stub.

## 7. Data-loading inventory

| Surface | Endpoint | Refresh |
| --- | --- | --- |
| Overview | `GET /api/admin/dashboard` | manual |
| Rescue | `GET /api/rescue/board` | manual |
| Alerts | `GET /api/alerts/board` | manual |
| Tracking | `GET /api/tracking/board` | manual |
| Mobility | `GET /api/smartbus/board` | manual |
| Finance | `GET /api/finance/board` | manual |
| Control Center | `GET /api/control-center/operations` | manual |
| Analytics | `GET /api/analytics/global` | manual |
| VIP | `GET /api/vip/dashboard` | manual |
| Truck/Cargo | `GET /api/truck-cargo/analytics` | manual |
| Private | `GET /api/private-vehicles/analytics` | manual |

**Every refresh is a manual button click.** No polling, no SSE, no WebSocket, and
no "updated N seconds ago" indicator anywhere. `ServerClock` is plumbed into
`/ready` and `smartbus-v2.js` but never surfaced to the operator.

## 8. Navigation is data, not markup

**Status: implemented in Phase 07/08/09.**

`app/Core/Navigation.php` + `GET /api/navigation` + `public/assets/js/core/shell.js`.
The sidebar is rendered from the server response.

### Why the server decides

The audit found the old sidebar hard-coded 18 staff entries in `app.html` and
gated them only on `role === 'CUSTOMER'`. Any non-customer — including a
**DRIVER** or a **CONDUCTOR** — was offered the entire operations platform.
Navigation is the first thing a user learns about a product; offering 18
destinations to someone whose job is one of them teaches them the interface does
not know who they are.

Measured effect, same database, before and after:

| Role | Destinations before | After | Domains |
| --- | --- | --- | --- |
| SYSTEM_ADMIN | 18 | 19 | 5 |
| HQ_DISPATCHER | 18 | 12 | 5 |
| FINANCE_MANAGER | 18 | 12 | 3 |
| RESCUE_OPERATOR | 18 | 9 | 5 |
| BUS_OPERATOR | 18 | 7 | 2 |
| AUDITOR | 18 | 11 | 5 |
| **CONDUCTOR** | **18** | **4** | **1** |
| **DRIVER** | **18** | **4** | **0** |
| CUSTOMER | 6 | 6 | 0 |

A group with no permitted items is omitted entirely rather than left as an empty
heading.

### It is presentation, not security

`Navigation` grants nothing. Every route still calls
`AuthService::requirePermission()` and still filters in SQL. The class only
decides what is *offered*, so the correct action is the easy one. Hiding a
control the server would reject is a usability decision; **refusing the action is
the service layer's job and is unchanged.**

### Why not put permissions in `publicUser()`

That would have been fewer lines, but it ships the full 57-permission vocabulary
to the browser on every login and makes the client's filtering look
authoritative. A dedicated endpoint keeps the decision where the data is, and
keeps `publicUser()` — and every test that depends on it — untouched.

### The duplicate is gone

`operations` was labelled "Rescue operations", duplicating `rescue`. It is the
cross-domain Control Center and is now named for what it shows.

### URL state

`switchPanel` used to mutate no history, so no view was linkable, nothing
survived a refresh, and the back button walked out of the app. The panel now
lives in `?panel=`, written with `replaceState` rather than `pushState` (a back
button full of panel switches is worse than none). Filter and search state is
Phase 13.

### Test impact

`tests/ui-wiring-test.php` asserted `data-panel="…"` literals in `app.html`.
Navigation is no longer static markup, so those assertions now check
`app/Core/Navigation.php` — a stronger guarantee, since it is the same source the
server renders from. A new check asserts that **every declared destination has a
real panel**, so nobody can click into the "coming soon" placeholder.

## 9. Global capabilities that do not exist yet

Search, command palette, notifications badge in the navbar, language switcher,
currency switcher, theme switcher, domain switcher, breadcrumb, page header
system, charts, maps, drawer, toast variants, skeleton, empty-state component,
error-state component, offline state, degraded state, action center, operations
pulse, insight cards, density mode, print styles for reports, analytics filters.

Each is a genuine gap, not a restyle.
