# Currency Architecture

Status: **Phase 11 implemented.** `app/Finance/ExchangeRateService.php`,
migration `023` (+`024`), `Support\Money` conversion API,
`GET|POST /api/currency`, `public/assets/js/core/currency.js`, navbar selector,
`tests/currency-integration.php`.

The brief refers to an "existing Mamore `ExchangeRateService`". **It did not
exist** — `grep -r ExchangeRate` returned zero matches across the repository —
so it was built in this phase. What *did* exist, and still does, is the correct
storage model underneath.

---

## 1. What shipped

| Piece | File | Purpose |
| --- | --- | --- |
| Service | `app/Finance/ExchangeRateService.php` | rates, cross rates, freshness ladder |
| Schema | `023_exchange_rates.sql`, `024_rate_precision.sql` | `exchange_rates`, TZS constraints, settlement context |
| Formatter | `app/Support/Money.php` | `convert()`, `display()`, `presentation()` |
| Transport | `GET\|POST /api/currency` | rate board + display preference |
| Client | `public/assets/js/core/currency.js` | one formatter, plus **unit** formatters |
| Selector | navbar `.currency-switcher` | USD / TZS / CDF with live rate status |
| Tests | `tests/currency-integration.php` | 30 assertions incl. the write invariant |

## 2. The invariant, proven

`tests/currency-integration.php` takes a checksum over **every column of every
row** in `payments`, `receipts`, `subscriptions`, `finance_transactions`,
`ledger_entries` and `revenue_ledgers`, then exercises all six conversion
directions, the unavailable path, the no-service path and settlement rounding,
then re-checksums.

> `a full conversion round-trip leaves every financial table byte-identical` — **PASS**

The checksum is deliberately whole-table rather than "check the amount column",
so a write to anything anyone forgot to assert on still fails the build.

## 3. The three ad-hoc formatters are gone

| Was | Now |
| --- | --- |
| `app.js:206` `money()` — hard-suffixed `CDF` on every value | delegates to `Mamore.currency.display(value, source)` |
| `subscriptions.js:13` `usd()` — a second, always-USD formatter | delegates, so a page cannot disagree with itself |
| `multi-domain.js:40` `asMoney()` — **used for cargo weight in kg** | `asWeight()` → `Mamore.currency.kilograms()` |

The weight bug was the worst of the three: a 12,500 kg load rendered as
`12500.00`, two decimals, no unit. **A weight is not money** — it has no currency
and no conversion — so it now has its own formatters and cannot be confused again.

## 4. Degradation ladder

| Situation | `status` | `rate` | What the user sees |
| --- | --- | --- | --- |
| Inside 15 min | `live` | number | normal value, green |
| Inside 1 h | `cached` | number | value + amber |
| Inside 24 h | `stale` | number | value + red + timestamp |
| Older / absent | `unavailable` | **null** | **the ORIGINAL amount in its ORIGINAL currency** |

The last row is the one that matters. `unavailable` returns `rate: null`, and the
test asserts that pairing, because a stale number presented with the confidence
of a fresh one is how money gets misreported. A missing rate service (`null`
rather than an object) degrades identically and does not throw.

**No default rate constant exists anywhere in the service.** A rate is never
invented.

## 5. Two real bugs found while building

### 5.1 Cross rates were unreachable, then unreachable in reverse

The seeded rates are `USD→CDF` and `USD→TZS`. The first implementation only
looked for the *requested* pair and then for legs *pointing at* USD, so:

- `CDF/USD` → `unavailable`, because only `USD/CDF` is stored and nothing
  inverted it;
- `CDF/TZS` → `unavailable`, because `CDF→USD` did not exist.

Fixed with an explicit four-step lookup — direct, **inverted**, through USD, then
give up — plus a `leg()` helper. `CDF→TZS` now derives to `0.9999999994` from
`USD→TZS ÷ USD→CDF`, which is what keeps the two legs from drifting apart.

### 5.2 Six decimals was not enough precision

`1/2900 = 0.000344827586…`. At 6 decimals that rounds to `0.000344`, a **0.24%
error on every conversion** — about 4,000 CDF on a 1,740,000 fare. The column
was widened to `DECIMAL(24,12)`, which puts the round-trip error at 6×10⁻¹⁰.

Because `Core\Migrator` checksums applied migrations and **refused to run** once
I edited 023 in place, the widening went into a separate `024`. That guard is
correct — a changed checksum usually means the schema no longer matches the file
— so it was worked with rather than bypassed.

## 6. A regression I caused, and how it surfaced

The first draft of 023 wrote:

```sql
ALTER TABLE payments MODIFY currency CHAR(3) NOT NULL,
    ADD CONSTRAINT ck_payments_currency CHECK (currency IN ('USD','CDF','TZS'));
```

The comment above it claimed *"the column definition is repeated verbatim"* —
and it was not. `MODIFY` restates the **whole** column, so the original
`DEFAULT 'USD'` was dropped from `payments`, `receipts` and `subscriptions`
(`finance_transactions` is nullable with no default and had to be restored that
way).

`tests/audit-notification-integration.php` caught it immediately with
`Field 'currency' doesn't have a default value` in
`SubscriptionService::create()`. The defaults are restored, the migration now
restates nullability and default explicitly, and the comment says what actually
happened rather than what I assumed.

**TZS is verified functionally, not by reading DDL**: a real `TZS` payment
inserts successfully and a real `EUR` payment is still rejected, so the
constraint was widened and not merely removed.

## 7. Language and currency are independent

`en · fr · sw` × `USD · TZS · CDF` are separate preferences with separate
storage (`mamore_locale` / `mamore_display_currency`, each in session *and*
cookie). A French operator reading TZS is a supported combination, and nothing in
either path reads the other value.

## 8. Remaining work, in order

1. **Per-dashboard source currency** (Phases 14–23): the legacy `money()` call
   sites default to `CDF` because that is what they already assumed. Each
   dashboard states its real source currency as it is rebuilt.
2. **Report conversion basis**: exported reports must print which currency, which
   rate and as-of timestamp produced the figure (Phase 21).
3. **Chart re-render on currency change**: charts are currency-aware and rebuild
   on `mamore:currencychange` (Phase 22).
4. **A fetched rate provider**: the service is read-side only and seeded
   `MANUAL`. Wiring an HTTP source is configuration, not architecture.
