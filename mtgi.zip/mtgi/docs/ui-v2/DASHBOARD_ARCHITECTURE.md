# Dashboard Architecture

The brief's core argument is that dashboards must not be "12 identical cards + 4
random charts". This document defines the mandatory structure every Mamore
dashboard follows, and the grid it sits on.

---

## 1. The seven-layer dashboard contract

Every dashboard — executive, rescue, Smart Bus, VIP, truck/cargo, private — is
composed in this order. A dashboard that cannot fill a layer says so explicitly
rather than padding.

| # | Layer | Answers | Component |
| --- | --- | --- | --- |
| 1 | **Executive summary** | What is the state of the whole domain, in one sentence? | Deterministic generated summary |
| 2 | **Current operational state** | What is happening right now? | KPI row |
| 3 | **Trend / context** | Is it improving or deteriorating? | Chart + comparison |
| 4 | **Exceptions** | What is wrong? | Action Center |
| 5 | **Action items** | What do I do about it? | Insight cards, each with a workflow link |
| 6 | **Detail** | Show me the records. | Table / list |
| 7 | **Drilldown** | Take me there. | Route or drawer |

The deterministic summary is generated from real status data — e.g. *"Operations
remain normal across most monitored assets. Three GPS devices require attention
and one high-severity truck incident is being handled near Kolwezi."* It is
**assembled from counts, never authored**, and it cites the counts it is built
from so it can be verified.

## 2. Grid

A 12-column grid, `gap: var(--space-20)`, collapsing 12 → 8 → 4 at 1280 / 1024
/ 768 px. Layouts are **per-dashboard**, not a template forced onto every
screen.

Executive overview, for example:

```
Row 1   [ 4 key KPIs spanning 12 ]              col-span-3 x4

## 3. KPI design

A KPI is never a bare number. Each carries:

- **label** (translated)
- **value** with unit and `tabular-nums`
- **comparison** with an explicit period — `vs yesterday`, `vs last week`,
  `vs last month`, `vs target`
- **status** tone when the metric has a good/bad direction
- **optional sparkline**
- **click-through** to the filtered list behind it

**Comparison periods are chosen per metric, not defaulted.** Incidents read
`vs yesterday`; revenue reads `vs last month`; fleet utilisation reads
`vs last week`. A percentage is shown only when the metric has a real trend and
enough history — otherwise it is omitted rather than fabricated. When there is no
meaningful trend, the KPI shows a **context line instead** ("3 teams available",
"all on-time today") rather than a fake 0.0%.

## 4. The Action Center — a signature feature

Ranks what needs a human **now**, by severity → urgency → age → business
impact. It is the answer to the brief's "management exception-first UX".

```
CRITICAL   Truck incident · Kolwezi Corridor       14 min   [ Respond ]
HIGH       3 rescue vehicles offline              22 min   [ Investigate ]
HIGH       7 buses with stale GPS                 31 min   [ Open tracking ]
MEDIUM     18 VIP subscriptions expire in 7 days   —       [ Review ]
```

Each row is a real link into the resolution workflow, not a dead-end alert. The
Action Center reuses `ControlCenterService` and `DispatchAdvisor` — it is a new
**presentation** of existing operational queries, not new business logic.

## 5. Operations Pulse

A compact reusable status strip — management awareness, not a metric row:

```
SYSTEM STATUS
Tracking      ● Healthy     Payments      ● Healthy
Smart Bus     ● Normal      Rescue        ● Active (2 open)
Notifications ● Healthy     Exchange rate ● Updated 10 min ago
```

Each service reports `ok | degraded | down | stale` **with the evidence that
justified it**. When a dependency fails it says DEGRADED — it never continues to
render "healthy" from stale data.

## 6. Domain dashboards — required content

| Dashboard | Must show |
| --- | --- |
| **Executive** | Tracked assets · people under protection · active journeys · passengers · cargo in transit · private vehicles online · VIP travellers · active incidents · available rescue teams · avg response · revenue · collection performance. Period: Today / 7d / 30d / Quarter / Year / Custom. |
| **Rescue Control Center** | Live KPIs · filters · live map · incidents + alerts · event stream · dispatch comparison table (unit, distance, ETA, capability, status). |
| **Smart Bus** | Trips today · live buses · passengers · tickets · revenue · avg occupancy · on-time departure · VIP passengers · rescue-protected trips · GPS health · incidents · operators active. |
| **VIP** | Total · active · expiring soon · covered vehicles · VIPs travelling · active rescue coverage · requests · response time · revenue · plan distribution · geography. |
| **Truck & Cargo** | Active trucks · in transit · idle · offline · breakdowns · active cargo · weight · value (where authorised) · on-time · delayed · incidents · GPS health · rescue coverage · revenue. |
| **Private Vehicles** | Subscribed · active coverage · online · offline · active journeys · emergency requests · incidents · response · renewals · revenue. |
| **Analytics** | Domain · metric · location · period · comparison · segment, driving dynamic charts. Saved views. |

## 7. Charts

Allowed: line, area, bar, stacked bar, donut, scatter, heatmap, timeline, gauge
(only where a bounded 0–100 is genuinely the metric), maps.

Forbidden: 3D, heavy shadows, rainbow palettes, decorative charts, pies beyond
~5 slices, gauges for unbounded values.

- Currency-aware charts rebuild on currency change, labelled in that currency.
- Language-aware charts rebuild labels on locale change.
- Every important chart carries a **textual summary** for screen readers
  ("Revenue increased 14% compared with last month").
- Sparklines only in KPIs, only where they show a real trend.

## 8. Freshness — a first-class design element

Every data surface displays its own age: `Live · 12 sec ago · 2 min ago · Stale`.
Thresholds are per domain (GPS health, exchange rates, board data) and declared
in one place, not guessed per screen. Stale data is visually distinct and is
**never** rendered with a live indicator.

Row 2   [ Primary operational trend   col-8 ] [ Action Center   col-4 ]
Row 3   [ Live map snapshot           col-8 ] [ Operations Pulse col-4 ]
Row 4   [ Domain performance table    col-7 ] [ Revenue/collections col-5 ]
Row 5   [ Critical lists / tables     col-12 ]
```

Rescue Control Center uses a different, deliberately operational layout:

```
Top    [ live operational KPIs — col-12 ]
Left   [ filters col-2 ] Centre [ live map col-7 ] Right [ incidents col-3 ]
Bottom [ selected operation / event stream — col-12, drawer-able ]
```

---

## 12. Phase 14 — what was actually built

The contract above is implemented for the executive overview. This section
records what shipped and, more usefully, what the data forced us to change.

### 12.1 The problem with the old front page

The overview panel rendered four metrics from `/api/admin/dashboard`:
registered users, active sessions, successful logins, failed logins. Those are
**authentication telemetry presented as the state of the business**. On an
operations platform, the landing screen answered "how many accounts exist"
instead of "what is Mamore doing right now".

`DashboardService` is retained, and `/api/admin/dashboard` still serves it — it
is a legitimate *security* view. It is no longer the front page.
`renderDashboard()` in `public/assets/app.js` now renders into
`#security-dashboard-body` and returns early when that mount is absent, so
removing the overview markup could not leave a null dereference behind.

### 12.2 Where the numbers come from

`app/Dashboard/ExecutiveService.php` assembles the overview from queries that
**already existed** in `ControlCenterService`, `FinanceService` and
`SubscriptionService`. No new business logic was invented for the dashboard; the
existing operational definitions were reused so the executive view cannot
disagree with the domain screens it summarises.

`GET /api/executive` is gated on `analytics.global_view`, the same permission
`/api/analytics/global` uses. A role that may not see the whole picture gets
403 rather than a quietly-empty dashboard.

### 12.3 Three things the data forced us to get right

**The summary is generated, not authored.** `ExecutiveService::summary()`
assembles the sentence from conditions, and the counts it used are returned
alongside it in `summaryBasis`. A reader can check the sentence rather than trust
it. The tone is `attention`, not `critical`, for anything short of a critical
incident — a summary that shouts on every refresh trains people to ignore it.

**A comparison is null when it cannot be computed.** `compare()` returns `null`
for a zero baseline, and the UI renders a context line instead of a percentage.
Every KPI carries an explicit `comparison` key that is `null` rather than
absent, so a client can distinguish "no baseline" from "comparison not run".

**Response averages carry their sample sizes.** This one was a real bug.
`AVG()` in MySQL ignores NULLs, so averaging the arrival column divides by
however many incidents happened to have been dispatched. In this database that
is 6 of 15, and because those 6 were dispatched seconds before arrival, the
reported average was **0 minutes** — a number that reads as world-class
performance and actually means "we only measure the easy ones". The service now
returns `dispatched`, `arrived` and `incidents` alongside each average, and
returns `null` rather than 0 when there were no incidents at all.

### 12.4 The contract test

`tests/executive-dashboard-integration.php` re-derives every headline figure
from the database and compares it to what the service returned, so a hard-coded
or invented KPI fails the build. It was verified by injecting `999` into the
tracked-asset KPI and confirming the test failed with:

```
FAIL: the tracked-asset KPI value is a real count, not a placeholder
```

It also pins: every KPI declares a state, every comparison names its period and
is computed from a non-zero baseline, Action Center rows are ranked by severity
and name the workflow they open, arrival samples never exceed dispatch samples,
and the response pulse says `unknown` when there are no incidents rather than
showing a time.

### 12.5 Layers 3, 6 and 7

**Layer 3, the trend.** Fourteen days of daily series -- incidents reported,
incidents resolved, payments received -- over a **generated date spine**. The
spine is the point: counts are mapped onto every declared date, so a day with no
activity is a plotted zero rather than a missing bar. Dropping empty days would
rescale the axis and turn a calm fortnight into a spike, which is the most
common way a sparkline lies about its own shape. `hasHistory` is false when
nothing was recorded, and the client then renders a sentence instead of a flat
line that looks like stability.

**Layer 6, the detail.** The records behind each Action Center count, so "12
tickets unpaid" is checkable. Capped at 8 rows per group, and the cap is
**stated**: "Showing the 8 most recent of 12." A short list must never be
mistaken for the whole story. Monetary rows carry their source currency and
convert for display only.

**Layer 7, the drilldown.** A detail row opens the shell's existing
`#detail-dialog` rather than adding a second modal, and renders what the
dashboard already has -- it does not re-fetch, so a row can never disagree with
the list it was clicked from.

### 12.6 Two more things the data forced

**A third tracking state.** `tracked_assets.tracking_status` is a varchar whose
DEFAULT is `'UNKNOWN'`. In this database 7 active assets are `UNKNOWN` and 6
are `NO_DEVICE` -- 13 of 14. Neither is an outage: these devices have never
reported a position at all. Counting them as "offline" would have invented 13
outages that did not happen. They are now counted as `gpsUnknown`, ranked
`low` in the Action Center (a configuration gap is not an outage), reported in
`summaryBasis`, and the tracking pulse says **unknown** rather than "healthy",
because a fleet where the majority has never reported is neither.

**`totalEvents` was summing a hand-picked subset.** It totalled reported
incidents and payments but not resolved incidents, so the declared total (25)
disagreed with the picture drawn directly above it (30). Caught by the contract
test, not by reading the code. It now totals every plotted series, and the test
asserts the two reconcile.

### 12.7 Not done in this phase

The remaining 22 panel bodies still use legacy markup; the new shell and design
system sit underneath them unchanged. The executive view's own layers are
complete.
