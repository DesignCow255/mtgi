# I18N Architecture

Status: **Phase 10 implemented.** `app/Core/Translator.php`,
`app/Support/DisplayTranslator.php`, `resources/lang/{en,fr,sw}/`,
`GET|POST /api/i18n`, `public/assets/js/core/i18n.js`, navbar selector,
`tests/i18n-integration.php`.

Before this phase the product had no localisation layer at all: `grep` for
`lang|locale|i18n|translat` across `app/` returned eleven hits, every one the
`preferred_language` **column** on `vip_emergency_profiles`. There was no
catalogue, no lookup and no fallback, and ~180 English literals sat in
`app.html` alone.

---

## 1. What shipped

| Piece | File | Purpose |
| --- | --- | --- |
| Service | `app/Core/Translator.php` | `t()`, `choice()`, `has()`, `catalogue()`, locale negotiation |
| Data policy | `app/Support/DisplayTranslator.php` | Categories A–D, one decision point |
| Catalogues | `resources/lang/{en,fr,sw}/` | `common`, `navigation`, `status` — **183 keys, full parity** |
| Transport | `GET|POST /api/i18n` | Whole catalogue for the active locale only |
| Client | `public/assets/js/core/i18n.js` | Same lookup, `data-i18n` binding |
| Selector | navbar `.locale-switcher` | EN / SW / FR radiogroup |
| Navigation | `app/Core/Navigation.php` | Resolves labels **server-side** |
| Tests | `tests/i18n-integration.php` | 60+ assertions |

**183 keys × 3 locales, no gaps and no extras**, verified by the test in both
directions — a key English does not define is dead weight that looks like
coverage, so it fails too.

## 2. Where the translation happens, and why

Navigation labels are resolved **on the server**, not shipped as English for the
browser to translate. The shell is served *before* sign-in, so the client cannot
know the locale at render time; `/api/navigation` is called *after* sign-in when
the session locale is known. This keeps exactly one copy of the vocabulary.

A language change therefore: `POST /api/i18n` (server session + cookie) →
`GET /api/i18n` (client catalogue) → re-render → re-fetch navigation so the
sidebar comes back in the new language.

## 3. The singleton is a documented trap, not a bug

`Translator::instance('fr')` **sets the shared locale** and returns the same
object every time. That is deliberate: PHP has one request and one locale, and a
second object holding a different locale is how you get a French page with an
English footer.

The consequence is asserted rather than left to be discovered:

```php
$handle = Translator::instance('fr');
Translator::instance('en');
$handle->t('status.ONLINE');        // "Online"  — English, as designed
$handle->t('status.ONLINE', [], 'fr'); // "En ligne" — explicit argument wins
```

This was found the hard way: the first version of the test compared two
`DisplayTranslator` handles and reported `ONLINE` translating to `Online` in
French. The cause was shared state, not a missing translation. `status()` now
takes an optional `$locale` so comparisons are explicit.

## 4. A session bug that a cookie was hiding

`POST /api/i18n` originally wrote `$_SESSION['mamore_locale']` and returned 200,
but the preference did not survive: **the router never starts a session**, so the
write was silently discarded and navigation kept returning English.

`Core\Theme` had the identical defect and did not show it, because it also sets
a cookie. The lesson generalises — a second persistence mechanism masked a real
bug — so both routes now call `Session::start()` explicitly, and the locale is
stored in **both** the session and a cookie. The cookie is not redundant: it is
what lets the server-rendered login screen be correct before any JavaScript runs,
and it survives a session expiry.

## 5. Data classification, enforced

`DisplayTranslator` is the single place the decision is made.

**Category A** — names, plates, references, emails, phones, coordinates, amounts.
Verified byte-identical across locales, and verified to win *even when the value
looks like a status code* (`plate = 'ONLINE'` is nonsense data, but
classification is a property of the **field**, not of the value).

**Category B** — status codes. The database stores `IN_TRANSIT`; the catalogue is
the only place a code becomes a word, so the same status cannot read differently
on two screens. This is the gap the audit recorded: the value used to be
interpolated raw, so a French operator saw `CRITICAL`.

An unmapped status degrades to `PENDING_REVIEW` → "Pending review", never a raw
code at an operator.

**Category C/D** — admin content and user free text render as authored, with the
`content_translations` table specified in §4 of the original design. The table
is not yet migrated; the policy is enforced and tested, so adding it later is
additive.

## 6. Fallback chain

`requested locale → en`. Never a raw key: a missing key returns the key *only*
so a developer can find it, and both the PHP and JS clients record it in a
`missing` list that the tests assert against.

A partial locale is topped up from English before it reaches the client, so the
browser always receives a complete, renderable message set. That is what makes
adding a fourth language incremental rather than all-or-nothing.

Verified live: `Accept-Language: fr-FR` → `fr`; `sw-KE` → `sw`;
`de-DE` → `en` (not a partial match); `POST {"locale":"frnch"}` → **422** rather
than silently storing English as the user's language.

## 7. What is not done yet

Honest scope: the catalogues cover `common`, `navigation` and `status`. The
remaining ~180 literals in `app.html` and the JS bundles are **still English** —
they are extracted in the per-dashboard phases, each of which now has the service
to extract *into*. The structure is complete; the coverage is not.

## 8. Remaining work, in order

1. **Lint** (`scripts/lint-i18n.php`): fail on a bare English literal in
   `app.html` and on hard-coded labels in the JS bundles. This is the guard that
   makes rule 1 above enforceable rather than aspirational.
2. **Extract per dashboard** (Phases 14–23): one panel at a time, each shipping
   its `en`/`sw`/`fr` keys in the same commit, so the catalogue never lags the UI.
3. **`content_translations`** (Category C) when admin-editable content needs
   translating; the policy is already enforced, so the table is purely additive.
4. **Locale-aware formatting**: `Intl.DateTimeFormat` / `RelativeTimeFormat` /
   `NumberFormat` on the client, including French's narrow no-break space as the
   group separator, which is why no layout may assume English width.

Language and currency remain **independent** preferences: a French operator
reading TZS is a supported, tested case in Phase 11.
