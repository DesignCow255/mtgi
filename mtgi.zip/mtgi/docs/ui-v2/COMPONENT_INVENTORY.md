# Component Inventory

Current state: ~40 ad-hoc CSS classes styled inline in one 489-line stylesheet,
plus raw `innerHTML` template literals in 4 JS bundles. There is no component
layer, no variant system, and no state contract.

---

## 1. What exists today, and what it should become

| Today | Count | Becomes |
| --- | --- | --- |
| `.primary-button` `.secondary-button` `.danger-button` `.row-action` `.sos-button` `.sos-confirm` `.text-button` `.icon-button` | 8 button classes | **5 variants**: `primary` `secondary` `ghost` `danger` `icon` |
| `.status-badge` (2 states) + `.pill`/`.pill-ok`/`.pill-wait`/`.pill-bad` + `.unit-status` + `.ticket-status` + `.priority-label` | 6 status patterns | **1 `StatusPill`** driven by a semantic lookup |
| `.metric` (`.metric.warning`) | 1 | **`Metric`** with label/value/trend/context/sparkline/action |
| `.rescue-metrics` (4-up strip) + `.mobility-summary` (3-up) + `.alert-metrics` (3-up) + `.tracking-metrics` (4-up) + `.domain-kpis` (flex wrap) | 5 KPI layouts | **`KpiRow`** on the 12-col grid |
| `.data-section` `.incident-board` `.unit-board` `.trip-board` | 4 panel shells | **`Card`** + **`ChartCard`** |
| `<dialog>` × 15 | 15 bespoke | **`Modal`** (7 variants) + **`Drawer`** (5 variants) |
| `.empty` in `<p>` and in `<td>` | 2 patterns | **`EmptyState`** (why + what to do) |
| `#toast` | 1 node, no variants | **`Toast`** with queue + 4 types |
| `.insight` | 1 static box | **`InsightCard`** (observation/severity/evidence/action) |
| `.domain-bars li` | gradient bar | **real chart** |
| — | missing | `ActionCenter`, `OperationsPulse`, `PageHeader`, `Breadcrumb`, `Skeleton`, `ErrorState`, `Drawer`, `Timeline`, `Pagination`, `Tabs`, `Table` |

## 2. The 34-component library

```
Button  IconButton  Badge  StatusPill  Card  Metric  InsightCard  Alert
Dropdown  Tabs  Table  Pagination  Drawer  Modal  Toast  Tooltip  Popover
FormControl  Select  DateRange  CurrencySelector  LanguageSelector
ThemeSwitcher  ChartCard  MapPanel  ActionCenter  Timeline  EmptyState
ErrorState  Skeleton  Avatar  Breadcrumb  PageHeader
```

Rendering is a **CSS class contract plus a tiny JS behaviour module**, not a
templating engine — consistent with vanilla-JS/no-framework and with the CSP,
which forbids inline handlers.

## 3. Button hierarchy (5 variants only)

| Variant | Use | Example |
| --- | --- | --- |
| `primary` | The single main action in a view | "Report incident" |
| `secondary` | Supporting actions | "Refresh", "Export" |
| `ghost` | Tertiary / repeated in a row | Row actions, toolbar toggles |
| `danger` | **Required** for destructive ops | "Void payment", "Revoke code" |
| `icon` | Square, always `aria-label`ed | Close, row menu |

Sizes: `sm` (28 px, dense tables) · `md` (36 px, default) · `lg` (44 px, mobile
primary). Touch targets are ≥ 44 px on coarse pointers (WCAG 2.5.8).

## 4. Status system — the most important component

One table maps a **domain value** to a tone, an icon and a label key:

```js
StatusPill.tone('CRITICAL')      -> danger  + fa-triangle-exclamation
StatusPill.tone('ONLINE')        -> success + fa-circle-check
StatusPill.tone('IN_TRANSIT')    -> info    + fa-truck
StatusPill.tone('AVAILABLE')     -> success + fa-circle-check
StatusPill.tone('STALE')         -> warning + fa-clock
StatusPill.tone('OFFLINE')       -> neutral + fa-plug-circle-xmark
```

Rules:

- The **label is translated** (Category B), the value is never shown raw.
- Tone is **never the only signal** — an icon and/or text always accompany it,
  satisfying WCAG 1.4.1.
- A page may not define a new status style. Unknown values fall back to
  `neutral` + the raw value, so a new backend status degrades safely rather than
  rendering unstyled.

## 5. The four-state contract (mandatory)

Every surface that loads data implements all four:

| State | Requirement |
| --- | --- |
| **Loading** | Skeleton matching final geometry — KPI blocks, chart plot area, table rows. No spinners over content. |
| **Empty** | What this area is · why it is empty · the action available. Never "No Data". |
| **Error** | Distinguishes: permission denied / network / server / stale. Never renders a value. |
| **Ready** | The data. |

Enforced by a test that greps for the raw `0`-on-error pattern
(`|| 0)` fed straight from a failed fetch) and for `.empty` used without the
`EmptyState` contract.

## 6. Density

`data-density="comfortable|compact"` on `<body>`, persisted per user.

| | Row padding | Cell font | Line height |
| --- | --- | --- | --- |
| comfortable | 14 px | 14 px | 21 px |
| compact | 7 px | 13 px | 18 px |

Compact is the default for the Control Center, finance tables and audit — the
dense-tasks the brief calls out.

## 7. Data table system

One `<DataTable>` with: server pagination · sortable columns · global search ·
advanced filters · date range · column visibility · sticky header · saved
filters · export · row actions · bulk actions where safe.

- **Stacked cells over column sprawl.** `T123 ABC / Volvo FH16 / Mulykap
  Logistics` becomes one cell with a strong primary line and two secondary
  lines, not three columns.
- **Mobile converts to record cards**, not a horizontally-shrunk desktop table.
  A `data-table-mode` attribute selects the strategy per table.
- Sticky header is native `position: sticky` — no JS scroll handler.

## 8. Motion

`--dur-fast: 120ms`, `--dur-base: 180ms`, `--dur-slow: 260ms`;
`--ease-out: cubic-bezier(.2,.8,.2,1)`.

Motion is used only to express state change, hierarchy, focus or progress —
drawer slide, drawer/modal entry, chart transition, count-up, toast entry,
skeleton shimmer, nav indicator. Never decorative, never continuous.
`@media (prefers-reduced-motion: reduce)` disables all of it; the existing
`app.css:377` rule already does this and is preserved.
