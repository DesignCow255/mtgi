# Responsive Strategy

Test matrix required by the brief: **1920 · 1600 · 1440 · 1366 · 1280 · 1024 ·
834 · 768 · 430 · 412 · 390 · 375**. Today the product has three breakpoints
(1000 / 760 / 440) and collapses by stacking.

---

## 1. Breakpoint model

Mobile-first, driven by *where the layout must change*, not by device names.

| Token | From | Layout change |
| --- | --- | --- |
| — | 0 | Single column. Bottom action bar on field screens. |
| `sm` | 640 | 2-up KPI grid, tables become record cards. |
| `md` | 768 | 4-col grid; sidebar becomes an overlay drawer. |
| `lg` | 1024 | 8-col grid; tables may use the horizontal-scroll strategy. |
| `xl` | 1280 | Persistent collapsed sidebar (72 px). |
| `2xl` | 1536 | Sidebar expands to 264 px. Full navbar: search + all controls. |
| `3xl` | 1920 | Content max-width 1680 px, centred — no infinite line lengths. |

## 2. Shell behaviour

| Width | Sidebar | Navbar |
| --- | --- | --- |
| ≥ 1536 | Expanded, 264 px | Search, currency, language, theme, notifications, profile |
| 1280–1535 | Collapsed, 72 px, icon + tooltip | Same, tighter |
| 1024–1279 | Collapsed, overlay on demand | Search collapses to an icon |
| 768–1023 | Drawer, overlay + scrim | Hamburger, title, status, more-menu |
| < 768 | Drawer, full-height | Hamburger, title, connection status, more-menu |

**The 390 px header is never overcrowded.** Currency, language and theme move
into the more-menu below 768 px rather than being squeezed. Touch targets are
≥ 44 px throughout (WCAG 2.5.8).

## 3. Tables — the hardest responsive problem

Full desktop tables are never shrunk into unusability. Each table declares a
strategy via `data-table-mode`:

- `table` — below `lg`, switches to **record cards**: label/value pairs with a
  strong primary line, preserving hierarchy rather than columns.
- `scroll` — a deliberately horizontal-scrolling table (audit log, ledger),
  with a sticky first column and an explicit scroll affordance.
- `priority` — columns are progressively dropped by priority as width falls.

Complex tables reserve width and switch at a defined breakpoint, so there is no
intermediate state where cells wrap into unreadable stacks.

## 4. Dashboards

- 12 col → 8 col (≤ 1280) → 4 col (≤ 768).
- KPI rows: 4-up → 2-up → 1-up. **KPI order is preserved** — priority order does
  not reshuffle on mobile, because it is priority order.
- Charts get an explicit aspect ratio container so the plot never causes layout
  shift, and legends move below the plot on narrow screens.
- The Rescue Control Center's three-column layout becomes a tabbed sequence on
  mobile: **Map → Incidents → Filters**, with the map default.

## 5. Mobile is not desktop, smaller

Field roles get purpose-built mobile layouts, not shrunken dashboards:

| Role | Mobile priority |
| --- | --- |
| **Driver** | Current trip · next stop · SOS button · manifest |
| **Conductor** | Trip · seat map · scan · board passenger |
| **Rescue responder** | Assigned incident · navigate · status update |
| **VIP / private** | Rescue Code · request help · coverage status |

A **bottom action bar** carries the single most important action, thumb-reachable
(44 px), with a safe-area inset for iOS notch/home-indicator.

## 6. Overflow discipline

`overflow-x: hidden` on `body` is **not** used to hide a real layout bug. The
rule is: no horizontal page overflow except inside an element explicitly marked
`data-allow-overflow` (scroll tables, maps, wide charts). A test asserts
`document.scrollWidth <= window.innerWidth + 1` at all 12 widths.

## 7. Long-text resilience

French and Kiswahili run 15–30% longer than English. Every text container is
built to truncate gracefully with `min-width: 0` on flex children (the classic
flexbox overflow trap), `text-overflow: ellipsis` where appropriate, and
wrapping rather than fixed widths for buttons, nav labels, table cells and
filter chips. Nav labels wrap to two lines in collapsed mode rather than
clipping.
