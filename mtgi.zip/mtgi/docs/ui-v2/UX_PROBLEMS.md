# Mamore — UX Problems

Severity is judged against the brief's own standard: does the interface help the
operator answer *what is happening, what changed, what is wrong, how serious,
where, what next*? Each entry cites the code that causes it.

Legend — **S1** blocks the mission · **S2** materially degrades it · **S3** polish

---

## S1 — Problems that make the product unsafe to rely on

### 1.1 Money is displayed under the wrong currency label
`app.js:206`
```js
const money = (value) => `${Number(value || 0).toLocaleString(...)} CDF`;
```
Every figure passed to `money()` is suffixed `CDF`. Callers include
`renderFinance` (`collectedCdf`, `rescueFundCdf`, `varianceCdf`) — which happens
to be right — but the same helper is reused for **trip fares**, so any USD value
reaching it is silently mislabelled. Two further independent formatters exist
(`subscriptions.js:13` `usd()`, `multi-domain.js:40` `asMoney()`), and
`multi-domain.js` uses `asMoney` to print **cargo weight in kg**.

Three formatters, one of which formats mass as money, and no rate source.
*Fix: one `Money.format(amount, source, display)` bound to one rate service.*

### 1.2 "Live" is a hard-coded word, not a measurement
`app.html:141` puts `<small>Live</small>` on nine nav items. It is markup, not
state. `tracking_positions.recorded_at` is never compared to now anywhere in
the frontend. `bin/job-tracking-health.php` detects staleness server-side, but
its verdict never reaches the UI.

An operator can look at an 8-minute-old bus position and see a green "Live"
badge. **This is the one defect that can get someone hurt.**

### 1.3 Destructive actions are one unguarded click
Void payment, revoke rescue code, close incident, remove a device, change a
user's role: all are ordinary buttons in an ordinary dialog. No danger variant,
no consequence statement, no typed confirmation, no undo. `Receipt@void` and
`RoleMiddleware` protect the *system*, but the interface gives the operator no
signal that they just did something irreversible.

### 1.4 Failures are indistinguishable from zeroes
`loadDashboard` and friends do `Number(values[index] || 0)`. If a fetch rejects,
the catch shows a toast and the KPI keeps showing `0`. **A dead endpoint and a
genuinely empty metric render identically.** The brief forbids this explicitly

## S2 — Problems that materially degrade the mission

### 2.1 No dark mode, and no token layer to build one on
A single `:root` with 15 hex values; ~60 raw colour declarations downstream.
`prefers-color-scheme` is never consulted.

### 2.2 No localisation at all
Zero infrastructure. ~180 English literals in `app.html` alone, plus every JS
template literal. Database *controlled* values (`CRITICAL`, `IN_TRANSIT`,
`AVAILABLE`, `PENDING`) are interpolated raw — so even if the chrome were
translated, the data would still read as English.

### 2.3 No charts, no map
"Live tracking" is a definition list of lat/lng. There is no spatial view of
buses, trucks, rescue units or incidents anywhere, despite `tracked_assets`,
`tracking_positions`, `service_locations` and `geofences` all being fully
populated in the schema.

### 2.4 The overview answers the wrong question
`DashboardService::snapshot()` returns **users, active sessions, successful
logins, failed logins**. The landing screen of an operations platform leads with
authentication telemetry. There is no "what is Mamore doing right now?" — no
active incidents, no people under protection, no revenue, no exception list.

### 2.5 Navigation is a flat list with a duplicate entry
18 undifferentiated items; **"Rescue operations" appears twice**
(`data-panel="rescue"` and `data-panel="operations"`). No domain grouping, no
breadcrumbs, no URL state, so nothing is linkable, shareable or back-safe.

### 2.6 Empty states are inconsistent and sometimes wrong
Three patterns coexist: `<p class="empty">No panic alerts.</p>`,
`<td class="empty">Open this section to load users.</td>`, and a good two-part
`<strong>` + `<p>` pattern in `renderPortalTrips`. None state *why* it is empty
or *what to do next*.

### 2.7 The toast is a single global element
One node, `textContent`, 2 800 ms, no queue, no type, no dismissal, no ARIA
politeness differentiation. Success and failure look identical.

### 2.8 No loading, skeleton, offline or degraded state
`button.disabled = true` during submit is the only feedback. Nothing is
reserved, so every load causes layout shift. Nothing tells the operator the
browser is offline or that GPS is delayed.

### 2.9 Responsive behaviour is three breakpoints and a squeeze
`@media` at 1000 px, 760 px, 440 px. Tracking, incident and finance layouts
collapse by stacking; wide tables rely on `.table-wrap` scrolling horizontally.
No mobile record-card transformation, no bottom action bar, no field-mode layout
for driver/conductor/responder roles.

### 2.10 Currency, language, theme and density are all single-valued
Stored per user in the database where they exist at all
(`vip_emergency_profiles.preferred_language/preferred_currency`), with no
session-level preference, no fallback chain, and no effect on the UI.

---

## S3 — Polish

- Font Awesome is a 154-glyph subset with a build guard (good), but the mapping
  is ad-hoc per screen — `fa-warehouse` for "Rescue operations" is arbitrary.
- `--font` declares one family; no type scale, no tabular numerals for figures.
- Three breakpoints versus the 12 widths the brief requires verified.
- No print styles except the receipt.
- Focus rings exist (`3px solid rgba(237,0,0,.4)`) but no visible focus on
  custom controls; no `aria-live` regions except `#metrics` and the rescue strip.
- Assets unversioned → stale-CSS risk on deploy.
- Sidebar icons turn gold on hover *and* active (`.app.css:78`), so active state
  has no affordance beyond colour.

---

## Root cause

These are not 40 independent bugs. They reduce to four missing foundations:

1. **No token layer** → no theming, no consistent colour, no density.
2. **No i18n service** → literals scattered across HTML and JS, untranslatable.
3. **No currency/rate service** → three ad-hoc formatters, wrong labels.
4. **No data-visualisation layer** → every "chart" is a decorative gradient.

Fixing those four unblocks most of §2 and §3. That is why the implementation
plan sequences tokens → themes → i18n → currency → components → dashboards,
rather than starting with page restyles.

("Never show zero when data actually failed to load"); today it is the default.

### 1.5 "Analytics" is a CSS gradient bar
`app.css:489` renders every analytical visual in the product:
```css
.domain-bars i { background: linear-gradient(90deg, #c9a227 var(--bar,20%), rgba(148,163,184,.15) var(--bar,20%)); }
```
No time axis, no comparison, no series, no tooltip, no drilldown, no textual
equivalent. It cannot answer "is this rising?".
