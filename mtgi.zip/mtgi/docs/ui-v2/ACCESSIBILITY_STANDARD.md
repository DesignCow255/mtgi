# Accessibility Standard

Target: **WCAG 2.2 AA**, verified by test where automation can reach it and by
manual keyboard/screen-reader passes where it cannot.

---

## 1. Baseline already in place (keep it)

- Semantic landmarks: `<main>`, `<nav aria-label>`, `<aside>`, `<header>`.
- A skip link (`.skip-link`, visually hidden until focused).
- `aria-live="polite"` on `#metrics` and the rescue strip.
- `aria-hidden="true"` on every decorative Font Awesome glyph.
- `aria-label` / `aria-pressed` on icon-only controls.
- Native `<dialog>` gives focus trapping and Esc handling for free.
- `.sr-only` for table action headers.
- `prefers-reduced-motion` honoured globally (`app.css:377`).
- Visible focus ring on `button`, `input`, `a` (`3px` outline + offset).
- `autocomplete` on identity fields; `inputmode`/`pattern` on codes.
- `prefers-color-scheme` is *not* relied on — we set an explicit theme.

## 2. Gaps to close

| Gap | Fix |
| --- | --- |
| No focus style on custom controls (tabs, pills, table row actions) | Visible `:focus-visible` ring on every interactive component |
| Status conveyed by colour alone in `.pill-ok/wait/bad` | Icon + text label always accompany tone (WCAG 1.4.1) |
| Tab order not verified for the sidebar/topbar | Logical DOM order; `tabindex` only where unavoidable |
| Toast has no politeness distinction | `role="status"` for info/success, `role="alert"` for error |
| Charts have no text equivalent | Every important chart gets a visually-hidden summary + `role="img"` + `aria-label` |
| No `<caption>` or header association on most tables | `<caption class="sr-only">`, `scope="col"` on every `<th>` |
| Form errors not associated to fields | `aria-describedby`, `aria-invalid`, error text linked to the input |
| No skip-to-content target focus management | `tabindex="-1"` on `#main`, focused on navigation |
| Modals don't restore focus to the trigger | Native `<dialog>` + explicit return-focus |
| Dense table cells may fall below 24 px | Row padding sized to keep targets ≥ 24 px (2.5.8) |
| Reduced motion honoured but not reduced transparency/flashing | `prefers-reduced-transparency` support; no flashing red ever |

## 3. Contrast budget

Enforced per theme by `tests/a11y-contrast-test.php`, computing WCAG contrast
from the token values (so it tests the real system, not screenshots):

- Body text ≥ **4.5:1**.
- Large text (≥ 24 px, or ≥ 18.66 px bold) ≥ **3:1**.
- UI component boundaries and meaningful graphics ≥ **3:1**.
- Focus indicator ≥ **3:1** against its adjacent background.

Known risk areas tested explicitly: gold `#FEAA03` on navy `#012F6C` (used for
active nav, so contrast is computed against the navy, not against white), muted
text on `surface-3`, and the dark theme's dimmed gold `#E0A21F` on `#0C1526`.

**Gold is never used for body text** — if a pairing cannot clear 4.5:1, the
token is wrong, not the test.

## 4. Keyboard UX

| Shortcut | Action |
| --- | --- |
| `⌘K` / `Ctrl+K` | Global search + command palette |
| `Esc` | Close topmost overlay (palette → drawer → modal) |
| `Enter` | Confirm the focused form / activate the focused row action |
| `↑ ↓` | Move within menus, palettes, listbox selectors |
| `Home` / `End` | Jump to first/last option |
| `?` | Keyboard shortcut help |

Menus and palettes implement the ARIA menu/listbox keyboard pattern with roving
`aria-activedescendant`; focus is **not** trapped in a `<dialog>`-less overlay
by accident. A visible shortcut hint appears in the search field.

## 5. Motion

`prefers-reduced-motion: reduce` removes transitions, skeleton shimmer, count-up
animation and map fly-to. **No critical incident ever flashes.** Escalation is
communicated by a persistent banner, a border weight change and an icon — never
by animation, which would be both an accessibility failure and a distraction
during a real emergency.

## 6. Chart accessibility

- `role="img"` with a descriptive `aria-label` summarising the trend.
- A visually-hidden data table as the accessible alternative for key charts.
- Text summary is generated from the same data as the chart, so it can never
  disagree with what is drawn.

## 7. Mobile / touch

- All interactive targets ≥ 44 × 44 px on coarse pointers.
- `viewport` meta already present; no `user-scalable=no` (never disable zoom).
- `env(safe-area-inset-bottom)` padding on the bottom action bar.

## 8. Verification

`tests/a11y-contrast-test.php` (token contrast, both themes) ·
`scripts/lint-a11y.php` (no `aria-hidden` on focusable elements, every `<img>`
has `alt`, every icon-only button has `aria-label`, every input has a label) ·
manual keyboard pass over login → dashboard → incident → dispatch → payment ·
screen-reader pass (VoiceOver) on the Control Center and a finance table.
