# Mamore — Current UI Audit (Baseline, 27 Sep 2026)

Branch: `feature/mamore-premium-ui-v2`
Scope: everything that renders to a human today. Backend routes, services and the
database are treated as fixed constraints; only the presentation layer is in
scope for change.

---

## 1. How this audit was produced

| Method | What it established |
| --- | --- |
| `find`/`wc -l` over the tree | 112 PHP files, 22 435 lines; 5 shipped CSS/JS bundles |
| Read of `public/index.php` | 88 registered routes, all closures in one file |
| Read of `public/app.html` (460 lines) | 23 panels, 20+ `<dialog>`s, one login shell |
| Read of `public/assets/app.css` (489 lines) | 4 breakpoints, 1 hard-coded theme, 0 tokens |
| Read of the 4 JS bundles (1 548 lines) | IIFE modules, `window.Mamore` registry, `innerHTML` rendering |
| Read of `database/migrations/*.sql` (22) | 101 tables live, RBAC matrix in `022_domain_rbac.sql` |
| Read `permissions` + `roles` from MySQL | 57 permissions, 9 system roles |
| `php bin/test.php` | Baseline suite — must stay green through the redesign |
| Pixel-sampled the official logo PNG | Brand palette, measured not guessed |

## 2. The actual shape of the product today

**Backend (to be preserved, not rewritten)**

- Pure PHP 8.3.14, PDO, MySQL 8.0.40, 101 tables, 22 migrations.
- PSR-4 autoload from `app/` via `bootstrap.php`; no Composer vendor tree.
- Services are already cleanly domain-split: `Rescue`, `SmartBus`, `Tracking`,
  `Vip`, `TruckCargo`, `PrivateVehicle`, `Subscription`, `Finance`, `Alerts`,
  `Portal`, `Admin`, `Dashboard`, `Support`, `Policies`, `Middleware`, `Core`.
- 9 roles / 57 permissions, all permission filtering done in SQL, not in the
  browser. This is correct today and must stay correct.
- Existing quality services worth keeping and reusing, not rebuilding:
  `ControlCenterService`, `DispatchAdvisor`, `GlobalSearch`, `Money`,
  `FeeEngine`, `AuditLog`, `ServerClock`, `NotificationService`.

**Frontend (this is what changes)**

The entire UI is one static HTML document plus four classic scripts. There is no
build step, no bundler, no module loader, and no framework — which is exactly

```
public/app.html               460 lines   the whole application shell
public/assets/app.css         489 lines   the whole stylesheet
public/assets/app.js          512 lines   auth, shell, 12 panels
public/assets/subscriptions.js 529 lines  subscriptions, receipts, audit, portal auth
public/assets/smartbus-v2.js   216 lines  pilot analytics, boarding, live trips
public/assets/multi-domain.js  291 lines  VIP, truck/cargo, private vehicle, analytics
```

Views are switched by hiding/showing `<section>` panels. Every render is an
`innerHTML` assignment of a template literal.

## 3. The seven structural problems that matter

Everything else follows from these.

### P1 — The stylesheet has no token layer and only one theme

`app.css` opens with a single `:root` block of 15 raw hex values. There is no
light/dark concept at all. The sidebar is a hard-coded `var(--navy)`, the metric
strip is a hard-coded `var(--forest)`, and panels hard-code `#cbd5f5`, `#86efac`,
`#fca5a5`, `#c9a227`. Colours are scattered through ~60 declarations.

**Consequence:** a theme switch is currently impossible without rewriting the
stylesheet, and any new component would have to re-guess a colour.

### P2 — There is no i18n layer whatsoever

`grep` for `lang|locale|i18n|translat` across `app/` returns exactly 11 hits,
all of them the `preferred_language` **column** on `vip_emergency_profiles`.
There is no `resources/lang/`, no `Translator` class, no `t()` helper.

Every user-visible string in the product is a hard-coded English literal in
either `app.html` or a JS template literal. The shell alone contains ~180.

### P3 — There is no currency service and the UI mislabels money

`grep -r ExchangeRate` across the whole repo returns **zero matches**. The
brief's reference to an "existing Mamore `ExchangeRateService`" is not accurate
— it does not exist and must be built.

Worse, the current display logic is actively wrong:

- `app.js:206` — `const money = (v) => \`...toLocaleString() CDF\``. Every value
  passed to it is labelled CDF regardless of its real currency.
- `subscriptions.js:13` — a second, independent `usd()` formatter.
- `multi-domain.js:40` — a third formatter, `asMoney()`, which despite its name
  is also used to format **cargo weight in kg** (lines 145, 207) — a weight
  rendered with 2 decimals and no unit.
- `smartbus-v2.js:177-178` hard-codes the words "Revenue (CDF)".

The database is the one part that is correct: `payments`, `receipts`,
`subscriptions` and `finance_transactions` all store `currency` plus
`usd_cdf_rate`, and CHECK constraints pin them. **The storage model is sound;
only presentation is broken.** That makes this fix tractable.

### P4 — "Live" is asserted by the interface, never proven by data

`app.html` marks nine separate nav items with a literal `<small>Live</small>`.
The word is hard-coded, not derived from a timestamp. Tracking has no staleness
or degraded mode; `tracking_positions` carries a `recorded_at` and the UI does
not look at it.

**Consequence:** the platform can present 8-minute-old GPS as current. This is
the most dangerous defect in the product, and it is an honesty problem rather
than a visual one.

### P5 — The UI has no visual data layer at all

No Chart.js, no ECharts, no Leaflet, no `<canvas>`. "Analytics" today is the
`.domain-bars` list — a CSS `linear-gradient` bar (`app.css:489`). The tracking
"map" is a `<dl>` of coordinates. `smartbus-v2.js` renders tables.

This is the largest genuine gap between the brief's intent and reality.

### P6 — Security UX is absent on destructive actions

`void payment`, `revoke rescue code`, `close incident` and `remove device` are
reachable through the same single-click `.row-action` / `.primary-button`
affordance used for harmless navigation. No confirmation, no consequence
statement, no distinct danger variant in the visual language.

### P7 — The 23 panels are a flat list, not an information architecture

The sidebar is one undifferentiated column of 18 staff items in 3 loose groups
("Workspace", "Operations", "Domains"), with duplicate labels — **"Rescue
operations" appears twice**, at line 141 for `data-panel="rescue"` and again for
`data-panel="operations"`. There is no domain switcher, no breadcrumb, no page
context concept, and no route in the address bar reflecting the panel
(`switchPanel` mutates no history).


**Consequence:** EN/SW/FR is not a styling task, it is a new backend service
plus removal of literals from the templates. It cannot be deferred to "after
the redesign" without a second pass over every file.


## 4. Quality baseline that must not regress

`php bin/test.php` runs 30 integration files against the live MySQL schema,
provisioning its own fixtures. `tests/ui-wiring-test.php` is a static guard that
cross-checks `app.html`, `app.js`, `subscriptions.js` and `public/index.php`
against each other and **fails the build** if:

- a panel, nav entry or dialog is missing;
- a bundle calls an `/api/` path the router does not register;
- a panel loader is not on the `window.Mamore` registry;
- a Font Awesome glyph is used that is absent from the 154-glyph subset.

That last check is a hard architectural constraint: **any new icon must be
re-subset into `fontawesome/fa-solid-subset.woff2` with `fontTools` and added to
`fontawesome.css`, or the build fails.** `fontTools 4.66.0` is available locally.

## 5. Asset budget today

| Asset | Size | Notes |
| --- | --- | --- |
| `app.css` | ~33 KB | single file, no tokens |
| `app.js` + 3 bundles | ~62 KB | uncompressed, all `defer` |
| Poppins woff2 × 11 | 2 weights preloaded | latin + latin-ext per weight |
| Font Awesome subset | ~10 KB | 154 glyphs, already optimised |
| Charts / maps | 0 KB | do not exist |

Assets are served raw from disk by `.htaccess` (`RewriteRule ^assets/... [END]`),
so there is no compression layer, and they are **unversioned** — `app.css` has
no cache-busting token, so a deploy can serve stale CSS to a warm browser.

## 6. Security posture to preserve

`Response::emit()` sends a strict CSP with **no `unsafe-inline` and no
`unsafe-eval`**:

```
default-src 'self'; script-src 'self'; style-src 'self'; img-src 'self' data:;
connect-src 'self'; base-uri 'none'; form-action 'self'; frame-ancestors 'none'
```

This is a good posture, and it has one sharp consequence for the redesign:
**the theme switcher cannot be an inline `<script>` reading `localStorage`.**
That is the standard anti-FOUC trick and it is blocked. `AppShell` already
works around this for the mount point by injecting `<meta name="mamore-base">`
instead of a script block. Theme bootstrapping must use the same technique — a
meta-driven class or a blocking external stylesheet — or the CSP must be
relaxed deliberately. Recommendation: keep the CSP, solve it properly.

Also in force: `nosniff`, `Referrer-Policy: same-origin`, `X-Frame-Options: DENY`,
bearer tokens in `sessionStorage`, CSRF tokens, per-route `requirePermission()`,
and `.htaccess` denial of `app/ bin/ config/ database/ resources/ routes/
scripts/ storage/ tests/ public` plus all dotfiles.

## 7. What is genuinely good and must be kept

A redesign that only lists faults is not an audit. These are assets:

- **Permission filtering in SQL.** `GlobalSearch` builds its domain IN-list in
  the query; ownership is enforced by `SubscriberOwnershipPolicy` /
  `OperatorOwnershipPolicy`. Rare and correct.
- **`ServerClock`.** `Core\ServerClock::skewSeconds()` compares PHP time to
  `UTC_TIMESTAMP(6)` and `/ready` reports the skew — built-in defence against
  "live GPS is stale because the web host's clock is wrong". The UI should
  surface this rather than duplicate it.
- **Deriving journey position from tracking**, not from a journey-local table.
  `boarding-integration` asserts it explicitly. Good normalization; the map
  benefits from it.
- **A self-subset Font Awesome** — 156 KB → 10 KB with a build-time guard.
- **A static UI-wiring test written in PHP** because CI has no Node runtime.
- **A 30-file integration suite** covering RBAC, boarding, reconciliation,
  coverage, panic, audit and every domain.
- **Self-hosted fonts** for an isolated-network intranet deployment.
- **`Money::usdToCdfRounded()`** using `bcmath` and ceil-to-100 — the correct
  convention for a currency with no practical minor unit.

## 8. Audit conclusion

The backend is in good shape and mostly should be left alone. The frontend is a
single-theme, single-language, currency-mislabelled, chart-free shell whose
"Live" indicators are decorative rather than derived.

**The redesign is therefore ~85% a construction job (tokens, i18n, currency
service, components, charts, states) and only ~15% a restyle.** Treating this as
"change some CSS" would be the single biggest planning error available here.

the constraint the brief asks us to keep.
