# Implementation Plan

Sequenced so that each phase is verifiable before the next depends on it. The
ordering rule: **foundations before surfaces, services before UI, one domain at
a time.**

---

## Gate conditions (checked before starting, and continuously)

| Gate | Status at plan time |
| --- | --- |
| `php bin/test.php` green | ✅ **29 passed, 0 failed** (211 s) |
| Branch created | ✅ `feature/mamore-premium-ui-v2` |
| No framework introduced | ✅ constraint |
| Routes / RBAC / business logic untouched | ✅ constraint |

Every commit must leave `bin/test.php` green. A phase that breaks a test is not
finished, regardless of how good it looks.

---

## Phase map

| # | Phase | Depends on | Verifiable by |
| --- | --- | --- | --- |
| 01 | UI audit | — | this document set |
| 02 | Brand extraction | 01 | sampled hexes in tokens |
| 03 | Design tokens | 02 | contrast test |
| 04 | Light + dark themes | 03 | both themes render, no FOUC |
| 05 | Typography / spacing / base CSS | 03 | lint clean |
| 06 | Core component library | 03–05 | component showcase |
| 07 | Global shell | 06 | shell renders both themes |
| 08 | Sidebar + navigation | 07 | nav IA complete, no duplicates |
| 09 | Navbar | 07–08 | all controls present |
| 10 | Language architecture | 06 | `i18n-integration` green |
| 11 | Currency architecture | 06 | `currency-integration` green |
| 12 | Global search + command palette | 08–11 | ⌘K works, permission-aware |
| 13 | Tables / forms / overlays | 06 | component states complete |
| 14 | Executive dashboard | 09–13 | seven-layer contract met |
| 15 | Rescue Control Center | 14 | map + dispatch + timeline |
| 16 | Tracking | 15 | map panel premium |
| 17 | Smart Bus | 14 | domain dashboard |
| 18 | VIP | 14 | domain dashboard |
| 19 | Truck & Cargo | 16–18 | domain dashboard |
| 20 | Private Vehicles | 16, 18 | domain dashboard |
| 21 | Finance / reporting | 11, 13 | currency-safe, export |
| 22 | Analytics Center | 11, 12, 14 | dynamic charts |
| 23 | Notifications / Action Center | 09, 14 | ranked exceptions |
| 24 | Responsive refinement | all UI | 12 widths pass |
| 25 | Accessibility | all UI | a11y + contrast tests |
| 26 | Performance | all UI | lint-perf budgets |
| 27 | Visual QA | 24–26 | light/dark screenshots |
| 28 | Cross-language/currency/theme QA | 10, 11, 27 | 18 combinations |
| 29 | Production hardening | all | deploy checklist |

## Critical path

```
02 -> 03 -> 04/05 -> 06 -> 07 -> 08 -> 09 -> 14 -> 15 -> 16 -> 19 -> 24 -> 27 -> 28 -> 29
                       \-> 10 (i18n) ------|
                       \-> 11 (currency) --|-> 22, 23

## Phase 03–05 detail — the foundation

**03 Design tokens** — `css/tokens.css` (brand, surfaces, text, borders,
semantic, radius, space, shadow, font, motion, layout), plus
`css/themes/light.css` and `css/themes/dark.css` redefining *semantic* tokens
only. A migration layer maps the 15 legacy names (`--navy`, `--forest`, `--red`,
`--gold`, `--paper`, `--line`, `--muted`…) onto the new tokens so the existing
489-line stylesheet keeps rendering during the transition — **this is what makes
the change incremental instead of a big-bang rewrite**.

**04 Themes** — `<html data-theme="light|dark">` set before first paint. **CSP
constraint**: `script-src 'self'` forbids the usual inline anti-FOUC script, so
the theme is applied by a **blocking external stylesheet** reading the stored
preference, with a `<meta>`-driven fallback mirroring the `AppShell`
`mamore-base` pattern. No FOUC, no CSP relaxation.

Resolution: explicit choice → stored preference → `prefers-color-scheme`.

**05 Base CSS** — flatten the two `@import`s into `<link>`s, add the type scale
and `tabular-nums`, the 4-based spacing utilities, the grid, and the
`prefers-reduced-motion` guarantee.

## Phase 10–11 detail — the two services

**10 i18n** — `resources/lang/{en,sw,fr}/`, `Core\Translator`, `GET /api/i18n`,
`data-i18n` attributes, `DisplayTranslator` for Categories A–D,
`content_translations` migration. Front-load this: it is the highest-friction
change and it touches every template.

**11 currency** — `ExchangeRateService`, `exchange_rates` table, `Cache`
integration, `Money::convert/format`, the TZS CHECK-constraint migration,
`GET /api/currency`, and deletion of all three ad-hoc frontend formatters.
Includes fixing `asMoney` being used for cargo weight.

## Phase 12 detail — search & palette

`GlobalSearch` already resolves rescue codes, VIP numbers, plates, trucks,
consignments and people, permission-filtered in SQL. The work is presentational:
a ⌘K palette, categorised results, and permission-aware command actions
(creation commands only where the caller holds the matching permission).

## Phase 14–20 detail — dashboards

Rebuilt against the seven-layer contract and the 12-col grid. Each reuses
existing services (`ControlCenterService`, `DispatchAdvisor`,
`PilotAnalyticsService`, `TruckService`, `VipSubscriberService`,
`PrivateVehicleService`). **No new business logic** — these are new
presentations of queries that already exist. Maps and charts load only on the
screens that need them.

## Phase 24–29 detail — hardening

Responsive verification at all 12 widths · a11y and contrast tests · performance
lint budgets · visual QA in both themes · cross-language/currency/theme QA
(EN/SW/FR × USD/TZS/CDF × light/dark) · production checklist: fingerprinted
assets, migration run, `bin/test.php` green, no console errors, RBAC unchanged.

---

## Git strategy

Branch `feature/mamore-premium-ui-v2` (created). Commits follow the brief's
vocabulary:

```
docs: audit current mamore ui
ui: create mamore design tokens
ui: implement premium light and dark themes
ui: create global application shell
feat: implement global language switching
feat: implement usd tzs cdf display currency
ui: redesign executive dashboard
ui: redesign rescue control center
ui: redesign smart bus / vip / truck cargo / private vehicles
feat: add global action center
feat: add command palette
a11y: improve accessibility
perf: optimize frontend assets
test: add presentation regression checks
```

## 8. Pre-existing defect found during Phase 03/04 verification

`tests/pilot-analytics-integration.php` fails **4 assertions**, and it fails
identically on the pre-UI baseline commit — it is **not** caused by the redesign
and was not introduced by it. Recorded here because it blocks a clean baseline.

```
FAIL: a window with no activity reports zero bookings
FAIL: a rate with no denominator is null, not zero
FAIL: occupancy says "No data available" with no trips
FAIL: revenue totals are exact decimals
```

**Cause** (line 54): the "empty platform" fixture asserts that *yesterday* is an
empty window.

```php
$empty = $analytics->summary([
    'from' => gmdate('Y-m-d', strtotime('-1 day')),
    'to'   => gmdate('Y-m-d', strtotime('-1 day')),
]);
```

That assumption holds only on a database that has never been used. The suite
provisions its own fixtures and does not backdate them, so **the first full run
writes rows dated yesterday and every later run fails** — the test is
order-dependent and not idempotent. Confirmed directly: after one suite run,
`smartbus_bookings` holds 33 rows dated `2026-09-26` ("yesterday").

This is worth fixing precisely because it is the same class of defect the brief
forbids elsewhere — a test that reports a number it did not verify. The fix is
a window the fixtures cannot touch (a fixed date in the distant past, or an
explicitly empty range guarded by a fixture), plus cleanup of created rows.

**Not fixed in this phase** on purpose: it is unrelated to the UI work, and
changing an existing integration test's semantics mid-redesign would make the
baseline ambiguous. It is tracked here and should be fixed as its own commit
before Phase 28, when the suite must be green and trustworthy.

---

## Risk register

| Risk | Impact | Mitigation |
| --- | --- | --- |
| **CSP blocks the anti-FOUC theme script** | Theme flash | Blocking external stylesheet; no CSP relaxation |
| **New Font Awesome glyphs** | Build failure | Re-subset with `fontTools 4.66.0`; `ui-wiring-test` verifies |
| **i18n is 180+ strings × 3 locales** | Long tail | `i18n-integration` fails on gaps; translate in domain batches |
| **TZS needs a schema migration** | Touches finance | CHECK constraints widened in one migration with a rollback |
| **Chart/map bundle cost** | Performance regression | Load per page only; enforced by `lint-perf` |
| **Rebuilding 23 panels at once** | Regression | One domain per phase, tests green at every commit |
| **Legacy CSS selectors** | Visual breakage | Legacy → token alias layer keeps old CSS working in transition |
| **Long FR/SW text** | Layout break | Truncation + wrapping rules; verified in Phase 28 |

## Status — what is actually verified

`S` = shipped and covered by an automated check. `H` = shipped, needs a human
with a browser. `P` = partial.

| Phase | State | Evidence |
| --- | --- | --- |
| 01–11 | S | `contrast-test`, `ui-v2-core-test`, `i18n-integration`, `currency-integration` |
| 12 | S | Palette bound; `ui-wiring-test` asserts `/api/search` is served |
| 13 | S | 52 `<dialog>` elements, balanced, with headers and backdrops (`a11y-responsive-test`) |
| 14 | S | `executive-dashboard-integration` — seven layers, figures re-derived from the DB |
| 15 | P | Rescue board live, permission-gated, metrics corrected; the incident/unit board still uses v1 markup |
| 16 | S | Tracking state bug fixed: three states, three cells. Enforced by `a11y-responsive-test` |
| 17 | P | Smart Bus command/boarding panels load through their own loaders; no domain dashboard |
| 18–20 | S | `domain-dashboard-test` — configured keys match the real payloads |
| 21 | S | Money flows through one formatter; `currency-integration` proves stored amounts are byte-identical |
| 22 | S | Analytics renders `/api/analytics/global`; field parity guarded |
| 23 | S | Notifications loader registered; Action Center ranks real counts |
| 24 | H | Breakpoints declared and guarded in source; **12 widths need a browser** |
| 25 | H | Names, dialogs, skip link, focus, motion all asserted; **screen-reader and keyboard passes need a human** |
| 26 | S | No inline scripts, no http origins, preloads present, stylesheet budget |
| 27 | — | **Not done.** Needs a browser. Nothing in this repo can replace it. |
| 28 | S (data) / H (render) | 18 combinations verified at the data layer; **rendering needs a browser** |
| 29 | S | `bin/preflight.php`, 9 checks, exits non-zero on failure |

The `H` rows are not "done with caveats". They are the part of the work that
has not been done, and `docs/ui-v2/PRODUCTION_CHECKLIST.md` lists them as
unchecked boxes rather than burying them.

## Definition of done

Tracked against the brief's 45 criteria. Non-negotiables that are **not** UI work
and must survive untouched: RBAC and server-side permission checks, route
behaviour, business logic, stored monetary values, audit completeness, and
tracking/RBAC integrity.

                       \-> 12 (search) ----|
```

Phases 10 and 11 are **not** cosmetic and **not** deferrable to the end: they
touch every template. Building them after the dashboards exist would mean
revisiting every file, which is exactly the rework the brief warns against.
