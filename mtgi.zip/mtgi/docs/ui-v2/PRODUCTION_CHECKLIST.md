# Production checklist (Phase 29)

Run `php bin/preflight.php` first. It answers the mechanical questions and
exits non-zero on any failure, so a deploy pipeline can gate on it.

## Automated — covered by `bin/preflight.php`

| Check | What it protects |
| --- | --- |
| Migrations applied and unmodified | The ledger matches the files. A modified applied migration means the schema may not match its source — this is the check that halted Phase 14. |
| No inline `<script>` or `on*=` handler | The app runs under `script-src 'self'`. An inline block fails in production and works in development. |
| CSP still strict | No `'unsafe-inline'` / `'unsafe-eval'` crept back in; `default-src`, `object-src`, `base-uri`, `frame-ancestors` all present. |
| Every referenced asset exists | A 404 stylesheet is invisible in review and fatal on screen. |
| No asset referenced twice | A duplicate `<link>` is a wasted request and a silent cascade conflict. |
| Every gated permission code exists | A renamed permission is a 403 nobody sees until a real user clicks. |
| Every role has a permission | A role with none can log in and see nothing, with no explanation. |
| Financial amounts carry a 3-letter currency | The invariant the currency work exists to protect. |
| No negative stored amounts | Catches a bad sign convention reaching the ledger. |

## Automated — covered by the test suite

`php bin/test.php` runs every `tests/*.php`. The UI-specific guards:

| Suite | Phase |
| --- | --- |
| `ui-wiring-test.php` | Every panel has a loader; every fetch hits a registered route. |
| `ui-v2-core-test.php` | Theme, tokens, and the core JS modules. |
| `contrast-test.php` | Both themes meet contrast at the sizes used. |
| `executive-dashboard-integration.php` | The seven-layer contract; figures re-derived from the database. |
| `domain-dashboard-test.php` | Configured metric keys match the real service payloads. |
| `a11y-responsive-test.php` | Accessible names, dialogs, skip link, focus, motion, breakpoints, budgets. |
| `cross-matrix-test.php` | 18 language × currency × theme combinations at the data layer. |

## NOT automated — requires a human with a browser

These are **not** verified by anything in this repository, and no claim should be
made that they are.

- [ ] **Visual QA in both themes (Phase 27).** No browser is available in the
      build environment. Every automated check above reads source; none of them
      look at a pixel. Check: overview, analytics, rescue, tracking, vip,
      truckcargo, privatevehicles in light and dark.
- [ ] **Responsive at 12 widths (Phase 24).** The breakpoints are *declared* and
      the grid uses `minmax(0, 1fr)`; whether a specific card overflows at 380px
      is not checked. Check 320 / 360 / 390 / 430 / 768 / 834 / 1024 / 1180 /
      1280 / 1440 / 1536 / 1920.
- [ ] **Rendered cross-matrix (Phase 28).** The data layer is verified for all
      18 combinations. French and Swahili text at real rendering width is not.
- [ ] **Screen reader pass.** Button names are asserted to exist; how they read
      in sequence is not checked.
- [ ] **Keyboard-only pass.** Focus is visible; tab order is not verified.
- [ ] **Browser console clean.** No runtime errors on any panel.
- [ ] **Login → every panel → logout**, as each of the five seeded roles
      (`admin@`, `hq@`, `rescue@`, `finance@`, a customer).

## Known, documented, out of scope

`tests/pilot-analytics-integration.php` fails, and did before the UI work. It
asserts that "yesterday" is empty while its own fixtures populate that window,
so it is time-dependent rather than broken. It reproduces on the pre-UI
baseline. Fixing it is a separate change, not a UI one.
