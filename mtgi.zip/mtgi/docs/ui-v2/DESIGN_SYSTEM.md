# Mamore Design System (UI v2)

Pure CSS custom properties. No framework, no preprocessor, no build step —
matching the existing stack. Tokens live in `public/assets/css/tokens.css`;
themes in `themes/light.css` and `themes/dark.css`.

---

## 1. Brand extraction — measured, not guessed

The official mark is `public/assets/mtgi-logo-256.png` (a 256×256 indexed PNG).
Sampling every pixel with GD and ranking by frequency gives the true palette:

| Hex | Pixels | Role in the mark |
| --- | --- | --- |
| `#FEFEFE` | 43 859 | white ground / knockout |
| `#012F6C` | 9 947 | **primary navy** — the dominant ink |
| `#FEAA03` | 2 397 | **gold** — the highlight |
| `#ED0302` | 2 037 | **red** — the action colour |
| `#00225D` | 1 265 | deep navy shadow / secondary plane |
| `#F7F8FA` | 756 | off-white surface |
| `#082461` | 451 | navy mid-tone |
| `#EF2A2B` | 342 | red light (antialiasing ramp) |

The existing `app.css` comment claims navy `#00306D`, red `#ED0000`, gold
`#FEAB01` — within 1–3 units of the sampled values, i.e. the current palette
was already taken from the mark. **The new tokens use the exact sampled hexes**
and keep the old names as aliases so nothing breaks.

Semantic mapping:

## 2. Token architecture

```
--brand-*        identity, immutable across themes
--bg-*           application background layers
--surface-*      raised surfaces (cards, panels, tables, drawers)
--text-*         primary / secondary / muted / inverse
--border-*       subtle / default / strong / focus
--success --warning --danger --info --critical --neutral
--radius-*       xs sm md lg xl pill
--space-*        4 8 12 16 20 24 32 40 48 64
--shadow-*       sm md lg overlay
--font-*         display + ui families, type scale
--dur-* --ease-* motion
--sidebar-width --sidebar-collapsed --topbar-height
```

Rules:

- **No raw hex outside `tokens.css` / `themes/`.** A lint script
  (`scripts/lint-tokens.php`) fails the build on a stray hex elsewhere.
- Semantic names only. `--success`, never `--green`.
- Dark theme redefines *semantic* tokens, never raw brand tokens, so a chart
  series colour stays recognisable across themes.

## 3. Typography

Direction: **Manrope** for display/headings, **Inter** for UI/body/data, per the
brief. Both self-hosted woff2, subset with `fontTools`, `font-display: swap`,
with a `unicode-range` excluding Cyrillic/Greek (the app is EN/SW/FR). If the
woff2 files cannot be obtained in the build environment, the token falls back to
the already-present Poppins and the architecture is unchanged — the family is a
token, not a hard-coded name.

| Token | Size / line-height | Weight | Use |
| --- | --- | --- | --- |
| `--text-display-xl` | 44 / 48 | 800 | Executive hero figure |
| `--text-display-l` | 34 / 40 | 800 | Page title |
| `--text-h1` | 26 / 32 | 700 | Section heading |
| `--text-h2` | 20 / 26 | 700 | Panel heading |
| `--text-h3` | 16 / 22 | 600 | Card heading |
| `--text-body-l` | 15 / 24 | 400 | Lead paragraph |
| `--text-body` | 14 / 21 | 400 | Default |
| `--text-body-s` | 13 / 19 | 400 | Dense table cell |
| `--text-caption` | 12 / 16 | 500 | Labels, meta |
| `--text-micro` | 11 / 14 | 600 | Uppercase eyebrow, table head |

**Financial and KPI figures use `font-variant-numeric: tabular-nums`** so columns
of money align to the digit. Functional requirement for finance, not decoration.

## 4. Spacing, radius, elevation

- Strict 4-based ramp. No arbitrary margins.
- Radius: buttons 10 px, inputs 9 px, cards 14 px, panels 18 px, overlays 20 px.
  Pills **only** for status, tags, filters, compact selectors.
- Elevation expresses depth order, never decoration: overlays > drawers >
  sticky bars > cards. Shadows are tinted with brand navy so they read as part
  of the identity rather than generic grey blur.
- Dark mode replaces shadows with **border + surface luminance steps**, because
  drop shadows are nearly invisible on dark surfaces.

## 5. Dark mode — layered, never `#000`

```
--bg-app        #070E1B   deep navy-black (not #000)
--surface-1     #0C1526   app panels
--surface-2     #111C31   cards
--surface-3     #17253E   raised / hovered
--surface-nav   #0A1424   sidebar & topbar
--border-subtle rgba(148,180,230,.08)
--border-default rgba(148,180,230,.14)
--text-primary  #EAF0FA
--text-secondary #A9BAD6
--text-muted    #7186A8
```

Four distinct surface levels create depth without shadow. Borders are
"illuminated" — a faint cool tint, not grey. Gold is dimmed to `#E0A21F` on dark
so it does not vibrate against navy. **Contrast is enforced, not assumed**: every
token pairing used for text is verified by `tests/contrast-test.php`, which
computes the real WCAG ratio from the stylesheet values (so it tests the system,
not a screenshot) across 40 pairings in both themes.

### Measured, not assumed

`tests/contrast-test.php` parses the tokens out of the stylesheets and computes
each pairing, so retuning a token immediately re-tests it. Running it during
this phase caught four real defects that eyeballing would have shipped:

| Finding | Was | Now | Why it matters |
| --- | --- | --- | --- |
| Light `--text-muted` | 4.23:1 on white | 5.27:1 | Muted metadata is **body text**, so it needs 4.5:1, not 3:1 |
| Dark `--text-inverse` | 1.06:1 on sidebar | 16.11:1 | It was dark ink on a dark sidebar — **invisible text** |
| `--border-control` | did not exist | 3.39–3.81:1 | A real control boundary needs 3:1 (WCAG 1.4.11) |
| Light `--border-nav-strong` | 1.92:1 | 3.28:1 | Nav separators on navy |

A dedicated `--border-control` token was introduced for this reason:
`--border-subtle` / `--border-default` are for decoration and grouping and stay
subtle, while anything that must be *identifiable* as a control uses
`--border-control`, which clears 3:1 on every surface it can land on.

## 6. Light mode

```
--bg-app        #F4F6FA   cool neutral
--surface-1     #FFFFFF
--surface-2     #FFFFFF  (separated by border + shadow, not by tone)
--surface-3     #F8FAFD
--surface-nav   #012F6C
--border-subtle #E8ECF3
--border-default #D8E0EC
--text-primary  #0B1A2E
--text-secondary #46587A
--text-muted    #6B7C99
```

Light mode separates surfaces with borders and restrained shadows rather than
grey fills, which is what keeps it from looking like a Bootstrap panel.

## 7. Component contract (34 components)

Button, IconButton, Badge, StatusPill, Card, Metric, InsightCard, Alert,
Dropdown, Tabs, Table, Pagination, Drawer, Modal, Toast, Tooltip, Popover,
FormControl, Select, DateRange, CurrencySelector, LanguageSelector,
ThemeSwitcher, ChartCard, MapPanel, ActionCenter, Timeline, EmptyState,
ErrorState, Skeleton, Avatar, Breadcrumb, PageHeader.

Rules that make this a *system* rather than a collection:

- **Status is semantic.** `StatusPill` maps a *domain value* (`ONLINE`,
  `IN_TRANSIT`, `CRITICAL`) to a tone via one lookup table. No page re-styles a
  status. Tone is always paired with an icon or text label, never colour alone
  (WCAG 1.4.1).
- **Five button variants only**: primary, secondary, ghost, danger, icon.
  Destructive actions *must* use `danger`.
- **Every asynchronous surface has four states**: loading (skeleton), empty
  (explains why + offers an action), error (distinguishes permission / network /
  server / stale), ready. These are components, not ad-hoc strings.
- **Density** is a `data-density` attribute on `<body>`: `comfortable` (default)
  or `compact` for Control Center and finance.

## 8. Icon system

Font Awesome 6 Free, solid, **154-glyph self-subset** (~10 KB) with a build
guard in `tests/ui-wiring-test.php`. A central `Icon` semantic map binds
concepts to glyphs so the same idea never wears two icons:

`home`, `chart`, `bus`, `truck`, `car`, `crown`, `pin`, `satellite`,
`warning`, `ambulance`, `shield`, `receipt`, `wallet`, `ticket`, `route`,
`boxes`, `user-shield`, `bell`, `search`, `language`, `coins`, plus UI glyphs.

**Any new icon requires re-subsetting** `fa-solid-subset.woff2` with
`fontTools 4.66.0` and adding the rule to `fontawesome.css`, or the build fails.
That is a feature, not an obstacle — it keeps the icon font at 10 KB.


| Token | Value | Rationale |
| --- | --- | --- |
| `--brand-primary` | `#012F6C` | Navy. Chrome, sidebar, headers, primary buttons. |
| `--brand-primary-2` | `#0A429A` | Lifted navy for hover / gradient partner. |
| `--brand-primary-dark` | `#00225D` | Pressed / deep plane. |
| `--brand-accent` | `#FEAA03` | Gold. Active nav, emphasis, rescue protection, charts. |
| `--brand-action` | `#ED0302` | Red. Destructive + primary submit only — used sparingly. |

**Gold discipline.** Gold is the most distinctive brand asset and the easiest to
overspend. It is reserved for: active navigation indicator, key action on a calm
surface, Rescue-protected state, chart emphasis series, and selected states. It
is never body text, never a large fill, and never on two adjacent components.
Red is reserved for destructive and critical only.
