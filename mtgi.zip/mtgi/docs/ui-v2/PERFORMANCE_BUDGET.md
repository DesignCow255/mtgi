# Performance Budget

Premium means fast. Every budget below is a **build-time check**
(`scripts/lint-perf.php`), not an aspiration. The application has no build step
today, so the lint scripts are how a no-Node CI keeps itself honest — the same
approach `tests/ui-wiring-test.php` already uses successfully.

---

## 1. Core Web Vitals targets

| Metric | Target | Why it matters here |
| --- | --- | --- |
| **LCP** | < 2.0 s (p75) | Dashboard must be useful fast |
| **INP** | < 150 ms (p75) | Filter/table/sort interactions |
| **CLS** | < 0.05 | Skeletons reserve geometry |
| **TTFB** | < 300 ms | PHP + PDO, no framework overhead |

## 2. Transfer budgets

| Resource | Budget | Current |
| --- | --- | --- |
| Critical CSS (shell + tokens + layout) | ≤ 30 KB raw | ~33 KB in one file |
| All CSS (loaded) | ≤ 60 KB raw | ~35 KB |
| Core JS (shell, i18n, currency, theme, api) | ≤ 45 KB raw | ~30 KB |
| Per-page JS | ≤ 25 KB raw | 4 flat bundles today |
| Fonts | ≤ 90 KB (2 families, 4 weights, latin) | 11 Poppins files |
| Icon font | ≤ 15 KB | ~10 KB (already excellent) |
| Chart library | ≤ 70 KB gzip, **only on chart pages** | 0 (does not exist) |
| Map library | ≤ 90 KB gzip, **only on map screens** | 0 (does not exist) |

Chart and map bundles are the big new cost, and the rule that keeps the budget
honest is: **they are loaded on the pages that need them and nowhere else.** The
login screen ships neither.

## 3. Delivery rules

- **One `<link>` per stylesheet**, no `@import` chains in production. Today's
  `app.css` opens with `@import url("fonts.css")` and `@import
  url("fontawesome.css")` — two extra round trips that must be flattened into
  `<link>` tags in the shell.
- **Cache busting by fingerprint**: `app.<hash>.css`. Assets are currently
  unversioned, so a deploy can serve stale CSS to a warm browser — a real
  production-hazard, fixed here.
- **Immutable caching** on fingerprinted files, `no-cache` on the HTML shell.
- **Preload only what the first screen needs** — currently 2 Poppins weights,
  which is correct and should become 1 family + 2 weights at most.
- `font-display: swap` everywhere, with a metric-compatible fallback so the swap
  does not shift layout.
- `defer` on all scripts; `async` is not used for ordered modules.
- Compression: the `.htaccess` already serves assets from disk; gzip/brotli for
  text assets is added there (MAMP/Apache), not in PHP.

## 4. Rendering performance

- **No layout thrash**: charts render once per data change, not per frame.
- `content-visibility: auto` on long below-the-fold panels.
- **Map**: canvas rendering + marker clustering, never thousands of DOM markers.
  Current position endpoint only; **GPS history is never loaded automatically**.
- **Tables**: server pagination, so DOM row count stays bounded regardless of
  table size. Virtualisation is not required at page-size row counts and is
  deliberately not added.
- `requestAnimationFrame`-throttled resize handlers, debounced filter input
  (150 ms).

## 5. Animation budget

- No continuous expensive animation on dashboards.
- No particles, no WebGL, no large decorative motion.
- Only `transform` and `opacity` are animated — both are compositor-friendly and
  do not trigger layout.
- Skeleton shimmer is the single looping animation, and it is disabled under
  `prefers-reduced-motion`.
- "Futuristic" comes from composition, precision, typography and depth — not
  from effects that cost frames.

## 6. Backend latency

- No N+1 queries. Dashboard services batch by domain; each new dashboard
  endpoint is measured.
- `EXPLAIN` reviewed for the Action Center, Control Center and analytics queries
  — these are the only genuinely heavy reads in the product.
- `EXISTS`/`IN` scoping preserved from `GlobalSearch` so permission filtering
  stays in the index-friendly form.
- Exchange rates are cached 15 min and refreshed by a cron job, never inline on
  a render.

## 7. Skeleton-first data UX

Every async region reserves its final dimensions before data arrives. The
existing pattern of "empty container → inject content" is what causes today's
layout shift; skeletons with matched geometry remove it.
