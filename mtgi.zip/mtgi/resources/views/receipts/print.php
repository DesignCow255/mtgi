<?php
/**
 * Printable Mamore receipt (view: receipts/print.php).
 *
 * $receipt is the hydrated ReceiptService payload. Chargeable lines reconcile to
 * the amount paid; the subset lines are printed as a transparent sub-allocation
 * of the taxable container and are explicitly labelled as not additive.
 *
 * @var array<string, mixed> $receipt
 */
$esc = static fn (mixed $value): string => \Mamore\Core\View::esc($value);
$breakdown = $receipt['breakdown'] ?? [];
$chargeable = $breakdown['chargeable'] ?? [];
$subsets = $breakdown['subsets'] ?? [];
?>
<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Mamore receipt <?= $esc($receipt['receiptNumber'] ?? '') ?></title>
  <link rel="stylesheet" href="<?= $esc(\Mamore\Core\Url::to('/assets/receipt.css')) ?>">
  <!-- The receipt is a standalone page, so it pulls the icon font in directly
       rather than inheriting the application shell's stylesheet. -->
  <link rel="stylesheet" href="<?= $esc(\Mamore\Core\Url::to('/assets/fontawesome.css')) ?>">
</head>
<body>
  <article class="receipt-sheet">
    <header>
      <div class="receipt-identity">
        <img class="receipt-logo" src="<?= $esc(\Mamore\Core\Url::to('/assets/mtgi-logo-128.png')) ?>" alt="MTGI" width="54" height="54">
        <div>
          <h1>Mamore Rescue Services</h1>
          <small>MTGI &middot; Digital Reliable Rescue</small>
        </div>
      </div>
      <div>
        <div class="receipt-number"><?= $esc($receipt['receiptNumber'] ?? '') ?></div>
        <div class="receipt-status <?= ($receipt['status'] ?? '') === 'VOID' ? 'is-void' : '' ?>"><?= $esc($receipt['status'] ?? '') ?></div>
      </div>
    </header>

    <dl class="receipt-parties">
      <div>
        <dt>Subscriber</dt>
        <dd>
          <i class="fa-solid fa-user" aria-hidden="true"></i>
          <?= $esc($receipt['subscriber']['name'] ?? '') ?>
          <?php if (!empty($receipt['subscriber']['membershipNumber'])): ?>
            &mdash; <?= $esc($receipt['subscriber']['membershipNumber']) ?>
          <?php endif; ?>
        </dd>
      </div>
      <div>
        <dt>Subscription</dt>
        <dd>
          <i class="fa-solid fa-shield-heart" aria-hidden="true"></i>
          <?= $esc($receipt['subscription']['subscriptionNo'] ?? '') ?>
          &mdash; <?= $esc($receipt['subscription']['productCode'] ?? '') ?>
          in <?= $esc($receipt['subscription']['province'] ?? '') ?>
        </dd>
      </div>
      <div>
        <dt>Paid</dt>
        <dd>
          <i class="fa-solid fa-credit-card" aria-hidden="true"></i>
          <?= $esc($receipt['payment']['method'] ?? '') ?>
          via <?= $esc($receipt['payment']['provider'] ?? '') ?>
          on <?= $esc($receipt['payment']['paidAt'] ?? '') ?>
        </dd>
      </div>
      <div>
        <dt>Coverage</dt>
        <dd><i class="fa-solid fa-calendar-days" aria-hidden="true"></i><?= $esc($receipt['subscription']['startDate'] ?? '') ?> to <?= $esc($receipt['subscription']['endDate'] ?? '') ?></dd>
      </div>
    </dl>

    <table>
      <caption>Charged components</caption>
      <thead>
        <tr><th scope="col">Component</th><th scope="col" class="amount">Amount</th></tr>
      </thead>
      <tbody>
        <?php foreach ($chargeable as $line): ?>
          <tr>
            <td><?= $esc($line['name'] ?? '') ?></td>
            <td class="amount"><?= $esc($line['formatted'] ?? '') ?></td>
          </tr>
        <?php endforeach; ?>
        <tr class="is-total">
          <td><i class="fa-solid fa-sack-dollar" aria-hidden="true"></i>Total paid</td>
          <td class="amount"><?= $esc($receipt['amountFormatted'] ?? '') ?></td>
        </tr>
      </tbody>
    </table>

    <?php if ($subsets !== []): ?>
      <table>
        <caption>Sub-allocation of the taxable container (informational, not added to the total)</caption>
        <thead>
          <tr><th scope="col">Component</th><th scope="col" class="amount">Amount</th></tr>
        </thead>
        <tbody>
          <?php foreach ($subsets as $line): ?>
            <tr class="is-subset">
              <td>
                <?= $esc($line['name'] ?? '') ?>
                <?php if (!empty($line['province'])): ?>
                  <em>(<?= $esc($line['province']) ?>)</em>
                <?php endif; ?>
              </td>
              <td class="amount"><?= $esc($line['formatted'] ?? '') ?></td>
            </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    <?php endif; ?>

    <p class="receipt-note">
      The sub-allocation above breaks down the taxable container of
      <?= $esc($breakdown['totals']['taxableContainerUsd'] ?? '0.00') ?> USD and is already included in the total paid.
      Verify this receipt with the code below or the QR data on the original.
    </p>

    <div class="receipt-verify">
      <div><i class="fa-solid fa-shield-halved" aria-hidden="true"></i>Verification code: <code><?= $esc($receipt['verificationNumber'] ?? '') ?></code></div>
      <div class="barcode"><?= $esc($receipt['barcodeData'] ?? '') ?></div>
      <div><i class="fa-solid fa-clock" aria-hidden="true"></i>Issued <?= $esc($receipt['issuedAt'] ?? '') ?><?php if (($receipt['printCount'] ?? 0) > 0): ?> &mdash; print #<?= $esc($receipt['printCount']) ?><?php endif; ?></div>
    </div>
  </article>
</body>
</html>
