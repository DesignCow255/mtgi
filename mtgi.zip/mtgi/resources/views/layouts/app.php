<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title><?= Mamore\Core\View::esc($title ?? 'Mamore') ?></title>
  <link rel="stylesheet" href="/assets/app.css">
</head>
<body>
  <a class="skip-link" href="#main">Skip to content</a>
  <main id="main"><?= $slot ?? '' ?></main>
</body>
</html>
