<?php

declare(strict_types=1);

/* Vue exécutive — le vocabulaire. Les mêmes clés que l'anglais, aucune de plus. */

return [
    'title' => 'Vue d\'ensemble exécutive',
    'eyebrow' => 'Écosystème Mamore',

    'tracked_assets' => 'Actifs suivis',
    'people_under_protection' => 'Personnes sous protection',
    'active_incidents' => 'Incidents actifs',
    'rescue_teams_available' => 'Équipes de sauvetage disponibles',
    'revenue_collected' => 'Recettes encaissées',
    'requires_attention' => 'Nécessite votre attention',
    'system_status' => 'État du système',
    'collections_today' => 'Encaissements du jour',
    'items_count' => '{count} élément(s)',

    'action_critical_incidents' => 'Incidents critiques ouverts',
    'action_gps_offline' => 'Dispositifs de suivi hors ligne',
    'action_gps_stale' => 'Signaux de suivi retardés',
    'action_subscriptions_expiring' => 'Abonnements expirant sous 7 jours',
    'action_unpaid' => 'Billets non payés',

    'trend_incidents' => 'Incidents signalés',
    'trend_resolved' => 'Incidents résolus',
    'trend_payments' => 'Paiements reçus',
    'activity_over_time' => 'Activité dans le temps',
    'action_gps_never_reported' => 'Appareils n\'ayant jamais signalé',

    'pulse_tracking' => 'Suivi',
    'pulse_rescue' => 'Intervention de sauvetage',
    'pulse_payments' => 'Paiements',
    'pulse_subscriptions' => 'Abonnements',
    'pulse_response' => 'Temps de réponse moyen',
    'pulse_healthy' => 'Opérationnel',
    'pulse_normal' => 'Normal',
    'pulse_active' => 'Actif',
    'pulse_attention' => 'Attention',
    'pulse_expiring' => 'Expirant',
    'pulse_degraded' => 'Dégradé',
    'pulse_offline' => 'Hors ligne',
    'pulse_unknown' => 'Inconnu',
    'pulse_no_data' => 'Aucune donnée',

    'loading' => 'Chargement de la situation opérationnelle…',
    'no_summary' => 'Aucun résumé disponible.',
    'no_metrics_title' => 'Aucune métrique disponible',
    'no_metrics_body' => 'Rien n\'a pu être dénombré pour cette période.',
    'nothing_attention_title' => 'Rien n\'requiert votre attention',
    'nothing_attention_body' => 'Toutes les opérations surveillées sont actuellement normales.',
];
