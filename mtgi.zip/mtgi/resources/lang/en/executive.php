<?php

declare(strict_types=1);

/*
 * Executive overview vocabulary.
 *
 * Deliberately flat and short: this is the screen an executive reads in ten
 * seconds, and a key that needs translating into three languages is already too
 * long. The SENTENCE itself is generated server-side from these counts rather
 * than stored here, because a translated sentence that no longer matches the
 * numbers behind it is worse than no sentence at all.
 */

return [
    'title' => 'Executive overview',
    'eyebrow' => 'Mamore Ecosystem',

    'tracked_assets' => 'Tracked assets',
    'people_under_protection' => 'People under protection',
    'active_incidents' => 'Active incidents',
    'rescue_teams_available' => 'Rescue teams available',
    'revenue_collected' => 'Revenue collected',
    'requires_attention' => 'Requires attention',
    'system_status' => 'System status',
    'collections_today' => 'Collections today',
    'items_count' => '{count} item(s)',

    // Action Center
    'action_critical_incidents' => 'Critical incidents open',
    'action_gps_offline' => 'Tracking devices offline',
    'action_gps_stale' => 'Tracking signals delayed',
    'action_subscriptions_expiring' => 'Subscriptions expiring within 7 days',
    'action_unpaid' => 'Unpaid tickets',

    'trend_incidents' => 'Incidents reported',
    'trend_resolved' => 'Incidents resolved',
    'trend_payments' => 'Payments received',
    'activity_over_time' => 'Activity over time',
    'action_gps_never_reported' => 'Devices that have never reported',

    // Pulse
    'pulse_tracking' => 'Tracking',
    'pulse_rescue' => 'Rescue dispatch',
    'pulse_payments' => 'Payments',
    'pulse_subscriptions' => 'Subscriptions',
    'pulse_response' => 'Average response',
    'pulse_healthy' => 'Healthy',
    'pulse_normal' => 'Normal',
    'pulse_active' => 'Active',
    'pulse_attention' => 'Attention',
    'pulse_expiring' => 'Expiring',
    'pulse_degraded' => 'Degraded',
    'pulse_offline' => 'Offline',
    'pulse_unknown' => 'Unknown',
    'pulse_no_data' => 'No data',

    // States
    'loading' => 'Loading the operational picture…',
    'no_summary' => 'No summary available.',
    'no_metrics_title' => 'No metrics available',
    'no_metrics_body' => 'Nothing could be counted for this period.',
    'nothing_attention_title' => 'Nothing needs attention',
    'nothing_attention_body' => 'All monitored operations are currently clear.',
];
