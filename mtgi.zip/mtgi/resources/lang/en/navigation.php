<?php

declare(strict_types=1);

/*
 * Navigation labels and the domain vocabulary.
 *
 * These are the strings the server resolves for /api/navigation, so the sidebar
 * is translated without the client shipping a second copy of the vocabulary.
 */

return [
    // Groups
    'group_overview' => 'Overview',
    'group_operations' => 'Operations',
    'group_mobility' => 'Mobility',
    'group_services' => 'Services',
    'group_intelligence' => 'Intelligence',
    'group_administration' => 'Administration',
    'group_my_mamore' => 'My Mamore',

    // Destinations
    'home' => 'Home',
    'control_center' => 'Control Center',
    'rescue_operations' => 'Rescue operations',
    'panic_alerts' => 'Panic alerts',
    'live_tracking' => 'Live tracking',
    'smart_bus' => 'Smart Bus',
    'boarding_manifest' => 'Boarding & manifest',
    'command_centre' => 'Command centre',
    'truck_cargo' => 'Truck & cargo',
    'private_vehicles' => 'Private vehicles',
    'vip_subscribers' => 'VIP subscribers',
    'rescue_subscriptions' => 'Rescue subscriptions',
    'analytics' => 'Analytics',
    'finance' => 'Finance',
    'receipts' => 'Receipts',
    'users' => 'Users',
    'security_sessions' => 'Security & sessions',
    'notifications' => 'Notifications',
    'audit_trail' => 'Audit trail',
    'find_trip' => 'Find a trip',
    'my_bookings' => 'My bookings',
    'my_rescue_cover' => 'My rescue cover',
    'my_vehicles' => 'My vehicles',
    'account_security' => 'Account security',

    // Domain switcher
    'domain_label' => 'Current domain',
    'domain_rescue' => 'Rescue Operations',
    'domain_tracking' => 'Tracking',
    'domain_smart_bus' => 'Smart Bus',
    'domain_vip' => 'VIP',
    'domain_truck' => 'Truck & Cargo',
    'domain_private' => 'Private Vehicles',
    'domain_analytics' => 'Analytics',
    'domain_administration' => 'Administration',

    // No-permission state
    'nav_empty' => 'No sections are available for your role. Contact an administrator.',
    'nav_empty_loading' => 'Loading your sections…',
    'collapse' => 'Collapse',
    'expand' => 'Expand',
    'system_connected' => 'System connected',
];
