<?php

declare(strict_types=1);

/*
 * Common strings: the vocabulary shared by every domain.
 *
 * English is the SOURCE catalogue. Every other locale falls back here, so a key
 * missing from a translation renders readable English rather than a raw key.
 * That is what makes adding a language incrementally safe.
 */

return [
    'app' => 'Mamore',
    'operations' => 'Mamore Operations',

    // Actions
    'save' => 'Save',
    'cancel' => 'Cancel',
    'close' => 'Close',
    'refresh' => 'Refresh',
    'retry' => 'Try again',
    'export' => 'Export',
    'search' => 'Search',
    'filter' => 'Filter',
    'clear' => 'Clear',
    'apply' => 'Apply',
    'back' => 'Back',
    'next' => 'Next',
    'sign_out' => 'Sign out',
    'create' => 'Create',
    'view_all' => 'View all',
    'add' => 'Add',
    'remove' => 'Remove',
    'confirm' => 'Confirm',
    'copy' => 'Copy',
    'print' => 'Print',

    // Time and freshness
    'just_now' => 'now',
    'seconds_ago' => '{count} sec ago',
    'minutes_ago' => '{count} min ago',
    'hours_ago' => '{count} h ago',
    'days_ago' => '{count} d ago',
    'last_updated' => 'Last updated {at}',
    'live' => 'Live',
    'delayed' => 'Delayed',
    'stale' => 'Stale',
    'offline' => 'Offline',
    'unknown' => 'Unknown',

    // States — used by the four-state contract
    'state_loading' => 'Loading',
    'state_empty_title' => 'Nothing here yet',
    'state_error_network_title' => 'Could not reach the server',
    'state_error_network_body' => 'The request did not complete. Check the connection and try again.',
    'state_error_permission_title' => 'You do not have access to this',
    'state_error_permission_body' => 'This area is limited by your role. Ask an administrator if you need it.',
    'state_error_server_title' => 'The server could not complete this',
    'state_error_server_body' => 'Something failed while loading this data. Try again, and report it if it continues.',
    'state_error_stale_title' => 'This data is out of date',
    'state_error_stale_body' => 'It was loaded earlier and has not refreshed. The figures shown are the last known values.',
    'state_error_offline_title' => 'You are offline',
    'state_error_offline_body' => 'This device has no connection, so live data cannot be fetched. Values shown are from the last sync.',

    // Units
    'unit_minutes' => 'min',
    'unit_hours' => 'h',
    'unit_km' => 'km',
    'unit_kg' => 'kg',
    'unit_tonnes' => 't',
    'unit_kmh' => 'km/h',

    // Accessibility helpers
    'nav_main' => 'Main navigation',
    'nav_breadcrumb' => 'Breadcrumb',
    'search_placeholder' => 'Search plates, rescue codes, trips, consignments',
    'theme_label' => 'Colour theme',
    'theme_light' => 'Light',
    'theme_dark' => 'Dark',
    'theme_system' => 'System',
    'density_label' => 'Density',
    'density_comfortable' => 'Comfortable',
    'density_compact' => 'Compact',
];
