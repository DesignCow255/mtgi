<?php

declare(strict_types=1);

/*
 * Status labels — Category B controlled data.
 *
 * The database stores a CODE (`IN_TRANSIT`, `CRITICAL`, `PENDING_PAYMENT`).
 * These files are the only place a code becomes a word, so the same status can
 * never read differently on two screens. This is exactly the gap the audit
 * recorded: the value was interpolated raw, so a French operator saw "CRITICAL".
 *
 * The key names are the database values verbatim, which makes a missing
 * translation detectable: a code with no key here is a code the UI cannot render
 * in any language, and tests/i18n-integration.php fails on it.
 */

return [
    // Healthy
    'ONLINE' => 'Online',
    'OFFLINE' => 'Offline',
    'ACTIVE' => 'Active',
    'INACTIVE' => 'Inactive',
    'AVAILABLE' => 'Available',
    'READY' => 'Ready',
    'COVERED' => 'Covered',
    'COMPLETED' => 'Completed',
    'COMPLETE' => 'Complete',
    'PAID' => 'Paid',
    'SETTLED' => 'Settled',
    'RESOLVED' => 'Resolved',
    'CLOSED' => 'Closed',
    'VERIFIED' => 'Verified',
    'APPROVED' => 'Approved',
    'DELIVERED' => 'Delivered',
    'BOARDED' => 'Boarded',
    'CONFIRMED' => 'Confirmed',
    'OK' => 'OK',
    'HEALTHY' => 'Healthy',
    'NORMAL' => 'Normal',
    'SUCCESS' => 'Success',
    'OPERATIONAL' => 'Operational',
    'RECOVERED' => 'Recovered',
    'DELIVERING' => 'Delivering',
    'RENEWED' => 'Renewed',

    // In progress
    'IN_TRANSIT' => 'In transit',
    'DISPATCHED' => 'Dispatched',
    'EN_ROUTE' => 'En route',
    'SCHEDULED' => 'Scheduled',
    'BOARDING' => 'Boarding',
    'PROCESSING' => 'Processing',
    'PENDING' => 'Pending',
    'IN_PROGRESS' => 'In progress',
    'RUNNING' => 'Running',
    'DEPARTED' => 'Departed',
    'ACKNOWLEDGED' => 'Acknowledged',
    'ASSIGNED' => 'Assigned',
    'PENDING_ACTIVATION' => 'Pending activation',

    // Needs attention
    'DELAYED' => 'Delayed',
    'STALE' => 'Stale',
    'DEGRADED' => 'Degraded',
    'DEGRADING' => 'Degrading',
    'EXPIRING' => 'Expiring',
    'PENDING_PAYMENT' => 'Pending payment',
    'PARTIAL' => 'Partial',
    'MAINTENANCE' => 'Maintenance',
    'OFF_ROUTE' => 'Off route',
    'DELAY' => 'Delay',
    'LOW' => 'Low',
    'MEDIUM' => 'Medium',
    'HIGH' => 'High',

    // Blocking
    'CRITICAL' => 'Critical',
    'FAILED' => 'Failed',
    'EXPIRED' => 'Expired',
    'SUSPENDED' => 'Suspended',
    'CANCELLED' => 'Cancelled',
    'DECLINED' => 'Declined',
    'VOID' => 'Void',
    'BREACH' => 'Breach',
    'DOWN' => 'Down',
    'EMERGENCY' => 'Emergency',
    'OVERDUE' => 'Overdue',
    'UNPAID' => 'Unpaid',
    'ESCALATED' => 'Escalated',
    'LOCKED' => 'Locked',
    'BLOCKED' => 'Blocked',

    // Neutral
    'NO_DEVICE' => 'No device',
    'NO_POSITION' => 'No position',
    'NOT_APPLICABLE' => 'Not applicable',
    'DRAFT' => 'Draft',
    'IDLE' => 'Idle',
    'DISABLED' => 'Disabled',
    'ARCHIVED' => 'Archived',
    'UNKNOWN' => 'Unknown',
    'NONE' => 'None',
    'PLANNED' => 'Planned',
];
