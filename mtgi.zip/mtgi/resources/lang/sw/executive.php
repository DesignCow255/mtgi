<?php

declare(strict_types=1);

/* Muhtasari wa kiotumbacho — msamiati. Vitufe vile vile kama Kiingereza, hakuna kimoja zaidi. */

return [
    'title' => 'Muhtasari wa kiotumbacho',
    'eyebrow' => 'Ekosistemu ya Mamore',

    'tracked_assets' => 'Vifaa vinavyofuatiliwa',
    'people_under_protection' => 'Watu chini ya ulinzi',
    'active_incidents' => 'Maudhui yanayoendelea',
    'rescue_teams_available' => 'Timu za uokoaji zilizopo',
    'revenue_collected' => 'Mapato yaliyokusanywa',
    'requires_attention' => 'Inahitaji uangalizi',
    'system_status' => 'Hali ya mfumo',
    'collections_today' => 'Makusanyiko ya leo',
    'items_count' => 'Vipengele {count}',

    'action_critical_incidents' => 'Maudhui muhtasari yaliyo wazi',
    'action_gps_offline' => 'Vifaa vya ufuatiliaji nje ya mtandao',
    'action_gps_stale' => 'Ishara za ufuatiliaji zilizochelewa',
    'action_subscriptions_expiring' => 'Msubscriptions zinaisha ndani ya siku 7',
    'action_unpaid' => 'Tikiti hazijalipwa',

    'trend_incidents' => 'Maudhui yaliyoripotiwa',
    'trend_resolved' => 'Maudhui yaliyokwishuliwa',
    'trend_payments' => 'Malipo yaliyopokelewa',
    'activity_over_time' => 'Shughuli kwa muda',
    'action_gps_never_reported' => 'Vifaa ambavyo hawakuwahi kuripoti',

    'pulse_tracking' => 'Ufuatiliaji',
    'pulse_rescue' => 'Uokoaji',
    'pulse_payments' => 'Malipo',
    'pulse_subscriptions' => 'Msubscriptions',
    'pulse_response' => 'Wastani wa jibu',
    'pulse_healthy' => 'Nzuri',
    'pulse_normal' => 'Kawaida',
    'pulse_active' => 'Inaendelea',
    'pulse_attention' => 'Inahitaji uangalizi',
    'pulse_expiring' => 'Inaisha karibuni',
    'pulse_degraded' => 'Imedhorora',
    'pulse_offline' => 'Nje ya mtandao',
    'pulse_unknown' => 'Haijulikani',
    'pulse_no_data' => 'Hakuna taarifa',

    'loading' => 'Inapakia hali ya uendeshaji…',
    'no_summary' => 'Hakuna muhtasari unaopatikana.',
    'no_metrics_title' => 'Hakuna vipimo vinavyopatikana',
    'no_metrics_body' => 'Hakuna kilichohesabiwa katika kipindi hiki.',
    'nothing_attention_title' => 'Hakuna kinachohitaji uangalizi',
    'nothing_attention_body' => 'Shughuli zote zinazofuatiliwa ziko katika hali nzuri sasa hivi.',
];
