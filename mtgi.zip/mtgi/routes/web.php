<?php

declare(strict_types=1);

// Web routes mirror React intent: staff, portal, smart-bus, health.
// API routes remain in public/index.php until controllers split.
return [
    'GET /' => 'landing',
    'GET /login' => 'staff.login',
    'GET /home' => 'staff.home',
    'GET /portal/login' => 'portal.login',
];
