<?php

declare(strict_types=1);

namespace Mamore\Alerts;

use Mamore\Auth\AuthException;
use Mamore\Core\Request;
use Mamore\Core\Uuid;
use Mamore\Rescue\RescueService;
use PDO;

final class PanicService
{
    public function __construct(private readonly PDO $database) {}

    public function activate(array $input,array $subscriber,Request $request):array
    {
        $location=$this->required($input,'location','Location or landmark');
        $lat=$this->coordinate($input['latitude']??null,-90,90);$lng=$this->coordinate($input['longitude']??null,-180,180);
        $province=$this->choice($input['province']??'', ['HAUT_KATANGA','LUALABA'],'province');
        $message=is_string($input['message']??null)?trim($input['message']):'';
        $this->database->beginTransaction();
        try{
            $incident=(new RescueService($this->database))->report(['source'=>'PANIC_DEVICE','callerName'=>trim($subscriber['first_name'].' '.$subscriber['last_name']),'callerPhone'=>(strlen((string)($subscriber['phone']?:'')) <= 32 ? ($subscriber['phone']?:'') : ''),'province'=>$province,'location'=>$location,'latitude'=>$lat,'longitude'=>$lng,'description'=>$message!==''?$message:'Subscriber activated the Mamore SOS panic alert.','priority'=>'CRITICAL'],$subscriber);
            $id=Uuid::v4();$code='SOS-'.gmdate('ymd').'-'.strtoupper(bin2hex(random_bytes(3)));
            $statement=$this->database->prepare('INSERT INTO panic_alerts(id,alert_code,subscriber_user_id,rescue_incident_id,latitude,longitude,location_text,message) VALUES(:id,:code,:subscriber,:incident,:lat,:lng,:location,:message)');
            $statement->execute(['id'=>$id,'code'=>$code,'subscriber'=>$subscriber['id'],'incident'=>$incident['id'],'lat'=>$lat,'lng'=>$lng,'location'=>$location,'message'=>$message===''?null:$message]);
            $notify=$this->database->prepare(<<<'SQL'
                INSERT INTO user_notifications(user_id,notification_type,title,message,entity_type,entity_id)
                SELECT DISTINCT u.id,'PANIC_ALERT',:title,:message,'PanicAlert',:entity
                FROM users u JOIN role_permissions rp ON rp.role_id=u.role_id JOIN permissions p ON p.id=rp.permission_id
                WHERE p.code='rescue.dispatch' AND u.status='ACTIVE' AND u.deleted_at IS NULL
                SQL);
            $notify->execute(['title'=>'Critical SOS alert '.$code,'message'=>trim($subscriber['first_name'].' '.$subscriber['last_name']).' needs emergency assistance at '.$location.'.','entity'=>$id]);
            $this->database->commit();
        }catch(\Throwable $error){$this->database->rollBack();throw $error;}
        return ['id'=>$id,'code'=>$code,'incidentCode'=>$incident['code'],'status'=>'ACTIVE','location'=>$location,'latitude'=>$lat,'longitude'=>$lng,'activatedAt'=>gmdate(DATE_ATOM)];
    }

    public function board():array
    {
        $alerts=$this->database->query(<<<'SQL'
            SELECT p.*,u.first_name,u.last_name,u.phone,u.email,i.incident_code,i.priority,i.status AS incident_status
            FROM panic_alerts p JOIN users u ON u.id=p.subscriber_user_id JOIN rescue_incidents i ON i.id=p.rescue_incident_id
            ORDER BY FIELD(p.status,'ACTIVE','ACKNOWLEDGED','RESOLVED','CANCELLED'),p.activated_at DESC LIMIT 100
            SQL)->fetchAll();
        $metrics=['active'=>0,'acknowledged'=>0,'resolved'=>0];foreach($alerts as $alert){$key=strtolower($alert['status']);if(isset($metrics[$key]))$metrics[$key]++;}
        return ['metrics'=>$metrics,'alerts'=>array_map([$this,'alert'],$alerts)];
    }

    public function mine(array $user):array
    {
        $statement=$this->database->prepare('SELECT p.*,i.incident_code,i.status AS incident_status FROM panic_alerts p JOIN rescue_incidents i ON i.id=p.rescue_incident_id WHERE p.subscriber_user_id=:user ORDER BY p.activated_at DESC');$statement->execute(['user'=>$user['id']]);
        return array_map([$this,'alert'],$statement->fetchAll());
    }

    public function acknowledge(string $id,array $actor):array
    {
        $statement=$this->database->prepare("UPDATE panic_alerts SET status='ACKNOWLEDGED',acknowledged_by_user_id=:actor,acknowledged_at=UTC_TIMESTAMP(6) WHERE id=:id AND status='ACTIVE'");$statement->execute(['actor'=>$actor['id'],'id'=>$id]);if($statement->rowCount()!==1)throw new AuthException('Active panic alert not found.',404);
        return ['id'=>$id,'status'=>'ACKNOWLEDGED'];
    }

    public function notifications(array $user):array
    {
        // The notification centre is owned by NotificationService so the portal,
        // the panic board and payments share one reader.
        return (new NotificationService($this->database))->list($user);
    }

    private function alert(array $row):array{return ['id'=>$row['id'],'code'=>$row['alert_code'],'subscriberName'=>isset($row['first_name'])?trim($row['first_name'].' '.$row['last_name']):null,'phone'=>$row['phone']??null,'email'=>$row['email']??null,'incidentCode'=>$row['incident_code'],'incidentStatus'=>$row['incident_status'],'location'=>$row['location_text'],'message'=>$row['message'],'latitude'=>$row['latitude']!==null?(float)$row['latitude']:null,'longitude'=>$row['longitude']!==null?(float)$row['longitude']:null,'status'=>$row['status'],'activatedAt'=>$row['activated_at'],'acknowledgedAt'=>$row['acknowledged_at']];}
    private function required(array $input,string $key,string $label):string{$value=is_string($input[$key]??null)?trim($input[$key]):'';if($value==='')throw new AuthException("{$label} is required.",422);return $value;}
    private function choice(mixed $value,array $allowed,string $label):string{$value=is_string($value)?strtoupper(trim($value)):'';if(!in_array($value,$allowed,true))throw new AuthException("Select a valid {$label}.",422);return $value;}
    private function coordinate(mixed $value,float $min,float $max):?float{if($value===null||$value==='')return null;if(!is_numeric($value)||(float)$value<$min||(float)$value>$max)throw new AuthException('Enter valid coordinates.',422);return(float)$value;}
}
