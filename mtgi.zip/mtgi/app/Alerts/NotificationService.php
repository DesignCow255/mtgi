<?php

declare(strict_types=1);

namespace Mamore\Alerts;

use Mamore\Auth\AuthException;
use PDO;

/**
 * Per-user notification centre.
 *
 * Canonical intent (GET /me/notifications + read + read-all) lives here, so the
 * portal, the panic board and the subscription payment flow all share one
 * reader. Every read is scoped to the caller's own rows: a notification id
 * belonging to somebody else is reported as not found, never as forbidden, so
 * the endpoint cannot be used to probe for other users' notifications.
 */
final class NotificationService
{
    private const MAX_LIMIT = 100;

    public function __construct(private readonly PDO $database) {}

    /** Notifications for one user, newest first. */
    public function list(array $user, int $limit = 50, bool $unreadOnly = false): array
    {
        $limit = min(max($limit, 1), self::MAX_LIMIT);
        $sql = 'SELECT id, notification_type, title, message, entity_type, entity_id, read_at, created_at
                FROM user_notifications WHERE user_id = :user';
        if ($unreadOnly) {
            $sql .= ' AND read_at IS NULL';
        }
        $sql .= ' ORDER BY created_at DESC, id DESC LIMIT ' . $limit;

        $statement = $this->database->prepare($sql);
        $statement->execute(['user' => $this->userId($user)]);

        return array_map([$this, 'hydrate'], $statement->fetchAll());
    }

    /** Number of notifications still waiting to be read. */
    public function unreadCount(array $user): int
    {
        $statement = $this->database->prepare(
            'SELECT COUNT(*) FROM user_notifications WHERE user_id = :user AND read_at IS NULL'
        );
        $statement->execute(['user' => $this->userId($user)]);

        return (int) $statement->fetchColumn();
    }

    /**
     * Mark one notification read. Idempotent: re-reading a read row is fine.
     *
     * The id accepts a string or an integer: user_notifications.id is a
     * BIGINT, so a JSON client naturally sends a number.
     */
    public function markRead(array $user, string|int $notificationId): array
    {
        $userId = $this->userId($user);
        $notificationId = (string) $notificationId;
        $statement = $this->database->prepare(<<<'SQL'
            UPDATE user_notifications SET read_at = UTC_TIMESTAMP(6)
            WHERE id = :id AND user_id = :user AND read_at IS NULL
            SQL);
        $statement->execute(['id' => $notificationId, 'user' => $userId]);

        return $this->findOwned($userId, $notificationId);
    }

    /**
     * Mark every unread notification read and report how many changed.
     *
     * @return array{markedRead:int, unreadRemaining:int}
     */
    public function markAllRead(array $user): array
    {
        $userId = $this->userId($user);
        $statement = $this->database->prepare(
            'UPDATE user_notifications SET read_at = UTC_TIMESTAMP(6) WHERE user_id = :user AND read_at IS NULL'
        );
        $statement->execute(['user' => $userId]);
        $marked = $statement->rowCount();

        $unread = $this->database->prepare(
            'SELECT COUNT(*) FROM user_notifications WHERE user_id = :user AND read_at IS NULL'
        );
        $unread->execute(['user' => $userId]);

        return ['markedRead' => $marked, 'unreadRemaining' => (int) $unread->fetchColumn()];
    }

    /** @return array<string,mixed> */
    private function findOwned(string $userId, string $notificationId): array
    {
        $statement = $this->database->prepare(
            'SELECT id, notification_type, title, message, entity_type, entity_id, read_at, created_at
             FROM user_notifications WHERE id = :id AND user_id = :user'
        );
        $statement->execute(['id' => $notificationId, 'user' => $userId]);
        $row = $statement->fetch();
        if (!is_array($row)) {
            throw new AuthException('Notification not found.', 404);
        }

        return $this->hydrate($row);
    }

    /** @param array<string,mixed> $user */
    private function userId(array $user): string
    {
        $id = $user['id'] ?? null;
        if (!is_string($id) || $id === '') {
            throw new AuthException('Authentication required.', 401);
        }

        return $id;
    }

    /** @return array<string,mixed> */
    private function hydrate(array $row): array
    {
        return [
            'id' => (int) $row['id'],
            'type' => $row['notification_type'],
            'title' => $row['title'],
            'message' => $row['message'],
            'entityType' => $row['entity_type'],
            'entityId' => $row['entity_id'],
            'readAt' => $row['read_at'],
            'read' => $row['read_at'] !== null,
            'createdAt' => $row['created_at'],
        ];
    }
}
