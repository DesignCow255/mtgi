<?php

declare(strict_types=1);

namespace Mamore\Tracking;

use Mamore\Auth\AuthException;
use Mamore\Core\AuditLog;
use Mamore\Core\RateLimiter;
use Mamore\Core\Request;
use Mamore\Core\ServerClock;
use Mamore\Core\Uuid;
use PDO;

/**
 * The single ingestion path for every domain's GPS data.
 *
 * Nothing is trusted: the device proves who it is with a token, must be
 * currently assigned to the asset it is reporting for, and every coordinate,
 * timestamp, speed and payload size is validated before a row is written. A
 * rejected payload is counted as an alert, so a failing device is visible rather
 * than silently dropping data.
 */
final class TrackingIngestionService
{
    public const MAX_PAYLOAD_BYTES = 8192;
    public const MAX_FUTURE_SECONDS = 120;
    public const MAX_AGE_DAYS = 30;
    public const MIN_INTERVAL_SECONDS = 5;
    public const MAX_SPEED_KPH = 400.0;
    public const RATE_LIMIT_PER_HOUR = 600;

    public function __construct(private readonly PDO $database) {}

    /**
     * Ingest one position report from an authenticated device.
     *
     * @param array<string,mixed> $payload
     *
     * @return array<string,mixed>
     */
    public function ingest(array $payload, Request $request): array
    {
        $this->assertPayloadSize($request);
        $device = $this->authenticateDevice($payload, $request);
        $position = $this->validatePosition($payload);

        $asset = $this->assignedAsset($device, $request);
        // Replay is checked before throttling: a duplicate id is a protocol
        // error and must report as one, not as a rate limit.
        if ($position['devicePositionId'] !== null && $this->isReplay($asset['id'], $position['devicePositionId'])) {
            throw new AuthException('Duplicate position report.', 409);
        }
        $this->throttle($asset, $device, $request);

        $this->database->beginTransaction();
        try {
            $this->appendHistory($asset['id'], $device['id'], $position, $payload);
            $this->upsertCurrentPosition($asset['id'], $position, $payload);
            $this->touchAsset($asset['id'], $position['recordedAt']);
            $this->touchDevice($device['id'], $position['recordedAt']);
            $this->database->commit();
        } catch (\Throwable $error) {
            if ($this->database->inTransaction()) {
                $this->database->rollBack();
            }
            $this->raiseDeviceAlert($device, 'DEVICE_FAULT', 'Position rejected: ' . $error->getMessage());
            throw $error;
        }

        $this->closeRecoveredOfflineAlert($asset['id']);
        $geofenceEvents = $this->evaluateGeofences($asset, $position);

        return [
            'assetId' => $asset['id'],
            'vehicleId' => $asset['vehicle_id'],
            'recordedAt' => $position['recordedAt'],
            'receivedAt' => gmdate('Y-m-d H:i:s', ServerClock::epoch($this->database)),
            'geofenceEvents' => $geofenceEvents,
        ];
    }

    /**
     * Register a device and assign it to a tracked asset.
     *
     * @return array<string,mixed>
     */
    public function registerDevice(array $input, array $actor): array
    {
        $uid = $this->required($input, 'deviceUid', 'Device UID');
        $token = $this->required($input, 'deviceToken', 'Device token');
        $assetId = $this->required($input, 'trackedAssetId', 'Tracked asset');
        $asset = $this->trackedAsset($assetId);
        $this->assertAssetNotAlreadyTracked($assetId);

        $deviceId = Uuid::v4();
        $this->database->beginTransaction();
        try {
            $existing = $this->database->prepare('SELECT * FROM tracking_devices WHERE device_uid = :uid');
            $existing->execute(['uid' => $uid]);
            $device = $existing->fetch();
            if (is_array($device)) {
                $deviceId = (string) $device['id'];
                $this->database->prepare(
                    "UPDATE tracking_devices SET device_token_hash = :hash, status = 'ACTIVE', imei = COALESCE(:imei, imei),
                     provider = COALESCE(:provider, provider), model = COALESCE(:model, model), updated_at = UTC_TIMESTAMP(6)
                     WHERE id = :id"
                )->execute([
                    'hash' => hash('sha256', $token),
                    'imei' => $this->nullable($input['imei'] ?? null),
                    'provider' => $this->nullable($input['provider'] ?? null),
                    'model' => $this->nullable($input['model'] ?? null),
                    'id' => $deviceId,
                ]);
            } else {
                $this->database->prepare(<<<'SQL'
                    INSERT INTO tracking_devices
                        (id, device_uid, device_token_hash, imei, provider, model, status, installed_at)
                    VALUES (:id, :uid, :hash, :imei, :provider, :model, 'ACTIVE', UTC_TIMESTAMP(6))
                    SQL)->execute([
                    'id' => $deviceId, 'uid' => $uid, 'hash' => hash('sha256', $token),
                    'imei' => $this->nullable($input['imei'] ?? null),
                    'provider' => $this->nullable($input['provider'] ?? null),
                    'model' => $this->nullable($input['model'] ?? null),
                ]);
            }

            $this->database->prepare(<<<'SQL'
                INSERT INTO tracking_device_assignments (device_id, tracked_asset_id, assigned_by_user_id, reason)
                VALUES (:device, :asset, :actor, :reason)
                SQL)->execute([
                'device' => $deviceId, 'asset' => $assetId, 'actor' => $actor['id'] ?? null,
                'reason' => $this->nullable($input['reason'] ?? null),
            ]);
            $this->database->prepare("UPDATE tracked_assets SET tracking_status = 'ONLINE' WHERE id = :id")
                ->execute(['id' => $assetId]);
            $this->database->commit();
        } catch (\Throwable $error) {
            if ($this->database->inTransaction()) {
                $this->database->rollBack();
            }
            throw $error;
        }

        (new AuditLog($this->database))->write(
            'TRACKING_DEVICE_ASSIGNED',
            'TrackedAsset',
            $assetId,
            $actor,
            null,
            null,
            ['deviceId' => $deviceId, 'deviceUid' => $uid],
            ['source' => 'tracking-core']
        );

        return ['deviceId' => $deviceId, 'trackedAssetId' => $assetId, 'deviceUid' => $uid, 'status' => 'ACTIVE'];
    }

    /** Detach a device. History is kept; the asset simply stops reporting. */
    public function removeDevice(array $input, array $actor, Request $request): array
    {
        $deviceId = $this->required($input, 'deviceId', 'Device');
        $reason = $this->required($input, 'reason', 'Removal reason');
        $device = $this->database->prepare('SELECT * FROM tracking_devices WHERE id = :id');
        $device->execute(['id' => $deviceId]);
        $row = $device->fetch();
        if (!is_array($row)) {
            throw new AuthException('Device not found.', 404);
        }

        $this->database->beginTransaction();
        try {
            $this->database->prepare(
                'UPDATE tracking_device_assignments SET unassigned_at = UTC_TIMESTAMP(6), reason = :reason
                 WHERE device_id = :device AND unassigned_at IS NULL'
            )->execute(['reason' => $reason, 'device' => $deviceId]);
            $this->database->prepare("UPDATE tracking_devices SET status = 'REMOVED' WHERE id = :id")->execute(['id' => $deviceId]);
            $this->database->prepare(
                "UPDATE tracked_assets SET tracking_status = 'NO_DEVICE' WHERE id IN (
                     SELECT tracked_asset_id FROM tracking_device_assignments WHERE device_id = :device)
                 AND id NOT IN (SELECT tracked_asset_id FROM tracking_device_assignments
                                WHERE unassigned_at IS NULL AND device_id <> :other)"
            )->execute(['device' => $deviceId, 'other' => $deviceId]);
            $this->database->commit();
        } catch (\Throwable $error) {
            if ($this->database->inTransaction()) {
                $this->database->rollBack();
            }
            throw $error;
        }

        (new AuditLog($this->database))->write(
            'TRACKING_DEVICE_REMOVED',
            'TrackingDevice',
            $deviceId,
            $actor,
            $request,
            ['status' => $row['status']],
            ['status' => 'REMOVED'],
            ['source' => 'tracking-core', 'reason' => $reason]
        );

        return ['deviceId' => $deviceId, 'status' => 'REMOVED'];
    }

    // ------------------------------------------------------------- internals

    private function assertPayloadSize(Request $request): void
    {
        $size = (int) ($request->headers['content-length'] ?? 0);
        if ($size > self::MAX_PAYLOAD_BYTES) {
            throw new AuthException('Position payload is too large.', 413);
        }
    }

    /**
     * Device authentication.
     *
     * A UID alone is an identifier, not proof: the token must match too. The
     * token is compared as a hash and never stored or logged in the clear.
     *
     * @param array<string,mixed> $payload
     *
     * @return array<string,mixed>
     */
    private function authenticateDevice(array $payload, Request $request): array
    {
        $uid = trim((string) ($payload['deviceUid'] ?? ''));
        $token = trim((string) ($payload['deviceToken'] ?? ''));
        if ($uid === '' || $token === '') {
            throw new AuthException('Device authentication is required.', 401);
        }
        if (!RateLimiter::allow('tracking-device:' . $request->ipAddress, 60, 60)) {
            throw new AuthException('Too many authentication attempts from this address.', 429);
        }

        $statement = $this->database->prepare(
            "SELECT * FROM tracking_devices WHERE device_uid = :uid AND status IN ('ACTIVE', 'OFFLINE')"
        );
        $statement->execute(['uid' => $uid]);
        $device = $statement->fetch();
        if (!is_array($device)) {
            throw new AuthException('Unknown device.', 401);
        }
        if (!hash_equals((string) $device['device_token_hash'], hash('sha256', $token))) {
            (new AuditLog($this->database))->write(
                'TRACKING_DEVICE_AUTH_FAILED',
                'TrackingDevice',
                (string) $device['id'],
                null,
                $request,
                null,
                null,
                ['source' => 'tracking-ingest', 'deviceUid' => $uid, 'ip' => $request->ipAddress]
            );
            throw new AuthException('Device authentication failed.', 401);
        }

        return $device;
    }

    /**
     * Coordinate, timestamp and speed validation.
     *
     * @param array<string,mixed> $payload
     *
     * @return array{latitude:float,longitude:float,speed:?float,heading:?float,accuracy:?float,altitude:?float,
     *               engine:?string,ignition:?string,recordedAt:string,devicePositionId:?string}
     */
    private function validatePosition(array $payload): array
    {
        $latitude = $this->coordinate($payload['latitude'] ?? null, 90.0, 'latitude');
        $longitude = $this->coordinate($payload['longitude'] ?? null, 180.0, 'longitude');
        if ($latitude === 0.0 && $longitude === 0.0) {
            throw new AuthException('Position (0, 0) is not a real location.', 422);
        }

        $now = ServerClock::epoch($this->database);
        $recordedRaw = trim((string) ($payload['recordedAt'] ?? ''));
        if ($recordedRaw === '') {
            $recordedEpoch = $now;
        } else {
            $parsed = ServerClock::parse($recordedRaw);
            if ($parsed === 0) {
                $parsed = strtotime($recordedRaw) ?: 0;
            }
            if ($parsed === 0) {
                throw new AuthException('Device timestamp could not be read.', 422);
            }
            if ($parsed > $now + self::MAX_FUTURE_SECONDS) {
                throw new AuthException('Device timestamp is too far in the future.', 422);
            }
            if ($parsed < $now - self::MAX_AGE_DAYS * 86400) {
                throw new AuthException('Device timestamp is too old to accept.', 422);
            }
            $recordedEpoch = $parsed;
        }

        $speed = $this->optionalNumber($payload['speedKph'] ?? null, 0.0, self::MAX_SPEED_KPH, 'speed');
        $heading = $this->optionalNumber($payload['headingDegrees'] ?? null, 0.0, 360.0, 'heading');
        $accuracy = $this->optionalNumber($payload['accuracyMeters'] ?? null, 0.0, 100000.0, 'accuracy');
        $altitude = $this->optionalNumber($payload['altitudeMeters'] ?? null, -500.0, 12000.0, 'altitude');

        return [
            'latitude' => $latitude,
            'longitude' => $longitude,
            'speed' => $speed,
            'heading' => $heading,
            'accuracy' => $accuracy,
            'altitude' => $altitude,
            'engine' => $this->flag($payload['engineStatus'] ?? null, ['ON', 'OFF', 'UNKNOWN']),
            'ignition' => $this->flag($payload['ignitionStatus'] ?? null, ['ON', 'OFF', 'UNKNOWN']),
            'recordedAt' => gmdate('Y-m-d H:i:s', $recordedEpoch),
            'devicePositionId' => $this->nullable($payload['devicePositionId'] ?? null),
        ];
    }

    /**
     * A device may only report for the asset it is currently assigned to.
     *
     * @return array<string,mixed>
     */
    private function assignedAsset(array $device, Request $request): array
    {
        $statement = $this->database->prepare(<<<'SQL'
            SELECT a.* FROM tracked_assets a
            JOIN tracking_device_assignments d ON d.tracked_asset_id = a.id AND d.unassigned_at IS NULL
            WHERE d.device_id = :device AND a.status = 'ACTIVE'
            LIMIT 1
            SQL);
        $statement->execute(['device' => $device['id']]);
        $asset = $statement->fetch();
        if (!is_array($asset)) {
            $this->raiseDeviceAlert($device, 'DEVICE_UNASSIGNED', 'A device reported a position while unassigned.');
            throw new AuthException('This device is not assigned to an active asset.', 403);
        }

        return $asset;
    }

    /** @param array{latitude:float,longitude:float,speed:?float,heading:?float,accuracy:?float,altitude:?float,engine:?string,ignition:?string,recordedAt:string,devicePositionId:?string} $position */
    private function appendHistory(string $assetId, string $deviceId, array $position, array $payload): void
    {
        $this->database->prepare(<<<'SQL'
            INSERT INTO location_history
                (tracked_asset_id, latitude, longitude, altitude_meters, speed_kph, heading_degrees, recorded_at,
                 device_position_id, metadata)
            VALUES (:asset, :lat, :lng, :alt, :speed, :heading, :recorded, :positionId, :metadata)
            SQL)->execute([
            'asset' => $assetId,
            'lat' => $position['latitude'],
            'lng' => $position['longitude'],
            'alt' => $position['altitude'],
            'speed' => $position['speed'],
            'heading' => $position['heading'],
            'recorded' => $position['recordedAt'],
            'positionId' => $position['devicePositionId'],
            'metadata' => $position['devicePositionId'] === null ? null : json_encode(
                ['deviceId' => $deviceId] + array_intersect_key($payload, array_flip(['odometerKm', 'fuelPercent', 'temperatureCelsius', 'ignitionStatus', 'engineStatus'])),
                JSON_THROW_ON_ERROR
            ),
        ]);
    }

    /** @param array{latitude:float,longitude:float,speed:?float,heading:?float,accuracy:?float,altitude:?float,engine:?string,ignition:?string,recordedAt:string,devicePositionId:?string} $position */
    private function upsertCurrentPosition(string $assetId, array $position, array $payload): void
    {
        // The map reads this one row, so it is never the history table.
        $this->database->prepare(<<<'SQL'
            INSERT INTO tracked_asset_positions
                (tracked_asset_id, latitude, longitude, altitude_meters, speed_kph, heading_degrees, accuracy_meters,
                 engine_status, ignition_status, source, recorded_at)
            VALUES (:asset, :lat, :lng, :alt, :speed, :heading, :accuracy, :engine, :ignition, 'DEVICE', :recorded)
            ON DUPLICATE KEY UPDATE
                latitude = VALUES(latitude), longitude = VALUES(longitude), altitude_meters = VALUES(altitude_meters),
                speed_kph = VALUES(speed_kph), heading_degrees = VALUES(heading_degrees),
                accuracy_meters = VALUES(accuracy_meters), engine_status = VALUES(engine_status),
                ignition_status = VALUES(ignition_status), recorded_at = VALUES(recorded_at), received_at = UTC_TIMESTAMP(6)
            SQL)->execute([
            'asset' => $assetId,
            'lat' => $position['latitude'],
            'lng' => $position['longitude'],
            'alt' => $position['altitude'],
            'speed' => $position['speed'],
            'heading' => $position['heading'],
            'accuracy' => $position['accuracy'],
            'engine' => $position['engine'],
            'ignition' => $position['ignition'],
            'recorded' => $position['recordedAt'],
        ]);
    }

    private function touchAsset(string $assetId, string $recordedAt): void
    {
        $this->database->prepare(<<<'SQL'
            UPDATE tracked_assets SET tracking_status = 'ONLINE', last_seen_at = :seen, updated_at = UTC_TIMESTAMP(6)
            WHERE id = :id
            SQL)->execute(['seen' => $recordedAt, 'id' => $assetId]);
    }

    private function touchDevice(string $deviceId, string $recordedAt): void
    {
        $this->database->prepare(
            "UPDATE tracking_devices SET status = 'ACTIVE', last_seen_at = :seen WHERE id = :id"
        )->execute(['seen' => $recordedAt, 'id' => $deviceId]);
    }

    private function isReplay(string $assetId, string $devicePositionId): bool
    {
        $statement = $this->database->prepare(
            'SELECT COUNT(*) FROM location_history WHERE tracked_asset_id = :asset AND device_position_id = :position'
        );
        $statement->execute(['asset' => $assetId, 'position' => $devicePositionId]);

        return (int) $statement->fetchColumn() > 0;
    }

    private function throttle(array $asset, array $device, Request $request): void
    {
        $lastStatement = $this->database->prepare('SELECT recorded_at FROM tracked_asset_positions WHERE tracked_asset_id = :asset');
        $lastStatement->execute(['asset' => $asset['id']]);
        $last = $lastStatement->fetchColumn();
        $now = ServerClock::epoch($this->database);
        if (is_string($last) && ($now - ServerClock::parse($last)) < self::MIN_INTERVAL_SECONDS) {
            throw new AuthException('Position reported too soon after the last one.', 429);
        }
        if (!RateLimiter::allow('tracking-ingest:' . $device['id'], self::RATE_LIMIT_PER_HOUR, 3600)) {
            throw new AuthException('Device position rate limit exceeded.', 429);
        }
    }

    /**
     * Geofence evaluation on the way in.
     *
     * A transition raises an alert; being inside the same fence again does not.
     *
     * @param array<string,mixed> $asset
     * @param array<string,mixed> $position
     *
     * @return list<array<string,mixed>>
     */
    private function evaluateGeofences(array $asset, array $position): array
    {
        $domain = is_string($asset['domain'] ?? null) ? (string) $asset['domain'] : null;
        $fences = $this->database->prepare(<<<'SQL'
            SELECT id, name, geofence_type, center_latitude, center_longitude, radius_meters, alert_on_enter, alert_on_exit
            FROM geofences WHERE status = 'ACTIVE'
            SQL);
        $fences->execute();
        $events = [];

        foreach ($fences->fetchAll() as $fence) {
            if ($fence['radius_meters'] === null) {
                continue; // polygon fences are evaluated by the geofence service, not the hot path
            }
            $inside = $this->distanceMeters(
                (float) $position['latitude'],
                (float) $position['longitude'],
                (float) $fence['center_latitude'],
                (float) $fence['center_longitude']
            ) <= (float) $fence['radius_meters'];

            $state = $this->database->prepare('SELECT is_inside FROM asset_geofence_state WHERE tracked_asset_id = :asset AND geofence_id = :fence');
            $state->execute(['asset' => $asset['id'], 'fence' => $fence['id']]);
            $previous = $state->fetchColumn();
            $wasInside = $previous === null ? false : (bool) $previous;

            $this->database->prepare(<<<'SQL'
                INSERT INTO asset_geofence_state (tracked_asset_id, geofence_id, is_inside, entered_at, exited_at, last_evaluated_at)
                VALUES (:asset, :fence, :inside, :entered, :exited, UTC_TIMESTAMP(6))
                ON DUPLICATE KEY UPDATE is_inside = VALUES(is_inside),
                    entered_at = IF(VALUES(is_inside) = 1, COALESCE(entered_at, UTC_TIMESTAMP(6)), entered_at),
                    exited_at = IF(VALUES(is_inside) = 0, UTC_TIMESTAMP(6), exited_at),
                    last_evaluated_at = UTC_TIMESTAMP(6)
                SQL)->execute([
                'asset' => $asset['id'],
                'fence' => $fence['id'],
                'inside' => $inside ? 1 : 0,
                'entered' => $inside && !$wasInside ? $position['recordedAt'] : null,
                'exited' => !$inside && $wasInside ? $position['recordedAt'] : null,
            ]);

            if ($inside && !$wasInside && (int) $fence['alert_on_enter'] === 1) {
                $events[] = $this->raiseAlert($asset, 'GEOFENCE_ENTER', sprintf('%s entered %s', $this->assetLabel($asset), $fence['name']), [
                    'geofenceId' => $fence['id'], 'geofenceType' => $fence['geofence_type'], 'domain' => $domain,
                ]);
            }
            if (!$inside && $wasInside && (int) $fence['alert_on_exit'] === 1) {
                $events[] = $this->raiseAlert($asset, 'GEOFENCE_EXIT', sprintf('%s left %s', $this->assetLabel($asset), $fence['name']), [
                    'geofenceId' => $fence['id'], 'geofenceType' => $fence['geofence_type'], 'domain' => $domain,
                ]);
            }
        }

        return array_values(array_filter($events));
    }

    /**
     * Open an alert for an asset. The unique index keeps one open alert per code
     * and asset, so a repeating condition updates rather than floods.
     *
     * @param array<string,mixed> $asset
     * @param array<string,mixed> $context
     *
     * @return array<string,mixed>
     */
    public function raiseAlert(array $asset, string $code, string $message, array $context = []): array
    {
        $severity = (string) ($this->database->query(
            'SELECT default_severity FROM alert_types WHERE code = ' . $this->database->quote($code)
        )->fetchColumn() ?: 'MEDIUM');

        $id = Uuid::v4();
        $this->database->prepare(<<<'SQL'
            INSERT INTO tracking_alerts (id, alert_code, tracked_asset_id, domain, severity, message, context, opened_at)
            VALUES (:id, :code, :asset, :domain, :severity, :message, :context, UTC_TIMESTAMP(6))
            ON DUPLICATE KEY UPDATE message = VALUES(message), context = VALUES(context), severity = VALUES(severity)
            SQL)->execute([
            'id' => $id, 'code' => $code, 'asset' => $asset['id'],
            'domain' => $asset['domain'] ?? null, 'severity' => $severity, 'message' => mb_substr($message, 0, 500),
            'context' => $context === [] ? null : json_encode($context, JSON_THROW_ON_ERROR),
        ]);

        $statement = $this->database->prepare(
            "SELECT id, status, opened_at FROM tracking_alerts WHERE alert_code = :code AND tracked_asset_id = :asset
             AND status IN ('NEW', 'ACKNOWLEDGED', 'INVESTIGATING') ORDER BY opened_at DESC LIMIT 1"
        );
        $statement->execute(['code' => $code, 'asset' => $asset['id']]);
        $row = $statement->fetch() ?: ['id' => $id, 'status' => 'NEW', 'opened_at' => gmdate('Y-m-d H:i:s')];

        return [
            'alertId' => (string) $row['id'],
            'code' => $code,
            'status' => (string) $row['status'],
            'severity' => $severity,
            'message' => mb_substr($message, 0, 500),
        ];
    }

    /** @param array<string,mixed> $device */
    private function raiseDeviceAlert(array $device, string $code, string $message): void
    {
        $this->database->prepare(<<<'SQL'
            INSERT INTO tracking_alerts (id, alert_code, message, severity, status, context, opened_at)
            VALUES (:id, :code, :message, 'MEDIUM', 'NEW', :context, UTC_TIMESTAMP(6))
            ON DUPLICATE KEY UPDATE message = VALUES(message)
            SQL)->execute([
            'id' => Uuid::v4(),
            'code' => $code,
            'message' => mb_substr($message, 0, 500),
            'context' => json_encode(['deviceId' => $device['id']], JSON_THROW_ON_ERROR),
        ]);
    }

    private function closeRecoveredOfflineAlert(string $assetId): void
    {
        $this->database->prepare(<<<'SQL'
            UPDATE tracking_alerts SET status = 'RESOLVED', resolved_at = UTC_TIMESTAMP(6),
                   resolution_note = 'Position signal restored.'
            WHERE tracked_asset_id = :asset AND alert_code = 'GPS_OFFLINE' AND status IN ('NEW', 'ACKNOWLEDGED', 'INVESTIGATING')
            SQL)->execute(['asset' => $assetId]);
    }

    /** @return array<string,mixed> */
    private function trackedAsset(string $assetId): array
    {
        $statement = $this->database->prepare("SELECT * FROM tracked_assets WHERE id = :id AND status = 'ACTIVE'");
        $statement->execute(['id' => $assetId]);
        $asset = $statement->fetch();
        if (!is_array($asset)) {
            throw new AuthException('Tracked asset not found.', 404);
        }

        return $asset;
    }

    private function assertAssetNotAlreadyTracked(string $assetId): void
    {
        $statement = $this->database->prepare(
            'SELECT COUNT(*) FROM tracking_device_assignments WHERE tracked_asset_id = :asset AND unassigned_at IS NULL'
        );
        $statement->execute(['asset' => $assetId]);
        if ((int) $statement->fetchColumn() > 0) {
            throw new AuthException('This asset already has an assigned device. Remove it first.', 409);
        }
    }

    private function distanceMeters(float $lat1, float $lng1, float $lat2, float $lng2): float
    {
        $earthRadius = 6371000.0;
        $deltaLat = deg2rad($lat2 - $lat1);
        $deltaLng = deg2rad($lng2 - $lng1);
        $a = sin($deltaLat / 2) ** 2
            + cos(deg2rad($lat1)) * cos(deg2rad($lat2)) * sin($deltaLng / 2) ** 2;

        return $earthRadius * 2 * atan2(sqrt($a), sqrt(1 - $a));
    }

    /** @param array<string,mixed> $asset */
    private function assetLabel(array $asset): string
    {
        return (string) ($asset['label'] ?? $asset['asset_code'] ?? $asset['id']);
    }

    private function coordinate(mixed $value, float $limit, string $label): float
    {
        if (!is_numeric($value)) {
            throw new AuthException("A valid {$label} is required.", 422);
        }
        $number = (float) $value;
        if ($number < -$limit || $number > $limit) {
            throw new AuthException("The {$label} is out of range.", 422);
        }

        return $number;
    }

    private function optionalNumber(mixed $value, float $min, float $max, string $label): ?float
    {
        if ($value === null || $value === '') {
            return null;
        }
        if (!is_numeric($value)) {
            throw new AuthException("The {$label} is not a number.", 422);
        }
        $number = (float) $value;
        if ($number < $min || $number > $max) {
            throw new AuthException("The {$label} is out of range.", 422);
        }

        return $number;
    }

    /** @param list<string> $allowed */
    private function flag(mixed $value, array $allowed): ?string
    {
        if (!is_string($value) || $value === '') {
            return null;
        }
        $flag = strtoupper($value);
        if (!in_array($flag, $allowed, true)) {
            throw new AuthException('Unrecognised status flag.', 422);
        }

        return $flag;
    }

    private function required(array $input, string $key, string $label): string
    {
        $value = is_string($input[$key] ?? null) ? trim($input[$key]) : '';
        if ($value === '') {
            throw new AuthException("{$label} is required.", 422);
        }

        return $value;
    }

    private function nullable(mixed $value): ?string
    {
        if (!is_string($value)) {
            return null;
        }
        $trimmed = trim($value);

        return $trimmed === '' ? null : mb_substr($trimmed, 0, 255);
    }
}
