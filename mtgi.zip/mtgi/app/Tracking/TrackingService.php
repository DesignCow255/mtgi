<?php

declare(strict_types=1);

namespace Mamore\Tracking;

use Mamore\Auth\AuthException;
use Mamore\Core\Uuid;
use PDO;

final class TrackingService
{
    public function __construct(private readonly PDO $database) {}

    public function board(): array
    {
        $assets=$this->database->query(<<<'SQL'
            SELECT a.*,p.latitude,p.longitude,p.speed_kph,p.heading_degrees,p.accuracy_meters,p.recorded_at,
                   CASE WHEN p.recorded_at IS NULL THEN 'NO_SIGNAL'
                        WHEN p.recorded_at < UTC_TIMESTAMP(6)-INTERVAL 15 MINUTE THEN 'STALE' ELSE 'LIVE' END AS signal_status
            FROM tracking_assets a LEFT JOIN tracking_positions p ON p.id=(SELECT p2.id FROM tracking_positions p2 WHERE p2.asset_id=a.id ORDER BY p2.recorded_at DESC LIMIT 1)
            ORDER BY a.asset_type,a.code
            SQL)->fetchAll();
        $locations=$this->database->query("SELECT id,location_type,name,province,address_text,latitude,longitude,contact_phone FROM service_locations WHERE status='ACTIVE' ORDER BY location_type,name")->fetchAll();
        $metrics=['assets'=>count($assets),'live'=>0,'stale'=>0,'noSignal'=>0,'locations'=>count($locations)];
        foreach($assets as $asset){if($asset['signal_status']==='LIVE')$metrics['live']++;elseif($asset['signal_status']==='STALE')$metrics['stale']++;else$metrics['noSignal']++;}
        return ['metrics'=>$metrics,'assets'=>array_map([$this,'asset'],$assets),'locations'=>array_map([$this,'location'],$locations)];
    }

    public function checkIn(array $input): array
    {
        $assetId=$this->required($input,'assetId','Asset'); $lat=$this->coordinate($input['latitude']??null,-90,90,'latitude'); $lng=$this->coordinate($input['longitude']??null,-180,180,'longitude');
        $exists=$this->database->prepare("SELECT 1 FROM tracking_assets WHERE id=:id AND status='ACTIVE'");$exists->execute(['id'=>$assetId]);if(!$exists->fetchColumn())throw new AuthException('Tracking asset not found.',404);
        $speed=$this->optionalNumber($input['speedKph']??null,0,300,'speed');$heading=$this->optionalNumber($input['heading']??null,0,360,'heading');$accuracy=$this->optionalNumber($input['accuracyMeters']??null,0,10000,'accuracy');
        $statement=$this->database->prepare('INSERT INTO tracking_positions(asset_id,latitude,longitude,speed_kph,heading_degrees,accuracy_meters,recorded_at) VALUES(:asset,:lat,:lng,:speed,:heading,:accuracy,UTC_TIMESTAMP(6))');
        $statement->execute(['asset'=>$assetId,'lat'=>$lat,'lng'=>$lng,'speed'=>$speed,'heading'=>$heading,'accuracy'=>$accuracy]);
        return ['assetId'=>$assetId,'latitude'=>$lat,'longitude'=>$lng,'speedKph'=>$speed,'recordedAt'=>gmdate(DATE_ATOM)];
    }

    public function createLocation(array $input): array
    {
        $id=Uuid::v4();$type=$this->choice($input['type']??'', ['HOSPITAL','GARAGE','FUEL_STATION','COMMAND_STATION','RESCUE_BASE'],'location type');
        $name=$this->required($input,'name','Name');$province=$this->choice($input['province']??'', ['HAUT_KATANGA','LUALABA'],'province');
        $lat=$this->coordinate($input['latitude']??null,-90,90,'latitude');$lng=$this->coordinate($input['longitude']??null,-180,180,'longitude');
        $statement=$this->database->prepare('INSERT INTO service_locations(id,location_type,name,province,address_text,latitude,longitude,contact_phone) VALUES(:id,:type,:name,:province,:address,:lat,:lng,:phone)');
        $statement->execute(['id'=>$id,'type'=>$type,'name'=>$name,'province'=>$province,'address'=>$this->optional($input,'address'),'lat'=>$lat,'lng'=>$lng,'phone'=>$this->optional($input,'phone')]);
        return ['id'=>$id,'type'=>$type,'name'=>$name,'province'=>$province,'latitude'=>$lat,'longitude'=>$lng];
    }

    public function nearest(float $lat,float $lng): array
    {
        $statement=$this->database->prepare(<<<'SQL'
            SELECT id,location_type,name,province,address_text,latitude,longitude,contact_phone,
                   (6371*ACOS(LEAST(1,COS(RADIANS(:lat1))*COS(RADIANS(latitude))*COS(RADIANS(longitude)-RADIANS(:lng))+SIN(RADIANS(:lat2))*SIN(RADIANS(latitude))))) AS distance_km
            FROM service_locations WHERE status='ACTIVE' ORDER BY distance_km ASC LIMIT 10
            SQL);
        $statement->execute(['lat1'=>$lat,'lat2'=>$lat,'lng'=>$lng]);
        return array_map(static fn(array $row):array=>['id'=>$row['id'],'type'=>$row['location_type'],'name'=>$row['name'],'province'=>$row['province'],'address'=>$row['address_text'],'latitude'=>(float)$row['latitude'],'longitude'=>(float)$row['longitude'],'phone'=>$row['contact_phone'],'distanceKm'=>round((float)$row['distance_km'],2)],$statement->fetchAll());
    }

    private function asset(array $row):array{return ['id'=>$row['id'],'type'=>$row['asset_type'],'code'=>$row['code'],'label'=>$row['label'],'status'=>$row['status'],'signalStatus'=>$row['signal_status'],'latitude'=>$row['latitude']!==null?(float)$row['latitude']:null,'longitude'=>$row['longitude']!==null?(float)$row['longitude']:null,'speedKph'=>$row['speed_kph']!==null?(float)$row['speed_kph']:null,'heading'=>$row['heading_degrees']!==null?(float)$row['heading_degrees']:null,'accuracyMeters'=>$row['accuracy_meters']!==null?(float)$row['accuracy_meters']:null,'recordedAt'=>$row['recorded_at']];}
    private function location(array $row):array{return ['id'=>$row['id'],'type'=>$row['location_type'],'name'=>$row['name'],'province'=>$row['province'],'address'=>$row['address_text'],'latitude'=>(float)$row['latitude'],'longitude'=>(float)$row['longitude'],'phone'=>$row['contact_phone']];}
    private function required(array $input,string $key,string $label):string{$value=is_string($input[$key]??null)?trim($input[$key]):'';if($value==='')throw new AuthException("{$label} is required.",422);return $value;}
    private function optional(array $input,string $key):?string{$value=is_string($input[$key]??null)?trim($input[$key]):'';return $value===''?null:$value;}
    private function choice(mixed $value,array $allowed,string $label):string{$value=is_string($value)?strtoupper(trim($value)):'';if(!in_array($value,$allowed,true))throw new AuthException("Select a valid {$label}.",422);return $value;}
    private function coordinate(mixed $value,float $min,float $max,string $label):float{if(!is_numeric($value)||(float)$value<$min||(float)$value>$max)throw new AuthException("Enter a valid {$label}.",422);return(float)$value;}
    private function optionalNumber(mixed $value,float $min,float $max,string $label):?float{if($value===null||$value==='')return null;if(!is_numeric($value)||(float)$value<$min||(float)$value>$max)throw new AuthException("Enter a valid {$label}.",422);return(float)$value;}
}
