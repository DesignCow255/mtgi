<?php

declare(strict_types=1);

namespace Mamore\PrivateVehicle;

use Mamore\Auth\AuthException;
use Mamore\Core\AuditLog;
use Mamore\Core\RateLimiter;
use Mamore\Core\Request;
use Mamore\Core\ServerClock;
use Mamore\Core\Uuid;
use Mamore\SmartBus\RescueCodeService;
use Mamore\Rescue\RescueCoverageService;
use PDO;

/**
 * The private vehicle domain.
 *
 * Enrols a canonical vehicle into Mamore Rescue, records who may drive it, runs a
 * protected journey, and handles an emergency request. Every rescue fact is
 * asked from the shared services, and the incident is raised through the shared
 * pipeline so the Control Center sees it with no special handling.
 */
final class PrivateVehicleService
{
    private const OPEN_JOURNEY_STATES = ['PLANNED', 'ACTIVE', 'PAUSED'];
    private const JOURNEY_TRANSITIONS = [
        'PLANNED' => ['ACTIVE', 'CANCELLED'],
        'ACTIVE' => ['PAUSED', 'INCIDENT', 'ARRIVED', 'COMPLETED', 'CANCELLED'],
        'PAUSED' => ['ACTIVE', 'COMPLETED', 'CANCELLED'],
        'INCIDENT' => ['ACTIVE', 'ARRIVED', 'COMPLETED', 'CANCELLED'],
        'ARRIVED' => ['COMPLETED', 'CANCELLED'],
        'COMPLETED' => [],
        'CANCELLED' => [],
    ];

    public function __construct(
        private readonly PDO $database,
        private readonly RescueCoverageService $coverage,
        private readonly RescueCodeService $codes,
    ) {}

    /**
     * Enrol a vehicle for a subscriber.
     *
     * @return array<string,mixed>
     */
    public function enrol(array $input, array $actor, Request $request): array
    {
        $vehicleId = $this->required($input, 'vehicleId', 'Vehicle');
        $subscriberId = $this->subscriberIdFor($actor);
        $vehicle = $this->vehicle($vehicleId);
        if ((string) $vehicle['vehicle_type'] !== 'PRIVATE_CAR' && (string) $vehicle['vehicle_type'] !== 'MOTORCYCLE') {
            throw new AuthException('Only a private car or motorcycle can be enrolled here.', 422);
        }
        $personId = $subscriberId === null ? null : $this->personIdForSubscriber($subscriberId);
        $ownerPersonId = $vehicle['owner_person_id'] ?? null;
        if ($personId !== null && is_string($ownerPersonId) && $ownerPersonId !== '' && $ownerPersonId !== $personId) {
            // The car already belongs to another person in the registry.
            throw new AuthException('This vehicle is registered to another person.', 403);
        }

        $existing = $this->database->prepare('SELECT id FROM private_vehicles WHERE vehicle_id = :vehicle');
        $existing->execute(['vehicle' => $vehicleId]);
        if ($existing->fetchColumn() !== false) {
            throw new AuthException('This vehicle is already enrolled.', 409);
        }

        $planId = $this->optional($input, 'servicePlanId') ?? $this->planId('PRIVATE-ROAD-ASSIST');
        $id = Uuid::v4();

        $this->database->beginTransaction();
        try {
            $this->database->prepare(<<<'SQL'
                INSERT INTO private_vehicles
                    (id, vehicle_id, subscriber_id, service_plan_id, primary_driver_person_id,
                     subscription_status, rescue_coverage_status, tracking_status, created_by_user_id)
                VALUES (:id, :vehicle, :subscriber, :plan, :driver, 'PENDING', 'UNCOVERED', 'NO_DEVICE', :actor)
                SQL)->execute([
                'id' => $id, 'vehicle' => $vehicleId, 'subscriber' => $subscriberId, 'plan' => $planId,
                'driver' => $personId, 'actor' => $actor['id'] ?? null,
            ]);
            if ($personId !== null) {
                $this->database->prepare(<<<'SQL'
                    INSERT INTO private_vehicle_drivers (id, private_vehicle_id, person_id, relationship, is_primary, authorized_from)
                    VALUES (:id, :vehicle, :person, 'OWNER', 1, UTC_TIMESTAMP(6))
                    SQL)->execute(['id' => Uuid::v4(), 'vehicle' => $id, 'person' => $personId]);
            }
            $this->database->prepare('UPDATE vehicles SET owner_person_id = COALESCE(owner_person_id, :person) WHERE id = :id')
                ->execute(['person' => $personId, 'id' => $vehicleId]);
            $this->database->commit();
        } catch (\Throwable $error) {
            if ($this->database->inTransaction()) {
                $this->database->rollBack();
            }
            throw $error;
        }

        (new AuditLog($this->database))->write(
            'PRIVATE_VEHICLE_ENROLLED',
            'PrivateVehicle',
            $id,
            $actor,
            $request,
            null,
            ['vehicleId' => $vehicleId, 'planId' => $planId],
            ['source' => 'private-vehicle-domain']
        );

        return $this->show($id, $actor);
    }

    /**
     * Activate the enrolment: cover through the shared engine, code through the
     * shared service, tracking linked to the canonical asset.
     *
     * @return array<string,mixed>
     */
    public function activate(array $input, array $actor, Request $request): array
    {
        $id = $this->required($input, 'privateVehicleId', 'Enrolment');
        $row = $this->row($id);
        $planId = $row['service_plan_id'] ?? $this->planId('PRIVATE-ROAD-ASSIST');

        $this->database->prepare(<<<'SQL'
            UPDATE private_vehicles SET subscription_status = 'ACTIVE', activated_at = UTC_TIMESTAMP(6),
                   expires_at = :expires, updated_at = UTC_TIMESTAMP(6) WHERE id = :id
            SQL)->execute(['expires' => $this->optional($input, 'expiresAt'), 'id' => $id]);

        $coverage = $this->coverage->grant([
            'subjectType' => 'VEHICLE',
            'subjectId' => (string) $row['vehicle_id'],
            'vehicleId' => (string) $row['vehicle_id'],
            'subscriberId' => $row['subscriber_id'],
            'servicePlanId' => $planId,
            'coverageType' => 'ROAD_ASSISTANCE',
            'endsAt' => $this->optional($input, 'expiresAt'),
        ], $actor);

        // A private vehicle gets its tracked asset if it does not have one, so it
        // appears on the same map as buses, trucks and rescue units.
        $assetId = $this->ensureTrackedAsset($id, (string) $row['vehicle_id']);
        $this->syncState($id);

        (new AuditLog($this->database))->write(
            'PRIVATE_VEHICLE_ACTIVATED',
            'PrivateVehicle',
            $id,
            $actor,
            $request,
            ['status' => $row['subscription_status']],
            ['status' => 'ACTIVE', 'coverage' => $coverage['status'], 'trackedAssetId' => $assetId],
            ['source' => 'private-vehicle-domain']
        );

        return $this->show($id, $actor);
    }

    /**
     * Authorize another driver on the vehicle.
     *
     * @return array<string,mixed>
     */
    public function authorizeDriver(array $input, array $actor, Request $request): array
    {
        $id = $this->required($input, 'privateVehicleId', 'Enrolment');
        $row = $this->row($id);
        $this->assertOwnership($row, $actor);
        $personId = $this->required($input, 'personId', 'Person');
        $this->person($personId);
        $relationship = $this->choice($input['relationship'] ?? 'AUTHORIZED_DRIVER', 'relationship', 'private_vehicle_relationships');

        $this->database->prepare(<<<'SQL'
            INSERT INTO private_vehicle_drivers
                (id, private_vehicle_id, person_id, relationship, is_primary, authorized_from, authorized_until, status)
            VALUES (:id, :vehicle, :person, :relationship, 0, UTC_TIMESTAMP(6), :until, 'ACTIVE')
            ON DUPLICATE KEY UPDATE relationship = VALUES(relationship), authorized_until = VALUES(authorized_until), status = 'ACTIVE'
            SQL)->execute([
            'id' => Uuid::v4(), 'vehicle' => $id, 'person' => $personId, 'relationship' => $relationship,
            'until' => $this->optional($input, 'authorizedUntil'),
        ]);

        (new AuditLog($this->database))->write(
            'PRIVATE_VEHICLE_DRIVER_AUTHORIZED',
            'PrivateVehicle',
            $id,
            $actor,
            $request,
            null,
            ['personId' => $personId, 'relationship' => $relationship],
            ['source' => 'private-vehicle-domain']
        );

        return $this->show($id, $actor);
    }

    /**
     * Start a protected journey.
     *
     * @return array<string,mixed>
     */
    public function startJourney(array $input, array $actor, Request $request): array
    {
        $id = $this->required($input, 'privateVehicleId', 'Enrolment');
        $row = $this->row($id);
        $this->assertOwnership($row, $actor);

        $open = $this->database->prepare(
            "SELECT id, status FROM private_vehicle_journeys WHERE private_vehicle_id = :vehicle
             AND status IN ('PLANNED', 'ACTIVE', 'PAUSED') LIMIT 1"
        );
        $open->execute(['vehicle' => $id]);
        if ($open->fetchColumn() !== false) {
            throw new AuthException('This vehicle already has an open journey.', 409);
        }

        $journeyId = Uuid::v4();
        $this->database->beginTransaction();
        try {
            $this->database->prepare(<<<'SQL'
                INSERT INTO private_vehicle_journeys
                    (id, private_vehicle_id, tracked_asset_id, status, origin_text, destination_text,
                     passenger_count, started_at, started_by_user_id)
                VALUES (:id, :vehicle, :asset, 'ACTIVE', :origin, :destination, :passengers, UTC_TIMESTAMP(6), :actor)
                SQL)->execute([
                'id' => $journeyId, 'vehicle' => $id,
                'asset' => $this->trackedAssetId((string) $row['vehicle_id']),
                'origin' => $this->optional($input, 'originText'),
                'destination' => $this->optional($input, 'destinationText'),
                'passengers' => max(1, (int) ($input['passengerCount'] ?? 1)),
                'actor' => $actor['id'] ?? null,
            ]);
            foreach ((is_array($input['passengers'] ?? null) ? $input['passengers'] : []) as $passenger) {
                if (!is_array($passenger)) {
                    continue;
                }
                $this->database->prepare(<<<'SQL'
                    INSERT INTO journey_passengers
                        (id, private_vehicle_journey_id, person_id, guest_name, guest_phone, relationship, is_vip, rescue_covered)
                    VALUES (:id, :journey, :person, :guest, :phone, :relationship, :vip, :covered)
                    SQL)->execute([
                    'id' => Uuid::v4(), 'journey' => $journeyId,
                    'person' => is_string($passenger['personId'] ?? null) ? $passenger['personId'] : null,
                    'guest' => $this->optional($passenger, 'name'),
                    'phone' => $this->optional($passenger, 'phone'),
                    'relationship' => $this->optional($passenger, 'relationship'),
                    'vip' => (bool) ($passenger['isVip'] ?? false) ? 1 : 0,
                    'covered' => (bool) ($passenger['rescueCovered'] ?? false) ? 1 : 0,
                ]);
            }
            $this->database->commit();
        } catch (\Throwable $error) {
            if ($this->database->inTransaction()) {
                $this->database->rollBack();
            }
            throw $error;
        }

        (new AuditLog($this->database))->write(
            'PRIVATE_JOURNEY_STARTED',
            'PrivateVehicleJourney',
            $journeyId,
            $actor,
            $request,
            null,
            ['privateVehicleId' => $id, 'destination' => $this->optional($input, 'destinationText')],
            ['source' => 'private-vehicle-domain']
        );

        return $this->journey($journeyId, $actor);
    }

    /**
     * Move a journey forward, or close it.
     *
     * @return array<string,mixed>
     */
    public function transitionJourney(array $input, array $actor, Request $request): array
    {
        $journeyId = $this->required($input, 'journeyId', 'Journey');
        $journey = $this->journeyRow($journeyId);
        $enrolment = $this->row((string) $journey['private_vehicle_id']);
        $this->assertOwnership($enrolment, $actor);
        $next = strtoupper((string) ($input['status'] ?? ''));
        $from = (string) $journey['status'];
        if (!in_array($next, self::JOURNEY_TRANSITIONS[$from] ?? [], true)) {
            throw new AuthException("A private journey cannot move from {$from} to {$next}.", 409);
        }

        $this->database->prepare(<<<'SQL'
            UPDATE private_vehicle_journeys SET status = :status,
                   arrived_at = IF(:arrived = 'ARRIVED', UTC_TIMESTAMP(6), arrived_at),
                   completed_at = IF(:completed = 1, UTC_TIMESTAMP(6), completed_at),
                   updated_at = UTC_TIMESTAMP(6)
            WHERE id = :id
            SQL)->execute([
            'status' => $next, 'arrived' => $next, 'completed' => $next === 'COMPLETED' ? 1 : 0, 'id' => $journeyId,
        ]);

        (new AuditLog($this->database))->write(
            'PRIVATE_JOURNEY_' . $next,
            'PrivateVehicleJourney',
            $journeyId,
            $actor,
            $request,
            ['status' => $from],
            ['status' => $next],
            ['source' => 'private-vehicle-domain']
        );

        return $this->journey($journeyId, $actor);
    }

    /**
     * REQUEST HELP.
     *
     * Deliberately friction-balanced: the request must be confirmed, the caller
     * is identified and the current position is attached automatically, but a
     * panic is never blocked - the rate limit only throttles a repeated tap.
     *
     * @return array<string,mixed>
     */
    public function requestHelp(array $input, array $actor, Request $request): array
    {
        $id = $this->required($input, 'privateVehicleId', 'Enrolment');
        $row = $this->row($id);
        $this->assertOwnership($row, $actor);

        if (($input['confirmed'] ?? false) !== true) {
            throw new AuthException('Please confirm the emergency request before it is sent.', 422);
        }
        $bucket = 'private-emergency:' . ($request->ipAddress ?? 'cli') . ':' . $id;
        if (!RateLimiter::allow($bucket, 5, 300)) {
            throw new AuthException('Too many emergency requests. If this is urgent, call the Mamore line.', 429);
        }

        $vehicle = $this->vehicle((string) $row['vehicle_id']);
        $assetId = $this->trackedAssetId((string) $row['vehicle_id']);
        $position = $this->currentPosition($assetId);
        $coverage = $this->coverage->forVehicle((string) $row['vehicle_id']);
        $journeyId = $this->openJourneyId($id);

        $incidentId = Uuid::v4();
        $this->database->beginTransaction();
        try {
            $this->database->prepare(<<<'SQL'
                INSERT INTO rescue_incidents
                    (id, incident_code, source, domain, incident_type, caller_name, caller_phone, province,
                     location_text, latitude, longitude, description, priority, severity, status, reported_by_user_id,
                     subscriber_id, vehicle_id, tracked_asset_id, journey_id, rescue_code_id, passenger_count,
                     source_latitude, source_longitude)
                VALUES
                    (:id, :code, 'PRIVATE_VEHICLE', 'PRIVATE_VEHICLE', 'PRIVATE_EMERGENCY', :caller, :phone, :province,
                     :location, :latitude, :longitude, :description, 'CRITICAL', 'CRITICAL', 'REPORTED', :reporter,
                     :subscriber, :vehicle, :asset, :journey, :codeId, :passengers, :sourceLat, :sourceLng)
                SQL)->execute([
                'id' => $incidentId,
                'code' => 'PVE-' . gmdate('ymd') . '-' . strtoupper(bin2hex(random_bytes(3))),
                'caller' => trim(((string) ($actor['first_name'] ?? '')) . ' ' . ((string) ($actor['last_name'] ?? ''))),
                'phone' => is_string($actor['phone'] ?? null) ? $actor['phone'] : '',
                'province' => $this->optional($input, 'province') ?? 'HAUT_KATANGA',
                'location' => $this->optional($input, 'location') ?? 'Private vehicle emergency request',
                'latitude' => $position['latitude'],
                'longitude' => $position['longitude'],
                'description' => $this->required($input, 'description', 'What happened'),
                'reporter' => $actor['id'] ?? null,
                'subscriber' => $row['subscriber_id'],
                'vehicle' => $row['vehicle_id'],
                'asset' => $assetId,
                'journey' => $journeyId,
                'codeId' => $row['rescue_code_id'],
                'passengers' => $journeyId === null ? 1 : (int) $this->database->query(
                    'SELECT passenger_count FROM private_vehicle_journeys WHERE id = ' . $this->database->quote($journeyId)
                )->fetchColumn(),
                'sourceLat' => $position['latitude'],
                'sourceLng' => $position['longitude'],
            ]);

            if ($journeyId !== null) {
                $this->database->prepare("UPDATE private_vehicle_journeys SET status = 'INCIDENT' WHERE id = :id")
                    ->execute(['id' => $journeyId]);
            }
            $this->database->prepare(<<<'SQL'
                INSERT INTO tracking_alerts (id, alert_code, tracked_asset_id, incident_id, domain, severity, message, status)
                VALUES (:id, 'EMERGENCY_REQUEST', :asset, :incident, 'PRIVATE_VEHICLE', 'CRITICAL', :message, 'NEW')
                ON DUPLICATE KEY UPDATE message = VALUES(message)
                SQL)->execute([
                'id' => Uuid::v4(), 'asset' => $assetId, 'incident' => $incidentId,
                'message' => 'Emergency request from a private vehicle.',
            ]);
            $this->database->commit();
        } catch (\Throwable $error) {
            if ($this->database->inTransaction()) {
                $this->database->rollBack();
            }
            throw $error;
        }

        (new AuditLog($this->database))->write(
            'PRIVATE_EMERGENCY_REQUESTED',
            'Incident',
            $incidentId,
            $actor,
            $request,
            null,
            ['privateVehicleId' => $id, 'covered' => $coverage['covered'], 'journeyId' => $journeyId],
            ['source' => 'private-vehicle-domain', 'position' => $position['status']]
        );

        return [
            'incidentId' => $incidentId,
            'incidentCode' => 'PVE-' . gmdate('ymd'),
            'status' => 'REPORTED',
            'dispatchStatus' => 'PENDING_DISPATCH',
            'position' => $position,
            'coverage' => $coverage,
            'vehicle' => [
                'registrationNumber' => $vehicle['registration_number'],
                'description' => trim(((string) $vehicle['make']) . ' ' . ((string) $vehicle['model'])),
            ],
            'journeyId' => $journeyId,
            'message' => 'Your request has reached the Mamore Control Center. Stay with your vehicle if it is safe to do so.',
        ];
    }

    /**
     * @return array<string,mixed>
     */
    public function show(string $id, ?array $actor = null): array
    {
        $row = $this->row($id);
        if ($actor !== null) {
            $this->assertOwnership($row, $actor);
        }
        $vehicle = $this->vehicle((string) $row['vehicle_id']);
        $coverage = $this->coverage->forVehicle((string) $row['vehicle_id']);
        $assetId = $this->trackedAssetId((string) $row['vehicle_id']);

        return [
            'id' => $id,
            'vehicle' => [
                'id' => $vehicle['id'],
                'registrationNumber' => $vehicle['registration_number'],
                'description' => trim(((string) $vehicle['make']) . ' ' . ((string) $vehicle['model'])),
                'vehicleType' => $vehicle['vehicle_type'],
                'verifiedStatus' => $vehicle['verified_status'],
            ],
            'subscriberId' => $row['subscriber_id'],
            'subscriptionStatus' => $row['subscription_status'],
            'rescueCoverage' => $coverage,
            'rescueCode' => $this->rescueCode($row['rescue_code_id']),
            // Derived at read time: a position that arrived since the last write
            // must be visible immediately, and a stale column must not say ONLINE.
            'trackingStatus' => $this->trackingStatus($assetId),
            'trackedAssetId' => $assetId,
            'position' => $this->currentPosition($assetId),
            'activatedAt' => $row['activated_at'],
            'expiresAt' => $row['expires_at'],
            'drivers' => $this->drivers($id),
            'journeys' => $this->journeys($id),
        ];
    }

    /**
     * The subscriber's own dashboard: their vehicles, coverage and journeys.
     *
     * @return array<string,mixed>
     */
    public function dashboard(?array $actor = null): array
    {
        $subscriberId = $this->subscriberIdFor($actor ?? []);
        $statement = $this->database->prepare(
            'SELECT * FROM private_vehicles WHERE subscriber_id = :subscriber ORDER BY created_at'
        );
        $statement->execute(['subscriber' => $subscriberId ?? '']);
        $rows = $statement->fetchAll();

        $covered = 0;
        $tracking = 0;
        $vehicles = [];
        foreach ($rows as $row) {
            $coverage = $this->coverage->forVehicle((string) $row['vehicle_id']);
            $covered += $coverage['covered'] ? 1 : 0;
            $tracking += $row['tracking_status'] === 'ONLINE' ? 1 : 0;
            $vehicles[] = $this->show((string) $row['id'], $actor);
        }

        $openJourneyStatement = $this->database->prepare(<<<'SQL'
            SELECT COUNT(*) FROM private_vehicle_journeys j
            JOIN private_vehicles v ON v.id = j.private_vehicle_id
            WHERE v.subscriber_id = :subscriber
              AND j.status IN ('PLANNED', 'ACTIVE', 'PAUSED', 'INCIDENT')
            SQL);
        $openJourneyStatement->execute(['subscriber' => $subscriberId ?? '']);
        $openJourneys = (int) $openJourneyStatement->fetchColumn();

        return [
            'metrics' => [
                'vehicles' => count($rows),
                'covered' => $covered,
                'trackingOnline' => $tracking,
                'openJourneys' => $openJourneys,
                'activeIncidents' => (int) $this->database->query(
                    'SELECT COUNT(*) FROM rescue_incidents WHERE subscriber_id = ' . $this->database->quote($subscriberId ?? '')
                    . " AND status NOT IN ('RESOLVED', 'CANCELLED')"
                )->fetchColumn(),
            ],
            'vehicles' => $vehicles,
            'message' => $rows === [] ? 'No data available.' : null,
        ];
    }

    // ------------------------------------------------------------- internals

    /** @return array<string,mixed> */
    private function row(string $id): array
    {
        $statement = $this->database->prepare('SELECT * FROM private_vehicles WHERE id = :id');
        $statement->execute(['id' => $id]);
        $row = $statement->fetch();
        if (!is_array($row)) {
            throw new AuthException('Private vehicle enrolment not found.', 404);
        }

        return $row;
    }

    /** @return array<string,mixed> */
    private function journeyRow(string $id): array
    {
        $statement = $this->database->prepare('SELECT * FROM private_vehicle_journeys WHERE id = :id');
        $statement->execute(['id' => $id]);
        $row = $statement->fetch();
        if (!is_array($row)) {
            throw new AuthException('Journey not found.', 404);
        }

        return $row;
    }

    /** @return array<string,mixed> */
    private function vehicle(string $id): array
    {
        $statement = $this->database->prepare('SELECT * FROM vehicles WHERE id = :id AND deleted_at IS NULL');
        $statement->execute(['id' => $id]);
        $vehicle = $statement->fetch();
        if (!is_array($vehicle)) {
            throw new AuthException('Vehicle not found.', 404);
        }

        return $vehicle;
    }

    /** @return array<string,mixed> */
    private function person(string $id): array
    {
        $statement = $this->database->prepare('SELECT * FROM persons WHERE id = :id AND deleted_at IS NULL');
        $statement->execute(['id' => $id]);
        $person = $statement->fetch();
        if (!is_array($person)) {
            throw new AuthException('Person not found.', 404);
        }

        return $person;
    }

    /**
     * A private vehicle reaches the shared tracking core through its own tracked
     * asset, so it appears on the same map as buses, trucks and rescue units.
     */
    private function ensureTrackedAsset(string $privateVehicleId, string $vehicleId): ?string
    {
        $statement = $this->database->prepare('SELECT id FROM tracked_assets WHERE vehicle_id = :vehicle');
        $statement->execute(['vehicle' => $vehicleId]);
        $assetId = $statement->fetchColumn();
        if (is_string($assetId) && $assetId !== '') {
            return $assetId;
        }

        $vehicle = $this->vehicle($vehicleId);
        $newId = Uuid::v4();
        $this->database->prepare(<<<'SQL'
            INSERT INTO tracked_assets (id, asset_type, vehicle_id, asset_code, label, tracking_status, domain, status)
            VALUES (:id, 'PRIVATE_VEHICLE', :vehicle, :code, :label, 'NO_DEVICE', 'PRIVATE_VEHICLE', 'ACTIVE')
            SQL)->execute([
            'id' => $newId, 'vehicle' => $vehicleId, 'code' => $vehicle['registration_number'],
            'label' => trim(((string) $vehicle['make']) . ' ' . ((string) $vehicle['model']) . ' · ' . $vehicle['registration_number']),
        ]);
        $this->database->prepare("UPDATE private_vehicles SET tracking_status = 'NO_DEVICE' WHERE id = :id")
            ->execute(['id' => $privateVehicleId]);

        return $newId;
    }

    private function trackedAssetId(string $vehicleId): ?string
    {
        $statement = $this->database->prepare('SELECT id FROM tracked_assets WHERE vehicle_id = :vehicle');
        $statement->execute(['vehicle' => $vehicleId]);
        $id = $statement->fetchColumn();

        return is_string($id) ? $id : null;
    }

    /**
     * The current position, with its age. A vehicle with no position says so.
     *
     * @return array<string,mixed>
     */
    private function currentPosition(?string $assetId): array
    {
        $none = ['status' => 'NO_POSITION', 'latitude' => null, 'longitude' => null, 'recordedAt' => null, 'secondsAgo' => null];
        if ($assetId === null) {
            return $none;
        }
        $statement = $this->database->prepare(
            'SELECT latitude, longitude, recorded_at FROM tracked_asset_positions WHERE tracked_asset_id = :asset'
        );
        $statement->execute(['asset' => $assetId]);
        $position = $statement->fetch();
        if (!is_array($position)) {
            return $none;
        }

        $secondsAgo = ServerClock::epoch($this->database) - ServerClock::parse((string) $position['recorded_at']);

        return [
            'status' => $secondsAgo <= 120 ? 'ONLINE' : 'OFFLINE',
            'latitude' => (float) $position['latitude'],
            'longitude' => (float) $position['longitude'],
            'recordedAt' => $position['recorded_at'],
            'secondsAgo' => $secondsAgo,
        ];
    }

    private function openJourneyId(string $privateVehicleId): ?string
    {
        $statement = $this->database->prepare(
            "SELECT id FROM private_vehicle_journeys WHERE private_vehicle_id = :vehicle
             AND status IN ('PLANNED', 'ACTIVE', 'PAUSED', 'INCIDENT') ORDER BY started_at DESC LIMIT 1"
        );
        $statement->execute(['vehicle' => $privateVehicleId]);
        $id = $statement->fetchColumn();

        return is_string($id) ? $id : null;
    }

    /** Tracking and coverage state are derived, never stored optimistically. */
    private function syncState(string $privateVehicleId): void
    {
        $row = $this->row($privateVehicleId);
        $coverage = $this->coverage->forVehicle((string) $row['vehicle_id']);
        $this->database->prepare(<<<'SQL'
            UPDATE private_vehicles SET rescue_coverage_status = :coverage, tracking_status = :tracking,
                   updated_at = UTC_TIMESTAMP(6) WHERE id = :id
            SQL)->execute([
            'coverage' => $coverage['covered'] ? 'ACTIVE' : 'UNCOVERED',
            'tracking' => $this->trackingStatus($this->trackedAssetId((string) $row['vehicle_id'])),
            'id' => $privateVehicleId,
        ]);
    }

    /**
     * ONLINE only when a device is assigned AND a fresh position exists.
     *
     * @return string NO_DEVICE|OFFLINE|ONLINE|UNKNOWN
     */
    private function trackingStatus(?string $assetId): string
    {
        if ($assetId === null) {
            return 'NO_DEVICE';
        }
        $assigned = $this->database->query(
            'SELECT COUNT(*) FROM tracking_device_assignments WHERE tracked_asset_id = '
            . $this->database->quote($assetId) . ' AND unassigned_at IS NULL'
        )->fetchColumn();
        if ((int) $assigned === 0) {
            return 'NO_DEVICE';
        }

        return $this->currentPosition($assetId)['status'] === 'ONLINE' ? 'ONLINE' : 'OFFLINE';
    }

    /** @return list<array<string,mixed>> */
    private function drivers(string $privateVehicleId): array
    {
        $statement = $this->database->prepare(<<<'SQL'
            SELECT d.relationship, d.is_primary, d.authorized_from, d.authorized_until, d.status,
                   p.first_name, p.last_name, p.phone
            FROM private_vehicle_drivers d JOIN persons p ON p.id = d.person_id
            WHERE d.private_vehicle_id = :id ORDER BY d.is_primary DESC, d.created_at
            SQL);
        $statement->execute(['id' => $privateVehicleId]);

        return array_map(static fn (array $row): array => [
            'name' => trim(((string) $row['first_name']) . ' ' . ((string) $row['last_name'])),
            'relationship' => $row['relationship'],
            'isPrimary' => (bool) $row['is_primary'],
            'phone' => $row['phone'],
            'status' => $row['status'],
            'authorizedFrom' => $row['authorized_from'],
            'authorizedUntil' => $row['authorized_until'],
        ], $statement->fetchAll());
    }

    /** @return list<array<string,mixed>> */
    private function journeys(string $privateVehicleId): array
    {
        $statement = $this->database->prepare(<<<'SQL'
            SELECT * FROM private_vehicle_journeys WHERE private_vehicle_id = :id
            ORDER BY COALESCE(started_at, created_at) DESC LIMIT 20
            SQL);
        $statement->execute(['id' => $privateVehicleId]);

        return array_map(fn (array $row): array => [
            'id' => $row['id'],
            'status' => $row['status'],
            'origin' => $row['origin_text'],
            'destination' => $row['destination_text'],
            'passengerCount' => (int) $row['passenger_count'],
            'startedAt' => $row['started_at'],
            'completedAt' => $row['completed_at'],
        ], $statement->fetchAll());
    }

    /** @return array<string,mixed> */
    public function journey(string $journeyId, ?array $actor = null): array
    {
        $row = $this->journeyRow($journeyId);
        if ($actor !== null) {
            $this->assertOwnership($this->row((string) $row['private_vehicle_id']), $actor);
        }

        $passengers = $this->database->prepare(<<<'SQL'
            SELECT person_id, guest_name, guest_phone, relationship, is_vip, rescue_covered
            FROM journey_passengers WHERE private_vehicle_journey_id = :id
            SQL);
        $passengers->execute(['id' => $journeyId]);
        $enrolment = $this->row((string) $row['private_vehicle_id']);

        return [
            'id' => $journeyId,
            'privateVehicleId' => $row['private_vehicle_id'],
            'status' => $row['status'],
            'origin' => $row['origin_text'],
            'destination' => $row['destination_text'],
            'passengerCount' => (int) $row['passenger_count'],
            'startedAt' => $row['started_at'],
            'arrivedAt' => $row['arrived_at'],
            'completedAt' => $row['completed_at'],
            'position' => $this->currentPosition($row['tracked_asset_id'] === null ? null : (string) $row['tracked_asset_id']),
            'rescueCoverage' => $this->coverage->forVehicle((string) $enrolment['vehicle_id']),
            'passengers' => array_map(static fn (array $p): array => [
                'personId' => $p['person_id'],
                'name' => $p['guest_name'],
                'phone' => $p['guest_phone'],
                'relationship' => $p['relationship'],
                'isVip' => (bool) $p['is_vip'],
                'rescueCovered' => (bool) $p['rescue_covered'],
            ], $passengers->fetchAll()),
        ];
    }

    /**
     * A subscriber sees only their own vehicles; staff see only what their role
     * allows. Nothing is guessed from the client.
     */
    private function assertOwnership(array $row, array $actor): void
    {
        $role = (string) ($actor['role_code'] ?? '');
        if (in_array($role, ['SYSTEM_ADMIN', 'HQ_DISPATCHER', 'AUDITOR', 'FINANCE_MANAGER', 'RESCUE_OPERATOR'], true)) {
            return;
        }

        $subscriberId = $this->subscriberIdFor($actor);
        if ($subscriberId === null || (string) $row['subscriber_id'] !== $subscriberId) {
            throw new AuthException('This vehicle is not yours.', 403);
        }
    }

    private function subscriberIdFor(array $actor): ?string
    {
        $id = $actor['id'] ?? null;
        if (!is_string($id) || $id === '') {
            return null;
        }
        $statement = $this->database->prepare('SELECT subscriber_id FROM users WHERE id = :id');
        $statement->execute(['id' => $id]);
        $subscriberId = $statement->fetchColumn();

        return is_string($subscriberId) && $subscriberId !== '' ? $subscriberId : null;
    }

    private function personIdForSubscriber(string $subscriberId): ?string
    {
        $statement = $this->database->prepare('SELECT person_id FROM subscribers WHERE id = :id AND deleted_at IS NULL');
        $statement->execute(['id' => $subscriberId]);
        $personId = $statement->fetchColumn();

        return is_string($personId) ? $personId : null;
    }

    private function planId(string $planCode): ?string
    {
        $statement = $this->database->prepare("SELECT id FROM service_plans WHERE plan_code = :code AND status = 'ACTIVE'");
        $statement->execute(['code' => $planCode]);
        $id = $statement->fetchColumn();

        return is_string($id) ? $id : null;
    }

    private function rescueCode(mixed $codeId): ?string
    {
        if (!is_string($codeId) || $codeId === '') {
            return null;
        }
        $statement = $this->database->prepare("SELECT code FROM rescue_codes WHERE id = :id AND status = 'ACTIVE'");
        $statement->execute(['id' => $codeId]);
        $code = $statement->fetchColumn();

        return is_string($code) ? $code : null;
    }

    private function choice(mixed $value, string $column, string $referenceTable): string
    {
        $choice = is_string($value) ? strtoupper(trim($value)) : '';
        if ($choice === '') {
            throw new AuthException("Choose a valid {$column}.", 422);
        }
        $statement = $this->database->prepare("SELECT code FROM {$referenceTable} WHERE code = :code");
        $statement->execute(['code' => $choice]);
        if ($statement->fetchColumn() === false) {
            throw new AuthException("Choose a valid {$column}.", 422);
        }

        return $choice;
    }

    private function required(array $input, string $key, string $label): string
    {
        $value = is_string($input[$key] ?? null) ? trim($input[$key]) : '';
        if ($value === '') {
            throw new AuthException("{$label} is required.", 422);
        }

        return $value;
    }

    private function optional(array $input, string $key): ?string
    {
        $value = $input[$key] ?? null;
        if (!is_string($value) || trim($value) === '') {
            return null;
        }

        return trim($value);
    }
}
