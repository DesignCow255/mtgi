<?php

declare(strict_types=1);

namespace Mamore\Finance;

use Mamore\Auth\AuthException;
use Mamore\Core\AuditLog;
use Mamore\Core\Env;
use Mamore\Core\Request;
use Mamore\Core\Uuid;
use Mamore\Support\FeeEngine;
use Mamore\Support\Money;
use PDO;

/**
 * Receipts for subscription payments.
 *
 * The stored `breakdown` JSON keeps the canonical chargeable/subset split so a
 * printed receipt can show the $430 + $170 = $600 (or $40 + $40 = $80) story
 * without recomputing anything, and the UNALLOCATED remainder stays visible.
 *
 * Ownership is enforced by the callers: staff use show(), the portal uses
 * showForSubscriber(), which refuses receipts belonging to someone else.
 */
final class ReceiptService
{
    public function __construct(private readonly PDO $database) {}

    /**
     * Issue the receipt for a payment. Runs inside the payment transaction, so
     * it never opens one itself and is idempotent per payment.
     *
     * @param array<string, mixed> $context payment row plus subscription context
     */
    public function issueForPayment(array $context): array
    {
        $paymentId = (string) $context['payment_id'];
        $existing = $this->findByPayment($paymentId);
        if ($existing !== null) {
            return $existing;
        }

        $subscription = $context['subscription'];
        $productCode = (string) $context['product_code'];
        $id = Uuid::v4();
        $receiptNumber = 'RCT-' . gmdate('y') . '-' . strtoupper(bin2hex(random_bytes(3)));
        $verificationNumber = 'VER-' . strtoupper(bin2hex(random_bytes(5)));
        $breakdown = $this->breakdown($productCode, (string) $subscription['province']);
        $qrData = rtrim(Env::get('APP_URL', ''), '/') . '/receipts/print?code=' . $verificationNumber;

        $this->database->prepare(<<<'SQL'
            INSERT INTO receipts
                (id, payment_id, subscription_id, subscriber_id, receipt_number, verification_number,
                 qr_data, barcode_data, breakdown, amount, currency, status)
            VALUES
                (:id, :payment, :subscription, :subscriber, :number, :verification,
                 :qr, :barcode, :breakdown, :amount, :currency, 'ISSUED')
            SQL)->execute([
            'id' => $id,
            'payment' => $paymentId,
            'subscription' => $subscription['id'],
            'subscriber' => $subscription['subscriberId'],
            'number' => $receiptNumber,
            'verification' => $verificationNumber,
            'qr' => $qrData,
            'barcode' => $receiptNumber,
            'breakdown' => json_encode($breakdown, JSON_THROW_ON_ERROR),
            'amount' => $context['amount'],
            'currency' => 'USD',
        ]);

        return $this->show($id);
    }

    /** Staff view: full receipt with breakdown, payment and subscriber context. */
    public function show(string $id): array
    {
        $statement = $this->database->prepare($this->selectSql() . ' WHERE r.id = :id');
        $statement->execute(['id' => $id]);
        $row = $statement->fetch();
        if (!is_array($row)) {
            throw new AuthException('Receipt not found.', 404);
        }

        return $this->hydrate($row);
    }

    /** Portal view: only the receipt of one of the caller's own payments. */
    public function showForSubscriber(string $id, string $subscriberId): array
    {
        $statement = $this->database->prepare($this->selectSql() . ' WHERE r.id = :id AND r.subscriber_id = :subscriber');
        $statement->execute(['id' => $id, 'subscriber' => $subscriberId]);
        $row = $statement->fetch();
        if (!is_array($row)) {
            throw new AuthException('Receipt not found.', 404);
        }

        return $this->hydrate($row);
    }

    /**
     * Receipt lookup by receipt number or verification code; this backs the
     * public verification page the QR code points at.
     */
    public function verify(string $code): array
    {
        $statement = $this->database->prepare(
            $this->selectSql() . ' WHERE r.verification_number = :code OR r.receipt_number = :byNumber'
        );
        $statement->execute(['code' => strtoupper(trim($code)), 'byNumber' => strtoupper(trim($code))]);
        $row = $statement->fetch();
        if (!is_array($row)) {
            throw new AuthException('Receipt could not be verified.', 404);
        }

        return $this->hydrate($row);
    }

    /** Record a print/reprint: the first print keeps ISSUED, later ones REPRINTED. */
    public function markPrinted(string $id, ?array $actor = null, ?Request $request = null): array
    {
        $receipt = $this->show($id);
        $this->database->prepare(<<<'SQL'
            UPDATE receipts
            SET status = CASE WHEN print_count = 0 THEN 'ISSUED' ELSE 'REPRINTED' END,
                printed = TRUE,
                print_count = print_count + 1,
                printed_at = UTC_TIMESTAMP(6)
            WHERE id = :id
            SQL)->execute(['id' => $id]);
        $printed = $this->show($id);
        $this->audit(
            'PRINT_RECEIPT',
            $id,
            $actor,
            ['status' => $receipt['status'], 'printCount' => $receipt['printCount'], 'printed' => $receipt['printed']],
            ['status' => $printed['status'], 'printCount' => $printed['printCount'], 'printed' => $printed['printed']],
            $request,
            ['receiptNumber' => $receipt['receiptNumber'], 'subscriptionId' => $receipt['subscription']['id']]
        );

        return $printed;
    }

    /** Void the receipt of a voided payment (canonical ReceiptStatus VOID). */
    public function voidForPayment(string $paymentId): void
    {
        $this->database->prepare("UPDATE receipts SET status = 'VOID' WHERE payment_id = :payment AND status <> 'VOID'")
            ->execute(['payment' => $paymentId]);
    }

    public function list(array $filters = []): array
    {
        $where = [];
        $params = [];
        if (($filters['subscriberId'] ?? '') !== '') {
            $where[] = 'r.subscriber_id = :subscriber';
            $params['subscriber'] = (string) $filters['subscriberId'];
        }
        if (($filters['subscriptionId'] ?? '') !== '') {
            $where[] = 'r.subscription_id = :subscription';
            $params['subscription'] = (string) $filters['subscriptionId'];
        }
        if (($filters['status'] ?? '') !== '') {
            $status = strtoupper((string) $filters['status']);
            if (!in_array($status, ['ISSUED', 'VOID', 'REPRINTED'], true)) {
                throw new AuthException('Select a valid receipt status.', 422);
            }
            $where[] = 'r.status = :status';
            $params['status'] = $status;
        }
        $limit = min(max((int) ($filters['limit'] ?? 50), 1), 200);

        $sql = $this->selectSql();
        if ($where !== []) {
            $sql .= ' WHERE ' . implode(' AND ', $where);
        }
        $sql .= ' ORDER BY r.issued_at DESC LIMIT ' . $limit;

        $statement = $this->database->prepare($sql);
        $statement->execute($params);

        return array_map([$this, 'hydrate'], $statement->fetchAll());
    }

    public function forSubscriber(string $subscriberId, int $limit = 100): array
    {
        return $this->list(['subscriberId' => $subscriberId, 'limit' => $limit]);
    }

    private function selectSql(): string
    {
        return <<<'SQL'
            SELECT r.*, p.payment_reference, p.transaction_number, p.payment_method, p.paid_at, p.provider, p.channel,
                   s.subscription_no, s.province, s.start_date, s.end_date, s.status AS subscription_status,
                   COALESCE(NULLIF(TRIM(CONCAT_WS(' ', sub.first_name, sub.last_name)), ''), sub.company_name) AS subscriber_name,
                   sub.membership_number, sub.phone AS subscriber_phone, sub.email AS subscriber_email,
                   rp.code AS product_code
            FROM receipts r
            JOIN payments p ON p.id = r.payment_id
            JOIN subscriptions s ON s.id = r.subscription_id
            JOIN subscribers sub ON sub.id = r.subscriber_id
            LEFT JOIN rescue_products rp ON rp.id = s.product_id
            SQL;
    }

    private function findByPayment(string $paymentId): ?array
    {
        $statement = $this->database->prepare($this->selectSql() . ' WHERE r.payment_id = :payment');
        $statement->execute(['payment' => $paymentId]);
        $row = $statement->fetch();

        return is_array($row) ? $this->hydrate($row) : null;
    }

    /**
     * Receipt breakdown: the chargeable lines that reconcile to the paid amount
     * plus the informational subsets of the taxable container. Amounts carry a
     * formatted string as well, so printing never re-formats money ad hoc.
     *
     * @return array<string, mixed>
     */
    private function breakdown(string $productCode, string $province): array
    {
        $product = FeeEngine::catalog()[$productCode];
        $format = static fn (array $lines): array => array_map(static fn (array $line): array => [
            'key' => $line['key'],
            'name' => $line['name'],
            'amount' => $line['amount'],
            'formatted' => Money::format($line['amount'], 'USD'),
            'province' => $line['province'] ?? null,
        ], $lines);

        return [
            'product' => [
                'code' => $product['code'],
                'name' => $product['name'],
                'billingFrequency' => $product['billingFrequency'],
            ],
            'province' => $province,
            'chargeable' => $format(FeeEngine::chargeableBreakdown($productCode)),
            'subsets' => $format(FeeEngine::rules($productCode, 'SUBSET')),
            'totals' => [
                'chargeableUsd' => FeeEngine::total(FeeEngine::chargeableBreakdown($productCode)),
                'chargeableFormatted' => Money::format(FeeEngine::total(FeeEngine::chargeableBreakdown($productCode)), 'USD'),
                'taxableContainerUsd' => FeeEngine::taxableContainer($productCode),
                'subsetTotalUsd' => FeeEngine::subsetTotal($productCode),
                'subsetTotalFormatted' => Money::format(FeeEngine::subsetTotal($productCode), 'USD'),
            ],
        ];
    }

    private function hydrate(array $row): array
    {
        return [
            'id' => $row['id'],
            'receiptNumber' => $row['receipt_number'],
            'verificationNumber' => $row['verification_number'],
            'status' => $row['status'],
            'printed' => (bool) $row['printed'],
            'printCount' => (int) $row['print_count'],
            'printedAt' => $row['printed_at'],
            'issuedAt' => $row['issued_at'],
            'amount' => bcadd((string) $row['amount'], '0', 2),
            'amountFormatted' => Money::format((string) $row['amount'], (string) $row['currency']),
            'currency' => $row['currency'],
            'qrData' => $row['qr_data'],
            'barcodeData' => $row['barcode_data'],
            'breakdown' => $row['breakdown'] !== null ? json_decode((string) $row['breakdown'], true) : null,
            'payment' => [
                'id' => $row['payment_id'],
                'reference' => $row['payment_reference'] ?? null,
                'transactionNumber' => $row['transaction_number'] ?? null,
                'method' => $row['payment_method'] ?? null,
                'provider' => $row['provider'] ?? null,
                'channel' => $row['channel'] ?? null,
                'paidAt' => $row['paid_at'] ?? null,
            ],
            'subscription' => [
                'id' => $row['subscription_id'],
                'subscriptionNo' => $row['subscription_no'] ?? null,
                'status' => $row['subscription_status'] ?? null,
                'province' => $row['province'] ?? null,
                'startDate' => $row['start_date'] ?? null,
                'endDate' => $row['end_date'] ?? null,
                'productCode' => $row['product_code'] ?? null,
            ],
            'subscriber' => [
                'id' => $row['subscriber_id'],
                'name' => $row['subscriber_name'] ?? null,
                'membershipNumber' => $row['membership_number'] ?? null,
                'phone' => $row['subscriber_phone'] ?? null,
                'email' => $row['subscriber_email'] ?? null,
            ],
        ];
    }

    private function audit(
        string $action,
        string $entityId,
        ?array $actor,
        array $previous,
        array $new,
        ?Request $request = null,
        ?array $metadata = null,
    ): void {
        (new AuditLog($this->database))->write($action, 'Receipt', $entityId, $actor, $request, $previous, $new, $metadata);
    }
}
