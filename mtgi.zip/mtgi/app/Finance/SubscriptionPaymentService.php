<?php

declare(strict_types=1);

namespace Mamore\Finance;

use Mamore\Auth\AuthException;
use Mamore\Core\AuditLog;
use Mamore\Core\Request;
use Mamore\Core\Uuid;
use Mamore\Subscription\SubscriptionService;
use Mamore\Support\FeeEngine;
use Mamore\Support\Money;
use PDO;
use PDOException;
use RuntimeException;

/**
 * Subscription payments.
 *
 * A payment is always for the catalog price of the subscription: the amount is
 * read back from the stored subscription (itself priced by FeeEngine) and any
 * client supplied amount must match it exactly. Each CHARGEABLE fee line becomes
 * a payment allocation plus a ledger credit, the money is debited from the
 * settlement account of the payment method, provincial/national taxes are
 * recorded from the SUBSET lines, the subscription is activated and a receipt
 * is issued with the canonical breakdown.
 *
 * Ledger integrity is asserted before commit: debits must equal credits to the
 * cent, otherwise the transaction rolls back and the error surfaces.
 */
final class SubscriptionPaymentService
{
    public function __construct(private readonly PDO $database) {}

    /**
     * Record a subscription payment (idempotent when idempotencyKey is given).
     *
     * @return array<string, mixed>
     */
    public function receive(array $input, array $actor, ?Request $request = null): array
    {
        $subscriptionId = $this->required($input, 'subscriptionId', 'Subscription');
        $method = PaymentProvider::normalize(is_string($input['paymentMethod'] ?? null) ? $input['paymentMethod'] : '');
        if (!in_array($method, PaymentProvider::methods(), true)) {
            throw new AuthException('Select a valid payment method.', 422);
        }

        $idempotencyKey = trim((string) ($input['idempotencyKey'] ?? ''));
        if ($idempotencyKey !== '') {
            $existing = $this->byIdempotencyKey($idempotencyKey);
            if ($existing !== null) {
                return $existing + ['idempotent' => true];
            }
        }

        $subscriptions = new SubscriptionService($this->database);
        $subscription = $subscriptions->show($subscriptionId);
        $amount = bcadd((string) $subscription['totalAmount'], '0', 2);
        $productCode = (string) $subscription['productCode'];

        if ($subscription['status'] === 'ACTIVE') {
            throw new AuthException('This subscription is already paid. Start a renewal instead.', 409);
        }
        if (in_array($subscription['status'], ['CANCELLED', 'RENEWED'], true)) {
            throw new AuthException('A cancelled or renewed subscription cannot be paid.', 409);
        }
        if (isset($input['amount']) && $input['amount'] !== null && $input['amount'] !== '') {
            if (!is_numeric($input['amount']) || bccomp((string) $input['amount'], $amount, 2) !== 0) {
                throw new AuthException("The amount must equal the subscription total of {$amount} USD.", 422);
            }
        }

        $province = is_string($input['province'] ?? null) ? strtoupper(trim($input['province'])) : '';
        if ($province !== '' && $province !== $subscription['province']) {
            if (!in_array($province, ['HAUT_KATANGA', 'LUALABA'], true)) {
                throw new AuthException('Select a valid province.', 422);
            }
        } else {
            $province = (string) $subscription['province'];
        }

        $rate = null;
        if (isset($input['usdCdfRate']) && $input['usdCdfRate'] !== null && $input['usdCdfRate'] !== '') {
            if (!is_numeric($input['usdCdfRate']) || (float) $input['usdCdfRate'] <= 0) {
                throw new AuthException('Enter a valid USD/CDF exchange rate.', 422);
            }
            $rate = bcadd((string) $input['usdCdfRate'], '0', 4);
        }

        $actorId = $actor['id'] ?? null;
        if (!is_string($actorId) || $actorId === '') {
            throw new AuthException('An authenticated operator is required.', 403);
        }

        $paidAt = $this->paidAt($input['paidAt'] ?? null);
        $paymentReference = 'PMT-' . gmdate('Y') . '-' . strtoupper(bin2hex(random_bytes(4)));
        $transactionNumber = 'TRX-' . gmdate('Y') . '-' . strtoupper(bin2hex(random_bytes(4)));
        $provider = PaymentProvider::initiate($method, $paymentReference);
        $settlement = PaymentProvider::settlementAccount($method);
        $chargeable = $subscription['fees']['chargeable'];
        $ledgerTotal = FeeEngine::total($chargeable);

        if (bccomp($ledgerTotal, $amount, 2) !== 0) {
            throw new RuntimeException(
                "Allocation lines total {$ledgerTotal} but the subscription is {$amount}; refusing to post an unbalanced payment."
            );
        }

        $paymentId = Uuid::v4();
        $this->database->beginTransaction();
        try {
            $this->insertPayment($paymentId, $input, $subscriptionId, $amount, $rate, $method, $provider, $paidAt, $paymentReference, $transactionNumber, $idempotencyKey, $actor);
            $this->allocate($paymentId, $chargeable);
            $this->postLedger($paymentId, $settlement, $chargeable, $amount, $transactionNumber);
            $this->recordTaxes($paymentId, $subscription, $province, $actorId);

            $subscriptions->activatePaid($subscriptionId, $actorId);

            $receipt = (new ReceiptService($this->database))->issueForPayment([
                'payment_id' => $paymentId,
                'subscription' => $subscription,
                'product_code' => $productCode,
                'amount' => $amount,
            ]);

            $this->notifySubscriber($subscription['subscriberId'], $receipt, $amount);
            $this->audit(
                'PAYMENT_RECEIVED',
                $paymentId,
                $actor,
                ['status' => 'PENDING', 'amount' => null, 'subscriptionStatus' => $subscription['status']],
                [
                    'status' => 'COMPLETED',
                    'amount' => $amount,
                    'amountCdf' => $rate === null ? null : Money::usdToCdfRounded($amount, $rate),
                    'paymentReference' => $paymentReference,
                    'transactionNumber' => $transactionNumber,
                    'method' => $method,
                    'provider' => $provider['provider'],
                    'receiptNumber' => $receipt['receiptNumber'],
                    'allocations' => array_map(
                        static fn (array $line): array => [
                            'key' => $line['key'],
                            'amount' => $line['amount'],
                            'ledgerAccount' => $line['ledgerAccount'],
                        ],
                        $chargeable
                    ),
                ],
                $request,
                [
                    'source' => 'subscription-payment',
                    'subscriptionNo' => $subscription['subscriptionNo'],
                    'subscriptionId' => $subscription['id'],
                    'subscriberId' => $subscription['subscriberId'],
                    'province' => $province,
                    'idempotencyKey' => $idempotencyKey === '' ? null : $idempotencyKey,
                ]
            );

            $this->database->commit();
        } catch (PDOException $error) {
            $this->database->rollBack();
            if ((string) $error->getCode() === '23000') {
                // The unique idempotency key won a race: return the stored payment.
                $existing = $idempotencyKey === '' ? null : $this->byIdempotencyKey($idempotencyKey);
                if ($existing !== null) {
                    return $existing + ['idempotent' => true];
                }
                throw new AuthException('This payment was already recorded.', 409);
            }
            throw $error;
        } catch (\Throwable $error) {
            $this->database->rollBack();
            throw $error;
        }

        return $this->show($paymentId);
    }

    /**
     * Void a completed payment: contra ledger entries, receipt marked VOID,
     * recorded taxes voided and the subscription returned to PENDING.
     */
    public function void(array $input, array $actor, ?Request $request = null): array
    {
        $paymentId = $this->required($input, 'paymentId', 'Payment');
        $reason = trim((string) ($input['reason'] ?? ''));
        if ($reason === '') {
            throw new AuthException('Give a reason for voiding this payment.', 422);
        }

        $payment = $this->show($paymentId);
        if ($payment['status'] === 'VOIDED') {
            return $payment + ['idempotent' => true];
        }
        if ($payment['status'] !== 'COMPLETED') {
            throw new AuthException('Only a completed payment can be voided.', 409);
        }

        $reference = (string) $payment['transactionNumber'] . '-VOID';
        $this->database->beginTransaction();
        try {
            $entries = array_map(static fn (array $allocation): array => [
                'account' => (string) $allocation['ledgerAccount'],
                'type' => 'DEBIT',
                'amount' => (string) $allocation['amount'],
            ], $payment['allocations']);
            $entries[] = [
                'account' => PaymentProvider::settlementAccount((string) $payment['method']),
                'type' => 'CREDIT',
                'amount' => (string) $payment['amount'],
            ];
            $this->writeLedgerEntries($paymentId, $entries, $reference);

            $this->database->prepare(
                "UPDATE payments SET status = 'VOIDED', voided_at = UTC_TIMESTAMP(6), void_reason = :reason WHERE id = :id AND status = 'COMPLETED'"
            )->execute(['reason' => $reason, 'id' => $paymentId]);

            $this->database->prepare("UPDATE government_taxes SET status = 'VOIDED' WHERE payment_id = :payment")
                ->execute(['payment' => $paymentId]);
            (new ReceiptService($this->database))->voidForPayment($paymentId);
            (new SubscriptionService($this->database))->markPaymentVoided(
                (string) $payment['subscriptionId'],
                $reason,
                is_string($actor['id'] ?? null) ? $actor['id'] : null,
                $request
            );
            $this->audit(
                'PAYMENT_VOIDED',
                $paymentId,
                $actor,
                ['status' => $payment['status'], 'voidReason' => null, 'amount' => $payment['amount']],
                ['status' => 'VOIDED', 'voidReason' => $reason, 'amount' => $payment['amount']],
                $request,
                [
                    'source' => 'subscription-payment',
                    'subscriptionId' => $payment['subscriptionId'],
                    'paymentReference' => $payment['paymentReference'],
                    'receiptNumber' => $payment['receipt']['receiptNumber'] ?? null,
                    'contraEntries' => count($payment['ledger']),
                ]
            );

            $this->database->commit();
        } catch (\Throwable $error) {
            $this->database->rollBack();
            throw $error;
        }

        return $this->show($paymentId);
    }

    /** Full payment payload: allocations, ledger trail, taxes and receipt. */
    public function show(string $id): array
    {
        $statement = $this->database->prepare($this->selectSql() . ' WHERE p.id = :id');
        $statement->execute(['id' => $id]);
        $row = $statement->fetch();
        if (!is_array($row)) {
            throw new AuthException('Payment not found.', 404);
        }

        return $this->hydrate($row);
    }

    public function list(array $filters = []): array
    {
        $where = [];
        $params = [];
        if (($filters['subscriptionId'] ?? '') !== '') {
            $where[] = 'p.subscription_id = :subscription';
            $params['subscription'] = (string) $filters['subscriptionId'];
        }
        if (($filters['subscriberId'] ?? '') !== '') {
            $where[] = 's.subscriber_id = :subscriber';
            $params['subscriber'] = (string) $filters['subscriberId'];
        }
        if (($filters['status'] ?? '') !== '') {
            $status = strtoupper((string) $filters['status']);
            if (!in_array($status, ['PENDING', 'COMPLETED', 'FAILED', 'VOIDED'], true)) {
                throw new AuthException('Select a valid payment status.', 422);
            }
            $where[] = 'p.status = :status';
            $params['status'] = $status;
        }
        $limit = min(max((int) ($filters['limit'] ?? 50), 1), 200);

        $sql = $this->selectSql();
        if ($where !== []) {
            $sql .= ' WHERE ' . implode(' AND ', $where);
        }
        $sql .= ' ORDER BY p.paid_at DESC LIMIT ' . $limit;

        $statement = $this->database->prepare($sql);
        $statement->execute($params);

        return array_map([$this, 'hydrate'], $statement->fetchAll());
    }

    private function insertPayment(
        string $paymentId,
        array $input,
        string $subscriptionId,
        string $amount,
        ?string $rate,
        string $method,
        array $provider,
        string $paidAt,
        string $reference,
        string $transactionNumber,
        string $idempotencyKey,
        array $actor
    ): void {
        $this->database->prepare(<<<'SQL'
            INSERT INTO payments
                (id, payment_reference, transaction_number, subscription_id, amount, amount_cdf, usd_cdf_rate,
                 payment_method, provider, channel, provider_reference, status, paid_at, operator_id, operator_name,
                 location, narration, idempotency_key, received_by_user_id)
            VALUES
                (:id, :reference, :transaction, :subscription, :amount, :amountCdf, :rate,
                 :method, :provider, :channel, :providerReference, 'COMPLETED', :paidAt, :operatorId, :operatorName,
                 :location, :narration, :idempotency, :actor)
            SQL)->execute([
            'id' => $paymentId,
            'reference' => $reference,
            'transaction' => $transactionNumber,
            'subscription' => $subscriptionId,
            'amount' => $amount,
            'amountCdf' => $rate === null ? null : Money::usdToCdfRounded($amount, $rate),
            'rate' => $rate,
            'method' => $method,
            'provider' => $provider['provider'],
            'channel' => $provider['channel'],
            'providerReference' => $provider['providerReference'],
            'paidAt' => $paidAt,
            'operatorId' => $actor['id'],
            'operatorName' => trim((string) (($actor['first_name'] ?? '') . ' ' . ($actor['last_name'] ?? ''))) ?: null,
            'location' => $this->nullableString($input['location'] ?? null),
            'narration' => $this->nullableString($input['narration'] ?? null),
            'idempotency' => $idempotencyKey === '' ? null : $idempotencyKey,
            'actor' => $actor['id'],
        ]);
    }

    /**
     * Allocate the chargeable fee lines. Allocations always mirror the catalog
     * lines of the subscription, so allocations match the receipt.
     *
     * @param list<array<string,mixed>> $chargeable
     */
    private function allocate(string $paymentId, array $chargeable): void
    {
        $insert = $this->database->prepare(<<<'SQL'
            INSERT INTO payment_allocations
                (payment_id, component_key, component_name, component_type, category, allocation_role, province,
                 amount, ledger_account)
            VALUES
                (:payment, :key, :name, :type, :category, 'CHARGEABLE', :province, :amount, :ledger)
            SQL);

        foreach ($chargeable as $line) {
            $insert->execute([
                'payment' => $paymentId,
                'key' => $line['key'],
                'name' => $line['name'],
                'type' => $line['componentType'],
                'category' => $line['category'],
                'province' => $line['province'],
                'amount' => $line['amount'],
                'ledger' => $line['ledgerAccount'],
            ]);
        }
    }

    /**
     * Double entry: debit the settlement account of the payment method, credit
     * every allocation account. The sums must match to the cent.
     *
     * @param list<array<string,mixed>> $chargeable
     */
    private function postLedger(string $paymentId, string $settlement, array $chargeable, string $amount, string $reference): void
    {
        $entries = [['account' => $settlement, 'type' => 'DEBIT', 'amount' => $amount]];
        foreach ($chargeable as $line) {
            $entries[] = [
                'account' => (string) $line['ledgerAccount'],
                'type' => 'CREDIT',
                'amount' => (string) $line['amount'],
            ];
        }

        $this->writeLedgerEntries($paymentId, $entries, $reference);
    }

    /**
     * Write ledger entries and assert the posting balances.
     *
     * @param list<array{account:string,type:string,amount:string}> $entries
     */
    private function writeLedgerEntries(string $paymentId, array $entries, ?string $reference): void
    {
        $debits = '0.00';
        $credits = '0.00';
        $insert = $this->database->prepare(
            'INSERT INTO ledger_entries (ledger_id, payment_id, entry_type, account, amount, description, reference)
             VALUES (:ledger, :payment, :type, :account, :amount, :description, :reference)'
        );

        foreach ($entries as $entry) {
            if (bccomp((string) $entry['amount'], '0', 2) <= 0) {
                throw new RuntimeException('Ledger entries must be positive amounts.');
            }
            $insert->execute([
                'ledger' => $this->ledgerId((string) $entry['account']),
                'payment' => $paymentId,
                'type' => $entry['type'],
                'account' => $entry['account'],
                'amount' => $entry['amount'],
                'description' => "Mamore ledger {$entry['type']} for {$entry['account']}",
                'reference' => $reference,
            ]);
            if ($entry['type'] === 'DEBIT') {
                $debits = bcadd($debits, (string) $entry['amount'], 2);
            } else {
                $credits = bcadd($credits, (string) $entry['amount'], 2);
            }
        }

        if (bccomp($debits, $credits, 2) !== 0) {
            throw new RuntimeException("Unbalanced ledger posting: debits {$debits} vs credits {$credits}.");
        }
    }

    private function ledgerId(string $account): string
    {
        $statement = $this->database->prepare('SELECT id FROM revenue_ledgers WHERE name = :name');
        $statement->execute(['name' => $account]);
        $id = $statement->fetchColumn();
        if (!is_string($id) || $id === '') {
            throw new RuntimeException("Ledger account {$account} is not configured; run php bin/migrate.php");
        }

        return $id;
    }

    /**
     * Record the provincial/national tax share of the paid fee. Only TAX and PDC
     * subset lines are recorded, and a province specific PDC line only for the
     * province of collection. DGI is attributed to the collecting province; no
     * split between provinces is invented.
     */
    private function recordTaxes(string $paymentId, array $subscription, string $province, string $actorId): void
    {
        $insert = $this->database->prepare(<<<'SQL'
            INSERT INTO government_taxes
                (id, payment_id, subscription_id, subscriber_id, component_key, component_type, province, amount, collected_by_user_id)
            VALUES
                (:id, :payment, :subscription, :subscriber, :key, :type, :province, :amount, :actor)
            SQL);

        foreach ($subscription['fees']['subsets'] as $line) {
            if (!in_array($line['category'], ['TAX', 'PDC'], true)) {
                continue;
            }
            if ($line['province'] !== null && $line['province'] !== $province) {
                continue;
            }
            $insert->execute([
                'id' => Uuid::v4(),
                'payment' => $paymentId,
                'subscription' => $subscription['id'],
                'subscriber' => $subscription['subscriberId'],
                'key' => $line['key'],
                'type' => $line['componentType'],
                'province' => $province,
                'amount' => $line['amount'],
                'actor' => $actorId,
            ]);
        }
    }

    /** Notify the portal account linked to the subscriber, when there is one. */
    private function notifySubscriber(string $subscriberId, array $receipt, string $amount): void
    {
        $statement = $this->database->prepare("SELECT id FROM users WHERE subscriber_id = :subscriber AND status = 'ACTIVE'");
        $statement->execute(['subscriber' => $subscriberId]);
        $userId = $statement->fetchColumn();
        if (!is_string($userId) || $userId === '') {
            return;
        }

        $this->database->prepare(
            'INSERT INTO user_notifications (user_id, notification_type, title, message, entity_type, entity_id)
             VALUES (:user, :type, :title, :message, :entityType, :entity)'
        )->execute([
            'user' => $userId,
            'type' => 'PAYMENT_SUCCESS',
            'title' => 'Payment received for ' . ($receipt['subscription']['subscriptionNo'] ?? 'your subscription'),
            'message' => 'Receipt ' . $receipt['receiptNumber'] . ' for USD ' . $amount . ' was issued.',
            'entityType' => 'Receipt',
            'entity' => $receipt['id'],
        ]);
    }

    /** @return array<string,mixed>|null */
    private function byIdempotencyKey(string $key): ?array
    {
        $statement = $this->database->prepare($this->selectSql() . ' WHERE p.idempotency_key = :key');
        $statement->execute(['key' => $key]);
        $row = $statement->fetch();

        return is_array($row) ? $this->hydrate($row) : null;
    }

    private function selectSql(): string
    {
        return <<<'SQL'
            SELECT p.*, s.subscription_no, s.subscriber_id, s.province, s.status AS subscription_status,
                   rp.code AS product_code,
                   COALESCE(NULLIF(TRIM(CONCAT_WS(' ', sub.first_name, sub.last_name)), ''), sub.company_name) AS subscriber_name,
                   sub.membership_number
            FROM payments p
            JOIN subscriptions s ON s.id = p.subscription_id
            JOIN subscribers sub ON sub.id = s.subscriber_id
            LEFT JOIN rescue_products rp ON rp.id = s.product_id
            SQL;
    }

    private function hydrate(array $row): array
    {
        $paymentId = (string) $row['id'];

        return [
            'id' => $paymentId,
            'paymentReference' => $row['payment_reference'],
            'transactionNumber' => $row['transaction_number'],
            'subscriptionId' => $row['subscription_id'],
            'subscriptionNo' => $row['subscription_no'] ?? null,
            'subscriberId' => $row['subscriber_id'] ?? null,
            'subscriberName' => $row['subscriber_name'] ?? null,
            'membershipNumber' => $row['membership_number'] ?? null,
            'productCode' => $row['product_code'] ?? null,
            'amount' => bcadd((string) $row['amount'], '0', 2),
            'amountFormatted' => Money::format((string) $row['amount'], (string) $row['currency']),
            'amountCdf' => $row['amount_cdf'] === null ? null : bcadd((string) $row['amount_cdf'], '0', 2),
            'usdCdfRate' => $row['usd_cdf_rate'] === null ? null : bcadd((string) $row['usd_cdf_rate'], '0', 4),
            'currency' => $row['currency'],
            'method' => $row['payment_method'],
            'provider' => $row['provider'],
            'channel' => $row['channel'],
            'providerReference' => $row['provider_reference'],
            'status' => $row['status'],
            'paidAt' => $row['paid_at'],
            'operatorName' => $row['operator_name'],
            'location' => $row['location'],
            'narration' => $row['narration'],
            'idempotencyKey' => $row['idempotency_key'],
            'voidedAt' => $row['voided_at'],
            'voidReason' => $row['void_reason'],
            'createdAt' => $row['created_at'],
            'allocations' => $this->allocations($paymentId),
            'ledger' => $this->ledgerTrail($paymentId),
            'taxes' => $this->taxes($paymentId),
            'receipt' => $this->receiptFor($paymentId),
        ];
    }

    /** @return list<array<string,mixed>> */
    private function allocations(string $paymentId): array
    {
        $statement = $this->database->prepare('SELECT * FROM payment_allocations WHERE payment_id = :id ORDER BY id ASC');
        $statement->execute(['id' => $paymentId]);

        return array_map(static fn (array $row): array => [
            'key' => $row['component_key'],
            'name' => $row['component_name'],
            'componentType' => $row['component_type'],
            'category' => $row['category'],
            'role' => $row['allocation_role'],
            'province' => $row['province'],
            'amount' => bcadd((string) $row['amount'], '0', 2),
            'ledgerAccount' => $row['ledger_account'],
        ], $statement->fetchAll());
    }

    /** @return list<array<string,mixed>> */
    private function ledgerTrail(string $paymentId): array
    {
        $statement = $this->database->prepare(
            'SELECT entry_type, account, amount, reference, created_at FROM ledger_entries WHERE payment_id = :id ORDER BY id ASC'
        );
        $statement->execute(['id' => $paymentId]);

        return array_map(static fn (array $row): array => [
            'type' => $row['entry_type'],
            'account' => $row['account'],
            'amount' => bcadd((string) $row['amount'], '0', 2),
            'reference' => $row['reference'],
            'createdAt' => $row['created_at'],
        ], $statement->fetchAll());
    }

    /** @return list<array<string,mixed>> */
    private function taxes(string $paymentId): array
    {
        $statement = $this->database->prepare(
            'SELECT component_key, component_type, province, amount, status FROM government_taxes
             WHERE payment_id = :id ORDER BY component_key ASC'
        );
        $statement->execute(['id' => $paymentId]);

        return array_map(static fn (array $row): array => [
            'key' => $row['component_key'],
            'componentType' => $row['component_type'],
            'province' => $row['province'],
            'amount' => bcadd((string) $row['amount'], '0', 2),
            'status' => $row['status'],
        ], $statement->fetchAll());
    }

    /** @return array<string,mixed>|null */
    private function receiptFor(string $paymentId): ?array
    {
        $statement = $this->database->prepare('SELECT id FROM receipts WHERE payment_id = :payment');
        $statement->execute(['payment' => $paymentId]);
        $receiptId = $statement->fetchColumn();
        if (!is_string($receiptId) || $receiptId === '') {
            return null;
        }

        return (new ReceiptService($this->database))->show($receiptId);
    }

    private function paidAt(mixed $value): string
    {
        if (!is_string($value) || trim($value) === '') {
            return gmdate('Y-m-d H:i:s');
        }
        $parsed = \DateTimeImmutable::createFromFormat('!Y-m-d H:i:s', trim($value), new \DateTimeZone('UTC'));
        if (!$parsed instanceof \DateTimeImmutable) {
            throw new AuthException('Enter the payment time as YYYY-MM-DD HH:MM:SS.', 422);
        }

        return $parsed->format('Y-m-d H:i:s');
    }

    private function audit(
        string $action,
        string $entityId,
        ?array $actor,
        array $previous,
        array $new,
        ?Request $request = null,
        ?array $metadata = null,
    ): void {
        (new AuditLog($this->database))->write(
            $action,
            'Payment',
            $entityId,
            $actor,
            $request,
            $previous,
            $new,
            $metadata
        );
    }

    private function required(array $input, string $key, string $label): string
    {
        $value = is_string($input[$key] ?? null) ? trim($input[$key]) : '';
        if ($value === '') {
            throw new AuthException("{$label} is required.", 422);
        }

        return $value;
    }

    private function nullableString(mixed $value): ?string
    {
        if (!is_string($value)) {
            return null;
        }
        $trimmed = trim($value);

        return $trimmed === '' ? null : $trimmed;
    }
}
