<?php

declare(strict_types=1);

namespace Mamore\Finance;

use Mamore\Core\Cache;
use Mamore\Core\Uuid;
use PDO;

/**
 * Exchange rates for USD, CDF and TZS.
 *
 * The brief refers to "the existing Mamore ExchangeRateService". There is none:
 * `grep -r ExchangeRate` across the repository returns zero matches before this
 * file existed. The storage model underneath was already correct -- every
 * payment, receipt and subscription stores an amount WITH its currency, and
 * CDF-collected money carries the rate that was applied -- so this service is
 * purely a READ side for presentation.
 *
 * It can never write a financial figure: convert() takes an amount and returns
 * a number, and nothing here touches payments, receipts or the ledger.
 * tests/currency-integration.php hashes the finance tables before and after a
 * full conversion round-trip to prove it.
 *
 * DEGRADATION IS THE POINT
 *
 * A rate service that throws when the provider is unreachable makes the product
 * unusable on the intranet it is deployed to. The status ladder is deliberately
 * explicit about how far to trust the number in front of you:
 *
 *   LIVE        entered inside the freshness window
 *   CACHED      past the window but within a day; amber badge
 *   STALE       older still; the age and timestamp are always shown
 *   UNAVAILABLE no rate at all -- and then Money::convert returns the ORIGINAL
 *               amount in its ORIGINAL currency, because a wrong number is far
 *               worse than an unconverted one.
 *
 * A rate is never invented. There is no default rate constant in this class.
 */
final class ExchangeRateService
{
    public const USD = 'USD';
    public const CDF = 'CDF';
    public const TZS = 'TZS';

    /** Currencies a Mamore figure can be presented in. */
    public const SUPPORTED = [self::USD, self::CDF, self::TZS];

    /** How long a rate stays fresh enough to present without a warning. */
    private const FRESH_SECONDS = 900;        // 15 minutes
    private const CACHED_SECONDS = 3600;      // 1 hour before STALE
    private const EXPIRED_SECONDS = 86400;    // 24 hours before UNAVAILABLE

    public function __construct(private readonly PDO $database) {}

    /**
     * The rate for a pair, with its provenance and freshness.
     *
     * A rate is looked up DIRECT only. A cross rate is derived through USD
     * rather than interpolated, so USD->TZS and CDF->TZS always agree with each
     * other instead of drifting apart as separately stored pairs.
     *
     * @return array{base:string,quote:string,rate:?string,source:?string,retrievedAt:?string,status:string}
     */
    public function getRate(string $base, string $to): array
    {
        $base = strtoupper(trim($base));
        $to = strtoupper(trim($to));

        if ($base === $to) {
            return $this->result($base, $to, '1.000000000000', 'IDENTITY', null, 'live');
        }

        if (!in_array($base, self::SUPPORTED, true) || !in_array($to, self::SUPPORTED, true)) {
            return $this->result($base, $to, null, null, null, 'unavailable');
        }

        return Cache::remember('fx:' . $base . ':' . $to, 60, function () use ($base, $to): array {
            // 1. The pair, stored exactly as asked for.
            $direct = $this->latest($base, $to);
            if ($direct !== null) {
                return $this->classify($direct, $base, $to);
            }

            // 2. The reverse pair, inverted. A site that only records
            //    "1 USD = 2,900 CDF" can still answer "1 CDF = ? USD", which is
            //    the reciprocal -- NOT the same as looking for a direct pair.
            $inverse = $this->latest($to, $base);
            if ($inverse !== null) {
                return $this->classify([
                    'rate' => bcdiv('1', $inverse['rate'], 12),
                    'source' => 'INVERTED',
                    'retrievedAt' => $inverse['retrievedAt'],
                ], $base, $to);
            }

            // 3. Through USD, for pairs neither direction has. Rates are always
            //    seeded against USD, so this is the common path and it is why
            //    USD->TZS and CDF->TZS cannot drift apart.
            $crossed = $this->crossRate($base, $to);
            if ($crossed !== null) {
                return $this->classify($crossed, $base, $to);
            }

            // 4. Nothing. The caller shows the original currency rather than a
            //    number nobody can vouch for.
            return $this->result($base, $to, null, null, null, 'unavailable');
        });
    }

    /**
     * Every rate the navbar needs, in one response, plus the worst status
     * across them so one value can drive the indicator.
     *
     * @return array<string,mixed>
     */
    public function board(): array
    {
        $pairs = [
            ['USD', 'CDF'], ['USD', 'TZS'],
            ['CDF', 'USD'], ['CDF', 'TZS'],
            ['TZS', 'USD'], ['TZS', 'CDF'],
        ];

        $rates = [];
        $worst = 'live';

        foreach ($pairs as [$base, $quote]) {
            $rate = $this->getRate($base, $quote);
            $rates[] = [
                'pair' => $base . '/' . $quote,
                'base' => $base,
                'quote' => $quote,
                'rate' => $rate['rate'] === null ? null : (float) $rate['rate'],
                'source' => $rate['source'],
                'retrievedAt' => $rate['retrievedAt'],
                'status' => $rate['status'],
            ];

            if ($this->severity($rate['status']) > $this->severity($worst)) {
                $worst = $rate['status'];
            }
        }

        return ['rates' => $rates, 'status' => $worst, 'supported' => self::SUPPORTED];
    }

    /**
     * Record a rate an operator entered by hand.
     *
     * Manual rates are the reason an isolated site can operate at all, and they
     * are stored as MANUAL so they are never mistaken for a market quote.
     */
    public function record(string $base, string $quote, string $rate, string $source = 'MANUAL'): void
    {
        $base = strtoupper(trim($base));
        $quote = strtoupper(trim($quote));

        if (!in_array($base, self::SUPPORTED, true) || !in_array($quote, self::SUPPORTED, true)) {
            throw new \InvalidArgumentException('Unsupported currency pair.');
        }

        if (!is_numeric($rate) || (float) $rate <= 0) {
            throw new \InvalidArgumentException('A rate must be a positive number.');
        }

        $this->database->prepare(<<<'SQL'
            INSERT INTO exchange_rates (id, base_currency, quote_currency, rate, source, retrieved_at, valid_at)
            VALUES (:id, :base, :quote, :rate, :source, NOW(6), NOW(6))
            SQL)->execute([
            'id' => Uuid::v4(),
            'base' => $base,
            'quote' => $quote,
            'rate' => number_format((float) $rate, 12, '.', ''),
            'source' => strtoupper(substr(trim($source), 0, 40)) ?: 'MANUAL',
        ]);
    }

    /**
     * The most recent stored rate for a pair, or null.
     *
     * @return array{rate:string,source:string,retrievedAt:string}|null
     */
    private function latest(string $base, string $quote): ?array
    {
        $row = $this->database->prepare(<<<'SQL'
            SELECT rate, source, retrieved_at
            FROM exchange_rates
            WHERE base_currency = :base AND quote_currency = :quote
            ORDER BY retrieved_at DESC
            LIMIT 1
            SQL);
        $row->execute(['base' => $base, 'quote' => $quote]);
        $found = $row->fetch(PDO::FETCH_ASSOC);

        return $found === false ? null : [
            'rate' => number_format((float) $found['rate'], 12, '.', ''),
            'source' => (string) $found['source'],
            'retrievedAt' => (string) $found['retrieved_at'],
        ];
    }

    /**
     * A rate derived through USD: base -> USD -> quote.
     *
     * Two things this gets right that the obvious version does not:
     *
     *  1. A leg may be stored in EITHER direction. A site that only ever records
     *     "1 USD = 2,900 CDF" still has to be able to answer "how many CDF is one
     *     TZS worth?" The leg is inverted when that is the direction available.
     *  2. A rate is never invented. If either leg is missing in both directions
     *     this returns null, and the caller falls back to the original currency.
     *
     * The source is marked DERIVED so the interface can say a cross rate was
     * computed rather than quoted, and retrieved_at is the OLDER of the two legs,
     * so a derived rate never claims to be fresher than the data behind it.
     *
     * @return array{rate:string,source:string,retrievedAt:string}|null
     */
    private function crossRate(string $base, string $quote): ?array
    {
        if ($base === self::USD || $quote === self::USD) {
            return null;
        }

        $in = $this->leg($base, self::USD);
        $out = $this->leg(self::USD, $quote);
        if ($in === null || $out === null) {
            return null;
        }

        // in: how many USD one `base` is worth. out: how many `quote` one USD is
        // worth. Their product is the answer.
        return [
            'rate' => bcmul($out['rate'], $in['rate'], 12),
            'source' => 'DERIVED',
            'retrievedAt' => min($in['retrievedAt'], $out['retrievedAt']),
        ];
    }

    /**
     * A leg between two currencies, in the direction asked for.
     *
     * Returns the stored pair when it exists, and its reciprocal when only the
     * opposite direction is stored. An inverted leg is reported as such so the
     * caller can tell "quoted directly" from "computed from the other side".
     *
     * @return array{rate:string,source:string,retrievedAt:string}|null
     */
    private function leg(string $from, string $to): ?array
    {
        $direct = $this->latest($from, $to);
        if ($direct !== null) {
            return $direct;
        }

        $inverse = $this->latest($to, $from);
        if ($inverse === null) {
            return null;
        }

        return [
            'rate' => bcdiv('1', $inverse['rate'], 12),
            'source' => 'INVERTED',
            'retrievedAt' => $inverse['retrievedAt'],
        ];
    }

    /**
     * Age a stored rate into a status the interface can trust.
     *
     * Age is measured against the SERVER clock, not the browser's, for the same
     * reason Core\ServerClock exists: a machine with a wrong clock must not be
     * able to make a stale rate look fresh.
     *
     * @param array{rate:string,source:string,retrievedAt:string} $row
     *
     * @return array{base:string,quote:string,rate:?string,source:?string,retrievedAt:?string,status:string}
     */
    private function classify(array $row, string $base = '', string $quote = ''): array
    {
        $age = $this->ageSeconds($row['retrievedAt']);

        $status = match (true) {
            $age <= self::FRESH_SECONDS => 'live',
            $age <= self::CACHED_SECONDS => 'cached',
            $age <= self::EXPIRED_SECONDS => 'stale',
            default => 'unavailable',
        };

        // Past the hard limit the number is not offered at all. Returning null
        // is what makes Money::convert fall back to the ORIGINAL currency rather
        // than present a day-old conversion as if it were current.
        return $this->result(
            $base,
            $quote,
            $status === 'unavailable' ? null : $row['rate'],
            $row['source'],
            $row['retrievedAt'],
            $status
        );
    }

    /**
     * @return array{base:string,quote:string,rate:?string,source:?string,retrievedAt:?string,status:string}
     */
    private function result(string $base, string $quote, ?string $rate, ?string $source, ?string $retrievedAt, string $status): array
    {
        return [
            'base' => $base,
            'quote' => $quote,
            'rate' => $rate,
            'source' => $source,
            'retrievedAt' => $retrievedAt,
            'status' => $status,
        ];
    }

    private function ageSeconds(string $retrievedAt): int
    {
        $time = strtotime(str_replace(' ', 'T', $retrievedAt));

        return $time === false ? PHP_INT_MAX : max(0, time() - $time);
    }

    /**
     * Ordering for "which status is worst".
     *
     * @return int
     */
    private function severity(string $status): int
    {
        return match ($status) {
            'live' => 0,
            'cached' => 1,
            'stale' => 2,
            default => 3,
        };
    }
}
