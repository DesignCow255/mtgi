<?php

declare(strict_types=1);

namespace Mamore\Finance;

use Mamore\Auth\AuthException;
use Mamore\Core\Uuid;
use PDO;
use PDOException;

final class FinanceService
{
    public function __construct(private readonly PDO $database) {}

    public function board(): array
    {
        $metrics = $this->database->query(<<<'SQL'
            SELECT COUNT(*) AS payments,
                   COALESCE(SUM(CASE WHEN status = 'RECONCILED' THEN amount_cdf ELSE 0 END), 0) AS collected_cdf,
                   COALESCE(SUM(CASE WHEN status = 'VARIANCE' THEN ABS(variance_cdf) ELSE 0 END), 0) AS variance_cdf
            FROM finance_transactions WHERE received_at >= UTC_DATE()
            SQL)->fetch();
        $rescue = $this->database->query("SELECT COALESCE(SUM(amount_cdf), 0) FROM finance_allocations WHERE account_code = 'RESCUE_FUND' AND created_at >= UTC_DATE()")->fetchColumn();
        $unpaid = $this->database->query(<<<'SQL'
            SELECT b.id, b.booking_reference, b.passenger_name, b.passenger_phone, b.total_cdf, b.rescue_fee_cdf,
                   t.trip_code, r.origin, r.destination, o.name AS operator_name
            FROM smartbus_bookings b JOIN smartbus_trips t ON t.id = b.trip_id JOIN smartbus_routes r ON r.id = t.route_id
            JOIN smartbus_vehicles v ON v.id = t.vehicle_id JOIN smartbus_operators o ON o.id = v.operator_id
            LEFT JOIN finance_transactions f ON f.smartbus_booking_id = b.id
            WHERE b.status = 'CONFIRMED' AND f.id IS NULL ORDER BY b.created_at DESC LIMIT 100
            SQL)->fetchAll();
        $transactions = $this->database->query(<<<'SQL'
            SELECT f.*, b.booking_reference, b.passenger_name
            FROM finance_transactions f LEFT JOIN smartbus_bookings b ON b.id = f.smartbus_booking_id
            ORDER BY f.received_at DESC LIMIT 50
            SQL)->fetchAll();
        return ['metrics' => ['paymentsToday' => (int) $metrics['payments'], 'collectedCdf' => (float) $metrics['collected_cdf'], 'varianceCdf' => (float) $metrics['variance_cdf'], 'rescueFundCdf' => (float) $rescue], 'unpaidBookings' => array_map([$this, 'unpaid'], $unpaid), 'transactions' => array_map([$this, 'transaction'], $transactions)];
    }

    public function receive(array $input, array $actor): array
    {
        $bookingId = $this->required($input, 'bookingId', 'Booking');
        $method = $this->choice($input['paymentMethod'] ?? '', ['CASH','MOBILE_MONEY','CARD','BANK_TRANSFER'], 'payment method');
        $currency = $this->choice($input['currency'] ?? '', ['CDF','USD'], 'currency');
        $amount = $this->positive($input['amount'] ?? null, 'amount');
        $rate = $this->positive($input['usdCdfRate'] ?? null, 'USD/CDF exchange rate');
        $external = is_string($input['externalReference'] ?? null) ? trim($input['externalReference']) : '';
        $this->database->beginTransaction();
        try {
            $statement = $this->database->prepare(<<<'SQL'
                SELECT b.*, t.trip_code, v.operator_id FROM smartbus_bookings b JOIN smartbus_trips t ON t.id = b.trip_id
                JOIN smartbus_vehicles v ON v.id = t.vehicle_id WHERE b.id = :id FOR UPDATE
                SQL);
            $statement->execute(['id' => $bookingId]); $booking = $statement->fetch();
            if (!is_array($booking)) throw new AuthException('Booking not found.', 404);
            $amountCdf = $currency === 'USD' ? round($amount * $rate, 2) : $amount;
            $expected = (float) $booking['total_cdf']; $variance = round($amountCdf - $expected, 2);
            $status = abs($variance) <= 0.01 ? 'RECONCILED' : 'VARIANCE';
            $id = Uuid::v4(); $receipt = 'RCP-' . gmdate('ymd') . '-' . strtoupper(bin2hex(random_bytes(3)));
            $insert = $this->database->prepare(<<<'SQL'
                INSERT INTO finance_transactions
                    (id, receipt_number, smartbus_booking_id, payment_method, currency, amount, usd_cdf_rate, amount_cdf, expected_cdf, variance_cdf, status, external_reference, received_by_user_id)
                VALUES (:id,:receipt,:booking,:method,:currency,:amount,:rate,:amount_cdf,:expected,:variance,:status,:external,:actor)
                SQL);
            $insert->execute(['id'=>$id,'receipt'=>$receipt,'booking'=>$bookingId,'method'=>$method,'currency'=>$currency,'amount'=>$amount,'rate'=>$rate,'amount_cdf'=>$amountCdf,'expected'=>$expected,'variance'=>$variance,'status'=>$status,'external'=>$external === '' ? null : $external,'actor'=>$actor['id']]);
            if ($status === 'RECONCILED') {
                $allocation = $this->database->prepare('INSERT INTO finance_allocations (transaction_id, account_code, beneficiary_type, beneficiary_id, amount_cdf) VALUES (:transaction,:account,:type,:beneficiary,:amount)');
                $allocation->execute(['transaction'=>$id,'account'=>'OPERATOR_PAYABLE','type'=>'SMARTBUS_OPERATOR','beneficiary'=>$booking['operator_id'],'amount'=>$booking['fare_cdf']]);
                $allocation->execute(['transaction'=>$id,'account'=>'RESCUE_FUND','type'=>'MAMORE_RESCUE','beneficiary'=>null,'amount'=>$booking['rescue_fee_cdf']]);
            }
            $this->database->commit();
        } catch (PDOException $error) { $this->database->rollBack(); if ((string) $error->getCode() === '23000') throw new AuthException('Payment has already been recorded for this booking.', 409); throw $error; }
        catch (\Throwable $error) { $this->database->rollBack(); throw $error; }
        return ['id'=>$id,'receiptNumber'=>$receipt,'bookingReference'=>$booking['booking_reference'],'passengerName'=>$booking['passenger_name'],'currency'=>$currency,'amount'=>$amount,'amountCdf'=>$amountCdf,'expectedCdf'=>$expected,'varianceCdf'=>$variance,'status'=>$status,'operatorAllocationCdf'=>$status === 'RECONCILED' ? (float) $booking['fare_cdf'] : 0,'rescueAllocationCdf'=>$status === 'RECONCILED' ? (float) $booking['rescue_fee_cdf'] : 0];
    }

    private function unpaid(array $row): array { return ['id'=>$row['id'],'reference'=>$row['booking_reference'],'passengerName'=>$row['passenger_name'],'passengerPhone'=>$row['passenger_phone'],'totalCdf'=>(float)$row['total_cdf'],'rescueFeeCdf'=>(float)$row['rescue_fee_cdf'],'tripCode'=>$row['trip_code'],'origin'=>$row['origin'],'destination'=>$row['destination'],'operatorName'=>$row['operator_name']]; }
    private function transaction(array $row): array { return ['id'=>$row['id'],'receiptNumber'=>$row['receipt_number'],'bookingReference'=>$row['booking_reference'],'passengerName'=>$row['passenger_name'],'method'=>$row['payment_method'],'currency'=>$row['currency'],'amount'=>(float)$row['amount'],'amountCdf'=>(float)$row['amount_cdf'],'varianceCdf'=>(float)$row['variance_cdf'],'status'=>$row['status'],'receivedAt'=>$row['received_at']]; }
    private function required(array $input,string $key,string $label): string { $value=is_string($input[$key]??null)?trim($input[$key]):''; if($value==='') throw new AuthException("{$label} is required.",422); return $value; }
    private function choice(mixed $value,array $allowed,string $label): string { $value=is_string($value)?strtoupper(trim($value)):''; if(!in_array($value,$allowed,true)) throw new AuthException("Select a valid {$label}.",422); return $value; }
    private function positive(mixed $value,string $label): float { if(!is_numeric($value)||(float)$value<=0) throw new AuthException("Enter a valid {$label}.",422); return (float)$value; }
}
