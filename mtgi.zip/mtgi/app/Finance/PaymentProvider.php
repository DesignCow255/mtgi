<?php

declare(strict_types=1);

namespace Mamore\Finance;

use Mamore\Auth\AuthException;

/**
 * Payment provider abstraction (canonical PaymentProviderFactory).
 *
 * A provider only attaches the *channel* a payment was collected through. The
 * authoritative amounts and allocations always come from FeeEngine::catalog();
 * a provider never recomputes or overrides the fee breakdown.
 */
final class PaymentProvider
{
    /** @var array<string, array{provider:string,channel:string,prefix:string,asyncSettlement:bool}> */
    private const PROVIDERS = [
        'CASH' => ['provider' => 'Cash', 'channel' => 'CASH', 'prefix' => 'CS', 'asyncSettlement' => false],
        'MOBILE_MONEY' => ['provider' => 'Mobile Money', 'channel' => 'MOBILE_MONEY', 'prefix' => 'MM', 'asyncSettlement' => true],
        'BANK' => ['provider' => 'Bank', 'channel' => 'BANK', 'prefix' => 'BK', 'asyncSettlement' => true],
        'BANK_TRANSFER' => ['provider' => 'Bank Transfer', 'channel' => 'BANK_TRANSFER', 'prefix' => 'BT', 'asyncSettlement' => true],
        'CARD' => ['provider' => 'Card', 'channel' => 'CARD', 'prefix' => 'CD', 'asyncSettlement' => false],
    ];

    /** @return list<string> */
    public static function methods(): array
    {
        return array_keys(self::PROVIDERS);
    }

    /** Ledger asset account that receives the money for a payment method. */
    public static function settlementAccount(string $method): string
    {
        return match (self::normalize($method)) {
            'CASH' => 'CASH',
            'MOBILE_MONEY' => 'MOBILE_MONEY',
            'CARD' => 'CARD',
            default => 'BANK',
        };
    }

    /**
     * Resolve the provider/channel metadata for a payment reference.
     *
     * @return array{provider:string,channel:string,providerReference:string,asyncSettlement:bool}
     */
    public static function initiate(string $method, string $paymentReference): array
    {
        $normalized = self::normalize($method);
        $provider = self::PROVIDERS[$normalized] ?? null;
        if ($provider === null) {
            throw new AuthException('Select a valid payment method.', 422);
        }

        return [
            'provider' => $provider['provider'],
            'channel' => $provider['channel'],
            'providerReference' => $provider['prefix'] . '-' . $paymentReference,
            'asyncSettlement' => $provider['asyncSettlement'],
        ];
    }

    public static function normalize(string $method): string
    {
        $normalized = strtoupper(trim($method));

        return $normalized === 'MOBILEMONEY' ? 'MOBILE_MONEY' : $normalized;
    }
}
