<?php

declare(strict_types=1);

namespace Mamore\Rescue;

use Mamore\Auth\AuthException;
use Mamore\Core\AuditLog;
use Mamore\Core\Request;
use Mamore\Core\ServerClock;
use Mamore\Core\Uuid;
use PDO;

/**
 * The single answer to "is this covered?".
 *
 * Controllers, dashboards, the tracking map and the incident pipeline all ask
 * this service. No domain re-implements the rule, so "covered" means the same
 * thing on every screen. The result is normalised and always explicit: when
 * nothing is known it says UNCOVERED with a reason, never a hopeful default.
 */
final class RescueCoverageService
{
    public const SUBJECTS = ['PERSON', 'VEHICLE', 'TRIP', 'JOURNEY', 'CONSIGNMENT', 'FLEET'];

    public function __construct(private readonly PDO $database) {}

    /**
     * Evaluate coverage for a subject.
     *
     * @return array{covered:bool,status:string,source:string,plan:?array<string,mixed>,subscriber:?string,
     *               vehicle:?string,rescueCode:?string,startsAt:?string,expiresAt:?string,restrictions:array<string,mixed>,
     *               reason:string}
     */
    public function check(string $subjectType, string $subjectId, ?string $vehicleId = null): array
    {
        if (!in_array($subjectType, self::SUBJECTS, true)) {
            throw new AuthException('Unknown coverage subject type.', 422);
        }

        $link = $this->bestLink($subjectType, $subjectId, $vehicleId);
        if ($link === null) {
            return $this->uncovered($subjectType, $subjectId, 'NO_COVERAGE_RECORD');
        }

        $now = ServerClock::epoch($this->database);
        $startsAt = ServerClock::parse((string) $link['starts_at']);
        $endsAt = $link['ends_at'] === null ? null : ServerClock::parse((string) $link['ends_at']);

        $reason = match (true) {
            (string) $link['status'] === 'REVOKED' => 'REVOKED',
            (string) $link['status'] === 'SUSPENDED' => 'SUSPENDED',
            (string) $link['status'] === 'PENDING' => 'NOT_YET_ACTIVE',
            $startsAt > $now => 'NOT_YET_ACTIVE',
            $endsAt !== null && $endsAt < $now => 'EXPIRED',
            default => 'ACTIVE',
        };

        $restrictions = $this->restrictions($link);
        $covered = $reason === 'ACTIVE';

        return [
            'covered' => $covered,
            'status' => $covered ? 'ACTIVE' : $reason,
            'source' => 'RESCUE_COVERAGE_LINK',
            'plan' => $this->plan($link['service_plan_id']),
            'subscriber' => $this->subscriberName($link['subscriber_id']),
            'vehicle' => $this->vehicleLabel($link['vehicle_id'] ?? $vehicleId),
            'rescueCode' => $this->rescueCode($link['rescue_code_id'] ?? $this->rescueCodeIdFor($link['subscriber_id'])),
            'startsAt' => (string) $link['starts_at'],
            'expiresAt' => $link['ends_at'],
            'restrictions' => $restrictions,
            'reason' => $covered ? 'Covered by an active plan.' : $this->reasonText($reason),
        ];
    }

    /**
     * Coverage for a vehicle, used by the tracking map and the incident pipeline.
     *
     * @return array<string,mixed>
     */
    public function forVehicle(string $vehicleId): array
    {
        return $this->check('VEHICLE', $vehicleId, $vehicleId);
    }

    /**
     * Grant coverage. Called by the domains when a subscription is activated or a
     * vehicle is enrolled; it never decides policy, it only records it.
     *
     * @return array<string,mixed>
     */
    public function grant(array $input, array $actor): array
    {
        $subjectType = $this->required($input, 'subjectType', 'Subject type');
        if (!in_array($subjectType, self::SUBJECTS, true)) {
            throw new AuthException('Unknown coverage subject type.', 422);
        }
        $subjectId = $this->required($input, 'subjectId', 'Subject');
        $coverageType = $this->required($input, 'coverageType', 'Coverage type');
        $planId = $this->optional($input, 'servicePlanId');
        $vehicleId = $this->optional($input, 'vehicleId');
        $subscriberId = $this->optional($input, 'subscriberId');
        $organizationId = $this->optional($input, 'organizationId');
        $subscriptionId = $this->optional($input, 'subscriptionId');
        $endsAt = $this->optional($input, 'endsAt');

        $this->assertSubjectExists($subjectType, $subjectId);
        $id = Uuid::v4();
        $this->database->prepare(<<<'SQL'
            INSERT INTO rescue_coverage_links
                (id, subject_type, subject_id, vehicle_id, subscriber_id, organization_id, subscription_id,
                 service_plan_id, coverage_type, status, starts_at, ends_at, rescue_code_id, restrictions)
            VALUES
                (:id, :subjectType, :subjectId, :vehicle, :subscriber, :organization, :subscription,
                 :plan, :coverage, 'ACTIVE', UTC_TIMESTAMP(6), :ends, NULL, :restrictions)
            SQL)->execute([
            'id' => $id, 'subjectType' => $subjectType, 'subjectId' => $subjectId,
            'vehicle' => $vehicleId, 'subscriber' => $subscriberId, 'organization' => $organizationId,
            'subscription' => $subscriptionId, 'plan' => $planId, 'coverage' => $coverageType,
            'ends' => $endsAt,
            'restrictions' => isset($input['restrictions']) && is_array($input['restrictions'])
                ? json_encode($input['restrictions'], JSON_THROW_ON_ERROR) : null,
        ]);

        (new AuditLog($this->database))->write(
            'RESCUE_COVERAGE_GRANTED',
            'RescueCoverage',
            $id,
            $actor,
            null,
            null,
            ['subjectType' => $subjectType, 'subjectId' => $subjectId, 'coverageType' => $coverageType],
            ['source' => 'rescue-coverage']
        );

        return $this->check($subjectType, $subjectId, $vehicleId);
    }

    /**
     * Suspend or revoke coverage, with a reason. Revoking a truck fleet's cover
     * must be as easy and as visible as granting it.
     *
     * @return array<string,mixed>
     */
    public function revoke(array $input, array $actor, Request $request): array
    {
        $id = $this->required($input, 'coverageId', 'Coverage record');
        $status = strtoupper((string) ($input['status'] ?? 'REVOKED'));
        if (!in_array($status, ['SUSPENDED', 'REVOKED'], true)) {
            throw new AuthException('Coverage can only be suspended or revoked.', 422);
        }
        $reason = $this->required($input, 'reason', 'Reason');

        $statement = $this->database->prepare('SELECT * FROM rescue_coverage_links WHERE id = :id');
        $statement->execute(['id' => $id]);
        $link = $statement->fetch();
        if (!is_array($link)) {
            throw new AuthException('Coverage record not found.', 404);
        }

        $this->database->prepare(
            'UPDATE rescue_coverage_links SET status = :status, updated_at = UTC_TIMESTAMP(6) WHERE id = :id'
        )->execute(['status' => $status, 'id' => $id]);

        (new AuditLog($this->database))->write(
            'RESCUE_COVERAGE_CHANGED',
            'RescueCoverage',
            $id,
            $actor,
            $request,
            ['status' => $link['status']],
            ['status' => $status],
            ['source' => 'rescue-coverage', 'reason' => $reason]
        );

        return $this->check((string) $link['subject_type'], (string) $link['subject_id'], $link['vehicle_id'] ?? null);
    }

    /**
     * The most specific active link wins: a direct link on the subject beats a
     * link inherited from its vehicle.
     *
     * @return array<string,mixed>|null
     */
    private function bestLink(string $subjectType, string $subjectId, ?string $vehicleId): ?array
    {
        $statement = $this->database->prepare(<<<'SQL'
            SELECT *, (subject_type = :orderType AND subject_id = :orderId) AS is_direct
            FROM rescue_coverage_links
            WHERE (subject_type = :subjectType AND subject_id = :subjectId)
               OR (:hasVehicle = 1 AND vehicle_id = :vehicleMatch)
            -- A link whose window has not ended outranks one that has expired, so
            -- a stale row can never outrank a live suspension on the same subject.
            ORDER BY is_direct DESC, (ends_at IS NULL OR ends_at >= UTC_TIMESTAMP(6)) DESC, starts_at DESC
            LIMIT 1
            SQL);
        // Each placeholder appears once: native prepared statements reject repeats.
        $statement->execute([
            'subjectType' => $subjectType, 'subjectId' => $subjectId,
            'orderType' => $subjectType, 'orderId' => $subjectId,
            'hasVehicle' => $vehicleId === null ? 0 : 1,
            'vehicleMatch' => $vehicleId,
        ]);
        $link = $statement->fetch();

        return is_array($link) ? $link : null;
    }

    private function assertSubjectExists(string $subjectType, string $subjectId): void
    {
        $table = match ($subjectType) {
            'PERSON' => 'persons',
            'VEHICLE' => 'vehicles',
            'FLEET' => 'organizations',
            'JOURNEY', 'TRIP' => 'journeys',
            'CONSIGNMENT' => 'consignments',
            default => null,
        };
        // Domains that do not exist yet simply defer the check: the link is still
        // recorded, and the foreign keys that matter are enforced by the domain.
        if ($table === null || !$this->tableExists($table)) {
            return;
        }
        $statement = $this->database->prepare("SELECT COUNT(*) FROM `{$table}` WHERE id = :id");
        $statement->execute(['id' => $subjectId]);
        if ((int) $statement->fetchColumn() === 0) {
            throw new AuthException('The subject being covered does not exist.', 404);
        }
    }

    private function tableExists(string $table): bool
    {
        return $this->database->query("SHOW TABLES LIKE " . $this->database->quote($table))->fetchColumn() !== false;
    }

    /** @return array<string,mixed>|null */
    private function plan(mixed $planId): ?array
    {
        if (!is_string($planId) || $planId === '') {
            return null;
        }
        $statement = $this->database->prepare(
            'SELECT plan_code, name, coverage_type, billing_period, currency, response_target_minutes FROM service_plans WHERE id = :id'
        );
        $statement->execute(['id' => $planId]);
        $plan = $statement->fetch();
        if (!is_array($plan)) {
            return null;
        }

        return [
            'code' => $plan['plan_code'],
            'name' => $plan['name'],
            'coverageType' => $plan['coverage_type'],
            'billingPeriod' => $plan['billing_period'],
            'currency' => $plan['currency'],
            'responseTargetMinutes' => $plan['response_target_minutes'] === null ? null : (int) $plan['response_target_minutes'],
        ];
    }

    private function subscriberName(mixed $subscriberId): ?string
    {
        if (!is_string($subscriberId) || $subscriberId === '') {
            return null;
        }
        $statement = $this->database->prepare('SELECT membership_number, first_name, last_name FROM subscribers WHERE id = :id');
        $statement->execute(['id' => $subscriberId]);
        $row = $statement->fetch();
        if (!is_array($row)) {
            return null;
        }

        return trim(((string) $row['first_name']) . ' ' . ((string) $row['last_name'])) . ' (' . $row['membership_number'] . ')';
    }

    private function vehicleLabel(mixed $vehicleId): ?string
    {
        if (!is_string($vehicleId) || $vehicleId === '') {
            return null;
        }
        $statement = $this->database->prepare('SELECT registration_number, make, model FROM vehicles WHERE id = :id');
        $statement->execute(['id' => $vehicleId]);
        $row = $statement->fetch();
        if (!is_array($row)) {
            return null;
        }

        return trim(((string) $row['make']) . ' ' . ((string) $row['model']) . ' · ' . $row['registration_number']);
    }

    private function rescueCodeIdFor(mixed $subscriberId): ?string
    {
        if (!is_string($subscriberId) || $subscriberId === '') {
            return null;
        }
        $statement = $this->database->prepare(
            "SELECT id FROM rescue_codes WHERE subscriber_id = :subscriber AND status = 'ACTIVE' LIMIT 1"
        );
        $statement->execute(['subscriber' => $subscriberId]);

        $id = $statement->fetchColumn();

        return is_string($id) ? $id : null;
    }

    private function rescueCode(mixed $codeId): ?string
    {
        if (!is_string($codeId) || $codeId === '') {
            return null;
        }
        $statement = $this->database->prepare("SELECT code FROM rescue_codes WHERE id = :id AND status = 'ACTIVE'");
        $statement->execute(['id' => $codeId]);
        $code = $statement->fetchColumn();

        return is_string($code) ? $code : null;
    }

    /** @return array<string,mixed> */
    private function restrictions(array $link): array
    {
        if (!is_string($link['restrictions'] ?? null) || $link['restrictions'] === '') {
            return [];
        }
        $decoded = json_decode((string) $link['restrictions'], true);

        return is_array($decoded) ? $decoded : [];
    }

    /**
     * @return array{covered:bool,status:string,source:string,plan:?array<string,mixed>,subscriber:?string,
     *               vehicle:?string,rescueCode:?string,startsAt:?string,expiresAt:?string,restrictions:array<string,mixed>,
     *               reason:string}
     */
    private function uncovered(string $subjectType, string $subjectId, string $reason): array
    {
        return [
            'covered' => false,
            'status' => 'UNCOVERED',
            'source' => 'NONE',
            'plan' => null,
            'subscriber' => null,
            'vehicle' => $this->vehicleLabel($subjectType === 'VEHICLE' ? $subjectId : null),
            'rescueCode' => null,
            'startsAt' => null,
            'expiresAt' => null,
            'restrictions' => [],
            'reason' => $this->reasonText($reason),
        ];
    }

    private function reasonText(string $code): string
    {
        return match ($code) {
            'NO_COVERAGE_RECORD' => 'No active rescue coverage is recorded for this subject.',
            'NOT_YET_ACTIVE' => 'Coverage has not started yet.',
            'EXPIRED' => 'Coverage has expired.',
            'SUSPENDED' => 'Coverage is suspended.',
            'REVOKED' => 'Coverage was revoked.',
            default => 'Coverage is active.',
        };
    }

    private function required(array $input, string $key, string $label): string
    {
        $value = is_string($input[$key] ?? null) ? trim($input[$key]) : '';
        if ($value === '') {
            throw new AuthException("{$label} is required.", 422);
        }

        return $value;
    }

    private function optional(array $input, string $key): ?string
    {
        $value = $input[$key] ?? null;
        if (!is_string($value) || trim($value) === '') {
            return null;
        }

        return trim($value);
    }
}
