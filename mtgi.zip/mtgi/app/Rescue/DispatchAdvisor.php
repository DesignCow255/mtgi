<?php

declare(strict_types=1);

namespace Mamore\Rescue;

use Mamore\Core\ServerClock;
use PDO;

/**
 * Dispatch advice (Feature: dispatch engine).
 *
 * Capability is filtered BEFORE distance: a heavy-towing unit is never offered
 * for a medical call just because it is closer. When no road distance is
 * available the straight-line distance is used, and the response records which
 * basis was applied so nobody mistakes a radius for a route.
 */
final class DispatchAdvisor
{
    /** Straight-line distance is only a last resort. */
    public const BASIS_GREAT_CIRCLE = 'GREAT_CIRCLE';
    public const BASIS_ROAD = 'ROAD';
    public const BASIS_UNKNOWN = 'UNKNOWN';

    public function __construct(private readonly PDO $database) {}

    /**
     * Candidate units for an incident, best first.
     *
     * @return list<array<string,mixed>>
     */
    public function candidates(string $incidentId, int $limit = 5): array
    {
        $incident = $this->incident($incidentId);
        $required = $this->requiredCapability($incident);
        $latitude = $incident['latitude'] === null ? null : (float) $incident['latitude'];
        $longitude = $incident['longitude'] === null ? null : (float) $incident['longitude'];

        $sql = <<<'SQL'
            SELECT u.id, u.code, u.name, u.unit_type, u.status, u.latitude, u.longitude, u.province,
                   GROUP_CONCAT(DISTINCT uc.capability_code) AS capabilities
            FROM rescue_units u
            LEFT JOIN rescue_unit_capabilities uc ON uc.rescue_unit_id = u.id
            WHERE u.status = 'AVAILABLE'
            SQL;
        $params = [];

        if ($required !== null) {
            // A unit without the capability is not a candidate, however close.
            $sql .= ' AND EXISTS (SELECT 1 FROM rescue_unit_capabilities c
                                 WHERE c.rescue_unit_id = u.id AND c.capability_code = :capability)';
            $params['capability'] = $required;
        }
        // GROUP_CONCAT aggregates, so the selected columns are grouped explicitly
        // (the server runs with ONLY_FULL_GROUP_BY).
        $sql .= ' GROUP BY u.id, u.code, u.name, u.unit_type, u.status, u.latitude, u.longitude, u.province';
        $sql .= ' AND u.id NOT IN (SELECT assigned_unit_id FROM rescue_incidents
                                   WHERE assigned_unit_id IS NOT NULL
                                     AND status NOT IN (\'RESOLVED\', \'CANCELLED\'))';

        if ($latitude !== null && $longitude !== null) {
            $sql .= <<<'SQL'
                 ORDER BY (6371 * ACOS(LEAST(1, COS(RADIANS(:originLat)) * COS(RADIANS(u.latitude))
                     * COS(RADIANS(u.longitude) - RADIANS(:originLng)) + SIN(RADIANS(:originLat2)) * SIN(RADIANS(u.latitude))))) ASC
                SQL;
            $params['originLat'] = $latitude;
            $params['originLat2'] = $latitude;
            $params['originLng'] = $longitude;
        } else {
            $sql .= ' ORDER BY u.code';
        }
        $sql .= ' LIMIT ' . max(1, min($limit, 20));

        $statement = $this->database->prepare($sql);
        $statement->execute($params);

        $basis = $latitude !== null && $longitude !== null ? self::BASIS_GREAT_CIRCLE : self::BASIS_UNKNOWN;
        $candidates = [];
        foreach ($statement->fetchAll() as $row) {
            $distance = null;
            if ($latitude !== null && $longitude !== null && $row['latitude'] !== null) {
                $distance = $this->haversine($latitude, $longitude, (float) $row['latitude'], (float) $row['longitude']);
            }
            $candidates[] = [
                'unitId' => $row['id'],
                'code' => $row['code'],
                'name' => $row['name'],
                'unitType' => $row['unit_type'],
                'province' => $row['province'],
                'status' => $row['status'],
                'distanceKm' => $distance === null ? null : round($distance, 1),
                'distanceBasis' => $distance === null ? self::BASIS_UNKNOWN : $basis,
                'capabilities' => $row['capabilities'] === null ? [] : explode(',', (string) $row['capabilities']),
                'requiredCapability' => $required,
                'capabilityMatched' => $required === null,
            ];
        }

        return $candidates;
    }

    /**
     * The capability an incident needs, from its type's configuration.
     *
     * @return array<string,mixed>
     */
    public function requiredCapability(array $incident): ?string
    {
        if ($incident['incident_type'] === null) {
            return null;
        }
        $statement = $this->database->prepare('SELECT requires_capability FROM incident_types WHERE code = :code');
        $statement->execute(['code' => $incident['incident_type']]);
        $capability = $statement->fetchColumn();

        return is_string($capability) && $capability !== '' ? $capability : null;
    }

    /**
     * The rescue context a responder needs, assembled rather than retyped.
     *
     * @return array<string,mixed>
     */
    public function context(string $incidentId): array
    {
        $incident = $this->incident($incidentId);
        $vehicle = $this->vehicleSummary($incident);
        $occupants = $this->occupants($incident);
        $cargo = $this->cargo($incident);
        $coverage = $incident['vehicle_id'] === null
            ? ['covered' => false, 'status' => 'UNKNOWN', 'reason' => 'No vehicle attached to this incident.']
            : (new RescueCoverageService($this->database))->forVehicle((string) $incident['vehicle_id']);

        $position = ['status' => 'NO_POSITION', 'latitude' => null, 'longitude' => null, 'recordedAt' => null, 'secondsAgo' => null];
        $assetId = $incident['tracked_asset_id'] === null ? null : (string) $incident['tracked_asset_id'];
        if ($assetId !== null) {
            $positionRow = $this->database->query(
                'SELECT latitude, longitude, recorded_at FROM tracked_asset_positions WHERE tracked_asset_id = '
                . $this->database->quote($assetId)
            )->fetch();
            if (is_array($positionRow)) {
                $secondsAgo = ServerClock::epoch($this->database) - ServerClock::parse((string) $positionRow['recorded_at']);
                $position = [
                    'status' => $secondsAgo <= 120 ? 'ONLINE' : 'OFFLINE',
                    'latitude' => (float) $positionRow['latitude'],
                    'longitude' => (float) $positionRow['longitude'],
                    'recordedAt' => $positionRow['recorded_at'],
                    'secondsAgo' => $secondsAgo,
                ];
            }
        }

        return [
            'incident' => [
                'id' => $incident['id'],
                'code' => $incident['incident_code'],
                'domain' => $incident['domain'],
                'type' => $incident['incident_type'],
                'severity' => $incident['severity'],
                'status' => $incident['status'],
                'description' => $incident['description'],
                'province' => $incident['province'],
                'reportedAt' => $incident['reported_at'],
            ],
            'person' => $this->person($incident),
            'vehicle' => $vehicle,
            'occupants' => $occupants,
            'cargo' => $cargo,
            'rescueCoverage' => $coverage,
            'position' => $position,
            'nearest' => $this->nearest($incident),
        ];
    }

    // ------------------------------------------------------------- internals

    /** @return array<string,mixed> */
    private function incident(string $id): array
    {
        $statement = $this->database->prepare('SELECT * FROM rescue_incidents WHERE id = :id');
        $statement->execute(['id' => $id]);
        $row = $statement->fetch();
        if (!is_array($row)) {
            throw new \Mamore\Auth\AuthException('Incident not found.', 404);
        }

        return $row;
    }

    /** @return array<string,mixed> */
    private function person(array $incident): array
    {
        if ($incident['subscriber_id'] === null) {
            return ['membershipNumber' => null, 'name' => $incident['caller_name'], 'phone' => $incident['caller_phone']];
        }
        $statement = $this->database->prepare(<<<'SQL'
            SELECT s.membership_number, s.first_name, s.last_name, s.phone, s.emergency_contact, s.emergency_phone
            FROM subscribers s WHERE s.id = :id
            SQL);
        $statement->execute(['id' => $incident['subscriber_id']]);
        $row = $statement->fetch();
        if (!is_array($row)) {
            return ['membershipNumber' => null, 'name' => $incident['caller_name'], 'phone' => $incident['caller_phone']];
        }

        return [
            'membershipNumber' => $row['membership_number'],
            'name' => trim(((string) $row['first_name']) . ' ' . ((string) $row['last_name'])),
            'phone' => $row['phone'],
            'emergencyContact' => $row['emergency_contact'],
            'emergencyPhone' => $row['emergency_phone'],
        ];
    }

    /** @return array<string,mixed>|null */
    private function vehicleSummary(array $incident): ?array
    {
        if ($incident['vehicle_id'] === null && $incident['smartbus_vehicle_id'] === null) {
            return null;
        }
        $vehicleId = $incident['vehicle_id'] ?? $incident['smartbus_vehicle_id'];
        $statement = $this->database->prepare('SELECT registration_number, make, model, vehicle_type FROM vehicles WHERE id = :id');
        $statement->execute(['id' => $vehicleId]);
        $vehicle = $statement->fetch();

        return [
            'registrationNumber' => is_array($vehicle) ? $vehicle['registration_number'] : null,
            'description' => is_array($vehicle) ? trim(((string) $vehicle['make']) . ' ' . ((string) $vehicle['model'])) : null,
            'vehicleType' => is_array($vehicle) ? $vehicle['vehicle_type'] : null,
            'passengerCount' => $incident['passenger_count'] === null ? null : (int) $incident['passenger_count'],
            'vipPassengerCount' => $incident['vip_passenger_count'] === null ? null : (int) $incident['vip_passenger_count'],
        ];
    }

    /**
     * Who is inside, asked per domain rather than guessed.
     *
     * @return list<array<string,mixed>>
     */
    private function occupants(array $incident): array
    {
        $journeyId = $incident['journey_id'] ?? null;
        if ($journeyId === null) {
            return [];
        }
        if ($incident['domain'] === 'TRUCK_CARGO') {
            $statement = $this->database->prepare(<<<'SQL'
                SELECT o.role, p.first_name, p.last_name, p.phone, d.license_number
                FROM truck_journey_occupants o
                JOIN persons p ON p.id = o.person_id
                LEFT JOIN truck_drivers d ON d.person_id = o.person_id
                WHERE o.truck_journey_id = :journey ORDER BY o.role DESC
                SQL);
        } else {
            $statement = $this->database->prepare(<<<'SQL'
                SELECT j.person_id, j.guest_name, j.relationship, j.is_vip, j.rescue_covered, p.first_name, p.last_name
                FROM journey_passengers j LEFT JOIN persons p ON p.id = j.person_id
                WHERE j.private_vehicle_journey_id = :journey
                SQL);
        }
        $statement->execute(['journey' => $journeyId]);

        return array_map(static fn (array $row): array => $incident['domain'] === 'TRUCK_CARGO'
            ? [
                'role' => $row['role'],
                'name' => trim(((string) $row['first_name']) . ' ' . ((string) $row['last_name'])),
                'phone' => $row['phone'],
                'licenseNumber' => $row['license_number'],
            ]
            : [
                'name' => $row['guest_name'] ?? trim(((string) ($row['first_name'] ?? '')) . ' ' . ((string) ($row['last_name'] ?? ''))),
                'relationship' => $row['relationship'],
                'isVip' => (bool) $row['is_vip'],
                'rescueCovered' => (bool) $row['rescue_covered'],
            ], $statement->fetchAll());
    }

    /** @return array<string,mixed>|null */
    private function cargo(array $incident): ?array
    {
        if ($incident['consignment_id'] === null) {
            return null;
        }
        $statement = $this->database->prepare(<<<'SQL'
            SELECT consignment_number, cargo_category, total_weight_kg, hazardous, hazard_class, un_number,
                   declared_value, declared_currency, status
            FROM consignments WHERE id = :id
            SQL);
        $statement->execute(['id' => $incident['consignment_id']]);
        $consignment = $statement->fetch();
        if (!is_array($consignment)) {
            return null;
        }

        return [
            'consignmentNumber' => $consignment['consignment_number'],
            'category' => $consignment['cargo_category'],
            'totalWeightKg' => (float) $consignment['total_weight_kg'],
            'hazardous' => (bool) $consignment['hazardous'],
            'hazardClass' => $consignment['hazard_class'],
            'unNumber' => $consignment['un_number'],
            'declaredValue' => $consignment['declared_value'] === null ? null : (string) $consignment['declared_value'],
            'declaredCurrency' => $consignment['declared_currency'],
            'status' => $consignment['status'],
        ];
    }

    /** @return array<string,mixed> */
    private function nearest(array $incident): array
    {
        $latitude = $incident['latitude'] === null ? null : (float) $incident['latitude'];
        $longitude = $incident['longitude'] === null ? null : (float) $incident['longitude'];
        if ($latitude === null || $longitude === null) {
            return ['basis' => self::BASIS_UNKNOWN, 'hospital' => null, 'garage' => null, 'fuelStation' => null, 'rescueUnit' => null];
        }

        return [
            'basis' => self::BASIS_GREAT_CIRCLE,
            'hospital' => $this->nearestLocation($latitude, $longitude, 'HOSPITAL'),
            'garage' => $this->nearestLocation($latitude, $longitude, 'GARAGE'),
            'fuelStation' => $this->nearestLocation($latitude, $longitude, 'FUEL_STATION'),
            'rescueUnit' => $this->nearestUnit($latitude, $longitude),
        ];
    }

    /** @return array<string,mixed>|null */
    private function nearestLocation(float $lat, float $lng, string $type): ?array
    {
        $statement = $this->database->prepare(<<<'SQL'
            SELECT name, latitude, longitude,
                   6371 * ACOS(LEAST(1, COS(RADIANS(:latA)) * COS(RADIANS(latitude))
                       * COS(RADIANS(longitude) - RADIANS(:lngA)) + SIN(RADIANS(:latB)) * SIN(RADIANS(latitude)))) AS distance_km
            FROM service_locations
            WHERE location_type = :type AND status = 'ACTIVE' AND latitude IS NOT NULL
            ORDER BY distance_km ASC LIMIT 1
            SQL);
        $statement->execute(['latA' => $lat, 'latB' => $lat, 'lngA' => $lng, 'type' => $type]);
        $row = $statement->fetch();
        if (!is_array($row)) {
            return null;
        }

        return [
            'name' => $row['name'],
            'distanceKm' => round((float) $row['distance_km'], 1),
            'distanceBasis' => self::BASIS_GREAT_CIRCLE,
        ];
    }

    /** @return array<string,mixed>|null */
    private function nearestUnit(float $lat, float $lng): ?array
    {
        $statement = $this->database->prepare(<<<'SQL'
            SELECT code, name, latitude, longitude,
                   6371 * ACOS(LEAST(1, COS(RADIANS(:latA)) * COS(RADIANS(latitude))
                       * COS(RADIANS(longitude) - RADIANS(:lngA)) + SIN(RADIANS(:latB)) * SIN(RADIANS(latitude)))) AS distance_km
            FROM rescue_units
            WHERE status IN ('AVAILABLE', 'DISPATCHED') AND latitude IS NOT NULL
            ORDER BY distance_km ASC LIMIT 1
            SQL);
        $statement->execute(['latA' => $lat, 'latB' => $lat, 'lngA' => $lng]);
        $row = $statement->fetch();
        if (!is_array($row)) {
            return null;
        }

        return [
            'code' => $row['code'],
            'name' => $row['name'],
            'distanceKm' => round((float) $row['distance_km'], 1),
            'distanceBasis' => self::BASIS_GREAT_CIRCLE,
        ];
    }

    private function haversine(float $lat1, float $lng1, float $lat2, float $lng2): float
    {
        $earthRadius = 6371.0;
        $deltaLat = deg2rad($lat2 - $lat1);
        $deltaLng = deg2rad($lng2 - $lng1);
        $a = sin($deltaLat / 2) ** 2 + cos(deg2rad($lat1)) * cos(deg2rad($lat2)) * sin($deltaLng / 2) ** 2;

        return $earthRadius * 2 * atan2(sqrt($a), sqrt(1 - $a));
    }
}
