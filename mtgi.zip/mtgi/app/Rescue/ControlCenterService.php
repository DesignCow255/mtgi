<?php

declare(strict_types=1);

namespace Mamore\Rescue;

use Mamore\Core\AuditLog;
use Mamore\Core\ServerClock;
use PDO;

/**
 * The cross-domain Rescue Control Center (Feature Group: control center upgrade).
 *
 * One operational picture: every tracked asset of every domain, every open
 * incident, and the alerts that need a human. Domain filtering happens in SQL,
 * and every domain reaches this board through the same tables, so there is no
 * per-domain branch here to drift out of step.
 */
final class ControlCenterService
{
    private const DOMAINS = ['SMART_BUS', 'TRUCK_CARGO', 'PRIVATE_VEHICLE', 'VIP', 'RESCUE', 'OTHER'];

    public function __construct(
        private readonly PDO $database,
        private readonly DispatchAdvisor $dispatch,
    ) {}

    /**
     * The operations board: KPIs, live assets, incidents and alerts.
     *
     * @param array<string,mixed> $filters domain, status, province, operatorId
     *
     * @return array<string,mixed>
     */
    public function operations(array $filters = [], ?array $actor = null): array
    {
        $domain = $this->domain($filters);
        [$assetWhere, $assetParams] = $this->assetScope($filters);
        [$incidentWhere, $incidentParams] = $this->incidentScope($filters);

        $kpis = [
            'trackedAssets' => $this->scalar("SELECT COUNT(*) FROM tracked_assets a WHERE {$assetWhere}", $assetParams),
            'activeBuses' => $this->scalar("SELECT COUNT(*) FROM tracked_assets a WHERE {$assetWhere} AND a.asset_type = 'BUS'", $assetParams),
            'activeTrucks' => $this->scalar("SELECT COUNT(*) FROM tracked_assets a WHERE {$assetWhere} AND a.asset_type = 'TRUCK'", $assetParams),
            'activePrivateVehicles' => $this->scalar("SELECT COUNT(*) FROM tracked_assets a WHERE {$assetWhere} AND a.asset_type = 'PRIVATE_VEHICLE'", $assetParams),
            'rescueVehiclesAvailable' => $this->scalar("SELECT COUNT(*) FROM rescue_units WHERE status = 'AVAILABLE'"),
            'openIncidents' => $this->scalar("SELECT COUNT(*) FROM rescue_incidents i WHERE {$incidentWhere}", $incidentParams),
            'criticalIncidents' => $this->scalar("SELECT COUNT(*) FROM rescue_incidents i WHERE {$incidentWhere} AND i.severity = 'CRITICAL'", $incidentParams),
            'gpsOffline' => $this->scalar(
                "SELECT COUNT(*) FROM tracked_assets a
                 WHERE {$assetWhere}
                   AND a.tracking_status = 'ONLINE'
                   AND NOT EXISTS (SELECT 1 FROM tracked_asset_positions p
                                   WHERE p.tracked_asset_id = a.id AND p.recorded_at >= DATE_SUB(UTC_TIMESTAMP(6), INTERVAL 2 MINUTE))",
                $assetParams
            ),
            'openAlerts' => (int) $this->database->query(
                "SELECT COUNT(*) FROM tracking_alerts WHERE status IN ('NEW', 'ACKNOWLEDGED', 'INVESTIGATING')"
            )->fetchColumn(),
        ];

        $assets = $this->assets($assetWhere, $assetParams, $filters);
        $incidents = $this->incidents($incidentWhere, $incidentParams, (int) ($filters['limit'] ?? 25));

        (new AuditLog($this->database))->write(
            'CONTROL_CENTER_OPERATIONS_VIEWED',
            'ControlCenter',
            null,
            $actor,
            null,
            null,
            null,
            ['source' => 'control-center', 'domain' => $domain ?? 'ALL', 'assets' => count($assets), 'incidents' => count($incidents)]
        );

        return [
            'domain' => $domain ?? 'ALL',
            'availableDomains' => self::DOMAINS,
            'kpis' => $kpis,
            'assets' => $assets,
            'incidents' => $incidents,
            'alerts' => $this->alerts($filters),
            'generatedAt' => gmdate('c', ServerClock::epoch($this->database)),
            'message' => $kpis['trackedAssets'] === 0 && $kpis['openIncidents'] === 0 ? 'No data available.' : null,
        ];
    }

    /**
     * Cross-domain operational intelligence (Feature Group Z, global).
     *
     * @param array<string,mixed> $filters
     *
     * @return array<string,mixed>
     */
    public function analytics(array $filters = []): array
    {
        return [
            'assetsByDomain' => $this->groups(
                "SELECT COALESCE(domain, 'UNASSIGNED') AS label, COUNT(*) AS total
                 FROM tracked_assets WHERE status = 'ACTIVE' GROUP BY domain ORDER BY total DESC"
            ),
            'assetsByType' => $this->groups(
                "SELECT asset_type AS label, COUNT(*) AS total FROM tracked_assets WHERE status = 'ACTIVE'
                 GROUP BY asset_type ORDER BY total DESC"
            ),
            'peopleInMovement' => [
                'smartBusPassengers' => $this->scalar(
                    "SELECT COUNT(*) FROM active_journeys WHERE status = 'ACTIVE'"
                ),
                'truckCrew' => $this->scalar(
                    "SELECT COUNT(*) FROM truck_journey_occupants o
                     JOIN truck_journeys j ON j.id = o.truck_journey_id
                     WHERE j.status IN ('IN_TRANSIT', 'PAUSED', 'DELAYED', 'INCIDENT', 'BREAKDOWN')"
                ),
                'privateOccupants' => $this->scalar(
                    "SELECT COALESCE(SUM(passenger_count), 0) FROM private_vehicle_journeys
                     WHERE status IN ('ACTIVE', 'PAUSED', 'INCIDENT')"
                ),
            ],
            'cargoInMotion' => [
                'consignments' => $this->scalar(
                    "SELECT COUNT(*) FROM truck_journeys WHERE status IN ('IN_TRANSIT', 'DELAYED')"
                ),
                'weightKg' => (string) $this->scalar(
                    "SELECT COALESCE(SUM(cargo_weight_kg), 0) FROM truck_journeys WHERE status IN ('IN_TRANSIT', 'DELAYED')"
                ),
                'hazardous' => $this->scalar(
                    "SELECT COUNT(*) FROM truck_journeys WHERE status IN ('IN_TRANSIT', 'DELAYED') AND cargo_hazardous = 1"
                ),
            ],
            'incidentsByDomain' => $this->groups(
                "SELECT domain AS label, COUNT(*) AS total FROM rescue_incidents
                 WHERE reported_at >= DATE_SUB(UTC_DATE(), INTERVAL 30 DAY) GROUP BY domain ORDER BY total DESC"
            ),
            'incidentsBySeverity' => $this->groups(
                "SELECT severity AS label, COUNT(*) AS total FROM rescue_incidents
                 WHERE reported_at >= DATE_SUB(UTC_DATE(), INTERVAL 30 DAY) GROUP BY severity ORDER BY total DESC"
            ),
            'rescueCoverage' => [
                'protectedJourneys' => $this->scalar(
                    "SELECT COUNT(*) FROM truck_journeys WHERE rescue_coverage_status = 'ACTIVE'"
                ) + $this->scalar("SELECT COUNT(*) FROM private_vehicles WHERE rescue_coverage_status = 'ACTIVE'"),
                'uncoveredSubjects' => (int) $this->database->query(
                    "SELECT COUNT(*) FROM rescue_coverage_links WHERE status <> 'ACTIVE'"
                )->fetchColumn(),
                'pending' => (int) $this->database->query(
                    "SELECT COUNT(*) FROM rescue_coverage_links WHERE status = 'PENDING'"
                )->fetchColumn(),
            ],
            'trackingHealth' => [
                'online' => $this->scalar(
                    "SELECT COUNT(*) FROM tracked_assets a WHERE a.tracking_status = 'ONLINE'
                     AND EXISTS (SELECT 1 FROM tracked_asset_positions p WHERE p.tracked_asset_id = a.id
                                 AND p.recorded_at >= DATE_SUB(UTC_TIMESTAMP(6), INTERVAL 2 MINUTE))"
                ),
                'delayedSignal' => $this->scalar(
                    "SELECT COUNT(*) FROM tracked_assets a WHERE a.tracking_status = 'ONLINE'
                     AND NOT EXISTS (SELECT 1 FROM tracked_asset_positions p WHERE p.tracked_asset_id = a.id
                                     AND p.recorded_at >= DATE_SUB(UTC_TIMESTAMP(6), INTERVAL 2 MINUTE))"
                ),
                'offline' => $this->scalar("SELECT COUNT(*) FROM tracked_assets WHERE tracking_status = 'OFFLINE'"),
                'noDevice' => $this->scalar("SELECT COUNT(*) FROM tracked_assets WHERE tracking_status = 'NO_DEVICE'"),
            ],
            'response' => $this->responseTimes(),
        ];
    }

    /**
     * Dispatch advice for an incident, including the full rescue context.
     *
     * @return array<string,mixed>
     */
    public function incidentDetail(string $incidentId, ?array $actor = null): array
    {
        $context = $this->dispatch->context($incidentId);
        $context['candidates'] = $this->dispatch->candidates($incidentId);

        return $context;
    }

    // ------------------------------------------------------------- internals

    /** @return array<string,mixed> */
    private function responseTimes(): array
    {
        $row = $this->database->query(<<<'SQL'
            SELECT COUNT(*) AS incidents,
                   AVG(TIMESTAMPDIFF(MINUTE, reported_at, dispatched_at)) AS dispatch_minutes,
                   AVG(TIMESTAMPDIFF(MINUTE, dispatched_at, arrived_at)) AS arrive_minutes,
                   AVG(TIMESTAMPDIFF(MINUTE, reported_at, resolved_at)) AS resolve_minutes
            FROM rescue_incidents WHERE reported_at >= DATE_SUB(UTC_DATE(), INTERVAL 30 DAY)
            SQL)->fetch() ?: [];

        return [
            'incidents' => (int) ($row['incidents'] ?? 0),
            'avgDispatchMinutes' => $row['dispatch_minutes'] === null ? null : round((float) $row['dispatch_minutes'], 1),
            'avgArriveMinutes' => $row['arrive_minutes'] === null ? null : round((float) $row['arrive_minutes'], 1),
            'avgResolveMinutes' => $row['resolve_minutes'] === null ? null : round((float) $row['resolve_minutes'], 1),
            'message' => (int) ($row['incidents'] ?? 0) === 0 ? 'No data available.' : null,
        ];
    }

    /**
     * @param array<string,mixed> $filters
     *
     * @return array{0:string,1:array<string,mixed>}
     */
    private function assetScope(array $filters): array
    {
        $clauses = ["a.status = 'ACTIVE'"];
        $params = [];
        $domain = $this->domain($filters);
        if ($domain !== null) {
            if ($domain === 'RESCUE') {
                $clauses[] = "a.asset_type = 'RESCUE_VEHICLE'";
            } else {
                $clauses[] = 'a.domain = :domain';
                $params['domain'] = $domain;
            }
        }
        if (($filters['operatorId'] ?? '') !== '') {
            $clauses[] = 'a.vehicle_id IN (SELECT vehicle_id FROM trucks WHERE truck_operator_id = :operator)';
            $params['operator'] = (string) $filters['operatorId'];
        }
        if (($filters['status'] ?? '') !== '' && $domain === null) {
            $clauses[] = 'a.tracking_status = :status';
            $params['status'] = strtoupper((string) $filters['status']);
        }

        return [implode(' AND ', $clauses), $params];
    }

    /**
     * @param array<string,mixed> $filters
     *
     * @return array{0:string,1:array<string,mixed>}
     */
    private function incidentScope(array $filters): array
    {
        $clauses = ["i.status NOT IN ('RESOLVED', 'CANCELLED')"];
        $params = [];
        $domain = $this->domain($filters);
        if ($domain !== null) {
            $clauses[] = 'i.domain = :domain';
            $params['domain'] = $domain;
        }
        if (($filters['province'] ?? '') !== '') {
            $clauses[] = 'i.province = :province';
            $params['province'] = (string) $filters['province'];
        }
        if (($filters['severity'] ?? '') !== '') {
            $clauses[] = 'i.severity = :severity';
            $params['severity'] = strtoupper((string) $filters['severity']);
        }

        return [implode(' AND ', $clauses), $params];
    }

    /** @param array<string,mixed> $filters */
    private function domain(array $filters): ?string
    {
        $domain = strtoupper((string) ($filters['domain'] ?? ''));
        if ($domain === '' || $domain === 'ALL') {
            return null;
        }
        if (!in_array($domain, self::DOMAINS, true)) {
            throw new \Mamore\Auth\AuthException('Unknown operational domain.', 422);
        }

        return $domain;
    }

    /**
     * Every domain reaches the map through the same current-position table, so
     * the map never reads a GPS history.
     *
     * @param array<string,mixed> $params
     *
     * @return list<array<string,mixed>>
     */
    private function assets(string $where, array $params, array $filters): array
    {
        $statement = $this->database->prepare(<<<SQL
            SELECT a.id, a.asset_type, a.domain, a.asset_code, a.label, a.tracking_status,
                   v.registration_number, v.make, v.model,
                   p.latitude, p.longitude, p.recorded_at, p.speed_kph,
                   d.device_uid IS NOT NULL AS has_device
            FROM tracked_assets a
            LEFT JOIN vehicles v ON v.id = a.vehicle_id
            LEFT JOIN tracked_asset_positions p ON p.tracked_asset_id = a.id
            LEFT JOIN tracking_device_assignments da ON da.tracked_asset_id = a.id AND da.unassigned_at IS NULL
            LEFT JOIN tracking_devices d ON d.id = da.device_id
            WHERE {$where}
            ORDER BY (p.recorded_at IS NULL), p.recorded_at DESC, a.asset_code
            LIMIT 500
            SQL);
        $statement->execute($params);
        $now = ServerClock::epoch($this->database);

        return array_map(function (array $row) use ($now): array {
            $secondsAgo = $row['recorded_at'] === null ? null : $now - ServerClock::parse((string) $row['recorded_at']);
            $status = $row['recorded_at'] === null
                ? 'NO_POSITION'
                : ($secondsAgo !== null && $secondsAgo <= 120 ? 'ONLINE' : 'OFFLINE');

            return [
                'trackedAssetId' => $row['id'],
                'domain' => $row['domain'] ?? 'UNASSIGNED',
                'assetType' => $row['asset_type'],
                'code' => $row['asset_code'],
                'label' => $row['label'],
                'registrationNumber' => $row['registration_number'],
                'description' => trim(((string) ($row['make'] ?? '')) . ' ' . ((string) ($row['model'] ?? ''))),
                'trackingStatus' => $status,
                'hasDevice' => (bool) $row['has_device'],
                'latitude' => $status === 'ONLINE' ? (float) $row['latitude'] : null,
                'longitude' => $status === 'ONLINE' ? (float) $row['longitude'] : null,
                'speedKph' => $status === 'ONLINE' && $row['speed_kph'] !== null ? (float) $row['speed_kph'] : null,
                'recordedAt' => $row['recorded_at'],
                'secondsAgo' => $secondsAgo,
            ];
        }, $statement->fetchAll());
    }

    /**
     * @param array<string,mixed> $params
     *
     * @return list<array<string,mixed>>
     */
    private function incidents(string $where, array $params, int $limit): array
    {
        // The limit is an integer derived from a clamped int, and the clause is
        // built whole so a filter can never concatenate an unbound fragment.
        $safeLimit = max(1, min($limit, 100));
        $statement = $this->database->prepare(<<<SQL
            SELECT i.id, i.incident_code, i.domain, i.incident_type, i.severity, i.status, i.province,
                   i.description, i.reported_at, i.latitude, i.longitude,
                   i.passenger_count, i.cargo_hazardous, u.code AS unit_code
            FROM rescue_incidents i
            LEFT JOIN rescue_units u ON u.id = i.assigned_unit_id
            WHERE {$where}
            ORDER BY FIELD(i.severity, 'CRITICAL', 'HIGH', 'MEDIUM', 'LOW'), i.reported_at DESC
            LIMIT {$safeLimit}
            SQL);
        $statement->execute($params);

        return array_map(static fn (array $row): array => [
            'id' => $row['id'],
            'code' => $row['incident_code'],
            'domain' => $row['domain'],
            'type' => $row['incident_type'],
            'severity' => $row['severity'],
            'status' => $row['status'],
            'province' => $row['province'],
            'description' => $row['description'],
            'reportedAt' => $row['reported_at'],
            'hasPosition' => $row['latitude'] !== null,
            'passengerCount' => $row['passenger_count'] === null ? null : (int) $row['passenger_count'],
            'cargoHazardous' => (bool) $row['cargo_hazardous'],
            'assignedUnit' => $row['unit_code'],
        ], $statement->fetchAll());
    }

    /**
     * @param array<string,mixed> $filters
     *
     * @return list<array<string,mixed>>
     */
    private function alerts(array $filters): array
    {
        $params = [];
        $sql = <<<'SQL'
            SELECT a.id, a.alert_code, a.severity, a.status, a.message, a.opened_at, a.domain,
                   t.label AS asset_label
            FROM tracking_alerts a
            LEFT JOIN tracked_assets t ON t.id = a.tracked_asset_id
            WHERE a.status IN ('NEW', 'ACKNOWLEDGED', 'INVESTIGATING')
            SQL;
        $domain = $this->domain($filters);
        if ($domain !== null) {
            $sql .= ' AND a.domain = :domain';
            $params['domain'] = $domain;
        }
        $sql .= ' ORDER BY FIELD(a.severity, \'CRITICAL\', \'HIGH\', \'MEDIUM\', \'LOW\'), a.opened_at DESC LIMIT 50';

        $statement = $this->database->prepare($sql);
        $statement->execute($params);

        return array_map(static fn (array $row): array => [
            'id' => $row['id'],
            'code' => $row['alert_code'],
            'severity' => $row['severity'],
            'status' => $row['status'],
            'message' => $row['message'],
            'assetLabel' => $row['asset_label'],
            'domain' => $row['domain'],
            'openedAt' => $row['opened_at'],
        ], $statement->fetchAll());
    }

    /**
     * @return list<array{label:string,total:int}>
     */
    private function groups(string $sql): array
    {
        return array_map(static fn (array $row): array => [
            'label' => (string) $row['label'],
            'total' => (int) $row['total'],
        ], $this->database->query($sql)->fetchAll());
    }

    /** @param array<string,mixed> $params */
    private function scalar(string $sql, array $params = []): int
    {
        $statement = $this->database->prepare($sql);
        $statement->execute($params);
        $value = $statement->fetchColumn();

        return is_numeric($value) ? (int) $value : 0;
    }
}
