<?php

declare(strict_types=1);

namespace Mamore\Rescue;

use Mamore\Auth\AuthException;
use Mamore\Core\Uuid;
use PDO;

final class RescueService
{
    private const PRIORITIES = ['CRITICAL', 'HIGH', 'MEDIUM', 'LOW'];
    private const STATUSES = ['REPORTED', 'DISPATCHED', 'ACKNOWLEDGED', 'EN_ROUTE', 'ON_SCENE', 'RESOLVED', 'CANCELLED'];
    private const TRANSITIONS = [
        'REPORTED' => ['DISPATCHED', 'CANCELLED'],
        'DISPATCHED' => ['ACKNOWLEDGED', 'EN_ROUTE', 'CANCELLED'],
        'ACKNOWLEDGED' => ['EN_ROUTE', 'CANCELLED'],
        'EN_ROUTE' => ['ON_SCENE', 'CANCELLED'],
        'ON_SCENE' => ['RESOLVED', 'CANCELLED'],
        'RESOLVED' => [], 'CANCELLED' => [],
    ];

    public function __construct(private readonly PDO $database) {}

    public function board(): array
    {
        $incidents = $this->database->query(<<<'SQL'
            SELECT i.*, u.code AS unit_code, u.name AS unit_name
            FROM rescue_incidents i LEFT JOIN rescue_units u ON u.id = i.assigned_unit_id
            -- OPEN WORK FIRST, THEN SEVERITY, THEN PROGRESS.
            --
            -- The original was (status, priority, time). Status first meant
            -- every REPORTED incident outranked every DISPATCHED one regardless
            -- of severity, so a LOW roadside report sat above a CRITICAL
            -- incident that already had a unit on the way.
            --
            -- Simply swapping to (priority, status) was worse: it pushed CLOSED
            -- incidents to the very top, because a resolved CRITICAL outranks an
            -- open LOW. On an emergency board the queue has to answer "what is
            -- still outstanding", so open-vs-closed is the first key.
            --
            -- CASE, not FIELD(status IN (...), 1, 0): FIELD() returns the
            -- 1-based INDEX of the match, and a boolean argument matches neither
            -- literal, so it returned 2 for every row and sorted by a constant.
            -- That mistake shipped a queue which looked sorted and was not.
            --
            -- Within the open band, severity ranks the work and status only
            -- sequences it. Closed incidents keep their own band at the bottom,
            -- still ordered among themselves by severity and recency, so nothing
            -- is lost.
            ORDER BY CASE WHEN i.status IN ('RESOLVED','CANCELLED') THEN 1 ELSE 0 END,
                     FIELD(i.priority, 'CRITICAL','HIGH','MEDIUM','LOW'),
                     FIELD(i.status, 'REPORTED','DISPATCHED','ACKNOWLEDGED','EN_ROUTE','ON_SCENE','RESOLVED','CANCELLED'),
                     i.reported_at DESC LIMIT 100
            SQL)->fetchAll();
        $units = $this->database->query('SELECT id, code, name, unit_type, province, base_name, status, contact_phone FROM rescue_units ORDER BY province, code')->fetchAll();
        $counts = ['open' => 0, 'critical' => 0, 'dispatched' => 0, 'availableUnits' => 0];
        foreach ($incidents as $incident) {
            if (!in_array($incident['status'], ['RESOLVED', 'CANCELLED'], true)) $counts['open']++;
            if ($incident['priority'] === 'CRITICAL' && !in_array($incident['status'], ['RESOLVED', 'CANCELLED'], true)) $counts['critical']++;
            if (in_array($incident['status'], ['DISPATCHED', 'ACKNOWLEDGED', 'EN_ROUTE', 'ON_SCENE'], true)) $counts['dispatched']++;
        }
        foreach ($units as $unit) if ($unit['status'] === 'AVAILABLE') $counts['availableUnits']++;
        return ['metrics' => $counts, 'incidents' => array_map([$this, 'incident'], $incidents), 'units' => array_map([$this, 'unit'], $units)];
    }

    public function report(array $input, array $actor): array
    {
        $phone = $this->required($input, 'callerPhone', 'Caller phone');
        $province = $this->choice($input['province'] ?? '', ['HAUT_KATANGA', 'LUALABA'], 'province');
        $location = $this->required($input, 'location', 'Location');
        $description = $this->required($input, 'description', 'Description');
        $priority = $this->choice($input['priority'] ?? '', self::PRIORITIES, 'priority');
        $id = Uuid::v4();
        $code = 'INC-' . gmdate('ymd') . '-' . strtoupper(bin2hex(random_bytes(3)));
        $statement = $this->database->prepare(<<<'SQL'
            INSERT INTO rescue_incidents
                (id, incident_code, source, caller_name, caller_phone, province, location_text, latitude, longitude, description, priority, reported_by_user_id)
            VALUES (:id, :code, :source, :caller_name, :phone, :province, :location, :latitude, :longitude, :description, :priority, :actor)
            SQL);
        $statement->execute([
            'id' => $id, 'code' => $code, 'source' => $this->choice($input['source'] ?? 'HQ_MANUAL', ['HQ_MANUAL', 'PANIC_DEVICE', 'PHONE', 'PARTNER'], 'source'),
            'caller_name' => $this->optional($input, 'callerName'), 'phone' => $phone, 'province' => $province,
            'location' => $location, 'latitude' => $this->coordinate($input['latitude'] ?? null, -90, 90),
            'longitude' => $this->coordinate($input['longitude'] ?? null, -180, 180), 'description' => $description,
            'priority' => $priority, 'actor' => $actor['id'],
        ]);
        $this->event($id, $actor['id'], 'INCIDENT_REPORTED', null, 'REPORTED', null);
        return $this->find($id);
    }

    public function dispatch(array $input, array $actor): array
    {
        $incidentId = $this->required($input, 'incidentId', 'Incident');
        $unitId = $this->required($input, 'unitId', 'Rescue unit');
        $this->database->beginTransaction();
        try {
            $incident = $this->lockedIncident($incidentId);
            if ($incident['status'] !== 'REPORTED') throw new AuthException('Only newly reported incidents can be dispatched.', 409);
            $unitStatement = $this->database->prepare('SELECT * FROM rescue_units WHERE id = :id FOR UPDATE');
            $unitStatement->execute(['id' => $unitId]); $unit = $unitStatement->fetch();
            if (!is_array($unit) || $unit['status'] !== 'AVAILABLE') throw new AuthException('The selected rescue unit is not available.', 409);
            $this->database->prepare("UPDATE rescue_incidents SET assigned_unit_id = :unit, status = 'DISPATCHED', dispatched_by_user_id = :actor, dispatched_at = UTC_TIMESTAMP(6) WHERE id = :id")
                ->execute(['unit' => $unitId, 'actor' => $actor['id'], 'id' => $incidentId]);
            $this->database->prepare("UPDATE rescue_units SET status = 'DISPATCHED' WHERE id = :id")->execute(['id' => $unitId]);
            $this->event($incidentId, $actor['id'], 'UNIT_DISPATCHED', 'REPORTED', 'DISPATCHED', $unit['code']);
            $this->database->commit();
        } catch (\Throwable $error) { $this->database->rollBack(); throw $error; }
        return $this->find($incidentId);
    }

    public function transition(array $input, array $actor): array
    {
        $incidentId = $this->required($input, 'incidentId', 'Incident');
        $next = $this->choice($input['status'] ?? '', self::STATUSES, 'status');
        $notes = $this->optional($input, 'notes');
        $this->database->beginTransaction();
        try {
            $incident = $this->lockedIncident($incidentId);
            if (!in_array($next, self::TRANSITIONS[$incident['status']] ?? [], true)) throw new AuthException("Cannot move incident from {$incident['status']} to {$next}.", 409);
            $timeColumn = match ($next) { 'ACKNOWLEDGED' => 'acknowledged_at', 'ON_SCENE' => 'arrived_at', 'RESOLVED' => 'resolved_at', default => null };
            $sql = 'UPDATE rescue_incidents SET status = :status' . ($timeColumn ? ", {$timeColumn} = UTC_TIMESTAMP(6)" : '') . ' WHERE id = :id';
            $this->database->prepare($sql)->execute(['status' => $next, 'id' => $incidentId]);
            if (in_array($next, ['RESOLVED', 'CANCELLED'], true) && $incident['assigned_unit_id']) {
                $this->database->prepare("UPDATE rescue_units SET status = 'AVAILABLE' WHERE id = :id")->execute(['id' => $incident['assigned_unit_id']]);
            }
            $this->event($incidentId, $actor['id'], 'STATUS_CHANGED', $incident['status'], $next, $notes);
            $this->database->commit();
        } catch (\Throwable $error) { $this->database->rollBack(); throw $error; }
        return $this->find($incidentId);
    }

    private function lockedIncident(string $id): array
    {
        $statement = $this->database->prepare('SELECT * FROM rescue_incidents WHERE id = :id FOR UPDATE');
        $statement->execute(['id' => $id]); $incident = $statement->fetch();
        if (!is_array($incident)) throw new AuthException('Incident not found.', 404);
        return $incident;
    }

    private function find(string $id): array
    {
        $statement = $this->database->prepare('SELECT i.*, u.code AS unit_code, u.name AS unit_name FROM rescue_incidents i LEFT JOIN rescue_units u ON u.id = i.assigned_unit_id WHERE i.id = :id');
        $statement->execute(['id' => $id]); $incident = $statement->fetch();
        if (!is_array($incident)) throw new AuthException('Incident not found.', 404);
        return $this->incident($incident);
    }

    /**
     * One incident by id.
     *
     * Added with the Smart Bus integration so an incident raised from a trip can
     * be returned through the same payload as one raised at the console.
     *
     * @return array<string,mixed>
     */
    public function show(string $id): array
    {
        $statement = $this->database->prepare(<<<'SQL'
            SELECT i.*, u.code AS unit_code, u.name AS unit_name
            FROM rescue_incidents i
            LEFT JOIN rescue_units u ON u.id = i.assigned_unit_id
            WHERE i.id = :id
            SQL);
        $statement->execute(['id' => $id]);
        $row = $statement->fetch();
        if (!is_array($row)) {
            throw new AuthException('Incident not found.', 404);
        }

        return $this->incident($row);
    }

    private function incident(array $row): array
    {
        return ['id' => $row['id'], 'code' => $row['incident_code'], 'source' => $row['source'], 'callerName' => $row['caller_name'], 'callerPhone' => $row['caller_phone'], 'province' => $row['province'], 'location' => $row['location_text'], 'latitude' => $row['latitude'], 'longitude' => $row['longitude'], 'description' => $row['description'], 'priority' => $row['priority'], 'status' => $row['status'], 'unitId' => $row['assigned_unit_id'], 'unitCode' => $row['unit_code'] ?? null, 'unitName' => $row['unit_name'] ?? null, 'reportedAt' => $row['reported_at'], 'dispatchedAt' => $row['dispatched_at'], 'arrivedAt' => $row['arrived_at'], 'resolvedAt' => $row['resolved_at']];
    }

    private function unit(array $row): array
    {
        return ['id' => $row['id'], 'code' => $row['code'], 'name' => $row['name'], 'type' => $row['unit_type'], 'province' => $row['province'], 'baseName' => $row['base_name'], 'status' => $row['status'], 'phone' => $row['contact_phone']];
    }

    private function event(string $incident, string $actor, string $type, ?string $from, ?string $to, ?string $notes): void
    {
        $statement = $this->database->prepare('INSERT INTO rescue_incident_events (incident_id, actor_user_id, event_type, from_status, to_status, notes) VALUES (:incident, :actor, :type, :from_status, :to_status, :notes)');
        $statement->execute(['incident' => $incident, 'actor' => $actor, 'type' => $type, 'from_status' => $from, 'to_status' => $to, 'notes' => $notes]);
    }

    private function required(array $input, string $key, string $label): string { $value = is_string($input[$key] ?? null) ? trim($input[$key]) : ''; if ($value === '') throw new AuthException("{$label} is required.", 422); return $value; }
    private function optional(array $input, string $key): ?string { $value = is_string($input[$key] ?? null) ? trim($input[$key]) : ''; return $value === '' ? null : $value; }
    private function choice(mixed $value, array $allowed, string $label): string { $value = is_string($value) ? strtoupper(trim($value)) : ''; if (!in_array($value, $allowed, true)) throw new AuthException("Select a valid {$label}.", 422); return $value; }
    private function coordinate(mixed $value, float $min, float $max): ?float { if ($value === null || $value === '') return null; if (!is_numeric($value) || (float) $value < $min || (float) $value > $max) throw new AuthException('Enter valid coordinates.', 422); return (float) $value; }
}
