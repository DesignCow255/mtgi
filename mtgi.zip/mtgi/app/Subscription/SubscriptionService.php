<?php

declare(strict_types=1);

namespace Mamore\Subscription;

use DateTimeImmutable;
use DateTimeZone;
use Mamore\Auth\AuthException;
use Mamore\Core\AuditLog;
use Mamore\Core\Request;
use Mamore\Core\Uuid;
use Mamore\Support\FeeEngine;
use PDO;
use RuntimeException;

/**
 * Subscriptions are always priced from FeeEngine::catalog() (and therefore from
 * the seeded rescue_products catalog). Nothing in this class hard-codes a fee.
 *
 * Lifecycle (canonical SubscriptionStatus):
 *   create()  -> PENDING   (a subscription is only worth something once paid)
 *   payment   -> ACTIVE    (SubscriptionPaymentService::receive())
 *   renew()   -> RENEWED   (new linked subscription; the old one becomes RENEWED)
 *   expireDue()-> EXPIRED  (expiry sweep honouring the grace period)
 */
final class SubscriptionService
{
    private const PROVINCES = ['HAUT_KATANGA', 'LUALABA'];
    private const STATUSES = ['PENDING', 'ACTIVE', 'EXPIRED', 'SUSPENDED', 'CANCELLED', 'RENEWED'];
    private const GRACE_PERIOD_DAYS = 30;

    public function __construct(private readonly PDO $database) {}

    /**
     * Catalog-driven price quote for the subscription wizard (read-only).
     *
     * @return array<string, mixed>
     */
    public function quote(array $input): array
    {
        $productCode = $this->product($input['productCode'] ?? $input['product'] ?? $input['service'] ?? '');
        $province = $this->province($input['province'] ?? '');
        $product = FeeEngine::catalog()[$productCode];
        $durationMonths = $this->duration($input['durationMonths'] ?? null, $productCode);
        $chargeable = FeeEngine::chargeableBreakdown($productCode);
        $total = FeeEngine::total($chargeable);

        if ($total !== $product['totalFee']) {
            // Fail loud rather than quoting a broken price (risk register item 2).
            throw new RuntimeException("Catalog for {$productCode} does not reconcile: {$total} vs {$product['totalFee']}");
        }

        return [
            'product' => [
                'code' => $product['code'],
                'name' => $product['name'],
                'productType' => $product['productType'],
                'vehicleType' => $product['vehicleType'],
                'billingFrequency' => $product['billingFrequency'],
                'baseFee' => $product['baseFee'],
                'totalFee' => $product['totalFee'],
                'currency' => $product['currency'],
                'provinces' => $product['provinces'],
            ],
            'province' => $province,
            'durationMonths' => $durationMonths,
            'chargeable' => array_map([$this, 'line'], $chargeable),
            'subsets' => array_map([$this, 'line'], FeeEngine::rules($productCode, 'SUBSET')),
            'totals' => [
                'chargeableUsd' => $total,
                'taxableContainerUsd' => FeeEngine::taxableContainer($productCode),
                'subsetTotalUsd' => FeeEngine::subsetTotal($productCode),
                'reconciles' => FeeEngine::reconciles($chargeable, $product['totalFee']),
            ],
        ];
    }

    /**
     * Create (or reuse) a subscriber and open a PENDING subscription with its
     * fee lines and history. Staff may pass a subscriberId; the portal path
     * passes the authenticated subscriber instead.
     */
    public function create(array $input, ?array $actor = null, ?Request $request = null): array
    {
        $productCode = $this->product($input['productCode'] ?? $input['product'] ?? $input['service'] ?? '');
        $province = $this->province($input['province'] ?? '');
        $durationMonths = $this->duration($input['durationMonths'] ?? null, $productCode);
        $startDate = $this->date($input['startDate'] ?? null);
        $endDate = $startDate->modify("+{$durationMonths} months");
        $notes = is_string($input['notes'] ?? null) ? trim($input['notes']) : null;
        $total = FeeEngine::total(FeeEngine::chargeableBreakdown($productCode));

        if ($total !== FeeEngine::totalFor($productCode)) {
            throw new RuntimeException("Catalog for {$productCode} does not reconcile: {$total}");
        }

        $this->database->beginTransaction();
        try {
            $subscriberId = $this->resolveSubscriber($input, $actor);
            $id = Uuid::v4();
            $subscriptionNo = $this->subscriptionNo();

            $this->database->prepare(<<<'SQL'
                INSERT INTO subscriptions
                    (id, subscription_no, subscriber_id, product_id, status, membership_status, start_date, end_date,
                     expiry_date, grace_period_days, grace_end_date, total_amount, taxable_amount, province, notes,
                     created_by_user_id)
                VALUES
                    (:id, :number, :subscriber, :product, 'PENDING', 'PENDING', :start, :end, :expiry,
                     :grace, :graceEnd, :total, :taxable, :province, :notes, :actor)
                SQL)->execute([
                'id' => $id,
                'number' => $subscriptionNo,
                'subscriber' => $subscriberId,
                'product' => $this->productId($productCode),
                'start' => $startDate->format('Y-m-d'),
                'end' => $endDate->format('Y-m-d'),
                'expiry' => $endDate->format('Y-m-d'),
                'grace' => self::GRACE_PERIOD_DAYS,
                'graceEnd' => $endDate->modify('+' . self::GRACE_PERIOD_DAYS . ' days')->format('Y-m-d'),
                'total' => $total,
                'taxable' => FeeEngine::taxableContainer($productCode),
                'province' => $province,
                'notes' => $notes === '' ? null : $notes,
                'actor' => $actor['id'] ?? null,
            ]);

            $this->storeFees($id, $productCode);
            $this->history($id, 'CREATED', "Subscription {$subscriptionNo} opened as PENDING for {$total} USD", null, $actor['id'] ?? null);
            $this->audit('SUBSCRIPTION_CREATED', $id, $actor, $request, null, [
                'subscriptionNo' => $subscriptionNo,
                'status' => 'PENDING',
                'totalAmount' => $total,
                'taxableAmount' => FeeEngine::taxableContainer($productCode),
                'province' => $province,
                'productCode' => $productCode,
                'startDate' => $startDate->format('Y-m-d'),
                'endDate' => $endDate->format('Y-m-d'),
                'durationMonths' => $durationMonths,
            ], [
                'source' => 'subscription-create',
                'subscriberId' => $subscriberId,
            ]);
            $this->database->commit();
        } catch (\Throwable $error) {
            $this->database->rollBack();
            throw $error;
        }

        return $this->show($id);
    }

    /**
     * Renewal creates a NEW linked subscription and marks the previous one as
     * RENEWED (canonical renewedFromId / renewalCount semantics).
     */
    public function renew(array $input, ?array $actor = null, ?Request $request = null): array
    {
        $existing = $this->requireSubscription($this->required($input, 'subscriptionId', 'Subscription'));
        $productCode = FeeEngine::resolveProduct((string) ($existing['product_code'] ?? '')) ?? 'TRUCK_RESCUE';
        $province = $this->province($input['province'] ?? $existing['province']);
        $durationMonths = $this->duration($input['durationMonths'] ?? null, $productCode);
        $startDate = $this->date($input['startDate'] ?? null);
        $endDate = $startDate->modify("+{$durationMonths} months");
        $notes = is_string($input['notes'] ?? null) ? trim($input['notes']) : null;
        $total = FeeEngine::total(FeeEngine::chargeableBreakdown($productCode));

        $this->database->beginTransaction();
        try {
            $id = Uuid::v4();
            $subscriptionNo = $this->subscriptionNo();

            $this->database->prepare(<<<'SQL'
                INSERT INTO subscriptions
                    (id, subscription_no, subscriber_id, product_id, status, membership_status, start_date, end_date,
                     expiry_date, grace_period_days, grace_end_date, is_renewed, renewed_from_id, renewal_count,
                     total_amount, taxable_amount, province, notes, created_by_user_id)
                VALUES
                    (:id, :number, :subscriber, :product, 'PENDING', 'PENDING', :start, :end, :expiry,
                     :grace, :graceEnd, TRUE, :renewedFrom, :renewalCount, :total, :taxable, :province, :notes, :actor)
                SQL)->execute([
                'id' => $id,
                'number' => $subscriptionNo,
                'subscriber' => $existing['subscriber_id'],
                'product' => $this->productId($productCode),
                'start' => $startDate->format('Y-m-d'),
                'end' => $endDate->format('Y-m-d'),
                'expiry' => $endDate->format('Y-m-d'),
                'grace' => self::GRACE_PERIOD_DAYS,
                'graceEnd' => $endDate->modify('+' . self::GRACE_PERIOD_DAYS . ' days')->format('Y-m-d'),
                'renewedFrom' => $existing['id'],
                'renewalCount' => ((int) $existing['renewal_count']) + 1,
                'total' => $total,
                'taxable' => FeeEngine::taxableContainer($productCode),
                'province' => $province,
                'notes' => $notes === '' ? null : $notes,
                'actor' => $actor['id'] ?? null,
            ]);

            $this->storeFees($id, $productCode);
            $this->history($id, 'RENEWED', "Renewed from {$existing['subscription_no']}", null, $actor['id'] ?? null);

            $this->database->prepare("UPDATE subscriptions SET status = 'RENEWED', is_renewed = TRUE WHERE id = :id")
                ->execute(['id' => $existing['id']]);
            $this->history($existing['id'], 'RENEWED', "Renewed into {$subscriptionNo}", null, $actor['id'] ?? null);
            $this->audit('SUBSCRIPTION_RENEWED', $existing['id'], $actor, $request, ['status' => $existing['status']], [
                'status' => 'RENEWED',
                'renewedInto' => $subscriptionNo,
                'renewalCount' => ((int) $existing['renewal_count']) + 1,
            ], [
                'source' => 'subscription-renew',
                'newSubscriptionId' => $id,
                'newSubscriptionNo' => $subscriptionNo,
            ]);
            $this->database->commit();
        } catch (\Throwable $error) {
            $this->database->rollBack();
            throw $error;
        }

        return $this->show($id);
    }

    /**
     * Move a subscription to another canonical status, keeping membership_status
     * and the history trail in step (canonical updateStatus()).
     */
    public function updateStatus(array $input, ?array $actor = null, ?Request $request = null): array
    {
        $subscription = $this->requireSubscription($this->required($input, 'subscriptionId', 'Subscription'));
        $status = $this->status($input['status'] ?? '');
        $reason = is_string($input['reason'] ?? null) ? trim($input['reason']) : '';

        $membership = match ($status) {
            'ACTIVE', 'RENEWED' => 'ACTIVE',
            'EXPIRED' => 'EXPIRED',
            'SUSPENDED' => 'SUSPENDED',
            'CANCELLED' => 'CANCELLED',
            default => 'PENDING',
        };

        $this->database->beginTransaction();
        try {
            $this->database->prepare('UPDATE subscriptions SET status = :status, membership_status = :membership WHERE id = :id')
                ->execute(['status' => $status, 'membership' => $membership, 'id' => $subscription['id']]);
            $this->history(
                $subscription['id'],
                'STATUS_CHANGED',
                trim("Status changed from {$subscription['status']} to {$status}. {$reason}"),
                ['from' => $subscription['status'], 'to' => $status, 'reason' => $reason === '' ? null : $reason],
                $actor['id'] ?? null
            );
            $this->audit('SUBSCRIPTION_STATUS_CHANGED', $subscription['id'], $actor, $request, [
                'status' => $subscription['status'],
                'membershipStatus' => $subscription['membership_status'],
            ], [
                'status' => $status,
                'membershipStatus' => $membership,
            ], [
                'source' => 'subscription-status',
                'reason' => $reason === '' ? null : $reason,
                'subscriptionNo' => $subscription['subscription_no'],
            ]);
            $this->database->commit();
        } catch (\Throwable $error) {
            $this->database->rollBack();
            throw $error;
        }

        return $this->show($subscription['id']);
    }

    /**
     * Activate a paid subscription. Called by the payment service inside its own
     * transaction, so this method never opens one itself.
     */
    public function activatePaid(string $subscriptionId, ?string $actorId = null): array
    {
        $this->requireSubscription($subscriptionId);
        $this->database->prepare("UPDATE subscriptions SET status = 'ACTIVE', membership_status = 'ACTIVE' WHERE id = :id")
            ->execute(['id' => $subscriptionId]);
        $this->history($subscriptionId, 'ACTIVATED', 'Payment received; membership activated.', null, $actorId);

        return $this->show($subscriptionId);
    }

    /**
     * Expiry sweep: ACTIVE subscriptions past expiry + grace become EXPIRED.
     *
     * @return list<string> affected subscription numbers
     */
    public function expireDue(): array
    {
        $due = $this->database->query(<<<'SQL'
            SELECT id, subscription_no FROM subscriptions
            WHERE status = 'ACTIVE' AND COALESCE(grace_end_date, expiry_date) < UTC_DATE()
            SQL)->fetchAll();
        if ($due === []) {
            return [];
        }

        $this->database->beginTransaction();
        try {
            $update = $this->database->prepare("UPDATE subscriptions SET status = 'EXPIRED', membership_status = 'EXPIRED' WHERE id = :id");
            foreach ($due as $row) {
                $update->execute(['id' => $row['id']]);
                $this->history($row['id'], 'EXPIRED', 'Grace period elapsed; membership expired.');
            }
            $this->database->commit();
        } catch (\Throwable $error) {
            $this->database->rollBack();
            throw $error;
        }

        return array_map(static fn (array $row): string => $row['subscription_no'], $due);
    }

    /** Full subscription payload (fees, subscriber, history). */
    public function show(string $id): array
    {
        return $this->hydrate($this->requireSubscription($id), true);
    }

    /**
     * Roll a subscription back to PENDING after its payment was voided. Called by
     * the payment service inside its transaction.
     */
    public function markPaymentVoided(string $subscriptionId, string $reason, ?string $actorId = null, ?Request $request = null): void
    {
        $subscription = $this->requireSubscription($subscriptionId);
        if (in_array($subscription['status'], ['CANCELLED', 'PENDING'], true)) {
            return;
        }
        $this->database->prepare(
            "UPDATE subscriptions SET status = 'PENDING', membership_status = 'PENDING' WHERE id = :id"
        )->execute(['id' => $subscriptionId]);
        $this->history($subscriptionId, 'PAYMENT_VOIDED', "Payment voided: {$reason}", ['reason' => $reason], $actorId);
        $this->audit(
            'SUBSCRIPTION_PAYMENT_VOIDED',
            $subscriptionId,
            $actorId === null ? null : ['id' => $actorId],
            $request,
            ['status' => $subscription['status'], 'membershipStatus' => $subscription['membership_status']],
            ['status' => 'PENDING', 'membershipStatus' => 'PENDING'],
            ['source' => 'subscription-payment-void', 'reason' => $reason]
        );
    }

    /**
     * Subscriber id behind a portal account (created and linked on first use), so
     * portal endpoints can scope every query to the caller.
     */
    public function subscriberIdForUser(array $user): string
    {
        return $this->subscriberForUser($user);
    }

    /**
     * Staff listing with optional filters: subscriberId, status, province,
     * productCode, search (subscription / membership number / name), limit.
     */
    public function list(array $filters = []): array
    {
        $where = [];
        $params = [];
        if (($filters['subscriberId'] ?? '') !== '') {
            $where[] = 's.subscriber_id = :subscriber';
            $params['subscriber'] = (string) $filters['subscriberId'];
        }
        if (($filters['status'] ?? '') !== '') {
            $where[] = 's.status = :status';
            $params['status'] = $this->status($filters['status']);
        }
        if (($filters['province'] ?? '') !== '') {
            $where[] = 's.province = :province';
            $params['province'] = $this->province($filters['province']);
        }
        if (($filters['productCode'] ?? '') !== '') {
            $where[] = 'p.code = :product';
            $params['product'] = $this->product($filters['productCode']);
        }
        if (($filters['search'] ?? '') !== '') {
            $where[] = '(s.subscription_no LIKE :search OR sub.membership_number LIKE :search OR sub.first_name LIKE :search'
                . ' OR sub.last_name LIKE :search OR sub.company_name LIKE :search)';
            $params['search'] = '%' . str_replace(['%', '_'], ['\\%', '\\_'], (string) $filters['search']) . '%';
        }
        $limit = min(max((int) ($filters['limit'] ?? 50), 1), 200);

        $sql = "SELECT s.*, p.code AS product_code, p.name AS product_name,
                       COALESCE(NULLIF(TRIM(CONCAT_WS(' ', sub.first_name, sub.last_name)), ''), sub.company_name) AS subscriber_name,
                       sub.membership_number
                FROM subscriptions s
                JOIN subscribers sub ON sub.id = s.subscriber_id
                LEFT JOIN rescue_products p ON p.id = s.product_id";
        if ($where !== []) {
            $sql .= ' WHERE ' . implode(' AND ', $where);
        }
        $sql .= ' ORDER BY s.created_at DESC LIMIT ' . $limit;

        $statement = $this->database->prepare($sql);
        $statement->execute($params);

        return array_map([$this, 'hydrate'], $statement->fetchAll());
    }

    public function forSubscriber(string $subscriberId): array
    {
        return $this->list(['subscriberId' => $subscriberId, 'limit' => 200]);
    }

    /** Subscriptions whose expiry or grace end falls within the next N days. */
    public function expiringWithin(int $days = 30): array
    {
        $days = max(0, min($days, 3650));
        $statement = $this->database->prepare(<<<'SQL'
            SELECT s.*, p.code AS product_code, p.name AS product_name FROM subscriptions s
            LEFT JOIN rescue_products p ON p.id = s.product_id
            WHERE s.status = 'ACTIVE'
              AND COALESCE(s.grace_end_date, s.expiry_date) BETWEEN UTC_DATE() AND DATE_ADD(UTC_DATE(), INTERVAL :days DAY)
            ORDER BY s.expiry_date ASC LIMIT 200
            SQL);
        $statement->execute(['days' => $days]);

        return array_map([$this, 'hydrate'], $statement->fetchAll());
    }

    /** History trail of one subscription (oldest first). */
    public function historyOf(string $subscriptionId): array
    {
        $this->requireSubscription($subscriptionId);
        $statement = $this->database->prepare(
            'SELECT action, description, metadata, created_at FROM subscription_history WHERE subscription_id = :id ORDER BY id ASC'
        );
        $statement->execute(['id' => $subscriptionId]);

        return array_map(static fn (array $row): array => [
            'action' => $row['action'],
            'description' => $row['description'],
            'metadata' => $row['metadata'] !== null ? json_decode((string) $row['metadata'], true) : null,
            'createdAt' => $row['created_at'],
        ], $statement->fetchAll());
    }

    /**
     * Resolve the subscriber for a subscription: explicit id, an inline
     * subscriber payload (membership number dedupe like the canonical service),
     * or the subscriber linked to the acting portal user.
     */
    private function resolveSubscriber(array $input, ?array $actor): string
    {
        $subscriberId = is_string($input['subscriberId'] ?? null) ? trim($input['subscriberId']) : '';
        if ($subscriberId !== '') {
            $statement = $this->database->prepare('SELECT id FROM subscribers WHERE id = :id AND deleted_at IS NULL');
            $statement->execute(['id' => $subscriberId]);
            $row = $statement->fetch();
            if (!is_array($row)) {
                throw new AuthException('Subscriber not found.', 404);
            }
            $this->storeVehicles($row['id'], $input['vehicles'] ?? []);

            return $row['id'];
        }

        $details = is_array($input['subscriber'] ?? null) ? $input['subscriber'] : [];
        if ($details === [] && is_array($actor)) {
            $subscriberId = $this->subscriberForUser($actor, $input['vehicles'] ?? []);
            return $subscriberId;
        }

        $membershipNumber = is_string($details['membershipNumber'] ?? null) ? trim($details['membershipNumber']) : '';
        if ($membershipNumber !== '') {
            $statement = $this->database->prepare('SELECT id FROM subscribers WHERE membership_number = :number AND deleted_at IS NULL');
            $statement->execute(['number' => $membershipNumber]);
            $existing = $statement->fetchColumn();
            if (is_string($existing) && $existing !== '') {
                $this->storeVehicles($existing, $input['vehicles'] ?? []);

                return $existing;
            }
        }

        $firstName = is_string($details['firstName'] ?? null) ? trim($details['firstName']) : '';
        $lastName = is_string($details['lastName'] ?? null) ? trim($details['lastName']) : '';
        $companyName = is_string($details['companyName'] ?? null) ? trim($details['companyName']) : '';
        if ($firstName === '' && $companyName === '') {
            throw new AuthException('Provide the subscriber name or company name.', 422);
        }

        $id = Uuid::v4();
        $this->database->prepare(<<<'SQL'
            INSERT INTO subscribers
                (id, membership_number, first_name, last_name, company_name, email, phone, alternative_phone,
                 national_id, passport_number, company_registration, emergency_contact, emergency_phone,
                 gps_latitude, gps_longitude, notes)
            VALUES
                (:id, :number, :firstName, :lastName, :companyName, :email, :phone, :alternativePhone,
                 :nationalId, :passport, :companyRegistration, :emergencyContact, :emergencyPhone,
                 :latitude, :longitude, :notes)
            SQL)->execute([
            'id' => $id,
            'number' => $membershipNumber !== '' ? $membershipNumber : $this->membershipNumber(),
            'firstName' => $firstName === '' ? null : $firstName,
            'lastName' => $lastName === '' ? null : $lastName,
            'companyName' => $companyName === '' ? null : $companyName,
            'email' => $this->nullableString($details['email'] ?? null),
            'phone' => $this->nullableString($details['phone'] ?? null),
            'alternativePhone' => $this->nullableString($details['alternativePhone'] ?? null),
            'nationalId' => $this->nullableString($details['nationalId'] ?? null),
            'passport' => $this->nullableString($details['passportNumber'] ?? null),
            'companyRegistration' => $this->nullableString($details['companyRegistration'] ?? null),
            'emergencyContact' => $this->nullableString($details['emergencyContact'] ?? null),
            'emergencyPhone' => $this->nullableString($details['emergencyPhone'] ?? null),
            'latitude' => $this->coordinate($details['gpsLatitude'] ?? null, -90.0, 90.0),
            'longitude' => $this->coordinate($details['gpsLongitude'] ?? null, -180.0, 180.0),
            'notes' => $this->nullableString($details['notes'] ?? null),
        ]);

        $this->subscriberHistory($id, 'CREATED', 'Subscriber created with a rescue subscription.', is_string($actor['id'] ?? null) ? $actor['id'] : null);
        $this->storeVehicles($id, $input['vehicles'] ?? []);

        return $id;
    }

    private function subscriberHistory(string $subscriberId, string $action, string $description, ?string $actorId): void
    {
        $this->database->prepare(
            'INSERT INTO subscriber_history (subscriber_id, action, description, created_by_user_id)
             VALUES (:subscriber, :action, :description, :actor)'
        )->execute([
            'subscriber' => $subscriberId,
            'action' => $action,
            'description' => $description,
            'actor' => $actorId,
        ]);
    }

    /** Subscriber linked to a portal login, created + linked on first use. */
    private function subscriberForUser(array $user, array $vehicles = []): string
    {
        $linked = $user['subscriber_id'] ?? null;
        if (is_string($linked) && $linked !== '') {
            $this->storeVehicles($linked, $vehicles);

            return $linked;
        }

        $firstName = trim((string) ($user['first_name'] ?? ''));
        $lastName = trim((string) ($user['last_name'] ?? ''));
        if ($firstName === '') {
            throw new AuthException('Your account has no subscriber profile; contact HQ.', 422);
        }

        $id = Uuid::v4();
        $this->database->prepare(
            'INSERT INTO subscribers (id, membership_number, first_name, last_name, email, phone) VALUES (:id, :number, :firstName, :lastName, :email, :phone)'
        )->execute([
            'id' => $id,
            'number' => $this->membershipNumber(),
            'firstName' => $firstName,
            'lastName' => $lastName === '' ? null : $lastName,
            'email' => $this->nullableString($user['email'] ?? null),
            'phone' => $this->nullableString($user['phone'] ?? null),
        ]);
        $this->database->prepare('UPDATE users SET subscriber_id = :subscriber WHERE id = :id')
            ->execute(['subscriber' => $id, 'id' => $user['id']]);
        $this->subscriberHistory($id, 'PROFILE_LINKED', 'Subscriber profile created from the portal account.', $user['id']);
        $this->storeVehicles($id, $vehicles);

        return $id;
    }

    /**
     * Persist the catalog fee lines of a subscription. CHARGEABLE lines are the
     * ones that reconcile to the total; SUBSET lines stay informational and are
     * never summed into total_amount.
     */
    private function storeFees(string $subscriptionId, string $productCode): void
    {
        $insert = $this->database->prepare(<<<'SQL'
            INSERT INTO subscription_fees
                (id, subscription_id, component_key, component_name, component_type, category, allocation_role,
                 ledger_account, amount, is_taxable, province, display_order)
            VALUES
                (:id, :subscription, :key, :name, :type, :category, :role,
                 :ledger, :amount, :taxable, :province, :order)
            SQL);

        $order = 0;
        foreach (FeeEngine::rules($productCode) as $rule) {
            $insert->execute([
                'id' => Uuid::v4(),
                'subscription' => $subscriptionId,
                'key' => $rule['key'],
                'name' => $rule['name'],
                'type' => $rule['componentType'],
                'category' => $rule['category'],
                'role' => $rule['role'],
                'ledger' => $rule['ledgerAccount'],
                'amount' => $rule['amount'],
                'taxable' => $rule['isTaxable'] ? 1 : 0,
                'province' => $rule['province'],
                'order' => ++$order,
            ]);
        }
    }

    /** Register the vehicles declared with a subscription (idempotent per plate). */
    private function storeVehicles(string $subscriberId, array $vehicles): void
    {
        if ($vehicles === []) {
            return;
        }

        $insert = $this->database->prepare(<<<'SQL'
            INSERT INTO subscriber_vehicles
                (id, subscriber_id, plate_number, vehicle_make, vehicle_model, vehicle_year, chassis_no, engine_no, cargo_category)
            VALUES
                (:id, :subscriber, :plate, :make, :model, :year, :chassis, :engine, :cargo)
            SQL);

        foreach ($vehicles as $vehicle) {
            if (!is_array($vehicle)) {
                continue;
            }
            $plate = is_string($vehicle['plateNumber'] ?? null) ? strtoupper(trim($vehicle['plateNumber'])) : '';
            if ($plate === '') {
                continue;
            }
            $exists = $this->database->prepare('SELECT COUNT(*) FROM subscriber_vehicles WHERE subscriber_id = :subscriber AND plate_number = :plate');
            $exists->execute(['subscriber' => $subscriberId, 'plate' => $plate]);
            if ((int) $exists->fetchColumn() > 0) {
                continue;
            }
            $cargo = is_string($vehicle['cargoCategory'] ?? null) ? strtoupper(trim($vehicle['cargoCategory'])) : 'GENERAL';
            if (!in_array($cargo, ['GENERAL', 'PERISHABLE', 'HAZARDOUS', 'HEAVY', 'CONTAINER', 'LIVESTOCK', 'OTHER'], true)) {
                $cargo = 'GENERAL';
            }
            $insert->execute([
                'id' => Uuid::v4(),
                'subscriber' => $subscriberId,
                'plate' => $plate,
                'make' => $this->nullableString($vehicle['vehicleMake'] ?? null),
                'model' => $this->nullableString($vehicle['vehicleModel'] ?? null),
                'year' => is_numeric($vehicle['vehicleYear'] ?? null) ? (int) $vehicle['vehicleYear'] : null,
                'chassis' => $this->nullableString($vehicle['chassisNo'] ?? null),
                'engine' => $this->nullableString($vehicle['engineNo'] ?? null),
                'cargo' => $cargo,
            ]);
        }
    }

    /**
     * API payload for one subscription row. Money stays an exact decimal string;
     * detail mode adds the fee lines and the history trail.
     */
    private function hydrate(array $row, bool $withDetail = false): array
    {
        $productCode = is_string($row['product_code'] ?? null) && $row['product_code'] !== ''
            ? (string) $row['product_code']
            : $this->productCodeFor($row['product_id'] ?? null);

        return [
            'id' => $row['id'],
            'subscriptionNo' => $row['subscription_no'],
            'subscriberId' => $row['subscriber_id'],
            'subscriberName' => $row['subscriber_name'] ?? null,
            'membershipNumber' => $row['membership_number'] ?? null,
            'productCode' => $productCode,
            'productName' => is_string($row['product_name'] ?? null)
                ? $row['product_name']
                : ($productCode !== null ? FeeEngine::catalog()[$productCode]['name'] : null),
            'status' => $row['status'],
            'membershipStatus' => $row['membership_status'],
            'startDate' => $row['start_date'],
            'endDate' => $row['end_date'],
            'expiryDate' => $row['expiry_date'],
            'gracePeriodDays' => (int) $row['grace_period_days'],
            'graceEndDate' => $row['grace_end_date'],
            'isRenewed' => (bool) $row['is_renewed'],
            'renewedFromId' => $row['renewed_from_id'],
            'renewalCount' => (int) $row['renewal_count'],
            'totalAmount' => bcadd((string) $row['total_amount'], '0', 2),
            'taxableAmount' => bcadd((string) $row['taxable_amount'], '0', 2),
            'currency' => $row['currency'],
            'province' => $row['province'],
            'notes' => $row['notes'],
            'createdAt' => $row['created_at'],
            'updatedAt' => $row['updated_at'],
            'fees' => $withDetail ? $this->fees($row['id']) : null,
            'history' => $withDetail ? $this->historyOf($row['id']) : null,
        ];
    }

    /**
     * Fee lines of a subscription split by allocation role, with reconciled
     * totals. CHARGEABLE lines reconcile to the subscription total; SUBSET lines
     * are informational sub-allocations of a taxable container.
     *
     * @return array{chargeable:list<array<string,mixed>>,subsets:list<array<string,mixed>>,totals:array<string,mixed>}
     */
    private function fees(string $subscriptionId): array
    {
        $statement = $this->database->prepare(
            'SELECT * FROM subscription_fees WHERE subscription_id = :id ORDER BY display_order ASC'
        );
        $statement->execute(['id' => $subscriptionId]);
        $chargeable = [];
        $subsets = [];
        foreach ($statement->fetchAll() as $row) {
            $payload = [
                'key' => $row['component_key'],
                'name' => $row['component_name'],
                'componentType' => $row['component_type'],
                'category' => $row['category'],
                'role' => $row['allocation_role'],
                'ledgerAccount' => $row['ledger_account'],
                'amount' => bcadd((string) $row['amount'], '0', 2),
                'isTaxable' => (bool) $row['is_taxable'],
                'province' => $row['province'],
            ];
            if ($row['allocation_role'] === 'CHARGEABLE') {
                $chargeable[] = $payload;
            } else {
                $subsets[] = $payload;
            }
        }

        $chargeableTotal = FeeEngine::total($chargeable);
        $subsetTotal = FeeEngine::total($subsets);

        return [
            'chargeable' => $chargeable,
            'subsets' => $subsets,
            'totals' => [
                'chargeableUsd' => $chargeableTotal,
                'subsetTotalUsd' => $subsetTotal,
                'reconciles' => bccomp($chargeableTotal, $subsetTotal, 2) >= 0,
            ],
        ];
    }

    private function productCodeFor(mixed $productId): ?string
    {
        if (!is_string($productId) || $productId === '') {
            return null;
        }
        $statement = $this->database->prepare('SELECT code FROM rescue_products WHERE id = :id');
        $statement->execute(['id' => $productId]);
        $code = $statement->fetchColumn();

        return is_string($code) ? $code : null;
    }

    private function productId(string $productCode): string
    {
        $statement = $this->database->prepare('SELECT id FROM rescue_products WHERE code = :code AND status = :status');
        $statement->execute(['code' => $productCode, 'status' => 'ACTIVE']);
        $id = $statement->fetchColumn();
        if (!is_string($id) || $id === '') {
            throw new RuntimeException("Rescue product {$productCode} is not configured; run php bin/migrate.php");
        }

        return $id;
    }

    private function requireSubscription(string $id): array
    {
        $statement = $this->database->prepare(
            'SELECT s.*, p.code AS product_code, p.name AS product_name FROM subscriptions s
             LEFT JOIN rescue_products p ON p.id = s.product_id WHERE s.id = :id'
        );
        $statement->execute(['id' => $id]);
        $row = $statement->fetch();
        if (!is_array($row)) {
            throw new AuthException('Subscription not found.', 404);
        }

        return $row;
    }

    /**
     * Append to the append-only audit trail (see Mamore\Core\AuditLog).
     *
     * @param array<string,mixed>|null $previous
     * @param array<string,mixed>|null $new
     * @param array<string,mixed>|null $metadata
     */
    private function audit(
        string $action,
        string $subscriptionId,
        ?array $actor,
        ?Request $request,
        ?array $previous,
        ?array $new,
        ?array $metadata = null,
    ): void {
        (new AuditLog($this->database))->write(
            $action,
            'Subscription',
            $subscriptionId,
            $actor,
            $request,
            $previous,
            $new,
            $metadata
        );
    }

    private function history(string $subscriptionId, string $action, string $description, ?array $metadata = null, ?string $actorId = null): void
    {
        $this->database->prepare(
            'INSERT INTO subscription_history (subscription_id, action, description, metadata, created_by_user_id)
             VALUES (:id, :action, :description, :metadata, :actor)'
        )->execute([
            'id' => $subscriptionId,
            'action' => $action,
            'description' => $description,
            'metadata' => $metadata === null ? null : json_encode($metadata, JSON_THROW_ON_ERROR),
            'actor' => $actorId,
        ]);
    }

    private function subscriptionNo(): string
    {
        return 'SUB-' . gmdate('ymd') . '-' . strtoupper(bin2hex(random_bytes(3)));
    }

    private function membershipNumber(): string
    {
        return 'MEM-' . gmdate('ymd') . '-' . strtoupper(bin2hex(random_bytes(3)));
    }

    /** @return array{key:string,name:string,amount:string} */
    private function line(array $rule): array
    {
        return ['key' => $rule['key'], 'name' => $rule['name'], 'amount' => $rule['amount']];
    }

    private function product(mixed $value): string
    {
        $code = is_string($value) ? FeeEngine::resolveProduct($value) : null;
        if ($code === null) {
            throw new AuthException('Select a valid rescue product.', 422);
        }

        return $code;
    }

    private function province(mixed $value): string
    {
        $province = is_string($value) ? strtoupper(trim($value)) : '';
        if (!in_array($province, self::PROVINCES, true)) {
            throw new AuthException('Select a valid province.', 422);
        }

        return $province;
    }

    private function status(mixed $value): string
    {
        $status = is_string($value) ? strtoupper(trim($value)) : '';
        if (!in_array($status, self::STATUSES, true)) {
            throw new AuthException('Select a valid subscription status.', 422);
        }

        return $status;
    }

    /**
     * Default duration follows the product billing frequency: monthly products
     * run for one month, one-off products cover the 12 month canonical period.
     * Both remain overridable through durationMonths.
     */
    private function duration(mixed $value, string $productCode): int
    {
        if ($value !== null && $value !== '') {
            if (!is_numeric($value)) {
                throw new AuthException('Duration must be a number of months.', 422);
            }
            $months = (int) $value;
            if ($months < 1 || $months > 60) {
                throw new AuthException('Duration must be between 1 and 60 months.', 422);
            }

            return $months;
        }

        $frequency = FeeEngine::catalog()[$productCode]['billingFrequency'] ?? 'ANNUAL';

        return $frequency === 'MONTHLY' ? 1 : 12;
    }

    private function date(mixed $value): DateTimeImmutable
    {
        $timezone = new DateTimeZone('UTC');
        if (!is_string($value) || trim($value) === '') {
            return new DateTimeImmutable('today', $timezone);
        }
        $parsed = DateTimeImmutable::createFromFormat('!Y-m-d', trim($value), $timezone);
        if (!$parsed instanceof DateTimeImmutable) {
            throw new AuthException('Enter a valid date (YYYY-MM-DD).', 422);
        }

        return $parsed;
    }

    private function required(array $input, string $key, string $label): string
    {
        $value = is_string($input[$key] ?? null) ? trim($input[$key]) : '';
        if ($value === '') {
            throw new AuthException("{$label} is required.", 422);
        }

        return $value;
    }

    private function nullableString(mixed $value): ?string
    {
        if (!is_string($value)) {
            return null;
        }
        $trimmed = trim($value);

        return $trimmed === '' ? null : $trimmed;
    }

    private function coordinate(mixed $value, float $min, float $max): ?float
    {
        if ($value === null || $value === '') {
            return null;
        }
        if (!is_numeric($value) || (float) $value < $min || (float) $value > $max) {
            throw new AuthException('Enter valid GPS coordinates.', 422);
        }

        return (float) $value;
    }
}
