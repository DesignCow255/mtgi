<?php

declare(strict_types=1);

namespace Mamore\Portal;

use Mamore\SmartBus\SmartBusService;
use PDO;

final class CustomerPortalService
{
    public function __construct(private readonly PDO $database) {}

    public function trips(): array
    {
        $rows = $this->database->query(<<<'SQL'
            SELECT t.id, t.trip_code, t.departure_at, t.fare_cdf, t.rescue_fee_usd, t.usd_cdf_rate, t.status,
                   r.origin, r.destination, v.capacity, v.code AS vehicle_code, o.name AS operator_name,
                   (SELECT COUNT(*) FROM smartbus_bookings b WHERE b.trip_id=t.id AND b.status IN ('CONFIRMED','BOARDED')) AS booked_seats
            FROM smartbus_trips t JOIN smartbus_routes r ON r.id=t.route_id JOIN smartbus_vehicles v ON v.id=t.vehicle_id
            JOIN smartbus_operators o ON o.id=v.operator_id
            WHERE t.status IN ('SCHEDULED','BOARDING') AND t.departure_at > UTC_TIMESTAMP(6)
            ORDER BY t.departure_at ASC LIMIT 50
            SQL)->fetchAll();
        foreach ($rows as &$row) {
            $statement=$this->database->prepare("SELECT seat_number FROM smartbus_bookings WHERE trip_id=:id AND status IN ('CONFIRMED','BOARDED') ORDER BY seat_number");
            $statement->execute(['id'=>$row['id']]); $row['occupied_seats']=array_map('intval',$statement->fetchAll(PDO::FETCH_COLUMN));
        }
        unset($row);
        return array_map(static fn(array $row):array=>[
            'id'=>$row['id'],'code'=>$row['trip_code'],'origin'=>$row['origin'],'destination'=>$row['destination'],
            'departureAt'=>$row['departure_at'],'fareCdf'=>(float)$row['fare_cdf'],'rescueFeeUsd'=>(float)$row['rescue_fee_usd'],
            'usdCdfRate'=>(float)$row['usd_cdf_rate'],'status'=>$row['status'],'capacity'=>(int)$row['capacity'],
            'bookedSeats'=>(int)$row['booked_seats'],'occupiedSeats'=>$row['occupied_seats'],'vehicleCode'=>$row['vehicle_code'],
            'operatorName'=>$row['operator_name'],
        ],$rows);
    }

    public function bookings(array $user): array
    {
        $statement=$this->database->prepare(<<<'SQL'
            SELECT b.id,b.booking_reference,b.seat_number,b.passenger_name,b.fare_cdf,b.rescue_fee_usd,b.rescue_fee_cdf,
                   b.total_cdf,b.status,b.qr_payload,b.created_at,t.trip_code,t.departure_at,r.origin,r.destination,o.name AS operator_name,
                   COALESCE(f.status,'UNPAID') AS payment_status,f.receipt_number
            FROM smartbus_bookings b JOIN smartbus_trips t ON t.id=b.trip_id JOIN smartbus_routes r ON r.id=t.route_id
            JOIN smartbus_vehicles v ON v.id=t.vehicle_id JOIN smartbus_operators o ON o.id=v.operator_id
            LEFT JOIN finance_transactions f ON f.smartbus_booking_id=b.id
            WHERE b.created_by_user_id=:user ORDER BY b.created_at DESC
            SQL);
        $statement->execute(['user'=>$user['id']]);
        return array_map(static fn(array $row):array=>[
            'id'=>$row['id'],'reference'=>$row['booking_reference'],'seatNumber'=>(int)$row['seat_number'],
            'passengerName'=>$row['passenger_name'],'fareCdf'=>(float)$row['fare_cdf'],'rescueFeeUsd'=>(float)$row['rescue_fee_usd'],
            'rescueFeeCdf'=>(float)$row['rescue_fee_cdf'],'totalCdf'=>(float)$row['total_cdf'],'status'=>$row['status'],
            'qrPayload'=>$row['qr_payload'],'createdAt'=>$row['created_at'],'tripCode'=>$row['trip_code'],
            'departureAt'=>$row['departure_at'],'origin'=>$row['origin'],'destination'=>$row['destination'],
            'operatorName'=>$row['operator_name'],'paymentStatus'=>$row['payment_status'],'receiptNumber'=>$row['receipt_number'],
        ],$statement->fetchAll());
    }

    public function book(array $input,array $user): array
    {
        $input['passengerName']=trim($user['first_name'].' '.$user['last_name']);
        $input['passengerPhone']=$user['phone'] ?: ($input['passengerPhone']??'');
        return (new SmartBusService($this->database))->book($input,$user);
    }
}
