<?php

declare(strict_types=1);

namespace Mamore\Dashboard;

use Mamore\Core\ServerClock;
use PDO;

/**
 * The executive overview.
 *
 * The landing screen of an operations platform used to answer "how many users
 * and sessions are there" -- authentication telemetry presented as the state of
 * the business. It now answers "what is Mamore doing right now", assembled from
 * queries that already existed in ControlCenterService, FinanceService and
 * SubscriptionService rather than new ones.
 *
 * TWO RULES THIS CLASS KEEPS
 *
 * 1. NOTHING IS FABRICATED. Every figure is a COUNT or an aggregate the database
 *    actually produced. Where a metric has no history, the trend is null and the
 *    UI shows context instead of a percentage. A comparison that cannot be
 *    computed is reported as unavailable, never as 0%.
 *
 * 2. NO SILENT ZEROS. A KPI carries a `state` alongside its value: `ok` when the
 *    query ran, `unavailable` when it did not. The four-state contract in
 *    assets/js/core/states.js renders those differently, which is the direct fix
 *    for the audit finding that a failed fetch rendered as a zero.
 *
 * The executive summary sentence is GENERATED from the counts it is built from
 * and the counts are returned alongside it, so the sentence is verifiable rather
 * than persuasive.
 */
final class ExecutiveService
{
    /** Freshness windows, in seconds. Declared once, here, not per screen. */
    private const GPS_STALE = 120;
    private const GPS_DEAD = 600;

    public function __construct(private readonly PDO $database) {}

    /**
     * @param array<string,mixed> $filters
     *
     * @return array<string,mixed>
     */
    public function overview(array $filters = [], ?array $actor = null): array
    {
        $clock = ServerClock::epoch($this->database);
        $period = $this->period($filters);
        [$previousFrom, $previousTo] = $this->previousWindow($period);

        $now = [
            'trackedAssets' => $this->count("SELECT COUNT(*) FROM tracked_assets WHERE status = 'ACTIVE'"),
            'activeJourneys' => $this->count("SELECT COUNT(*) FROM active_journeys WHERE status = 'ACTIVE'"),
            'smartBusPassengers' => $this->count('SELECT COUNT(*) FROM active_journeys WHERE status = \'ACTIVE\''),
            'cargoInTransit' => $this->count("SELECT COUNT(*) FROM truck_journeys WHERE status IN ('IN_TRANSIT','DELAYED')"),
            'privateVehiclesOnline' => $this->count(
                "SELECT COUNT(*) FROM tracked_assets WHERE status = 'ACTIVE' AND asset_type = 'PRIVATE_VEHICLE'
                 AND tracking_status = 'ONLINE'
                 AND EXISTS (SELECT 1 FROM tracked_asset_positions p WHERE p.tracked_asset_id = tracked_assets.id
                             AND p.recorded_at >= DATE_SUB(UTC_TIMESTAMP(6), INTERVAL 2 MINUTE))"
            ),
            'vipTravelling' => $this->count("SELECT COUNT(*) FROM vip_subscribers WHERE status = 'ACTIVE'"),
            'openIncidents' => $this->count("SELECT COUNT(*) FROM rescue_incidents WHERE resolved_at IS NULL"),
            // Counts on PRIORITY, not severity. These are two different columns
            // and the difference matters: RescueService::report() writes
            // `priority` on intake and never writes `severity`, which therefore
            // sits at its MEDIUM default for every row. Counting on severity
            // reported 0 critical incidents while 5 were open -- the KPI was
            // structurally incapable of ever being non-zero.
            //
            // RescueService::board() already counts on priority (critical: 5),
            // so this also makes the two screens agree.
            'criticalIncidents' => $this->count("SELECT COUNT(*) FROM rescue_incidents WHERE resolved_at IS NULL AND priority = 'CRITICAL'"),
            'rescueTeamsAvailable' => $this->count("SELECT COUNT(*) FROM rescue_units WHERE status = 'AVAILABLE'"),
            // tracking_status is a varchar whose DEFAULT is 'UNKNOWN'. Assets
            // sitting at UNKNOWN or NO_DEVICE have never reported a position.
            // That is a THIRD state, and counting it as "offline" would invent
            // an outage that did not happen -- so it is counted and shown
            // separately rather than folded into either bucket.
            'gpsOffline' => $this->count(
                "SELECT COUNT(*) FROM tracked_assets WHERE status = 'ACTIVE' AND tracking_status = 'OFFLINE'"
            ),
            'gpsUnknown' => $this->count(
                "SELECT COUNT(*) FROM tracked_assets
                 WHERE status = 'ACTIVE' AND tracking_status IN ('UNKNOWN', 'NO_DEVICE')"
            ),
            'gpsStale' => $this->count(
                "SELECT COUNT(*) FROM tracked_assets a
                 WHERE a.status = 'ACTIVE' AND a.tracking_status = 'ONLINE'
                   AND NOT EXISTS (SELECT 1 FROM tracked_asset_positions p
                                   WHERE p.tracked_asset_id = a.id
                                     AND p.recorded_at >= DATE_SUB(UTC_TIMESTAMP(6), INTERVAL 2 MINUTE))"
            ),
            'subscriptionsExpiring' => $this->count(
                "SELECT COUNT(*) FROM subscriptions WHERE status = 'ACTIVE'
                 AND COALESCE(grace_end_date, expiry_date) BETWEEN UTC_DATE() AND DATE_ADD(UTC_DATE(), INTERVAL 7 DAY)"
            ),
            'unpaidBookings' => $this->count(
                "SELECT COUNT(*) FROM smartbus_bookings b
                 LEFT JOIN finance_transactions f ON f.smartbus_booking_id = b.id
                 WHERE b.status = 'CONFIRMED' AND f.id IS NULL"
            ),
        ];

        // The comparison window immediately before the current one. These feed
        // the trend lines only, so a null here degrades to a context string
        // rather than a fabricated percentage.
        $window = ['from' => $previousFrom, 'to' => $previousTo];

        $before = [
            'openIncidents' => $this->count(
                'SELECT COUNT(*) FROM rescue_incidents WHERE reported_at >= :from AND reported_at < :to',
                $window
            ),
            'smartBusPassengers' => $this->count(
                'SELECT COUNT(*) FROM smartbus_bookings WHERE created_at >= :from AND created_at < :to',
                $window
            ),
        ];

        $revenue = $this->revenue();
        $response = $this->response();

        $summary = $this->summary($now, $response);

        return [
            'kpis' => $this->kpis($now, $before, $revenue, $response),
            'summary' => $summary,
            'summaryBasis' => [
                'trackedAssets' => $now['trackedAssets'],
                'openIncidents' => $now['openIncidents'],
                'criticalIncidents' => $now['criticalIncidents'],
                'gpsOffline' => $now['gpsOffline'],
                'gpsStale' => $now['gpsStale'],
                'gpsUnknown' => $now['gpsUnknown'],
                'subscriptionsExpiring' => $now['subscriptionsExpiring'],
            ],
            'actionCenter' => $this->actionCenter($now),
            'pulse' => $this->pulse($now, $response),
            'trend' => $this->trend(),
            'attention' => $this->attention($now),
            'revenue' => $revenue,
            'response' => $response,
            'period' => $period['key'],
            'generatedAt' => gmdate('c', $clock),
            'serverEpoch' => $clock,
        ];
    }

    /**
     * KPI definitions.
     *
     * Each carries a label key, a value and a COMPARISON whose period is stated
     * explicitly. `direction` declares which way is good, so the UI does not
     * guess: rising incidents are bad, rising revenue is good.
     *
     * A comparison is null when it cannot be computed, and the UI renders a
     * context line instead of a percentage. That is the difference between a
     * dashboard and a slot machine.
     *
     * @param array<string,mixed> $now
     * @param array<string,mixed> $before
     * @param array<string,mixed> $revenue
     * @param array<string,mixed> $response
     *
     * @return list<array<string,mixed>>
     */
    private function kpis(array $now, array $before, array $revenue, array $response): array
    {
        return [
            [
                'key' => 'trackedAssets',
                'labelKey' => 'executive.tracked_assets',
                'value' => $now['trackedAssets'],
                'state' => 'ok',
                'direction' => 'up',
                // Always present, explicitly null when there is no baseline, so
                // a client can tell "no comparison" from "comparison not run".
                'comparison' => null,
                'context' => 'across all monitored domains',
            ],
            [
                'key' => 'peopleProtected',
                'labelKey' => 'executive.people_under_protection',
                'value' => $now['smartBusPassengers'] + $now['cargoInTransit'],
                'state' => 'ok',
                'direction' => 'up',
                'comparison' => null,
                'context' => 'passengers and crew in motion',
            ],
            [
                'key' => 'openIncidents',
                'labelKey' => 'executive.active_incidents',
                'value' => $now['openIncidents'],
                'state' => 'ok',
                'direction' => 'down',
                'comparison' => $this->compare($before['openIncidents'], $now['openIncidents'], 'vs the previous window'),
                'critical' => $now['criticalIncidents'],
            ],
            [
                'key' => 'rescueTeamsAvailable',
                'labelKey' => 'executive.rescue_teams_available',
                'value' => $now['rescueTeamsAvailable'],
                'state' => 'ok',
                'direction' => 'up',
                'comparison' => null,
                'context' => $response['avgDispatchMinutes'] === null
                    ? 'ready to respond'
                    : 'avg dispatch ' . $response['avgDispatchMinutes'] . ' min',
            ],
            [
                'key' => 'revenue',
                'labelKey' => 'executive.revenue_collected',
                'value' => $revenue['collectedToday'],
                'currency' => $revenue['currency'],
                'state' => 'ok',
                'direction' => 'up',
                'comparison' => null,
                'context' => 'collected today',
            ],
        ];
    }

    /**
     * The Action Center: what needs a human now, ranked.
     *
     * Every row is a real count from the same queries that produce the KPIs, and
     * every row names the workflow it opens. A row the reader cannot act on is
     * noise, so `panel` is part of the definition rather than an afterthought.
     *
     * @param array<string,mixed> $now
     *
     * @return list<array<string,mixed>>
     */
    private function actionCenter(array $now): array
    {
        $rows = [];

        if ($now['criticalIncidents'] > 0) {
            $rows[] = [
                'key' => 'criticalIncidents',
                'severity' => 'critical',
                'titleKey' => 'executive.action_critical_incidents',
                'count' => $now['criticalIncidents'],
                'unit' => 'incidents',
                'panel' => 'rescue',
            ];
        }

        if ($now['gpsOffline'] > 0) {
            $rows[] = [
                'key' => 'gpsOffline',
                'severity' => 'high',
                'titleKey' => 'executive.action_gps_offline',
                'count' => $now['gpsOffline'],
                'unit' => 'devices offline',
                'panel' => 'tracking',
            ];
        }

        if ($now['gpsStale'] > 0) {
            $rows[] = [
                'key' => 'gpsStale',
                'severity' => 'high',
                'titleKey' => 'executive.action_gps_stale',
                'count' => $now['gpsStale'],
                'unit' => 'signals delayed',
                'panel' => 'tracking',
            ];
        }

        // Never-reported devices are a configuration gap rather than an outage,
        // so they rank below a real outage of the same size.
        if ($now['gpsUnknown'] > 0) {
            $rows[] = [
                'key' => 'gpsUnknown',
                'severity' => 'low',
                'titleKey' => 'executive.action_gps_never_reported',
                'count' => $now['gpsUnknown'],
                'unit' => 'devices never reported',
                'panel' => 'tracking',
            ];
        }

        if ($now['subscriptionsExpiring'] > 0) {
            $rows[] = [
                'key' => 'subscriptionsExpiring',
                'severity' => 'medium',
                'titleKey' => 'executive.action_subscriptions_expiring',
                'count' => $now['subscriptionsExpiring'],
                'unit' => 'within 7 days',
                'panel' => 'subscriptions',
            ];
        }

        if ($now['unpaidBookings'] > 0) {
            $rows[] = [
                'key' => 'unpaidBookings',
                'severity' => 'medium',
                'titleKey' => 'executive.action_unpaid',
                'count' => $now['unpaidBookings'],
                'unit' => 'tickets unpaid',
                'panel' => 'finance',
            ];
        }

        // Severity first, then count, so the most numerous issue within a
        // severity leads. That ordering is the whole point of the component.
        $order = ['critical' => 0, 'high' => 1, 'medium' => 2, 'low' => 3];
        usort($rows, static function (array $a, array $b) use ($order): int {
            return [$order[$a['severity']], -$a['count']] <=> [$order[$b['severity']], -$b['count']];
        });

        return $rows;
    }

    /**
     * The Operations Pulse strip.
     *
     * Each service reports what it knows, INCLUDING when it knows nothing.
     * "unknown" is a valid state and is rendered differently from "ok", because
     * a system that is genuinely healthy and a system nobody has checked look
     * identical otherwise.
     *
     * @param array<string,mixed> $now
     * @param array<string,mixed> $response
     *
     * @return list<array<string,mixed>>
     */
    private function pulse(array $now, array $response): array
    {
        // A fleet where half the devices have never reported is not "healthy",
        // and it is not "offline" either. 'unknown' is the honest word.
        $tracking = match (true) {
            $now['gpsOffline'] > 0 => $now['gpsStale'] > 0 ? 'degraded' : 'down',
            $now['gpsStale'] > 0 => 'degraded',
            $now['gpsUnknown'] > 0 => 'unknown',
            default => 'ok',
        };

        return [
            ['key' => 'tracking', 'value' => $this->pulseLabel($tracking), 'state' => $tracking],
            [
                'key' => 'rescue',
                'value' => $now['openIncidents'] > 0 ? 'Active' : 'Normal',
                'state' => $now['openIncidents'] > 0 ? 'active' : 'ok',
            ],
            [
                'key' => 'payments',
                'value' => $now['unpaidBookings'] > 0 ? 'Attention' : 'Healthy',
                'state' => $now['unpaidBookings'] > 0 ? 'degraded' : 'ok',
            ],
            [
                'key' => 'subscriptions',
                'value' => $now['subscriptionsExpiring'] > 0 ? 'Expiring' : 'Healthy',
                'state' => $now['subscriptionsExpiring'] > 0 ? 'degraded' : 'ok',
            ],
            [
                'key' => 'response',
                'value' => $response['avgDispatchMinutes'] === null
                    ? 'No data'
                    : $response['avgDispatchMinutes'] . ' min',
                // The number itself travels with the label, so a client can
                // assert that a value was actually measured instead of
                // pattern-matching a display string.
                'measurement' => $response['avgDispatchMinutes'],
                'sampleSize' => $response['dispatched'],
                // Null response time means no incidents in the window, which is
                // NOT the same as a fast response and must never read as one.
                'state' => $response['avgDispatchMinutes'] === null ? 'unknown' : 'ok',
            ],
        ];
    }

    private function pulseLabel(string $state): string
    {
        return match ($state) {
            'ok' => 'Healthy',
            'degraded' => 'Degraded',
            'down' => 'Offline',
            'active' => 'Active',
            default => 'Unknown',
        };
    }

    /**
     * Layer 3: the trend, as real daily series.
     *
     * Two rules make this honest rather than decorative.
     *
     * GAPS ARE ZEROS ONLY WHEN THEY REALLY ARE. A day with no incidents is a
     * genuine 0 and is plotted as one. The date spine is generated here and the
     * counts are mapped onto it, so a day with no rows reads 0 instead of
     * vanishing and compressing the axis -- which is the failure mode that makes
     * a sparkline lie about its own shape.
     *
     * THE SPINE IS DECLARED, NOT ASSUMED. `dates` is the exact domain the
     * client may draw, and `hasHistory` says whether any of it has data. With
     * no history the client renders a context line instead of a flat line that
     * looks like stability.
     *
     * @return array<string,mixed>
     */
    private function trend(): array
    {
        $days = 14;
        $series = [
            'dates' => [],
            'incidentsReported' => [],
            'incidentsResolved' => [],
            'payments' => [],
        ];

        $cursor = new \DateTimeImmutable('today', new \DateTimeZone('UTC'));
        for ($i = $days - 1; $i >= 0; $i--) {
            $series['dates'][] = $cursor->modify("-{$i} days")->format('Y-m-d');
        }

        $reported = $this->daily('rescue_incidents', 'reported_at', $series['dates']);
        $resolved = $this->daily('rescue_incidents', 'resolved_at', $series['dates']);
        $payments = $this->daily('finance_transactions', 'received_at', $series['dates']);

        $series['incidentsReported'] = array_map(
            static fn (string $date): int => (int) ($reported[$date] ?? 0),
            $series['dates']
        );
        $series['incidentsResolved'] = array_map(
            static fn (string $date): int => (int) ($resolved[$date] ?? 0),
            $series['dates']
        );
        $series['payments'] = array_map(
            static fn (string $date): int => (int) ($payments[$date] ?? 0),
            $series['dates']
        );

        // Totalled across EVERY plotted series, so the declared total can be
        // reconciled against the picture above it. Summing a hand-picked subset
        // would make the two disagree for no visible reason -- which is exactly
        // the kind of small arithmetic lie that erodes trust in a dashboard.
        $total = 0;
        foreach (['incidentsReported', 'incidentsResolved', 'payments'] as $key) {
            $total += array_sum($series[$key]);
        }

        return [
            'window' => "{$days}d",
            'dates' => $series['dates'],
            'series' => [
                ['key' => 'incidentsReported', 'labelKey' => 'executive.trend_incidents', 'values' => $series['incidentsReported'], 'direction' => 'down'],
                ['key' => 'incidentsResolved', 'labelKey' => 'executive.trend_resolved', 'values' => $series['incidentsResolved'], 'direction' => 'up'],
                ['key' => 'payments', 'labelKey' => 'executive.trend_payments', 'values' => $series['payments'], 'direction' => 'up'],
            ],
            // A flat line across a window with no activity is not "stable", it
            // is "nothing happened". The client needs to be able to tell.
            'hasHistory' => $total > 0,
            'totalEvents' => $total,
        ];
    }

    /**
     * Count rows per day across an explicit list of dates.
     *
     * @param list<string> $dates
     *
     * @return array<string,int>
     */
    private function daily(string $table, string $column, array $dates): array
    {
        if ($dates === []) {
            return [];
        }

        $placeholders = implode(',', array_fill(0, count($dates), '?'));
        $statement = $this->database->prepare(
            "SELECT DATE({$column}) AS day, COUNT(*) AS total
             FROM {$table}
             WHERE DATE({$column}) IN ({$placeholders})
             GROUP BY DATE({$column})"
        );
        $statement->execute($dates);

        $counts = [];
        foreach ($statement->fetchAll() as $row) {
            $counts[(string) $row['day']] = (int) $row['total'];
        }

        return $counts;
    }

    /**
     * The one-sentence executive summary.
     *
     * GENERATED from the counts beside it, not authored. The brief is explicit
     * that this must come from real status data, so the sentence is assembled
     * from conditions and the exact counts it used are returned separately in
     * `summaryBasis`, so a reader can check it rather than trust it.
     *
     * @param array<string,mixed> $now
     * @param array<string,mixed> $response
     *
     * @return array{state:string,sentence:string}
     */
    private function summary(array $now, array $response): array
    {
        $exceptions = $now['criticalIncidents'] + $now['gpsOffline'] + $now['gpsStale']
            + $now['gpsUnknown'] + $now['subscriptionsExpiring'] + $now['unpaidBookings'];

        if ($exceptions === 0) {
            return [
                'state' => 'ok',
                'sentence' => 'Operations are normal across all monitored assets. No exceptions require attention right now.',
            ];
        }

        $parts = [];
        if ($now['openIncidents'] === 0) {
            $parts[] = 'Operations are normal across monitored assets';
        } else {
            $parts[] = $now['openIncidents'] . ' open incident' . ($now['openIncidents'] === 1 ? '' : 's') . ' are open';
        }

        if ($now['criticalIncidents'] > 0) {
            $parts[] = $now['criticalIncidents'] . ' critical incident' . ($now['criticalIncidents'] === 1 ? '' : 's') . ' require immediate attention';
        }
        if ($now['gpsOffline'] > 0) {
            $parts[] = $now['gpsOffline'] . ' tracking device' . ($now['gpsOffline'] === 1 ? '' : 's') . ' offline';
        }
        if ($now['gpsStale'] > 0) {
            $parts[] = $now['gpsStale'] . ' signal' . ($now['gpsStale'] === 1 ? '' : 's') . ' delayed';
        }
        if ($now['gpsUnknown'] > 0) {
            $parts[] = $now['gpsUnknown'] . ' device' . ($now['gpsUnknown'] === 1 ? '' : 's') . ' have never reported a position';
        }
        if ($now['subscriptionsExpiring'] > 0) {
            $parts[] = $now['subscriptionsExpiring'] . ' subscription' . ($now['subscriptionsExpiring'] === 1 ? '' : 's') . ' expiring within 7 days';
        }
        if ($now['unpaidBookings'] > 0) {
            $parts[] = $now['unpaidBookings'] . ' ticket' . ($now['unpaidBookings'] === 1 ? '' : 's') . ' await payment';
        }

        $sentence = ucfirst(implode(', ', $parts)) . '.';
        if ($response['avgDispatchMinutes'] !== null) {
            $sentence .= ' Average dispatch is ' . $response['avgDispatchMinutes'] . ' minutes.';
        }

        return [
            // "attention" rather than "critical" for the non-critical cases: a
            // stale GPS device is not a crisis, and a summary that shouts on
            // every refresh trains people to ignore it.
            'state' => $now['criticalIncidents'] > 0 ? 'critical' : 'attention',
            'sentence' => $sentence,
        ];
    }

    /**
     * A comparison, or null when there is genuinely nothing to compare against.
     *

    /**
     * Layer 6: the records behind each Action Center count.
     *
     * The Action Center says "12 tickets unpaid". This says WHICH twelve, so the
     * count is checkable and the reader does not have to go hunting. Every row
     * carries the id needed to open the full record, and the list is capped --
     * a dashboard is not a report, and a count of 4,000 rendered as 4,000 rows
     * is the same as showing nothing.
     *
     * @param array<string,mixed> $now
     *
     * @return array<string,mixed>
     */
    private function attention(array $now): array
    {
        $groups = [];

        if ($now['openIncidents'] > 0) {
            // `domain` and `location_text` live on the incident itself, so this
            // needs no join. The domain is what tells a reader whether an
            // incident is a bus, a truck or a private vehicle, which is the
            // only reason to show a bare code.
            $statement = $this->database->query(
                // priority, not severity, for the same reason as the KPI above:
                // intake never writes severity, so ordering on it sorted every
                // incident identically and the queue was not actually ranked.
                "SELECT id, incident_code, priority, status, domain, location_text, reported_at
                 FROM rescue_incidents
                 WHERE resolved_at IS NULL
                 ORDER BY FIELD(priority, 'CRITICAL', 'HIGH', 'MEDIUM', 'LOW'), reported_at DESC
                 LIMIT 8"
            );
            $incidentRows = $statement->fetchAll();
            $groups['incidents'] = [
                'count' => $now['openIncidents'],
                'shown' => count($incidentRows),
                'rows' => array_map(static fn (array $row): array => [
                    'id' => (string) $row['id'],
                    'reference' => (string) ($row['incident_code'] ?? $row['id']),
                    'severity' => strtolower((string) $row['priority']),
                    'status' => strtolower((string) $row['status']),
                    'meta' => trim(((string) ($row['domain'] ?? '')) . ' ' . ((string) ($row['location_text'] ?? ''))) ?: '—',
                    'at' => $row['reported_at'],
                ], $incidentRows),
            ];
        }

        if ($now['unpaidBookings'] > 0) {
            $statement = $this->database->query(
                "SELECT b.id, b.booking_reference, b.passenger_name, b.total_cdf, b.created_at
                 FROM smartbus_bookings b
                 LEFT JOIN finance_transactions f ON f.smartbus_booking_id = b.id
                 WHERE b.status = 'CONFIRMED' AND f.id IS NULL
                 ORDER BY b.created_at DESC LIMIT 8"
            );
            $rows = $statement->fetchAll();
            $groups['unpaid'] = [
                'count' => $now['unpaidBookings'],
                'shown' => count($rows),
                'rows' => array_map(static fn (array $row): array => [
                    'id' => (string) $row['id'],
                    'reference' => (string) ($row['booking_reference'] ?? $row['id']),
                    'severity' => 'medium',
                    'status' => 'unpaid',
                    // The amount travels with its currency so the client can
                    // convert for display; the stored value is never rewritten.
                    'amount' => number_format((float) $row['total_cdf'], 2, '.', ''),
                    'currency' => 'CDF',
                    'meta' => (string) ($row['passenger_name'] ?? '—'),
                    'at' => $row['created_at'],
                ], $rows),
            ];
        }

        return $groups;
    }

    /**
     * A comparison, or null when there is genuinely nothing to compare against.
     *
     * @return array<string,mixed>|null
     */
    private function compare(?int $previous, int $current, string $label): ?array
    {
        if ($previous === null || $previous === 0) {
            // No baseline. Null means the UI shows a context line instead, which
            // is honest; returning 0% would be a fabricated trend.
            return null;
        }

        $change = round((($current - $previous) / $previous) * 100, 1);

        return [
            'value' => $change,
            'direction' => $change > 0 ? 'up' : ($change < 0 ? 'down' : 'flat'),
            'label' => $label,
            'previous' => $previous,
        ];
    }

    /**
     * Money collected today, plus the outstanding balance.
     *
     * Amounts are returned as strings with their SOURCE currency, and the
     * display currency is applied by Money in the presentation layer. Nothing
     * here converts, because nothing here should be able to.
     *
     * @return array<string,mixed>
     */
    private function revenue(): array
    {
        $row = $this->database->query(<<<'SQL'
            SELECT COUNT(*) AS payments,
                   COALESCE(SUM(CASE WHEN status = 'RECONCILED' THEN amount ELSE 0 END), 0) AS collected,
                   COALESCE(SUM(CASE WHEN status = 'VARIANCE' THEN ABS(amount) ELSE 0 END), 0) AS variance,
                   COALESCE(MIN(currency), 'USD') AS currency
            FROM finance_transactions WHERE received_at >= UTC_DATE()
            SQL)->fetch() ?: [];

        return [
            'paymentsToday' => (int) ($row['payments'] ?? 0),
            'collectedToday' => number_format((float) ($row['collected'] ?? 0), 2, '.', ''),
            'varianceToday' => number_format((float) ($row['variance'] ?? 0), 2, '.', ''),
            'currency' => (string) ($row['currency'] ?? 'USD'),
            'outstandingBookings' => $this->count(
                "SELECT COUNT(*) FROM smartbus_bookings b
                 LEFT JOIN finance_transactions f ON f.smartbus_booking_id = b.id
                 WHERE b.status = 'CONFIRMED' AND f.id IS NULL"
            ),
        ];
    }

    /**
     * Response times over the incident window.


    /**
     * Response times over the incident window.
     *
     * Averages are null rather than 0 when there were no incidents. "0 minutes"
     * and "no incidents happened" are different facts, and conflating them is
     * how a quiet month looks like excellent performance.
     *
     * @return array<string,mixed>
     */
    private function response(): array
    {
        $row = $this->database->query(<<<'SQL'
            SELECT COUNT(*) AS incidents,
                   SUM(dispatched_at IS NOT NULL) AS dispatched_n,
                   SUM(arrived_at IS NOT NULL) AS arrived_n,
                   AVG(TIMESTAMPDIFF(MINUTE, reported_at, dispatched_at)) AS dispatch_minutes,
                   AVG(TIMESTAMPDIFF(MINUTE, dispatched_at, arrived_at)) AS arrive_minutes,
                   AVG(TIMESTAMPDIFF(MINUTE, reported_at, resolved_at)) AS resolve_minutes
            FROM rescue_incidents WHERE reported_at >= DATE_SUB(UTC_DATE(), INTERVAL 30 DAY)
            SQL)->fetch() ?: [];

        $incidents = (int) ($row['incidents'] ?? 0);
        $dispatched = (int) ($row['dispatched_n'] ?? 0);
        $arrived = (int) ($row['arrived_n'] ?? 0);

        // Each average is taken over the rows that actually have BOTH
        // timestamps, and the sample size travels with it.
        //
        // AVG() in MySQL already ignores NULLs, so a naive average of the
        // arrival column divides by however many incidents HAPPEN to have been
        // dispatched. In this database that is 6 of 15, and because those 6 are
        // the ones dispatched seconds before arrival, the reported average was
        // 0 minutes -- a number that reads as world-class performance and
        // actually means "we only measure the easy ones".
        return [
            'window' => '30d',
            'incidents' => $incidents,
            'dispatched' => $dispatched,
            'arrived' => $arrived,
            'avgDispatchMinutes' => $dispatched === 0 || $row['dispatch_minutes'] === null
                ? null
                : round((float) $row['dispatch_minutes'], 1),
            'avgArriveMinutes' => $arrived === 0 || $row['arrive_minutes'] === null
                ? null
                : round((float) $row['arrive_minutes'], 1),
            'avgResolveMinutes' => $incidents === 0 || $row['resolve_minutes'] === null
                ? null
                : round((float) $row['resolve_minutes'], 1),
        ];
    }

    /**
     * The reporting window.
     *
     * @param array<string,mixed> $filters
     *
     * @return array{key:string,from:string,to:string}
     */
    private function period(array $filters): array
    {
        $key = strtoupper((string) ($filters['period'] ?? 'TODAY'));

        return match ($key) {
            'WEEK' => ['key' => '7d', 'from' => gmdate('Y-m-d', strtotime('-6 days')), 'to' => gmdate('Y-m-d')],
            'MONTH' => ['key' => '30d', 'from' => gmdate('Y-m-d', strtotime('-29 days')), 'to' => gmdate('Y-m-d')],
            'QUARTER' => ['key' => '90d', 'from' => gmdate('Y-m-d', strtotime('-89 days')), 'to' => gmdate('Y-m-d')],
            'YEAR' => ['key' => '365d', 'from' => gmdate('Y-m-d', strtotime('-364 days')), 'to' => gmdate('Y-m-d')],
            default => ['key' => 'today', 'from' => gmdate('Y-m-d'), 'to' => gmdate('Y-m-d')],
        };
    }

    /**
     * The window immediately before the current one, for an honest comparison.
     *
     * @param array{key:string,from:string,to:string} $period
     *
     * @return array{0:string,1:string}
     */
    private function previousWindow(array $period): array
    {
        $from = strtotime($period['from']);
        $to = strtotime($period['to']);
        $span = max(1, (int) (($to - $from) / 86400) + 1);

        return [gmdate('Y-m-d', $from - ($span * 86400)), gmdate('Y-m-d', $from - 86400)];
    }

    /**
     * @param array<string,string> $params
     */
    private function count(string $query, array $params = []): int
    {
        $statement = $this->database->prepare($query);
        $statement->execute($params);

        return (int) $statement->fetchColumn();
    }
}
