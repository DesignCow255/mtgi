<?php

declare(strict_types=1);

namespace Mamore\Dashboard;

use PDO;

final class DashboardService
{
    public function __construct(private readonly PDO $database)
    {
    }

    public function snapshot(): array
    {
        return [
            'metrics' => [
                'users' => $this->count('SELECT COUNT(*) FROM users WHERE deleted_at IS NULL'),
                'activeSessions' => $this->count('SELECT COUNT(*) FROM user_sessions WHERE revoked_at IS NULL AND refresh_expires_at > UTC_TIMESTAMP(6)'),
                'successfulLogins24h' => $this->count('SELECT COUNT(*) FROM login_history WHERE succeeded = 1 AND occurred_at >= UTC_TIMESTAMP(6) - INTERVAL 24 HOUR'),
                'failedLogins24h' => $this->count('SELECT COUNT(*) FROM login_history WHERE succeeded = 0 AND occurred_at >= UTC_TIMESTAMP(6) - INTERVAL 24 HOUR'),
            ],
            'roles' => $this->roles(),
            'recentLogins' => $this->recentLogins(),
            'generatedAt' => gmdate(DATE_ATOM),
        ];
    }

    private function count(string $query): int
    {
        return (int) $this->database->query($query)->fetchColumn();
    }

    private function roles(): array
    {
        $statement = $this->database->query(
            'SELECT r.code, r.name, COUNT(u.id) AS users
             FROM roles r LEFT JOIN users u ON u.role_id = r.id AND u.deleted_at IS NULL
             GROUP BY r.id, r.code, r.name ORDER BY users DESC, r.name ASC'
        );

        return array_map(static fn (array $row): array => [
            'code' => $row['code'],
            'name' => $row['name'],
            'users' => (int) $row['users'],
        ], $statement->fetchAll());
    }

    private function recentLogins(): array
    {
        $statement = $this->database->query(
            'SELECT attempted_email, succeeded, failure_reason, ip_address, occurred_at
             FROM login_history ORDER BY occurred_at DESC LIMIT 8'
        );

        return array_map(static fn (array $row): array => [
            'email' => $row['attempted_email'],
            'succeeded' => (bool) $row['succeeded'],
            'failureReason' => $row['failure_reason'],
            'ipAddress' => $row['ip_address'],
            'createdAt' => $row['occurred_at'],
        ], $statement->fetchAll());
    }
}
