<?php

declare(strict_types=1);

namespace Mamore\Admin;

use Mamore\Auth\AuthException;
use Mamore\Core\AuditLog;
use Mamore\Core\PasswordPolicy;
use Mamore\Core\Request;
use Mamore\Core\Uuid;
use PDO;
use PDOException;

final class UserAdminService
{
    private const STATUSES = ['PENDING', 'ACTIVE', 'SUSPENDED', 'LOCKED', 'DISABLED'];

    public function __construct(private readonly PDO $database)
    {
    }

    public function users(string $search = ''): array
    {
        $search = trim($search);
        $statement = $this->database->prepare(<<<'SQL'
            SELECT u.id, u.first_name, u.last_name, u.email, u.phone, u.status,
                   u.last_login_at, u.created_at, r.id AS role_id, r.code AS role_code, r.name AS role_name
            FROM users u JOIN roles r ON r.id = u.role_id
            WHERE u.deleted_at IS NULL
              AND (:search = '' OR u.first_name LIKE :term_first OR u.last_name LIKE :term_last OR u.email LIKE :term_email OR u.phone LIKE :term_phone)
            ORDER BY u.created_at DESC LIMIT 100
            SQL);
        $term = '%' . $search . '%';
        $statement->execute(['search' => $search, 'term_first' => $term, 'term_last' => $term, 'term_email' => $term, 'term_phone' => $term]);
        return array_map([$this, 'publicUser'], $statement->fetchAll());
    }

    public function roles(): array
    {
        return $this->database->query('SELECT id, code, name FROM roles ORDER BY name')->fetchAll();
    }

    public function create(array $input, array $actor, Request $request): array
    {
        $firstName = $this->required($input, 'firstName', 'First name');
        $lastName = $this->required($input, 'lastName', 'Last name');
        $email = strtolower($this->required($input, 'email', 'Email'));
        $password = $this->required($input, 'password', 'Password');
        $roleId = $this->required($input, 'roleId', 'Role');
        $phone = $this->optional($input, 'phone');
        $status = $this->status($input['status'] ?? 'ACTIVE');

        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) throw new AuthException('Enter a valid email address.', 422);
        PasswordPolicy::assert($password);
        $this->ensureRole($roleId);

        $id = Uuid::v4();
        try {
            $statement = $this->database->prepare(<<<'SQL'
                INSERT INTO users (id, role_id, first_name, last_name, email, phone, password_hash, status, email_verified_at)
                VALUES (:id, :role_id, :first_name, :last_name, :email, :phone, :password_hash, :status,
                        CASE WHEN :status_verified = 'ACTIVE' THEN UTC_TIMESTAMP(6) ELSE NULL END)
                SQL);
            $statement->execute([
                'id' => $id, 'role_id' => $roleId, 'first_name' => $firstName, 'last_name' => $lastName,
                'email' => $email, 'phone' => $phone, 'password_hash' => password_hash($password, PASSWORD_DEFAULT),
                'status' => $status, 'status_verified' => $status,
            ]);
        } catch (PDOException $error) {
            if ((string) $error->getCode() === '23000') throw new AuthException('That email address or phone number is already registered.', 409);
            throw $error;
        }
        $this->audit($actor['id'], 'ADMIN_USER_CREATED', $id, ['roleId' => $roleId, 'status' => $status], $request);
        return $this->find($id);
    }

    public function update(array $input, array $actor, Request $request): array
    {
        $id = $this->required($input, 'userId', 'User');
        $roleId = $this->required($input, 'roleId', 'Role');
        $status = $this->status($input['status'] ?? '');
        if ($id === $actor['id'] && $status !== 'ACTIVE') throw new AuthException('You cannot disable your own active administrator account.', 422);
        $this->ensureRole($roleId);
        $before = $this->find($id);

        $statement = $this->database->prepare('UPDATE users SET role_id = :role_id, status = :status WHERE id = :id AND deleted_at IS NULL');
        $statement->execute(['role_id' => $roleId, 'status' => $status, 'id' => $id]);
        if ($statement->rowCount() === 0 && ($before['roleId'] !== $roleId || $before['status'] !== $status)) {
            throw new AuthException('User could not be updated.', 409);
        }
        if ($status !== 'ACTIVE') {
            $this->database->prepare("UPDATE user_sessions SET revoked_at = UTC_TIMESTAMP(6), revoke_reason = 'ACCOUNT_STATUS_CHANGED' WHERE user_id = :id AND revoked_at IS NULL")->execute(['id' => $id]);
        }
        $this->audit($actor['id'], 'ADMIN_USER_UPDATED', $id, ['roleId' => $roleId, 'status' => $status], $request, $before);
        return $this->find($id);
    }

    private function find(string $id): array
    {
        $statement = $this->database->prepare(<<<'SQL'
            SELECT u.id, u.first_name, u.last_name, u.email, u.phone, u.status,
                   u.last_login_at, u.created_at, r.id AS role_id, r.code AS role_code, r.name AS role_name
            FROM users u JOIN roles r ON r.id = u.role_id WHERE u.id = :id AND u.deleted_at IS NULL LIMIT 1
            SQL);
        $statement->execute(['id' => $id]);
        $user = $statement->fetch();
        if (!is_array($user)) throw new AuthException('User not found.', 404);
        return $this->publicUser($user);
    }

    private function publicUser(array $row): array
    {
        return [
            'id' => $row['id'], 'firstName' => $row['first_name'], 'lastName' => $row['last_name'],
            'email' => $row['email'], 'phone' => $row['phone'], 'status' => $row['status'],
            'roleId' => $row['role_id'], 'roleCode' => $row['role_code'], 'roleName' => $row['role_name'],
            'lastLoginAt' => $row['last_login_at'], 'createdAt' => $row['created_at'],
        ];
    }

    private function required(array $input, string $key, string $label): string
    {
        $value = is_string($input[$key] ?? null) ? trim($input[$key]) : '';
        if ($value === '') throw new AuthException("{$label} is required.", 422);
        return $value;
    }

    private function optional(array $input, string $key): ?string
    {
        $value = is_string($input[$key] ?? null) ? trim($input[$key]) : '';
        return $value === '' ? null : $value;
    }

    private function status(mixed $value): string
    {
        $status = is_string($value) ? strtoupper(trim($value)) : '';
        if (!in_array($status, self::STATUSES, true)) throw new AuthException('Select a valid account status.', 422);
        return $status;
    }

    private function ensureRole(string $roleId): void
    {
        $statement = $this->database->prepare('SELECT 1 FROM roles WHERE id = :id');
        $statement->execute(['id' => $roleId]);
        if (!$statement->fetchColumn()) throw new AuthException('Select a valid role.', 422);
    }

    private function audit(string $actorId, string $action, string $entityId, array $data, Request $request, ?array $previous = null): void
    {
        (new AuditLog($this->database))->write(
            $action,
            'User',
            $entityId,
            ['id' => $actorId],
            $request,
            $previous,
            $data,
            ['source' => 'user-admin']
        );
    }
}
