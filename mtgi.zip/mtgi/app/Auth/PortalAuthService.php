<?php

declare(strict_types=1);

namespace Mamore\Auth;

use Mamore\Core\AuditLog;
use Mamore\Core\Env;
use Mamore\Core\PasswordPolicy;
use Mamore\Core\RateLimiter;
use Mamore\Core\Request;
use Mamore\Core\Uuid;
use PDO;
use PDOException;

/**
 * Portal self-service auth: register a subscriber, verify the email with a
 * one-time code, resend that code, and reset a forgotten password.
 *
 * Canonical intent: POST /auth/register-subscriber, /auth/verify-otp,
 * /auth/resend-otp, /auth/forgot-password, /auth/reset-password.
 *
 * Security rules that shape the API:
 *  - the account starts PENDING and cannot log in until the code is verified;
 *  - forgot-password always answers the same way, so it cannot be used to
 *    discover which email addresses have accounts;
 *  - verify/reset failures answer with one generic message, never which part
 *    of the code was wrong;
 *  - every endpoint is rate limited per IP, and resends honour a cooldown.
 */
final class PortalAuthService
{
    private const REGISTER_LIMIT = [5, 3600];
    private const CODE_LIMIT = [10, 3600];
    private const FORGOT_LIMIT = [5, 3600];

    public function __construct(private readonly PDO $database) {}

    /**
     * Register a subscriber: creates the subscriber profile plus a PENDING
     * portal account, then issues an EMAIL_VERIFICATION code.
     *
     * @return array<string,mixed>
     */
    public function registerSubscriber(array $input, Request $request): array
    {
        $this->throttle('register', $request);

        $firstName = $this->required($input, 'firstName', 'First name');
        $lastName = $this->required($input, 'lastName', 'Last name');
        $email = $this->email($input['email'] ?? '');
        $phone = $this->phone($input['phone'] ?? null, true);
        $password = $this->required($input, 'password', 'Password');
        $channel = $this->channel($input['preferredMethod'] ?? 'EMAIL');
        $this->acceptsTerms($input);

        PasswordPolicy::assert($password);
        $this->assertEmailFree($email);
        $this->assertPhoneFree($phone);

        $role = $this->role();
        $userId = Uuid::v4();
        $subscriberId = Uuid::v4();
        $membershipNumber = 'MEM-' . gmdate('ymd') . '-' . strtoupper(bin2hex(random_bytes(3)));

        $this->database->beginTransaction();
        try {
            $this->database->prepare(<<<'SQL'
                INSERT INTO subscribers
                    (id, membership_number, first_name, last_name, email, phone)
                VALUES
                    (:id, :number, :firstName, :lastName, :email, :phone)
                SQL)->execute([
                'id' => $subscriberId,
                'number' => $membershipNumber,
                'firstName' => $firstName,
                'lastName' => $lastName,
                'email' => $email,
                'phone' => $phone,
            ]);

            $this->database->prepare(<<<'SQL'
                INSERT INTO users
                    (id, role_id, subscriber_id, first_name, last_name, email, phone, password_hash, status)
                VALUES
                    (:id, :role, :subscriber, :firstName, :lastName, :email, :phone, :password, 'PENDING')
                SQL)->execute([
                'id' => $userId,
                'role' => $role,
                'subscriber' => $subscriberId,
                'firstName' => $firstName,
                'lastName' => $lastName,
                'email' => $email,
                'phone' => $phone,
                'password' => password_hash($password, PASSWORD_DEFAULT),
            ]);
            $this->database->commit();
        } catch (PDOException $error) {
            $this->database->rollBack();
            if ((string) $error->getCode() === '23000') {
                throw new AuthException('That email address or phone number is already registered.', 409);
            }
            throw $error;
        } catch (\Throwable $error) {
            $this->database->rollBack();
            throw $error;
        }

        $issued = (new OtpService($this->database))->issue(
            $userId,
            OtpService::PURPOSE_EMAIL_VERIFICATION,
            ['channel' => $channel],
            $request
        );

        (new AuditLog($this->database))->write(
            'PORTAL_SUBSCRIBER_REGISTERED',
            'User',
            $userId,
            null,
            $request,
            null,
            ['email' => $email, 'phone' => $phone, 'status' => 'PENDING', 'membershipNumber' => $membershipNumber],
            ['source' => 'portal-register', 'channel' => $channel]
        );

        return [
            'id' => $userId,
            'email' => $email,
            'firstName' => $firstName,
            'lastName' => $lastName,
            'membershipNumber' => $membershipNumber,
            'subscriberId' => $subscriberId,
            'emailVerified' => false,
            'codeExpiresAt' => $issued['expiresAt'],
            'channel' => $issued['channel'],
            'message' => 'Registration successful. Please verify your email.',
        ] + $this->debugCode($issued);
    }

    /**
     * Verify a one-time code.
     *
     * EMAIL_VERIFICATION activates the account (status + email_verified_at);
     * a PASSWORD_RESET code is NOT burned here, because resetPassword() still
     * has to consume it.
     *
     * @return array<string,mixed>
     */
    public function verifyOtp(array $input, Request $request): array
    {
        $this->throttle('verify', $request);
        $email = $this->email($input['email'] ?? '');
        $code = $this->required($input, 'code', 'Verification code');
        $purpose = $this->purpose($input['purpose'] ?? OtpService::PURPOSE_EMAIL_VERIFICATION);
        $user = $this->findByEmail($email);

        $generic = new AuthException('The code is invalid or has expired.', 422);
        if ($user === null) {
            $this->auditCodeFailure($email, $purpose, 'unknown_account', $request);
            throw $generic;
        }

        $result = (new OtpService($this->database))->verify($user['id'], $code, $purpose);
        if (!$result['valid']) {
            $this->auditCodeFailure($email, $purpose, (string) $result['reason'], $request);
            throw $generic;
        }

        if ($purpose === OtpService::PURPOSE_PASSWORD_RESET) {
            return [
                'email' => $email,
                'purpose' => $purpose,
                'verified' => true,
                'nextStep' => 'reset-password',
                'message' => 'Code accepted. Choose a new password.',
            ];
        }

        $this->database->beginTransaction();
        try {
            $this->database->prepare(
                "UPDATE users SET status = 'ACTIVE', email_verified_at = UTC_TIMESTAMP(6) WHERE id = :id"
            )->execute(['id' => $user['id']]);
            $this->database->prepare(
                'INSERT INTO subscriber_history (subscriber_id, action, description, created_by_user_id)
                 VALUES (:subscriber, :action, :description, :actor)'
            )->execute([
                'subscriber' => $user['subscriber_id'],
                'action' => 'EMAIL_VERIFIED',
                'description' => 'Portal account email verified.',
                'actor' => $user['id'],
            ]);
            $this->database->commit();
        } catch (\Throwable $error) {
            $this->database->rollBack();
            throw $error;
        }

        (new AuditLog($this->database))->write(
            'PORTAL_EMAIL_VERIFIED',
            'User',
            $user['id'],
            $user,
            $request,
            ['status' => $user['status'], 'emailVerifiedAt' => $user['email_verified_at']],
            ['status' => 'ACTIVE', 'emailVerifiedAt' => true],
            ['source' => 'portal-verify-otp', 'purpose' => $purpose]
        );

        return [
            'id' => $user['id'],
            'email' => $email,
            'purpose' => $purpose,
            'verified' => true,
            'status' => 'ACTIVE',
            'message' => 'Your account is verified. You can sign in now.',
        ];
    }

    /**
     * Re-issue a one-time code. The OtpService cooldown applies per user, so a
     * caller cannot spam a subscriber's inbox.
     *
     * @return array<string,mixed>
     */
    public function resendOtp(array $input, Request $request): array
    {
        $this->throttle('resend', $request);
        $email = $this->email($input['email'] ?? '');
        $purpose = $this->purpose($input['purpose'] ?? OtpService::PURPOSE_EMAIL_VERIFICATION);
        $user = $this->findByEmail($email);
        $generic = new AuthException('The code is invalid or has expired.', 422);

        if ($user === null) {
            $this->auditCodeFailure($email, $purpose, 'unknown_account', $request);
            throw $generic;
        }

        $issued = (new OtpService($this->database))->issue($user['id'], $purpose, [], $request);
        (new AuditLog($this->database))->write(
            'PORTAL_OTP_RESENT',
            'User',
            $user['id'],
            $user,
            $request,
            null,
            null,
            ['source' => 'portal-resend-otp', 'purpose' => $purpose, 'channel' => $issued['channel']]
        );

        return [
            'email' => $email,
            'purpose' => $purpose,
            'sent' => true,
            'codeExpiresAt' => $issued['expiresAt'],
            'channel' => $issued['channel'],
            'message' => 'A new code has been sent.',
        ] + $this->debugCode($issued);
    }

    /**
     * Start a password reset.
     *
     * The answer is identical whether or not the email has an account, so this
     * endpoint cannot be used to enumerate subscribers.
     *
     * @return array<string,mixed>
     */
    public function forgotPassword(array $input, Request $request): array
    {
        $this->throttle('forgot', $request);
        $email = $this->email($input['email'] ?? '');
        $user = $this->findByEmail($email);
        $payload = [
            'email' => $email,
            'sent' => true,
            'message' => 'If that account exists, a reset code is on its way.',
        ];

        if ($user === null) {
            (new AuditLog($this->database))->write(
                'PORTAL_RESET_UNKNOWN_ACCOUNT',
                'User',
                null,
                null,
                $request,
                null,
                null,
                ['source' => 'portal-forgot-password']
            );
            return $payload;
        }

        $issued = (new OtpService($this->database))->issue(
            $user['id'],
            OtpService::PURPOSE_PASSWORD_RESET,
            [],
            $request
        );
        (new AuditLog($this->database))->write(
            'PORTAL_RESET_REQUESTED',
            'User',
            $user['id'],
            $user,
            $request,
            null,
            null,
            ['source' => 'portal-forgot-password', 'channel' => $issued['channel']]
        );

        return $payload + $this->debugCode($issued);
    }

    /**
     * Finish a password reset: consume the code, store the new password and
     * revoke every existing session for that account.
     *
     * @return array<string,mixed>
     */
    public function resetPassword(array $input, Request $request): array
    {
        $this->throttle('reset', $request);
        $email = $this->email($input['email'] ?? '');
        $code = $this->required($input, 'code', 'Reset code');
        $password = $this->required($input, 'password', 'Password');
        PasswordPolicy::assert($password, 'New password');

        $user = $this->findByEmail($email);
        $generic = new AuthException('The code is invalid or has expired.', 422);
        if ($user === null) {
            $this->auditCodeFailure($email, OtpService::PURPOSE_PASSWORD_RESET, 'unknown_account', $request);
            throw $generic;
        }

        $result = (new OtpService($this->database))->verify(
            $user['id'],
            $code,
            OtpService::PURPOSE_PASSWORD_RESET
        );
        if (!$result['valid']) {
            $this->auditCodeFailure($email, OtpService::PURPOSE_PASSWORD_RESET, (string) $result['reason'], $request);
            throw $generic;
        }

        $revoked = 0;
        $this->database->beginTransaction();
        try {
            $this->database->prepare('UPDATE users SET password_hash = :password WHERE id = :id')
                ->execute(['password' => password_hash($password, PASSWORD_DEFAULT), 'id' => $user['id']]);
            $revoke = $this->database->prepare(
                "UPDATE user_sessions SET revoked_at = UTC_TIMESTAMP(6), revoke_reason = 'PASSWORD_RESET'
                 WHERE user_id = :user AND revoked_at IS NULL"
            );
            $revoke->execute(['user' => $user['id']]);
            $revoked = $revoke->rowCount();
            (new OtpService($this->database))->invalidate($user['id'], OtpService::PURPOSE_PASSWORD_RESET);
            $this->database->commit();
        } catch (\Throwable $error) {
            $this->database->rollBack();
            throw $error;
        }

        (new AuditLog($this->database))->write(
            'PORTAL_PASSWORD_RESET',
            'User',
            $user['id'],
            $user,
            $request,
            null,
            ['sessionsRevoked' => $revoked],
            ['source' => 'portal-reset-password']
        );

        return [
            'email' => $email,
            'reset' => true,
            'sessionsRevoked' => $revoked,
            'message' => 'Your password has been changed. Please sign in again.',
        ];
    }

    /** @return array<string,mixed>|null */
    private function findByEmail(string $email): ?array
    {
        $statement = $this->database->prepare(<<<'SQL'
            SELECT u.*, r.code AS role_code FROM users u JOIN roles r ON r.id = u.role_id
            WHERE u.email = :email AND u.deleted_at IS NULL LIMIT 1
            SQL);
        $statement->execute(['email' => $email]);
        $row = $statement->fetch();

        return is_array($row) ? $row : null;
    }

    private function role(): string
    {
        $role = $this->database->query("SELECT id FROM roles WHERE code = 'CUSTOMER' LIMIT 1")->fetchColumn();
        if (!is_string($role) || $role === '') {
            throw new AuthException('The subscriber role is not configured; run php bin/migrate.php', 500);
        }

        return $role;
    }

    private function assertEmailFree(string $email): void
    {
        $statement = $this->database->prepare('SELECT COUNT(*) FROM users WHERE email = :email AND deleted_at IS NULL');
        $statement->execute(['email' => $email]);
        if ((int) $statement->fetchColumn() > 0) {
            throw new AuthException('An account with this email already exists.', 409);
        }
    }

    private function assertPhoneFree(string $phone): void
    {
        $statement = $this->database->prepare('SELECT COUNT(*) FROM users WHERE phone = :phone AND deleted_at IS NULL');
        $statement->execute(['phone' => $phone]);
        if ((int) $statement->fetchColumn() > 0) {
            throw new AuthException('An account with this phone number already exists.', 409);
        }
    }

    private function auditCodeFailure(string $email, string $purpose, string $reason, Request $request): void
    {
        (new AuditLog($this->database))->write(
            'PORTAL_CODE_REJECTED',
            'User',
            null,
            null,
            $request,
            null,
            null,
            ['source' => 'portal-code', 'purpose' => $purpose, 'reason' => $reason, 'email' => $email]
        );
    }

    /**
     * Per-IP throttle.
     *
     * RateLimiter keeps its buckets in process memory: that is exact for the
     * single-process dev server and a safety net per worker in production, but
     * a multi-worker deployment needs a shared store (see
     * docs/migration/MIGRATION_RISK_REGISTER.md item 4).
     */
    private function throttle(string $bucket, Request $request): void
    {
        $limits = [
            'register' => self::REGISTER_LIMIT,
            'verify' => self::CODE_LIMIT,
            'resend' => self::CODE_LIMIT,
            'forgot' => self::FORGOT_LIMIT,
            'reset' => self::FORGOT_LIMIT,
        ][$bucket] ?? [10, 3600];

        if (!RateLimiter::allow('portal:' . $bucket . ':' . ($request->ipAddress ?? 'cli'), $limits[0], $limits[1])) {
            throw new AuthException('Too many attempts. Please try again later.', 429);
        }
    }

    /**
     * Deliver the code inside the response outside production.
     *
     * This environment has no SMS/email gateway, so without this the flow is
     * not completable end to end.
     *
     * The gate is an explicit opt-in (OTP_DEBUG_CODES=1), NOT "anything that is
     * not production". Inverting the test to a negative one matters: APP_ENV is
     * simply unset on plenty of deployments, and a default of 'local' means any
     * environment that forgot to set it hands a working password-reset code back
     * over HTTP to whoever asked for one. Failing closed costs nothing - a
     * developer sets one variable - while failing open hands out the account.
     *
     * Production is refused even if the flag is set, so a stray env file cannot
     * re-open the hole in the environment that matters most.
     *
     * @param array{id:string,code:string,expiresAt:string,channel:string} $issued
     * @return array{debugCode?:string}
     */
    private function debugCode(array $issued): array
    {
        if (strtolower(Env::get('APP_ENV', 'local')) === 'production') {
            return [];
        }

        if (in_array(strtolower(Env::get('OTP_DEBUG_CODES', '')), ['1', 'true', 'yes', 'on'], true)) {
            return ['debugCode' => $issued['code']];
        }

        return [];
    }

    private function acceptsTerms(array $input): void
    {
        if (($input['acceptTerms'] ?? false) !== true || ($input['acceptPrivacy'] ?? false) !== true) {
            throw new AuthException('Accept the terms of service and the privacy policy to continue.', 422);
        }
    }

    private function email(mixed $value): string
    {
        $email = is_string($value) ? strtolower(trim($value)) : '';
        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            throw new AuthException('Enter a valid email address.', 422);
        }

        return $email;
    }

    private function phone(mixed $value, bool $required = false): ?string
    {
        $phone = is_string($value) ? trim($value) : '';
        if ($phone === '' && !$required) {
            return null;
        }
        if (!preg_match('/^\+?[0-9 ()\-]{9,20}$/', $phone)) {
            throw new AuthException('Enter a valid phone number.', 422);
        }

        return $phone;
    }

    private function channel(mixed $value): string
    {
        $channel = is_string($value) ? strtoupper(trim($value)) : 'EMAIL';
        if (!in_array($channel, ['EMAIL', 'SMS'], true)) {
            throw new AuthException('Select EMAIL or SMS as the delivery channel.', 422);
        }

        return $channel;
    }

    private function purpose(mixed $value): string
    {
        $purpose = is_string($value) ? strtoupper(trim($value)) : '';
        if (!in_array($purpose, [OtpService::PURPOSE_EMAIL_VERIFICATION, OtpService::PURPOSE_PASSWORD_RESET], true)) {
            throw new AuthException('Select a valid code purpose.', 422);
        }

        return $purpose;
    }

    private function required(array $input, string $key, string $label): string
    {
        $value = is_string($input[$key] ?? null) ? trim($input[$key]) : '';
        if ($value === '') {
            throw new AuthException("{$label} is required.", 422);
        }

        return $value;
    }
}
