<?php

declare(strict_types=1);

namespace Mamore\Auth;

use Mamore\Core\AuditLog;
use Mamore\Core\Request;
use Mamore\Core\Uuid;
use PDO;

final class AuthService
{
    public function __construct(private readonly PDO $database)
    {
    }

    public function login(string $email, string $password, Request $request): array
    {
        $email = strtolower(trim($email));
        if ($this->tooManyFailures($email, $request->ipAddress)) {
            throw new AuthException('Too many login attempts. Try again later.', 429);
        }
        $statement = $this->database->prepare(<<<'SQL'
            SELECT u.*, r.code AS role_code
            FROM users u
            JOIN roles r ON r.id = u.role_id
            WHERE u.email = :email AND u.deleted_at IS NULL
            LIMIT 1
            SQL);
        $statement->execute(['email' => $email]);
        $user = $statement->fetch();

        $valid = is_array($user)
            ? password_verify($password, $user['password_hash'])
            : password_verify($password, password_hash('invalid-login-placeholder', PASSWORD_DEFAULT));

        if (!$valid || !is_array($user) || $user['status'] !== 'ACTIVE') {
            $this->recordLogin(is_array($user) ? $user['id'] : null, $email, false, 'INVALID_CREDENTIALS', $request);
            throw new AuthException('Invalid email or password.');
        }

        $accessToken = $this->token();
        $refreshToken = $this->token();
        $sessionId = Uuid::v4();
        $now = new \DateTimeImmutable('now', new \DateTimeZone('UTC'));
        $accessExpiresAt = $now->modify('+15 minutes');
        $refreshExpiresAt = $now->modify('+7 days');

        $this->database->beginTransaction();
        try {
            $insert = $this->database->prepare(<<<'SQL'
                INSERT INTO user_sessions
                    (id, user_id, access_token_hash, refresh_token_hash, ip_address, user_agent, expires_at, refresh_expires_at)
                VALUES
                    (:id, :user_id, :access_hash, :refresh_hash, :ip, :agent, :expires_at, :refresh_expires_at)
                SQL);
            $insert->execute([
                'id' => $sessionId,
                'user_id' => $user['id'],
                'access_hash' => hash('sha256', $accessToken),
                'refresh_hash' => hash('sha256', $refreshToken),
                'ip' => $request->ipAddress,
                'agent' => $request->userAgent,
                'expires_at' => $accessExpiresAt->format('Y-m-d H:i:s.u'),
                'refresh_expires_at' => $refreshExpiresAt->format('Y-m-d H:i:s.u'),
            ]);
            $this->database->prepare('UPDATE users SET last_login_at = CURRENT_TIMESTAMP(6) WHERE id = :id')->execute(['id' => $user['id']]);
            $this->recordLogin($user['id'], $email, true, null, $request);
            $this->audit($user['id'], 'AUTH_LOGIN', 'UserSession', $sessionId, $request, ['id' => $user['id'], 'session_id' => $sessionId]);
            $this->database->commit();
        } catch (\Throwable $error) {
            $this->database->rollBack();
            throw $error;
        }

        return [
            'accessToken' => $accessToken,
            'accessTokenExpiresAt' => $accessExpiresAt->format(DATE_ATOM),
            'refreshToken' => $refreshToken,
            'refreshTokenExpiresAt' => $refreshExpiresAt->format(DATE_ATOM),
            'user' => $this->publicUser($user),
        ];
    }

    public function authenticate(?string $accessToken): array
    {
        if (!$accessToken) {
            throw new AuthException('Authentication required.');
        }
        $statement = $this->database->prepare(<<<'SQL'
            SELECT u.*, r.code AS role_code, s.id AS session_id
            FROM user_sessions s
            JOIN users u ON u.id = s.user_id
            JOIN roles r ON r.id = u.role_id
            WHERE s.access_token_hash = :token_hash
              AND s.revoked_at IS NULL
              AND s.expires_at > CURRENT_TIMESTAMP(6)
              AND u.status = 'ACTIVE'
              AND u.deleted_at IS NULL
            LIMIT 1
            SQL);
        $statement->execute(['token_hash' => hash('sha256', $accessToken)]);
        $user = $statement->fetch();
        if (!is_array($user)) {
            throw new AuthException('Invalid, expired or revoked session.');
        }
        $this->database->prepare('UPDATE user_sessions SET last_activity_at = CURRENT_TIMESTAMP(6) WHERE id = :id')->execute(['id' => $user['session_id']]);
        return $user;
    }

    public function refresh(string $refreshToken, Request $request): array
    {
        $statement = $this->database->prepare(<<<'SQL'
            SELECT u.*, r.code AS role_code, s.id AS session_id
            FROM user_sessions s
            JOIN users u ON u.id = s.user_id
            JOIN roles r ON r.id = u.role_id
            WHERE s.refresh_token_hash = :token_hash
              AND s.revoked_at IS NULL
              AND s.refresh_expires_at > CURRENT_TIMESTAMP(6)
              AND u.status = 'ACTIVE'
              AND u.deleted_at IS NULL
            LIMIT 1
            SQL);
        $statement->execute(['token_hash' => hash('sha256', $refreshToken)]);
        $user = $statement->fetch();
        if (!is_array($user)) throw new AuthException('Invalid, expired or revoked refresh token.');

        $accessToken = $this->token();
        $nextRefreshToken = $this->token();
        $now = new \DateTimeImmutable('now', new \DateTimeZone('UTC'));
        $accessExpiresAt = $now->modify('+15 minutes');
        $refreshExpiresAt = $now->modify('+7 days');
        $this->database->beginTransaction();
        try {
            $update = $this->database->prepare(<<<'SQL'
            UPDATE user_sessions SET
                access_token_hash = :access_hash,
                refresh_token_hash = :refresh_hash,
                expires_at = :expires_at,
                refresh_expires_at = :refresh_expires_at,
                last_activity_at = CURRENT_TIMESTAMP(6),
                ip_address = :ip,
                user_agent = :agent
            WHERE id = :id AND revoked_at IS NULL
            SQL);
            $update->execute([
                'access_hash' => hash('sha256', $accessToken), 'refresh_hash' => hash('sha256', $nextRefreshToken),
                'expires_at' => $accessExpiresAt->format('Y-m-d H:i:s.u'), 'refresh_expires_at' => $refreshExpiresAt->format('Y-m-d H:i:s.u'),
                'ip' => $request->ipAddress, 'agent' => $request->userAgent, 'id' => $user['session_id'],
            ]);
            if ($update->rowCount() !== 1) throw new AuthException('Session could not be rotated.');
            $this->audit($user['id'], 'AUTH_TOKEN_ROTATED', 'UserSession', $user['session_id'], $request, ['id' => $user['id'], 'session_id' => $user['session_id']]);
            $this->database->commit();
        } catch (\Throwable $error) {
            $this->database->rollBack();
            throw $error;
        }
        return [
            'accessToken' => $accessToken, 'accessTokenExpiresAt' => $accessExpiresAt->format(DATE_ATOM),
            'refreshToken' => $nextRefreshToken, 'refreshTokenExpiresAt' => $refreshExpiresAt->format(DATE_ATOM),
            'user' => $this->publicUser($user),
        ];
    }

    public function sessions(array $user): array
    {
        $statement = $this->database->prepare(<<<'SQL'
            SELECT id, ip_address, user_agent, expires_at, refresh_expires_at, last_activity_at, created_at,
                   CASE WHEN revoked_at IS NULL AND refresh_expires_at > CURRENT_TIMESTAMP(6) THEN TRUE ELSE FALSE END AS is_active
            FROM user_sessions WHERE user_id = :user_id ORDER BY created_at DESC
            SQL);
        $statement->execute(['user_id' => $user['id']]);
        return $statement->fetchAll();
    }

    public function revokeSession(array $user, string $sessionId, Request $request): void
    {
        $statement = $this->database->prepare(<<<'SQL'
            UPDATE user_sessions SET revoked_at = CURRENT_TIMESTAMP(6), revoke_reason = 'USER_REVOKED'
            WHERE id = :id AND user_id = :user_id AND revoked_at IS NULL
            SQL);
        $statement->execute(['id' => $sessionId, 'user_id' => $user['id']]);
        if ($statement->rowCount() !== 1) throw new AuthException('Active session not found.', 404);
        $this->audit($user['id'], 'AUTH_SESSION_REVOKED', 'UserSession', $sessionId, $request, ['id' => $user['id'], 'session_id' => $user['session_id']]);
    }

    public function requirePermission(array $user, string $permission): void
    {
        $statement = $this->database->prepare(<<<'SQL'
            SELECT 1 FROM role_permissions rp
            JOIN permissions p ON p.id = rp.permission_id
            WHERE rp.role_id = :role_id AND p.code = :permission LIMIT 1
            SQL);
        $statement->execute(['role_id' => $user['role_id'], 'permission' => $permission]);
        if (!$statement->fetchColumn()) throw new AuthException('You do not have permission to perform this action.', 403);
    }

    public function logout(array $user, Request $request): void
    {
        $this->database->prepare(<<<'SQL'
            UPDATE user_sessions
            SET revoked_at = CURRENT_TIMESTAMP(6), revoke_reason = 'LOGOUT'
            WHERE id = :id AND user_id = :user_id AND revoked_at IS NULL
            SQL)->execute(['id' => $user['session_id'], 'user_id' => $user['id']]);
        $this->audit($user['id'], 'AUTH_LOGOUT', 'UserSession', $user['session_id'], $request, ['id' => $user['id'], 'session_id' => $user['session_id']]);
    }

    public function publicUser(array $user): array
    {
        return ['id' => $user['id'], 'firstName' => $user['first_name'], 'lastName' => $user['last_name'], 'email' => $user['email'], 'phone' => $user['phone'], 'role' => $user['role_code']];
    }

    private function token(): string
    {
        return rtrim(strtr(base64_encode(random_bytes(32)), '+/', '-_'), '=');
    }

    private function tooManyFailures(string $email, ?string $ipAddress): bool
    {
        $statement = $this->database->prepare(<<<'SQL'
            SELECT
                SUM(CASE WHEN attempted_email = :email THEN 1 ELSE 0 END) AS email_failures,
                SUM(CASE WHEN :has_ip = 1 AND ip_address = :ip THEN 1 ELSE 0 END) AS ip_failures
            FROM login_history
            WHERE succeeded = FALSE
              AND occurred_at >= (CURRENT_TIMESTAMP(6) - INTERVAL 15 MINUTE)
            SQL);
        $statement->execute(['email' => $email, 'has_ip' => $ipAddress !== null ? 1 : 0, 'ip' => $ipAddress]);
        $failures = $statement->fetch();
        return (int) ($failures['email_failures'] ?? 0) >= 5 || (int) ($failures['ip_failures'] ?? 0) >= 50;
    }

    private function recordLogin(?string $userId, string $email, bool $succeeded, ?string $reason, Request $request): void
    {
        $statement = $this->database->prepare(<<<'SQL'
            INSERT INTO login_history (user_id, attempted_email, succeeded, failure_reason, ip_address, user_agent)
            VALUES (:user_id, :email, :succeeded, :reason, :ip, :agent)
            SQL);
        $statement->execute(['user_id' => $userId, 'email' => $email, 'succeeded' => $succeeded ? 1 : 0, 'reason' => $reason, 'ip' => $request->ipAddress, 'agent' => $request->userAgent]);
    }

    private function audit(string $userId, string $action, string $entityType, string $entityId, Request $request, ?array $actor = null): void
    {
        // Login/logout rows are written before a session exists, so the actor is
        // carried explicitly and the role is left to be filled by the reader.
        (new AuditLog($this->database))->write(
            $action,
            $entityType,
            $entityId,
            $actor ?? ($userId === '' ? null : ['id' => $userId]),
            $request,
            null,
            null,
            ['source' => 'auth']
        );
    }
}
