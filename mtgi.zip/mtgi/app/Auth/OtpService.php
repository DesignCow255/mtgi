<?php

declare(strict_types=1);

namespace Mamore\Auth;

use Mamore\Core\AuditLog;
use Mamore\Core\Logger;
use Mamore\Core\Request;
use Mamore\Core\ServerClock;
use Mamore\Core\Uuid;
use PDO;

/**
 * One-time passcodes for email verification and password reset.
 *
 * Canonical rules (backend/src/services/otp.service.ts): 6 digit code, 10 minute
 * expiry, 5 attempts, 60 second resend cooldown. Two hardenings:
 *
 *  - the code is stored as a SHA-256 hash, never in clear text;
 *  - delivery goes through deliver(), so swapping in SMS/email later touches
 *    exactly one method.
 */
final class OtpService
{
    public const PURPOSE_EMAIL_VERIFICATION = 'EMAIL_VERIFICATION';
    public const PURPOSE_PASSWORD_RESET = 'PASSWORD_RESET';
    public const DEFAULT_EXPIRE_MINUTES = 10;
    public const DEFAULT_MAX_ATTEMPTS = 5;
    public const DEFAULT_RESEND_COOLDOWN_SECONDS = 60;

    public function __construct(private readonly PDO $database) {}

    /**
     * Issue a code for a user, honouring the resend cooldown.
     *
     * @param array{channel?:string,expireMinutes?:int,maxAttempts?:int,cooldownSeconds?:int} $options
     *
     * @return array{id:string,code:string,expiresAt:string,channel:string}
     */
    public function issue(string $userId, string $purpose, array $options = [], ?Request $request = null): array
    {
        $purpose = $this->purpose($purpose);
        $channel = $this->channel($options['channel'] ?? 'EMAIL');
        $expireMinutes = max(1, min((int) ($options['expireMinutes'] ?? self::DEFAULT_EXPIRE_MINUTES), 60));
        $maxAttempts = max(1, min((int) ($options['maxAttempts'] ?? self::DEFAULT_MAX_ATTEMPTS), 10));
        $cooldown = max(0, min((int) ($options['cooldownSeconds'] ?? self::DEFAULT_RESEND_COOLDOWN_SECONDS), 3600));

        $this->assertCooldown($userId, $purpose, $cooldown, $request);

        $code = $this->generateCode();
        $id = Uuid::v4();
        // Expiry is derived from the database clock, because expires_at is
        // written here but compared against UTC_TIMESTAMP(6) in SQL. Deriving one
        // from the PHP clock and the other from the database makes codes expire
        // early - or never - whenever the two hosts disagree.
        $expiresAt = gmdate('Y-m-d H:i:s', ServerClock::epoch($this->database) + $expireMinutes * 60);
        $this->database->prepare(<<<'SQL'
            INSERT INTO otp_codes
                (id, user_id, purpose, code_hash, channel, attempts, max_attempts, expires_at, delivered_at)
            VALUES
                (:id, :user, :purpose, :hash, :channel, 0, :maxAttempts, :expires, UTC_TIMESTAMP(6))
            SQL)->execute([
            'id' => $id,
            'user' => $userId,
            'purpose' => $purpose,
            'hash' => $this->hash($userId, $purpose, $code),
            'channel' => $channel,
            'maxAttempts' => $maxAttempts,
            'expires' => $expiresAt,
        ]);

        $this->deliver($userId, $purpose, $code, $channel, $request);

        return ['id' => $id, 'code' => $code, 'expiresAt' => $expiresAt, 'channel' => $channel];
    }

    /**
     * Validate a code.
     *
     * A wrong code increments attempts; once the cap is reached the code is
     * dead. Reasons are for internal logging only - the HTTP layer answers with
     * one generic message so the endpoint cannot be used to enumerate accounts
     * or guess which part of the code was wrong.
     *
     * @return array{valid:bool,reason:?string,expiresAt:?string}
     */
    public function verify(string $userId, string $code, string $purpose): array
    {
        $purpose = $this->purpose($purpose);
        $code = trim($code);

        $latest = $this->latestCode($userId, $purpose);
        if ($latest === null) {
            return ['valid' => false, 'reason' => 'no_active_code', 'expiresAt' => null];
        }
        if ($latest['used_at'] !== null) {
            return ['valid' => false, 'reason' => 'already_used', 'expiresAt' => $latest['expires_at']];
        }
        if ((int) $latest['attempts'] >= (int) $latest['max_attempts']) {
            return ['valid' => false, 'reason' => 'attempts_exhausted', 'expiresAt' => $latest['expires_at']];
        }
        if (ServerClock::parse((string) $latest['expires_at']) < ServerClock::epoch($this->database)) {
            return ['valid' => false, 'reason' => 'expired', 'expiresAt' => $latest['expires_at']];
        }

        if (!hash_equals((string) $latest['code_hash'], $this->hash($userId, $purpose, $code))) {
            $this->database->prepare('UPDATE otp_codes SET attempts = attempts + 1 WHERE id = :id')
                ->execute(['id' => $latest['id']]);

            return ['valid' => false, 'reason' => 'mismatch', 'expiresAt' => $latest['expires_at']];
        }

        // Claim the code atomically. Checking used_at in PHP and then writing it
        // is a time-of-check-to-time-of-use race: two requests carrying the same
        // correct code both read used_at IS NULL, both pass, and a one-time code
        // activates an account twice. The guarded UPDATE makes the database the
        // arbiter, and exactly one caller can win.
        $claim = $this->database->prepare('UPDATE otp_codes SET used_at = UTC_TIMESTAMP(6) WHERE id = :id AND used_at IS NULL');
        $claim->execute(['id' => $latest['id']]);

        if ($claim->rowCount() !== 1) {
            return ['valid' => false, 'reason' => 'already_used', 'expiresAt' => $latest['expires_at']];
        }

        return ['valid' => true, 'reason' => null, 'expiresAt' => $latest['expires_at']];
    }

    /** Invalidate every active code for a user + purpose. */
    public function invalidate(string $userId, string $purpose): int
    {
        $statement = $this->database->prepare(
            'UPDATE otp_codes SET used_at = UTC_TIMESTAMP(6) WHERE user_id = :user AND purpose = :purpose AND used_at IS NULL'
        );
        $statement->execute(['user' => $userId, 'purpose' => $this->purpose($purpose)]);

        return $statement->rowCount();
    }

    /** @return array{attempts:int,max_attempts:int,expires_at:string,used_at:?string,code_hash:string,id:string}|null */
    private function latestCode(string $userId, string $purpose): ?array
    {
        $statement = $this->database->prepare(
            'SELECT id, code_hash, attempts, max_attempts, expires_at, used_at FROM otp_codes
             WHERE user_id = :user AND purpose = :purpose ORDER BY created_at DESC, id DESC LIMIT 1'
        );
        $statement->execute(['user' => $userId, 'purpose' => $purpose]);
        $row = $statement->fetch();

        return is_array($row) ? $row : null;
    }

    private function assertCooldown(string $userId, string $purpose, int $cooldown, ?Request $request): void
    {
        if ($cooldown === 0) {
            return;
        }
        $statement = $this->database->prepare(
            'SELECT created_at FROM otp_codes
             WHERE user_id = :user AND purpose = :purpose AND used_at IS NULL AND expires_at > UTC_TIMESTAMP(6)
             ORDER BY created_at DESC LIMIT 1'
        );
        $statement->execute(['user' => $userId, 'purpose' => $purpose]);
        $createdAt = $statement->fetchColumn();
        if (!is_string($createdAt) || $createdAt === '') {
            return;
        }

        $age = ServerClock::epoch($this->database) - ServerClock::parse($createdAt);
        if ($age >= $cooldown) {
            return;
        }

        $wait = (int) ceil($cooldown - $age);
        (new AuditLog($this->database))->write(
            'OTP_RESEND_BLOCKED',
            'User',
            $userId,
            null,
            $request,
            null,
            null,
            ['purpose' => $purpose, 'waitSeconds' => $wait]
        );
        throw new AuthException("Please wait {$wait}s before requesting a new code.", 429);
    }

    /**
     * Delivery seam. This environment has no SMS/email gateway wired, so the
     * code goes to the application log - the same dev channel the canonical
     * service uses. Swapping in a real gateway touches only this method.
     */
    private function deliver(string $userId, string $purpose, string $code, string $channel, ?Request $request): void
    {
        Logger::info('One-time code issued', [
            'userId' => $userId,
            'purpose' => $purpose,
            'channel' => $channel,
            'code' => $code,
            'ip' => $request?->ipAddress,
        ]);
    }

    private function generateCode(): string
    {
        return (string) random_int(100000, 999999);
    }

    /** Bind the code to user and purpose so codes cannot be swapped around. */
    private function hash(string $userId, string $purpose, string $code): string
    {
        return hash('sha256', $userId . '|' . $purpose . '|' . $code);
    }

    private function purpose(string $purpose): string
    {
        $purpose = strtoupper(trim($purpose));
        if (!in_array($purpose, [self::PURPOSE_EMAIL_VERIFICATION, self::PURPOSE_PASSWORD_RESET], true)) {
            throw new AuthException('Select a valid code purpose.', 422);
        }

        return $purpose;
    }

    private function channel(string $channel): string
    {
        $channel = strtoupper(trim($channel));
        if (!in_array($channel, ['EMAIL', 'SMS'], true)) {
            throw new AuthException('Select EMAIL or SMS as the delivery channel.', 422);
        }

        return $channel;
    }
}
