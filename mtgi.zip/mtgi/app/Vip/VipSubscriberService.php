<?php

declare(strict_types=1);

namespace Mamore\Vip;

use Mamore\Auth\AuthException;
use Mamore\Core\AuditLog;
use Mamore\Core\Request;
use Mamore\Core\ServerClock;
use Mamore\Core\Uuid;
use Mamore\SmartBus\RescueCodeService;
use Mamore\Rescue\RescueCoverageService;
use PDO;

/**
 * The VIP domain (Feature: VIP subscribers).
 *
 * A VIP is a profile hanging off the canonical person, a set of covered vehicles
 * off the canonical registry, and a rescue code issued through the single shared
 * service. VIP is a real operational domain: it has its own lifecycle, its own
 * dashboard and its own analytics, and it never re-implements coverage.
 */
final class VipSubscriberService
{
    public function __construct(
        private readonly PDO $database,
        private readonly RescueCoverageService $coverage,
        private readonly RescueCodeService $codes,
    ) {}

    /**
     * The administrative VIP board.
     *
     * @param array<string,mixed> $filters
     *
     * @return array<string,mixed>
     */
    public function dashboard(array $filters = [], ?array $actor = null): array
    {
        $params = $this->filterParams($filters);
        $statusColumn = static fn (string $status): string => "v.status = '{$status}'";

        $metrics = [
            'total' => $this->scalar('SELECT COUNT(*) FROM vip_subscribers v ' . $this->filterClause($filters), $params),
            'active' => $this->scalar(
                'SELECT COUNT(*) FROM vip_subscribers v ' . $this->filterClauseWith($filters, $statusColumn('ACTIVE')),
                $params
            ),
            'pending' => $this->scalar(
                'SELECT COUNT(*) FROM vip_subscribers v ' . $this->filterClauseWith($filters, $statusColumn('PENDING')),
                $params
            ),
            'suspended' => $this->scalar(
                'SELECT COUNT(*) FROM vip_subscribers v ' . $this->filterClauseWith($filters, $statusColumn('SUSPENDED')),
                $params
            ),
            'expired' => $this->scalar(
                'SELECT COUNT(*) FROM vip_subscribers v ' . $this->filterClauseWith($filters, $statusColumn('EXPIRED')),
                $params
            ),
            'expiringSoon' => $this->scalar(
                'SELECT COUNT(*) FROM vip_subscribers v ' . $this->filterClauseWith($filters,
                    'v.expires_at IS NOT NULL AND v.expires_at BETWEEN UTC_TIMESTAMP(6) AND DATE_ADD(UTC_TIMESTAMP(6), INTERVAL 30 DAY)'),
                $params
            ),
            'coveredVehicles' => $this->scalar("SELECT COUNT(*) FROM vip_vehicle_links WHERE coverage_status = 'ACTIVE'"),
            'covered' => $this->scalar(
                'SELECT COUNT(*) FROM vip_subscribers v ' . $this->filterClauseWith($filters, "v.rescue_coverage_status = 'ACTIVE'"),
                $params
            ),
            'activeJourneys' => $this->scalar(
                "SELECT COUNT(*) FROM active_journeys aj
                 JOIN vip_subscribers v ON v.person_id = aj.subscriber_id
                 WHERE aj.status = 'ACTIVE'"
            ),
            'incidents' => $this->scalar("SELECT COUNT(*) FROM rescue_incidents WHERE status NOT IN ('RESOLVED', 'CANCELLED')"),
        ];

        return [
            'metrics' => $metrics,
            'byPlan' => $this->groups("SELECT COALESCE(p.name, 'No plan') AS label, COUNT(v.id) AS total
                                       FROM vip_subscribers v LEFT JOIN service_plans p ON p.id = v.service_plan_id
                                       " . $this->filterClause($filters) . " GROUP BY p.id, p.name ORDER BY total DESC", $params),
            'byStatus' => $this->groups("SELECT v.status AS label, COUNT(*) AS total FROM vip_subscribers v
                                         " . $this->filterClause($filters) . " GROUP BY v.status ORDER BY total DESC", $params),
            'byType' => $this->groups("SELECT t.label AS label, COUNT(*) AS total FROM vip_subscribers v
                                       JOIN vip_membership_types t ON t.code = v.membership_type
                                       " . $this->filterClause($filters) . " GROUP BY t.code, t.label ORDER BY total DESC", $params),
            'byGeography' => $this->groups(
                "SELECT CONCAT(COALESCE(v.home_region, 'Unspecified'), ' / ', COALESCE(v.home_city, 'Unspecified')) AS label,
                        COUNT(*) AS total
                 FROM vip_subscribers v " . $this->filterClause($filters) . "
                 GROUP BY v.home_region, v.home_city ORDER BY total DESC LIMIT 10",
                $params
            ),
            'message' => $metrics['total'] === 0 ? 'No data available.' : null,
        ];
    }

    /**
     * Create a VIP profile for a canonical person.
     *
     * @return array<string,mixed>
     */
    public function create(array $input, array $actor, Request $request): array
    {
        $personId = $this->required($input, 'personId', 'Person');
        $person = $this->person($personId);
        $membershipType = $this->choice($input['membershipType'] ?? 'INDIVIDUAL', 'membership_type', 'vip_membership_types');
        $priority = $this->choice($input['priorityLevel'] ?? 'STANDARD', 'priority_level', 'vip_priority_levels');
        $planId = $this->optional($input, 'servicePlanId');
        $organizationId = $this->optional($input, 'organizationId');
        if ($planId !== null) {
            $this->plan($planId, 'VIP');
        }

        $membershipNumber = $this->membershipNumber();
        $id = Uuid::v4();
        $this->database->beginTransaction();
        try {
            $this->database->prepare(<<<'SQL'
                INSERT INTO vip_subscribers
                    (id, person_id, organization_id, membership_number, membership_type, service_plan_id, status,
                     priority_level, home_country, home_region, home_city, primary_phone, alternative_phone,
                     preferred_language, preferred_currency, created_by_user_id)
                VALUES
                    (:id, :person, :organization, :number, :type, :plan, 'PENDING', :priority, :country, :region, :city,
                     :phone, :altPhone, :language, :currency, :actor)
                SQL)->execute([
                'id' => $id, 'person' => $personId, 'organization' => $organizationId, 'number' => $membershipNumber,
                'type' => $membershipType, 'plan' => $planId, 'priority' => $priority,
                'country' => $this->optional($input, 'homeCountry') ?? 'CD',
                'region' => $this->optional($input, 'homeRegion'),
                'city' => $this->optional($input, 'homeCity'),
                'phone' => $this->optional($input, 'primaryPhone') ?? $person['phone'] ?? null,
                'altPhone' => $this->optional($input, 'alternativePhone'),
                'language' => $this->optional($input, 'preferredLanguage') ?? 'en',
                'currency' => $this->optional($input, 'preferredCurrency') ?? 'USD',
                'actor' => $actor['id'] ?? null,
            ]);

            $this->database->prepare(
                'INSERT INTO vip_emergency_profiles (vip_subscriber_id, preferred_language) VALUES (:id, :language)'
            )->execute(['id' => $id, 'language' => $this->optional($input, 'preferredLanguage') ?? 'en']);
            $this->database->commit();
        } catch (\PDOException $error) {
            if ($this->database->inTransaction()) {
                $this->database->rollBack();
            }
            // One VIP profile per person, expressed as a domain rule rather than
            // a raw driver error.
            if ((string) $error->getCode() === '23000') {
                throw new AuthException('This person already holds a VIP membership.', 422);
            }
            throw $error;
        } catch (\Throwable $error) {
            if ($this->database->inTransaction()) {
                $this->database->rollBack();
            }
            throw $error;
        }

        (new AuditLog($this->database))->write(
            'VIP_SUBSCRIBER_CREATED',
            'VipSubscriber',
            $id,
            $actor,
            $request,
            null,
            ['membershipNumber' => $membershipNumber, 'membershipType' => $membershipType, 'priority' => $priority],
            ['source' => 'vip-domain']
        );

        return $this->show($id, $actor);
    }

    /**
     * Activate a VIP: this is where the domain connects to Rescue.
     *
     * The rescue code is issued through the shared service and the coverage link
     * through the shared coverage engine, so a VIP is covered by exactly the same
     * machinery as every other domain.
     *
     * @return array<string,mixed>
     */
    public function activate(array $input, array $actor, Request $request): array
    {
        $id = $this->required($input, 'vipSubscriberId', 'VIP subscriber');
        $vip = $this->row($id);
        if ($vip['status'] === 'ACTIVE') {
            return $this->show($id, $actor);
        }

        $expiresAt = $this->optional($input, 'expiresAt');
        $subscriberId = $this->subscriberIdForPerson((string) $vip['person_id']);
        $planId = $vip['service_plan_id'] ?? $this->planForCode('VIP-ROAD-ASSIST');

        $this->database->beginTransaction();
        try {
            $this->database->prepare(<<<'SQL'
                UPDATE vip_subscribers SET status = 'ACTIVE', activated_at = UTC_TIMESTAMP(6), expires_at = :expires,
                       subscription_id = :subscription, updated_at = UTC_TIMESTAMP(6)
                WHERE id = :id
                SQL)->execute([
                'expires' => $expiresAt,
                'subscription' => $vip['subscription_id'] ?? null,
                'id' => $id,
            ]);
            $this->database->commit();
        } catch (\Throwable $error) {
            if ($this->database->inTransaction()) {
                $this->database->rollBack();
            }
            throw $error;
        }

        // Rescue code: issued only when there is a subscriber record to own it.
        $rescueCode = null;
        if ($subscriberId !== null) {
            try {
                $issued = $this->codes->issue([
                    'subscriberId' => $subscriberId,
                    'expiresAt' => $expiresAt,
                ], $actor, $request);
                $rescueCode = $issued;
            } catch (AuthException $error) {
                // A VIP without a membership record still activates; the code is
                // simply not issued, and the reason is not swallowed.
                $rescueCode = ['code' => null, 'error' => $error->getMessage()];
            }
        }

        // Coverage: recorded through the shared engine, never invented here.
        $coverage = $this->coverage->grant([
            'subjectType' => 'PERSON',
            'subjectId' => (string) $vip['person_id'],
            'subscriberId' => $subscriberId,
            'organizationId' => $vip['organization_id'] ?? null,
            'subscriptionId' => $vip['subscription_id'] ?? null,
            'servicePlanId' => $planId,
            'coverageType' => 'ROAD_ASSISTANCE',
            'endsAt' => $expiresAt,
        ], $actor);

        $this->syncCoverageStatus($id);
        if (is_string($rescueCode['code'] ?? null)) {
            $this->attachRescueCode($id, (string) $rescueCode['code']);
        }

        (new AuditLog($this->database))->write(
            'VIP_ACTIVATED',
            'VipSubscriber',
            $id,
            $actor,
            $request,
            ['status' => $vip['status']],
            ['status' => 'ACTIVE', 'rescueCodeIssued' => is_string($rescueCode['code'] ?? null), 'coverage' => $coverage['status']],
            ['source' => 'vip-domain']
        );

        return $this->show($id, $actor);
    }

    /**
     * A VIP profile, with the rescue facts resolved.
     *
     * @return array<string,mixed>
     */
    public function show(string $id, ?array $actor = null): array
    {
        $vip = $this->row($id);
        if ($actor !== null) {
            $this->assertCanView($vip, $actor);
        }

        $coverage = $this->coverage->check('PERSON', (string) $vip['person_id']);
        $codeStatement = $this->database->prepare(
            "SELECT id, code, status FROM rescue_codes WHERE subscriber_id = :subscriber AND status = 'ACTIVE' LIMIT 1"
        );
        $codeStatement->execute(['subscriber' => $this->subscriberIdForPerson((string) $vip['person_id'])]);
        $code = $codeStatement->fetch();

        $statement = $this->database->prepare(<<<'SQL'
            SELECT l.id, l.relationship, l.is_primary, l.coverage_status, v.id AS vehicle_id,
                   v.registration_number, v.make, v.model, v.vehicle_type, v.verified_status,
                   a.id AS tracked_asset_id, a.tracking_status, pos.latitude, pos.longitude, pos.recorded_at
            FROM vip_vehicle_links l
            JOIN vehicles v ON v.id = l.vehicle_id
            LEFT JOIN tracked_assets a ON a.vehicle_id = v.id
            LEFT JOIN tracked_asset_positions pos ON pos.tracked_asset_id = a.id
            WHERE l.vip_subscriber_id = :id
            ORDER BY l.is_primary DESC, v.registration_number
            SQL);
        $statement->execute(['id' => $id]);

        return [
            'id' => $vip['id'],
            'membershipNumber' => $vip['membership_number'],
            'person' => $this->personSummary((string) $vip['person_id']),
            'organizationId' => $vip['organization_id'],
            'membershipType' => $vip['membership_type'],
            'priorityLevel' => $vip['priority_level'],
            'status' => $vip['status'],
            'homeCountry' => $vip['home_country'],
            'homeRegion' => $vip['home_region'],
            'homeCity' => $vip['home_city'],
            'primaryPhone' => $vip['primary_phone'],
            'preferredLanguage' => $vip['preferred_language'],
            'preferredCurrency' => $vip['preferred_currency'],
            'plan' => $vip['service_plan_id'] === null ? null : $this->planSummary((string) $vip['service_plan_id']),
            'activatedAt' => $vip['activated_at'],
            'expiresAt' => $vip['expires_at'],
            'rescueCode' => is_array($code) ? $code['code'] : null,
            'rescueCodeStatus' => is_array($code) ? $code['status'] : 'NOT_ISSUED',
            'rescueCoverage' => $coverage,
            'emergencyProfileComplete' => (bool) $vip['emergency_profile_complete'],
            'dependants' => $this->dependants($id),
            'vehicles' => array_map([$this, 'vehicleSummary'], $statement->fetchAll()),
        ];
    }

    /**
     * Link a vehicle to a VIP, respecting the membership type's rules.
     *
     * @return array<string,mixed>
     */
    public function linkVehicle(array $input, array $actor, Request $request): array
    {
        $vipId = $this->required($input, 'vipSubscriberId', 'VIP subscriber');
        $vehicleId = $this->required($input, 'vehicleId', 'Vehicle');
        $vip = $this->row($vipId);
        $relationship = $this->choice($input['relationship'] ?? 'OWNER', 'relationship', null, [
            'OWNER', 'PRIMARY_DRIVER', 'FAMILY_VEHICLE', 'COMPANY_VEHICLE', 'AUTHORIZED_USER',
        ]);
        $isPrimary = (bool) ($input['isPrimary'] ?? false);

        $this->vehicle($vehicleId);

        $alreadyLinked = (int) $this->database->query(
            'SELECT COUNT(*) FROM vip_vehicle_links WHERE vip_subscriber_id = ' . $this->database->quote($vipId)
            . ' AND vehicle_id = ' . $this->database->quote($vehicleId)
        )->fetchColumn();
        if ($alreadyLinked > 0) {
            throw new AuthException('This vehicle is already linked to the membership.', 409);
        }
        if ($isPrimary) {
            $primaryExists = (int) $this->database->query(
                'SELECT COUNT(*) FROM vip_vehicle_links WHERE vip_subscriber_id = ' . $this->database->quote($vipId)
                . ' AND is_primary = 1'
            )->fetchColumn();
            if ($primaryExists > 0) {
                throw new AuthException('A primary vehicle is already set for this membership.', 422);
            }
        }

        $limits = $this->database->query(
            'SELECT allows_multiple_vehicles FROM vip_membership_types WHERE code = '
            . $this->database->quote($vip['membership_type'])
        )->fetchColumn();
        $existing = (int) $this->database->query(
            'SELECT COUNT(*) FROM vip_vehicle_links WHERE vip_subscriber_id = ' . $this->database->quote($vipId)
        )->fetchColumn();
        if ($limits === 0 && $existing >= 1) {
            throw new AuthException('This membership type covers a single vehicle.', 409);
        }

        $id = Uuid::v4();
        $this->database->beginTransaction();
        try {
            $this->database->prepare(<<<'SQL'
                INSERT INTO vip_vehicle_links
                    (id, vip_subscriber_id, vehicle_id, relationship, is_primary, coverage_status, coverage_start)
                VALUES (:id, :vip, :vehicle, :relationship, :isPrimary, 'UNCOVERED', UTC_TIMESTAMP(6))
                SQL)->execute([
                'id' => $id, 'vip' => $vipId, 'vehicle' => $vehicleId,
                'relationship' => $relationship, 'isPrimary' => $isPrimary ? 1 : 0,
            ]);
            $this->database->prepare(
                'UPDATE vehicles SET owner_person_id = COALESCE(owner_person_id, :person) WHERE id = :id'
            )->execute(['person' => $vip['person_id'], 'id' => $vehicleId]);
            $this->database->commit();
        } catch (\PDOException $error) {
            if ($this->database->inTransaction()) {
                $this->database->rollBack();
            }
            if ((string) $error->getCode() === '23000') {
                throw new AuthException('This vehicle is already linked to the membership.', 409);
            }
            throw $error;
        } catch (\Throwable $error) {
            if ($this->database->inTransaction()) {
                $this->database->rollBack();
            }
            throw $error;
        }

        // A covered VIP vehicle inherits the membership's coverage.
        $this->coverage->grant([
            'subjectType' => 'VEHICLE',
            'subjectId' => $vehicleId,
            'vehicleId' => $vehicleId,
            'subscriberId' => $this->subscriberIdForPerson((string) $vip['person_id']),
            'servicePlanId' => $vip['service_plan_id'],
            'coverageType' => 'ROAD_ASSISTANCE',
            'endsAt' => $vip['expires_at'],
        ], $actor);
        $this->syncVehicleCoverage($vipId);

        (new AuditLog($this->database))->write(
            'VIP_VEHICLE_LINKED',
            'VipSubscriber',
            $vipId,
            $actor,
            $request,
            null,
            ['vehicleId' => $vehicleId, 'relationship' => $relationship, 'isPrimary' => $isPrimary],
            ['source' => 'vip-domain']
        );

        return $this->show($vipId, $actor);
    }

    /**
     * A dependant is a person, not a copy: the same canonical person record is
     * linked, and whether they are covered is explicit.
     *
     * @return array<string,mixed>
     */
    public function addDependant(array $input, array $actor, Request $request): array
    {
        $vipId = $this->required($input, 'vipSubscriberId', 'VIP subscriber');
        $vip = $this->row($vipId);
        $personId = $this->required($input, 'personId', 'Person');
        $this->person($personId);
        $relationship = $this->choice($input['relationship'] ?? 'DEPENDANT', 'relationship', null, [
            'SPOUSE', 'CHILD', 'PARENT', 'DEPENDANT', 'STAFF',
        ]);

        $allows = $this->database->query(
            'SELECT allows_dependants FROM vip_membership_types WHERE code = ' . $this->database->quote($vip['membership_type'])
        )->fetchColumn();
        if ((int) $allows === 0) {
            throw new AuthException('This membership type does not support dependants.', 409);
        }

        $id = Uuid::v4();
        $this->database->prepare(<<<'SQL'
            INSERT INTO vip_dependants (id, vip_subscriber_id, person_id, relationship, rescue_covered, emergency_priority, notes)
            VALUES (:id, :vip, :person, :relationship, :covered, :priority, :notes)
            SQL)->execute([
            'id' => $id, 'vip' => $vipId, 'person' => $personId, 'relationship' => $relationship,
            'covered' => (bool) ($input['rescueCovered'] ?? true) ? 1 : 0,
            'priority' => isset($input['emergencyPriority']) ? (int) $input['emergencyPriority'] : null,
            'notes' => $this->optional($input, 'notes'),
        ]);

        (new AuditLog($this->database))->write(
            'VIP_DEPENDANT_ADDED',
            'VipSubscriber',
            $vipId,
            $actor,
            $request,
            null,
            ['personId' => $personId, 'relationship' => $relationship],
            ['source' => 'vip-domain']
        );

        return $this->show($vipId, $actor);
    }

    /**
     * Update the emergency profile.
     *
     * Health-adjacent fields are stored here and returned only to roles that need
     * them; the summary returned to a staff board never includes them.
     *
     * @return array<string,mixed>
     */
    public function updateEmergencyProfile(array $input, array $actor, Request $request): array
    {
        $vipId = $this->required($input, 'vipSubscriberId', 'VIP subscriber');
        $this->row($vipId);
        $this->database->prepare(<<<'SQL'
            UPDATE vip_emergency_profiles SET
                preferred_hospital_location_id = :hospital,
                preferred_language = COALESCE(:language, preferred_language),
                accessibility_requirements = :accessibility,
                insurance_provider = :insurance,
                insurance_policy_number = :policy,
                blood_type = :blood,
                critical_notes = :notes,
                updated_by_user_id = :actor,
                updated_at = UTC_TIMESTAMP(6)
            WHERE vip_subscriber_id = :id
            SQL)->execute([
            'hospital' => $this->optional($input, 'preferredHospitalLocationId'),
            'language' => $this->optional($input, 'preferredLanguage'),
            'accessibility' => $this->optional($input, 'accessibilityRequirements'),
            'insurance' => $this->optional($input, 'insuranceProvider'),
            'policy' => $this->optional($input, 'insurancePolicyNumber'),
            'blood' => $this->optional($input, 'bloodType'),
            'notes' => $this->optional($input, 'criticalNotes'),
            'actor' => $actor['id'] ?? null,
            'id' => $vipId,
        ]);

        $this->database->prepare(
            'UPDATE vip_subscribers SET emergency_profile_complete = :complete WHERE id = :id'
        )->execute([
            'complete' => $this->emergencyProfileComplete($vipId) ? 1 : 0,
            'id' => $vipId,
        ]);

        (new AuditLog($this->database))->write(
            'VIP_EMERGENCY_PROFILE_UPDATED',
            'VipSubscriber',
            $vipId,
            $actor,
            $request,
            null,
            ['updated' => true],
            ['source' => 'vip-domain']
        );

        return $this->show($vipId, $actor);
    }

    /**
     * What the subscriber themselves sees. No internal identifiers, no other
     * VIP's data, and the rescue code in full because it is theirs.
     *
     * @return array<string,mixed>
     */
    public function forSubscriber(array $user): array
    {
        $statement = $this->database->prepare(
            'SELECT v.* FROM vip_subscribers v JOIN users u ON u.person_id = v.person_id WHERE u.id = :user LIMIT 1'
        );
        $statement->execute(['user' => $user['id']]);
        $vip = $statement->fetch();
        if (!is_array($vip)) {
            return ['membership' => false, 'message' => 'No VIP membership is linked to this account.'];
        }

        $profile = $this->show((string) $vip['id']);
        $coverage = $this->coverage->check('PERSON', (string) $vip['person_id']);

        return [
            'membership' => true,
            'membershipNumber' => $profile['membershipNumber'],
            'membershipType' => $profile['membershipType'],
            'priorityLevel' => $profile['priorityLevel'],
            'status' => $profile['status'],
            'rescueCode' => $profile['rescueCode'],
            'rescueCoverage' => $coverage,
            'expiresAt' => $profile['expiresAt'],
            'plan' => $profile['plan'],
            'emergencyProfileComplete' => $profile['emergencyProfileComplete'],
            'dependants' => $profile['dependants'],
            'vehicles' => array_map(static fn (array $vehicle): array => [
                'registrationNumber' => $vehicle['registrationNumber'],
                'description' => $vehicle['description'],
                'coverageStatus' => $vehicle['coverageStatus'],
                'isPrimary' => $vehicle['isPrimary'],
                'trackingStatus' => $vehicle['trackingStatus'],
                'lastKnownPosition' => $vehicle['lastKnownPosition'],
            ], $profile['vehicles']),
        ];
    }

    // ------------------------------------------------------------- internals

    /** @return array<string,mixed> */
    private function row(string $id): array
    {
        $statement = $this->database->prepare('SELECT * FROM vip_subscribers WHERE id = :id');
        $statement->execute(['id' => $id]);
        $row = $statement->fetch();
        if (!is_array($row)) {
            throw new AuthException('VIP subscriber not found.', 404);
        }

        return $row;
    }

    /** @return array<string,mixed>|null */
    private function subscriberIdForPerson(string $personId): ?string
    {
        $statement = $this->database->prepare('SELECT id FROM subscribers WHERE person_id = :person AND deleted_at IS NULL LIMIT 1');
        $statement->execute(['person' => $personId]);
        $id = $statement->fetchColumn();

        return is_string($id) ? $id : null;
    }

    private function planForCode(string $code): ?string
    {
        $statement = $this->database->prepare("SELECT id FROM service_plans WHERE plan_code = :code AND status = 'ACTIVE'");
        $statement->execute(['code' => $code]);
        $id = $statement->fetchColumn();

        return is_string($id) ? $id : null;
    }

    private function plan(string $planId, string $expectedDomain): void
    {
        $statement = $this->database->prepare('SELECT domain FROM service_plans WHERE id = :id AND status = :status');
        $statement->execute(['id' => $planId, 'status' => 'ACTIVE']);
        $domain = $statement->fetchColumn();
        if (!is_string($domain)) {
            throw new AuthException('Service plan not found.', 404);
        }
        if ($domain !== $expectedDomain) {
            throw new AuthException("That plan belongs to the {$domain} domain, not {$expectedDomain}.", 422);
        }
    }

    /** @return array<string,mixed>|null */
    private function planSummary(string $planId): ?array
    {
        $statement = $this->database->prepare(
            'SELECT plan_code, name, coverage_type, billing_period, currency, response_target_minutes FROM service_plans WHERE id = :id'
        );
        $statement->execute(['id' => $planId]);
        $plan = $statement->fetch();
        if (!is_array($plan)) {
            return null;
        }

        return [
            'code' => $plan['plan_code'],
            'name' => $plan['name'],
            'coverageType' => $plan['coverage_type'],
            'billingPeriod' => $plan['billing_period'],
            'currency' => $plan['currency'],
            'responseTargetMinutes' => $plan['response_target_minutes'] === null ? null : (int) $plan['response_target_minutes'],
        ];
    }

    /** @return array<string,mixed> */
    private function person(string $personId): array
    {
        $statement = $this->database->prepare('SELECT * FROM persons WHERE id = :id AND deleted_at IS NULL');
        $statement->execute(['id' => $personId]);
        $person = $statement->fetch();
        if (!is_array($person)) {
            throw new AuthException('Person not found.', 404);
        }

        return $person;
    }

    /** @return array<string,mixed> */
    private function personSummary(string $personId): array
    {
        $person = $this->person($personId);

        return [
            'name' => trim(((string) $person['first_name']) . ' ' . ((string) $person['last_name'])),
            'phone' => $person['phone'],
            'email' => $person['email'],
            'nationality' => $person['nationality'],
        ];
    }

    /** @return array<string,mixed> */
    private function vehicle(string $vehicleId): array
    {
        $statement = $this->database->prepare('SELECT * FROM vehicles WHERE id = :id AND deleted_at IS NULL');
        $statement->execute(['id' => $vehicleId]);
        $vehicle = $statement->fetch();
        if (!is_array($vehicle)) {
            throw new AuthException('Vehicle not found.', 404);
        }

        return $vehicle;
    }

    /** @return array<string,mixed> */
    private function vehicleSummary(array $row): array
    {
        $trackedAssetId = $row['tracked_asset_id'] ?? null;
        $fresh = $trackedAssetId !== null
            && $row['recorded_at'] !== null
            && ServerClock::epoch($this->database) - ServerClock::parse((string) $row['recorded_at']) <= 120;

        return [
            'id' => $row['id'],
            'vehicleId' => $row['vehicle_id'],
            'registrationNumber' => $row['registration_number'],
            'description' => trim(((string) $row['make']) . ' ' . ((string) $row['model'])),
            'vehicleType' => $row['vehicle_type'],
            'relationship' => $row['relationship'],
            'isPrimary' => (bool) $row['is_primary'],
            'coverageStatus' => $row['coverage_status'],
            'verifiedStatus' => $row['verified_status'],
            'trackingStatus' => $trackedAssetId === null ? 'NO_DEVICE' : ($fresh ? 'ONLINE' : (string) ($row['tracking_status'] ?? 'UNKNOWN')),
            'lastKnownPosition' => $fresh && $row['latitude'] !== null
                ? ['latitude' => (float) $row['latitude'], 'longitude' => (float) $row['longitude'], 'recordedAt' => $row['recorded_at']]
                : null,
        ];
    }

    /** @return list<array<string,mixed>> */
    private function dependants(string $vipId): array
    {
        $statement = $this->database->prepare(<<<'SQL'
            SELECT d.relationship, d.rescue_covered, d.emergency_priority, p.first_name, p.last_name
            FROM vip_dependants d JOIN persons p ON p.id = d.person_id
            WHERE d.vip_subscriber_id = :id ORDER BY d.created_at
            SQL);
        $statement->execute(['id' => $vipId]);

        return array_map(static fn (array $row): array => [
            'name' => trim(((string) $row['first_name']) . ' ' . ((string) $row['last_name'])),
            'relationship' => $row['relationship'],
            'rescueCovered' => (bool) $row['rescue_covered'],
            'emergencyPriority' => $row['emergency_priority'] === null ? null : (int) $row['emergency_priority'],
        ], $statement->fetchAll());
    }

    private function emergencyProfileComplete(string $vipId): bool
    {
        $statement = $this->database->prepare(
            'SELECT preferred_hospital_location_id, insurance_provider, critical_notes, accessibility_requirements
             FROM vip_emergency_profiles WHERE vip_subscriber_id = :id'
        );
        $statement->execute(['id' => $vipId]);
        $profile = $statement->fetch();
        if (!is_array($profile)) {
            return false;
        }

        return $profile['preferred_hospital_location_id'] !== null
            || $profile['insurance_provider'] !== null
            || $profile['critical_notes'] !== null
            || $profile['accessibility_requirements'] !== null;
    }

    /** The VIP's coverage status is derived from the shared engine, never stored optimistically. */
    private function syncCoverageStatus(string $vipId): void
    {
        $vip = $this->row($vipId);
        $coverage = $this->coverage->check('PERSON', (string) $vip['person_id']);
        $status = $coverage['covered'] ? 'ACTIVE' : ($vip['status'] === 'SUSPENDED' ? 'SUSPENDED' : 'UNCOVERED');
        $this->database->prepare('UPDATE vip_subscribers SET rescue_coverage_status = :status WHERE id = :id')
            ->execute(['status' => $status, 'id' => $vipId]);
    }

    private function syncVehicleCoverage(string $vipId): void
    {
        $this->database->prepare(<<<'SQL'
            UPDATE vip_vehicle_links l
            JOIN (SELECT vehicle_id, MAX(status = 'ACTIVE') AS covered FROM rescue_coverage_links
                  WHERE status = 'ACTIVE' GROUP BY vehicle_id) c ON c.vehicle_id = l.vehicle_id
            SET l.coverage_status = IF(c.covered = 1, 'ACTIVE', 'UNCOVERED')
            WHERE l.vip_subscriber_id = :id
            SQL)->execute(['id' => $vipId]);
    }

    private function attachRescueCode(string $vipId, string $code): void
    {
        $codeId = $this->database->query('SELECT id FROM rescue_codes WHERE code = ' . $this->database->quote($code))->fetchColumn();
        if (!is_string($codeId)) {
            return;
        }
        $vip = $this->row($vipId);
        $this->database->prepare('UPDATE vip_subscribers SET rescue_code_id = :code WHERE id = :id')
            ->execute(['code' => $codeId, 'id' => $vipId]);
        // A code can cover the person and each of their vehicles: one code, many
        // subjects, no second code system.
        $this->database->prepare(<<<'SQL'
            INSERT INTO rescue_code_links (id, rescue_code_id, subject_type, subject_id, relationship)
            VALUES (:id, :code, 'PERSON', :person, 'PRIMARY')
            ON DUPLICATE KEY UPDATE relationship = 'PRIMARY'
            SQL)->execute(['id' => Uuid::v4(), 'code' => $codeId, 'person' => $vip['person_id']]);
        $vehicles = $this->database->prepare('SELECT vehicle_id FROM vip_vehicle_links WHERE vip_subscriber_id = :id');
        $vehicles->execute(['id' => $vipId]);
        foreach ($vehicles->fetchAll(PDO::FETCH_COLUMN) as $vehicleId) {
            $this->database->prepare(<<<'SQL'
                INSERT INTO rescue_code_links (id, rescue_code_id, subject_type, subject_id, relationship)
                VALUES (:id, :code, 'VEHICLE', :vehicle, 'ADDITIONAL')
                ON DUPLICATE KEY UPDATE relationship = 'ADDITIONAL'
                SQL)->execute(['id' => Uuid::v4(), 'code' => $codeId, 'vehicle' => $vehicleId]);
        }
    }

    /**
     * A VIP profile is visible to VIP staff, to admins and auditors, and to the
     * subscriber it belongs to. The subscriber check is by canonical person, so
     * a VIP who is not a portal user is simply not visible to themselves rather
     * than being guessed at.
     */
    private function assertCanView(array $vip, array $actor): void
    {
        $role = (string) ($actor['role_code'] ?? '');
        if (in_array($role, ['SYSTEM_ADMIN', 'HQ_DISPATCHER', 'AUDITOR', 'FINANCE_MANAGER'], true)) {
            return;
        }
        if ($role === 'RESCUE_OPERATOR' || $role === 'CUSTOMER') {
            // A responder sees the VIP they are rescuing; a subscriber sees their own.
            if ($this->database->query(
                'SELECT 1 FROM users u WHERE u.id = ' . $this->database->quote((string) ($actor['id'] ?? ''))
                . ' AND u.person_id = ' . $this->database->quote((string) $vip['person_id'])
            )->fetchColumn() !== false) {
                return;
            }
        }

        throw new AuthException('You do not have access to this VIP profile.', 403);
    }

    private function membershipNumber(): string
    {
        for ($attempt = 0; $attempt < 5; $attempt++) {
            $number = 'VIP-' . gmdate('ymd') . '-' . strtoupper(bin2hex(random_bytes(3)));
            $exists = $this->database->prepare('SELECT COUNT(*) FROM vip_subscribers WHERE membership_number = :number');
            $exists->execute(['number' => $number]);
            if ((int) $exists->fetchColumn() === 0) {
                return $number;
            }
        }

        throw new AuthException('Could not allocate a VIP membership number.', 500);
    }

    /**
     * A complete WHERE for a filter set plus one extra condition.
     *
     * Appending "AND ..." to an empty filter clause produces invalid SQL, so the
     * clause is always built whole.
     *
     * @param array<string,mixed> $filters
     */
    private function filterClauseWith(array $filters, string $extra): string
    {
        $clauses = [];
        foreach (['status' => 'v.status', 'membershipType' => 'v.membership_type', 'country' => 'v.home_country'] as $key => $column) {
            if (($filters[$key] ?? '') !== '') {
                $clauses[] = $column . ' = :' . $key;
            }
        }
        if ($extra !== '') {
            $clauses[] = $extra;
        }

        return $clauses === [] ? '' : 'WHERE ' . implode(' AND ', $clauses);
    }

    /** @param array<string,mixed> $filters */
    private function filterClause(array $filters): string
    {
        $clauses = [];
        if (($filters['status'] ?? '') !== '') {
            $clauses[] = 'v.status = :status';
        }
        if (($filters['membershipType'] ?? '') !== '') {
            $clauses[] = 'v.membership_type = :membershipType';
        }
        if (($filters['country'] ?? '') !== '') {
            $clauses[] = 'v.home_country = :country';
        }
        if (($filters['covered'] ?? '') === 'true') {
            $clauses[] = "v.rescue_coverage_status = 'ACTIVE'";
        }

        return $clauses === [] ? '' : 'WHERE ' . implode(' AND ', $clauses);
    }

    /** @param array<string,mixed> $filters @return array<string,mixed> */
    private function filterParams(array $filters): array
    {
        $params = [];
        foreach (['status', 'membershipType', 'country'] as $key) {
            if (($filters[$key] ?? '') !== '') {
                $params[$key] = (string) $filters[$key];
            }
        }

        return $params;
    }

    /** @param array<string,mixed> $params */
    private function scalar(string $sql, array $params = []): int
    {
        $statement = $this->database->prepare($sql);
        $statement->execute($params);
        $value = $statement->fetchColumn();

        return is_numeric($value) ? (int) $value : 0;
    }

    /**
     * @param array<string,mixed> $params
     *
     * @return list<array{label:string,total:int}>
     */
    private function groups(string $sql, array $params): array
    {
        $statement = $this->database->prepare($sql);
        $statement->execute($params);

        return array_map(static fn (array $row): array => [
            'label' => (string) $row['label'],
            'total' => (int) $row['total'],
        ], $statement->fetchAll());
    }

    /** @param list<string>|null $allowed */
    private function choice(mixed $value, string $column, ?string $referenceTable, ?array $allowed = null): string
    {
        $choice = is_string($value) ? strtoupper(trim($value)) : '';
        if ($choice === '') {
            throw new AuthException("Choose a valid {$column}.", 422);
        }
        if ($allowed !== null) {
            if (!in_array($choice, $allowed, true)) {
                throw new AuthException("Choose a valid {$column}.", 422);
            }

            return $choice;
        }
        if ($referenceTable === null) {
            return $choice;
        }
        $statement = $this->database->prepare(
            "SELECT code FROM {$referenceTable} WHERE code = :code"
        );
        $statement->execute(['code' => $choice]);
        if ($statement->fetchColumn() === false) {
            throw new AuthException("Choose a valid {$column}.", 422);
        }

        return $choice;
    }

    private function required(array $input, string $key, string $label): string
    {
        $value = is_string($input[$key] ?? null) ? trim($input[$key]) : '';
        if ($value === '') {
            throw new AuthException("{$label} is required.", 422);
        }

        return $value;
    }

    private function optional(array $input, string $key): ?string
    {
        $value = $input[$key] ?? null;
        if (!is_string($value) || trim($value) === '') {
            return null;
        }

        return trim($value);
    }
}
