<?php

declare(strict_types=1);

namespace Mamore\TruckCargo;

use Mamore\Auth\AuthException;
use Mamore\Core\AuditLog;
use Mamore\Core\Request;
use Mamore\Core\ServerClock;
use Mamore\Core\Uuid;
use Mamore\Rescue\RescueCoverageService;
use PDO;

/**
 * The Truck & Cargo domain.
 *
 * Cargo is modelled properly - a consignment with items, containers and declared
 * values - because a responder needs to know what is in the vehicle. Payload
 * rules are enforced here rather than left to the operator: a truck cannot be
 * loaded beyond its rating, a hazardous consignment must declare its class, and a
 * trailer assignment is history rather than a permanent link.
 */
final class TruckService
{
    public const JOURNEY_TRANSITIONS = [
        'PLANNED' => ['READY', 'CANCELLED'],
        'READY' => ['IN_TRANSIT', 'CANCELLED'],
        'IN_TRANSIT' => ['PAUSED', 'DELAYED', 'BREAKDOWN', 'INCIDENT', 'ARRIVED', 'COMPLETED', 'CANCELLED'],
        'PAUSED' => ['IN_TRANSIT', 'DELAYED', 'COMPLETED', 'CANCELLED'],
        'DELAYED' => ['IN_TRANSIT', 'ARRIVED', 'COMPLETED', 'CANCELLED'],
        'BREAKDOWN' => ['IN_TRANSIT', 'INCIDENT', 'ARRIVED', 'COMPLETED', 'CANCELLED'],
        'INCIDENT' => ['IN_TRANSIT', 'ARRIVED', 'COMPLETED', 'CANCELLED'],
        'ARRIVED' => ['COMPLETED', 'CANCELLED'],
        'COMPLETED' => [],
        'CANCELLED' => [],
    ];

    public function __construct(
        private readonly PDO $database,
        private readonly RescueCoverageService $coverage,
    ) {}

    /**
     * Create a truck operator. Identity is the canonical organization.
     *
     * @return array<string,mixed>
     */
    public function createOperator(array $input, array $actor, Request $request): array
    {
        $organizationId = $this->optional($input, 'organizationId');
        if ($organizationId === null) {
            $organizationId = $this->createOrganization($input);
        }
        $this->organizationExists($organizationId);
        $planId = $this->optional($input, 'servicePlanId') ?? $this->planId('TRUCK-FLEET-CARGO');
        if ($planId !== null) {
            $this->assertPlanDomain($planId, 'TRUCK');
        }

        $id = Uuid::v4();
        $this->database->prepare(<<<'SQL'
            INSERT INTO truck_operators
                (id, organization_id, operator_number, verification_status, license_number, license_expires_at,
                 service_plan_id, fleet_size, operating_country, support_phone, created_by_user_id)
            VALUES (:id, :organization, :number, :verification, :license, :licenseExpiry, :plan, :fleet, :country, :phone, :actor)
            SQL)->execute([
            'id' => $id, 'organization' => $organizationId,
            'number' => $this->operatorNumber(),
            'verification' => $this->choice($input['verificationStatus'] ?? 'PENDING', 'verification_status', null, [
                'UNVERIFIED', 'PENDING', 'VERIFIED', 'EXPIRED', 'SUSPENDED', 'REJECTED',
            ]),
            'license' => $this->optional($input, 'licenseNumber'),
            'licenseExpiry' => $this->optional($input, 'licenseExpiresAt'),
            'plan' => $planId,
            'fleet' => isset($input['fleetSize']) ? (int) $input['fleetSize'] : null,
            'country' => $this->optional($input, 'operatingCountry') ?? 'CD',
            'phone' => $this->optional($input, 'supportPhone'),
            'actor' => $actor['id'] ?? null,
        ]);

        (new AuditLog($this->database))->write(
            'TRUCK_OPERATOR_CREATED',
            'TruckOperator',
            $id,
            $actor,
            $request,
            null,
            ['operatorId' => $id, 'organizationId' => $organizationId],
            ['source' => 'truck-cargo-domain']
        );

        return $this->operator($id, $actor);
    }

    /**
     * Register a truck against a canonical vehicle.
     *
     * @return array<string,mixed>
     */
    public function createTruck(array $input, array $actor, Request $request): array
    {
        $operatorId = $this->required($input, 'truckOperatorId', 'Truck operator');
        $operator = $this->operatorRow($operatorId);
        $vehicleId = $this->required($input, 'vehicleId', 'Vehicle');
        $vehicle = $this->vehicle($vehicleId);

        if ((string) $vehicle['vehicle_type'] !== 'TRUCK' && (string) $vehicle['vehicle_type'] !== 'VAN') {
            throw new AuthException('Register this vehicle as a truck before adding it to a fleet.', 422);
        }

        $truckType = $this->choice($input['truckType'] ?? 'RIGID_TRUCK', 'truck_type', 'truck_types');
        $gross = $this->weight($input, 'grossVehicleWeightKg');
        $tare = $this->weight($input, 'tareWeightKg');
        $payload = $this->weight($input, 'maximumPayloadKg');
        if ($gross !== null && $payload !== null && $payload > $gross) {
            throw new AuthException('The maximum payload cannot exceed the gross vehicle weight.', 422);
        }
        if ($tare !== null && $gross !== null && $tare > $gross) {
            throw new AuthException('The tare weight cannot exceed the gross vehicle weight.', 422);
        }

        $id = Uuid::v4();
        $this->database->beginTransaction();
        try {
            $this->database->prepare(<<<'SQL'
                INSERT INTO trucks
                    (id, vehicle_id, truck_operator_id, truck_number, truck_type, axle_configuration,
                     gross_vehicle_weight_kg, tare_weight_kg, maximum_payload_kg, body_type, trailer_required,
                     hazardous_goods_approved, cross_border_enabled)
                VALUES (:id, :vehicle, :operator, :number, :type, :axles, :gross, :tare, :payload, :body, :trailer,
                        :hazmat, :crossBorder)
                SQL)->execute([
                'id' => $id, 'vehicle' => $vehicleId, 'operator' => $operatorId,
                'number' => $this->truckNumber($operatorId, $input['truckNumber'] ?? null),
                'type' => $truckType,
                'axles' => $this->optional($input, 'axleConfiguration'),
                'gross' => $gross, 'tare' => $tare, 'payload' => $payload,
                'body' => $this->optional($input, 'bodyType'),
                'trailer' => (bool) ($input['trailerRequired'] ?? false) ? 1 : 0,
                'hazmat' => (bool) ($input['hazardousGoodsApproved'] ?? false) ? 1 : 0,
                'crossBorder' => (bool) ($input['crossBorderEnabled'] ?? false) ? 1 : 0,
            ]);
            $this->database->prepare('UPDATE vehicles SET vehicle_type = :type WHERE id = :id')
                ->execute(['type' => 'TRUCK', 'id' => $vehicleId]);
            $this->ensureTrackedAsset($vehicleId, $operatorId);
            $this->database->commit();
        } catch (\PDOException $error) {
            if ($this->database->inTransaction()) {
                $this->database->rollBack();
            }
            // The domain rules (one vehicle per truck, unique fleet number) are
            // reported as domain errors, not driver errors.
            if ((string) $error->getCode() === '23000') {
                throw new AuthException('This vehicle is already registered in a fleet, or the truck number is taken.', 422);
            }
            throw $error;
        } catch (\Throwable $error) {
            if ($this->database->inTransaction()) {
                $this->database->rollBack();
            }
            throw $error;
        }

        (new AuditLog($this->database))->write(
            'TRUCK_CREATED',
            'Truck',
            $id,
            $actor,
            $request,
            null,
            ['vehicleId' => $vehicleId, 'truckType' => $truckType, 'operatorId' => $operatorId],
            ['source' => 'truck-cargo-domain']
        );

        return $this->truck($id, $actor);
    }

    /**
     * Add a trailer to the operator's fleet. Trailers are separate vehicles and
     * are assigned per journey, never hard-linked to one tractor.
     *
     * @return array<string,mixed>
     */
    public function createTrailer(array $input, array $actor, Request $request): array
    {
        $operatorId = $this->required($input, 'truckOperatorId', 'Truck operator');
        $this->operatorRow($operatorId);
        $vehicleId = $this->optional($input, 'vehicleId');
        if ($vehicleId !== null) {
            $this->vehicle($vehicleId);
        }
        $id = Uuid::v4();
        $this->database->prepare(<<<'SQL'
            INSERT INTO trailers (id, vehicle_id, truck_operator_id, trailer_number, trailer_type, max_load_kg)
            VALUES (:id, :vehicle, :operator, :number, :type, :maxLoad)
            SQL)->execute([
            'id' => $id, 'vehicle' => $vehicleId, 'operator' => $operatorId,
            'number' => $this->trailerNumber($operatorId, $input['trailerNumber'] ?? null),
            'type' => $this->choice($input['trailerType'] ?? 'BOX', 'trailer_type', 'trailer_types'),
            'maxLoad' => $this->weight($input, 'maxLoadKg'),
        ]);

        (new AuditLog($this->database))->write(
            'TRAILER_CREATED',
            'Trailer',
            $id,
            $actor,
            $request,
            null,
            ['operatorId' => $operatorId, 'trailerType' => $input['trailerType'] ?? 'BOX'],
            ['source' => 'truck-cargo-domain']
        );

        return ['id' => $id, 'trailerNumber' => $this->database->query(
            'SELECT trailer_number FROM trailers WHERE id = ' . $this->database->quote($id)
        )->fetchColumn()];
    }

    /**
     * Assign a trailer to a truck, keeping history.
     *
     * @return array<string,mixed>
     */
    public function assignTrailer(array $input, array $actor, Request $request): array
    {
        $truckId = $this->required($input, 'truckId', 'Truck');
        $trailerId = $this->required($input, 'trailerId', 'Trailer');
        $truck = $this->truckRow($truckId);
        $trailer = $this->trailerRow($trailerId);

        if ((string) $truck['truck_operator_id'] !== (string) $trailer['truck_operator_id']) {
            throw new AuthException('A trailer can only be assigned to a truck of the same operator.', 403);
        }
        $inUse = (int) $this->database->query(
            'SELECT COUNT(*) FROM truck_trailer_assignments WHERE trailer_id = ' . $this->database->quote($trailerId)
            . ' AND released_at IS NULL'
        )->fetchColumn();
        if ($inUse > 0) {
            throw new AuthException('This trailer is already assigned to another truck.', 409);
        }

        $this->database->beginTransaction();
        try {
            // A truck keeps at most one current trailer; the previous one is
            // released, not deleted, so the history survives.
            $this->database->prepare(
                'UPDATE truck_trailer_assignments SET released_at = UTC_TIMESTAMP(6)
                 WHERE truck_id = :truck AND released_at IS NULL'
            )->execute(['truck' => $truckId]);
            $this->database->prepare(<<<'SQL'
                INSERT INTO truck_trailer_assignments (truck_id, trailer_id, assigned_by_user_id, reason, journey_id)
                VALUES (:truck, :trailer, :actor, :reason, :journey)
                SQL)->execute([
                'truck' => $truckId, 'trailer' => $trailerId, 'actor' => $actor['id'] ?? null,
                'reason' => $this->optional($input, 'reason'),
                'journey' => $this->optional($input, 'journeyId'),
            ]);
            $this->database->commit();
        } catch (\Throwable $error) {
            if ($this->database->inTransaction()) {
                $this->database->rollBack();
            }
            throw $error;
        }

        (new AuditLog($this->database))->write(
            'TRAILER_ASSIGNED',
            'Truck',
            $truckId,
            $actor,
            $request,
            null,
            ['trailerId' => $trailerId],
            ['source' => 'truck-cargo-domain']
        );

        return $this->truck($truckId, $actor);
    }

    /**
     * Register a driver against a canonical person.
     *
     * @return array<string,mixed>
     */
    public function createDriver(array $input, array $actor, Request $request): array
    {
        $operatorId = $this->required($input, 'truckOperatorId', 'Truck operator');
        $this->operatorRow($operatorId);
        $personId = $this->required($input, 'personId', 'Person');
        $this->person($personId);

        $id = Uuid::v4();
        $this->database->prepare(<<<'SQL'
            INSERT INTO truck_drivers
                (id, person_id, truck_operator_id, driver_number, license_number, license_class, license_expiry,
                 cross_border_authorized)
            VALUES (:id, :person, :operator, :number, :license, :class, :expiry, :crossBorder)
            SQL)->execute([
            'id' => $id, 'person' => $personId, 'operator' => $operatorId,
            'number' => $this->driverNumber($operatorId),
            'license' => $this->optional($input, 'licenseNumber'),
            'class' => $this->optional($input, 'licenseClass'),
            'expiry' => $this->optional($input, 'licenseExpiry'),
            'crossBorder' => (bool) ($input['crossBorderAuthorized'] ?? false) ? 1 : 0,
        ]);

        (new AuditLog($this->database))->write(
            'TRUCK_DRIVER_CREATED',
            'TruckDriver',
            $id,
            $actor,
            $request,
            null,
            ['personId' => $personId, 'operatorId' => $operatorId],
            ['source' => 'truck-cargo-domain']
        );

        return ['id' => $id, 'personId' => $personId, 'operatorId' => $operatorId];
    }

    /**
     * Create a consignment with its items.
     *
     * @return array<string,mixed>
     */
    public function createConsignment(array $input, array $actor, Request $request): array
    {
        $category = $this->choice($input['cargoCategory'] ?? 'GENERAL', 'cargo_category', 'cargo_categories');
        $hazardous = (bool) ($input['hazardous'] ?? false);
        $categoryRequiresHazard = (int) $this->database->query(
            'SELECT requires_hazard_class FROM cargo_categories WHERE code = ' . $this->database->quote($category)
        )->fetchColumn() === 1;
        $hazardClass = $this->optional($input, 'hazardClass');
        if ($hazardous && $hazardClass === null) {
            // The platform never guesses a hazard class; dangerous goods without
            // one are refused rather than recorded wrongly.
            throw new AuthException('A hazardous consignment must declare its hazard class.', 422);
        }
        if ($categoryRequiresHazard && !$hazardous) {
            throw new AuthException('This cargo category is a hazardous category and must be flagged hazardous.', 422);
        }

        $id = Uuid::v4();
        $number = $this->consignmentNumber();
        $this->database->beginTransaction();
        try {
            $this->database->prepare(<<<'SQL'
                INSERT INTO consignments
                    (id, consignment_number, cargo_owner_person_id, cargo_owner_organization_id, shipper_organization_id,
                     consignee_organization_id, origin_location_id, destination_location_id, origin_text, destination_text,
                     declared_value, declared_currency, cargo_category, hazardous, hazard_class, un_number,
                     temperature_controlled, special_handling, package_count, created_by_user_id)
                VALUES (:id, :number, :ownerPerson, :ownerOrg, :shipper, :consignee, :origin, :destination, :originText,
                        :destinationText, :value, :currency, :category, :hazardous, :hazardClass, :unNumber,
                        :temperature, :special, :packages, :actor)
                SQL)->execute([
                'id' => $id, 'number' => $number,
                'ownerPerson' => $this->optional($input, 'cargoOwnerPersonId'),
                'ownerOrg' => $this->optional($input, 'cargoOwnerOrganizationId'),
                'shipper' => $this->optional($input, 'shipperOrganizationId'),
                'consignee' => $this->optional($input, 'consigneeOrganizationId'),
                'origin' => $this->optional($input, 'originLocationId'),
                'destination' => $this->optional($input, 'destinationLocationId'),
                'originText' => $this->optional($input, 'originText'),
                'destinationText' => $this->optional($input, 'destinationText'),
                'value' => isset($input['declaredValue']) ? (string) $input['declaredValue'] : null,
                'currency' => $this->optional($input, 'declaredCurrency') ?? 'USD',
                'category' => $category,
                'hazardous' => $hazardous ? 1 : 0,
                'hazardClass' => $hazardClass,
                'unNumber' => $this->optional($input, 'unNumber'),
                'temperature' => (bool) ($input['temperatureControlled'] ?? false) ? 1 : 0,
                'special' => $this->optional($input, 'specialHandling'),
                'packages' => isset($input['packageCount']) ? (int) $input['packageCount'] : null,
                'actor' => $actor['id'] ?? null,
            ]);

            $totalWeight = 0.0;
            $totalValue = 0.0;
            foreach ((is_array($input['items'] ?? null) ? $input['items'] : []) as $item) {
                if (!is_array($item)) {
                    continue;
                }
                $weight = isset($item['weightKg']) ? (float) $item['weightKg'] : 0.0;
                $totalWeight += $weight;
                $totalValue += isset($item['declaredValue']) ? (float) $item['declaredValue'] : 0.0;
                $this->database->prepare(<<<'SQL'
                    INSERT INTO cargo_items
                        (id, consignment_id, description, category, quantity, unit, weight_kg, volume_m3,
                         declared_value, currency, hazard_class, temperature_min_c, temperature_max_c, fragile, special_instructions)
                    VALUES (:id, :consignment, :description, :category, :quantity, :unit, :weight, :volume,
                            :value, :currency, :hazardClass, :tempMin, :tempMax, :fragile, :instructions)
                    SQL)->execute([
                    'id' => Uuid::v4(), 'consignment' => $id,
                    'description' => $this->required($item, 'description', 'Item description'),
                    'category' => is_string($item['category'] ?? null) ? $item['category'] : null,
                    'quantity' => isset($item['quantity']) ? (string) $item['quantity'] : null,
                    'unit' => is_string($item['unit'] ?? null) ? $item['unit'] : null,
                    'weight' => $weight > 0 ? (string) $weight : null,
                    'volume' => isset($item['volumeM3']) ? (string) $item['volumeM3'] : null,
                    'value' => isset($item['declaredValue']) ? (string) $item['declaredValue'] : null,
                    'currency' => is_string($item['currency'] ?? null) ? $item['currency'] : null,
                    'hazardClass' => is_string($item['hazardClass'] ?? null) ? $item['hazardClass'] : null,
                    'tempMin' => isset($item['temperatureMinC']) ? (string) $item['temperatureMinC'] : null,
                    'tempMax' => isset($item['temperatureMaxC']) ? (string) $item['temperatureMaxC'] : null,
                    'fragile' => (bool) ($item['fragile'] ?? false) ? 1 : 0,
                    'instructions' => is_string($item['specialInstructions'] ?? null) ? $item['specialInstructions'] : null,
                ]);
            }
            $declared = isset($input['totalWeightKg'])
                ? (float) $input['totalWeightKg']
                : ($totalWeight > 0 ? $totalWeight : 0.0);
            $this->database->prepare(
                'UPDATE consignments SET total_weight_kg = :weight, total_volume_m3 = :volume WHERE id = :id'
            )->execute([
                'weight' => (string) round($declared, 2),
                'volume' => isset($input['totalVolumeM3']) ? (string) $input['totalVolumeM3'] : null,
                'id' => $id,
            ]);
            $this->database->commit();
            unset($totalValue);
        } catch (\Throwable $error) {
            if ($this->database->inTransaction()) {
                $this->database->rollBack();
            }
            throw $error;
        }

        (new AuditLog($this->database))->write(
            'CONSIGNMENT_CREATED',
            'Consignment',
            $id,
            $actor,
            $request,
            null,
            ['consignmentNumber' => $number, 'cargoCategory' => $category, 'hazardous' => $hazardous],
            ['source' => 'truck-cargo-domain']
        );

        return $this->consignment($id, $actor);
    }

    /**
     * Plan and start a truck journey, attaching cargo, driver and trailer.
     *
     * @return array<string,mixed>
     */
    public function createJourney(array $input, array $actor, Request $request): array
    {
        $truckId = $this->required($input, 'truckId', 'Truck');
        $truck = $this->truckRow($truckId);
        $this->assertOperatorAccess($actor, (string) $truck['truck_operator_id']);
        $consignmentId = $this->required($input, 'consignmentId', 'Consignment');
        $consignment = $this->consignmentRow($consignmentId);

        $this->assertPayloadFits($truck, $consignment);

        $openJourney = (int) $this->database->query(
            'SELECT COUNT(*) FROM truck_journeys WHERE truck_id = ' . $this->database->quote($truckId)
            . " AND status IN ('PLANNED', 'READY', 'IN_TRANSIT', 'PAUSED', 'DELAYED', 'BREAKDOWN', 'INCIDENT')"
        )->fetchColumn();
        if ($openJourney > 0) {
            throw new AuthException('This truck already has an open journey.', 409);
        }

        $id = Uuid::v4();
        $code = 'TRJ-' . gmdate('ymd') . '-' . strtoupper(bin2hex(random_bytes(3)));
        $this->database->beginTransaction();
        try {
            $this->database->prepare(<<<'SQL'
                INSERT INTO truck_journeys
                    (id, journey_code, truck_id, trailer_id, truck_operator_id, tracked_asset_id, consignment_id,
                     status, origin_location_id, destination_location_id, origin_text, destination_text,
                     planned_departure_at, cargo_weight_kg, cargo_hazardous, rescue_coverage_status, created_by_user_id)
                VALUES (:id, :code, :truck, :trailer, :operator, :asset, :consignment, 'PLANNED', :origin, :destination,
                        :originText, :destinationText, :planned, :weight, :hazardous, :coverage, :actor)
                SQL)->execute([
                'id' => $id, 'code' => $code, 'truck' => $truckId,
                'trailer' => $this->currentTrailerId($truckId),
                'operator' => $truck['truck_operator_id'],
                'asset' => $this->trackedAssetId((string) $truck['vehicle_id']),
                'consignment' => $consignmentId,
                'origin' => $this->optional($input, 'originLocationId'),
                'destination' => $this->optional($input, 'destinationLocationId'),
                'originText' => $this->optional($input, 'originText'),
                'destinationText' => $this->optional($input, 'destinationText'),
                'planned' => $this->optional($input, 'plannedDepartureAt'),
                'weight' => $consignment['total_weight_kg'],
                'hazardous' => (bool) $consignment['hazardous'] ? 1 : 0,
                'coverage' => $this->coverage->forVehicle((string) $truck['vehicle_id'])['covered'] ? 'ACTIVE' : 'UNCOVERED',
                'actor' => $actor['id'] ?? null,
            ]);
            $this->database->prepare(
                'INSERT INTO truck_journey_consignments (truck_journey_id, consignment_id, is_primary) VALUES (:journey, :consignment, 1)'
            )->execute(['journey' => $id, 'consignment' => $consignmentId]);

            foreach ((is_array($input['occupants'] ?? null) ? $input['occupants'] : []) as $occupant) {
                if (!is_array($occupant) || !is_string($occupant['driverId'] ?? null)) {
                    continue;
                }
                $role = strtoupper((string) ($occupant['role'] ?? 'DRIVER')) === 'CO_DRIVER' ? 'CO_DRIVER' : 'DRIVER';
                $this->database->prepare(<<<'SQL'
                    INSERT INTO truck_journey_occupants (id, truck_journey_id, person_id, role)
                    VALUES (:id, :journey, :person, :role)
                    SQL)->execute([
                    'id' => Uuid::v4(), 'journey' => $id,
                    'person' => (string) $this->driverPersonId((string) $occupant['driverId']),
                    'role' => $role,
                ]);
                $this->database->prepare(<<<'SQL'
                    UPDATE truck_driver_assignments SET journey_id = :journey, released_at = NULL
                    WHERE truck_id = :truck AND role = :role
                    SQL)->execute(['journey' => $id, 'truck' => $truckId, 'role' => $role]);
            }
            $this->database->commit();
        } catch (\Throwable $error) {
            if ($this->database->inTransaction()) {
                $this->database->rollBack();
            }
            throw $error;
        }

        $this->database->prepare("UPDATE consignments SET status = 'BOOKED' WHERE id = :id")
            ->execute(['id' => $consignmentId]);

        (new AuditLog($this->database))->write(
            'TRUCK_JOURNEY_CREATED',
            'TruckJourney',
            $id,
            $actor,
            $request,
            null,
            ['journeyCode' => $code, 'truckId' => $truckId, 'consignmentId' => $consignmentId,
             'cargoWeightKg' => (string) $consignment['total_weight_kg'], 'hazardous' => (bool) $consignment['hazardous']],
            ['source' => 'truck-cargo-domain']
        );

        return $this->journey($id, $actor);
    }

    /**
     * Move a journey forward. BREAKDOWN and INCIDENT are domain states, not
     * free text, so the Control Center can filter on them.
     *
     * @return array<string,mixed>
     */
    public function transitionJourney(array $input, array $actor, Request $request): array
    {
        $journeyId = $this->required($input, 'journeyId', 'Journey');
        $journey = $this->journeyRow($journeyId);
        $this->assertOperatorAccess($actor, (string) $journey['truck_operator_id']);
        $next = strtoupper((string) ($input['status'] ?? ''));
        $from = (string) $journey['status'];
        if (!in_array($next, self::JOURNEY_TRANSITIONS[$from] ?? [], true)) {
            throw new AuthException("A truck journey cannot move from {$from} to {$next}.", 409);
        }

        $this->database->prepare(<<<'SQL'
            UPDATE truck_journeys SET status = :status,
                   started_at = IF(:started = 'IN_TRANSIT', COALESCE(started_at, UTC_TIMESTAMP(6)), started_at),
                   arrived_at = IF(:arrived = 'ARRIVED', UTC_TIMESTAMP(6), arrived_at),
                   completed_at = IF(:completed = 'COMPLETED', UTC_TIMESTAMP(6), completed_at),
                   updated_at = UTC_TIMESTAMP(6)
            WHERE id = :id
            SQL)->execute([
            'status' => $next, 'started' => $next, 'arrived' => $next,
            'completed' => $next === 'COMPLETED' ? 1 : 0, 'id' => $journeyId,
        ]);

        if (in_array($next, ['ARRIVED', 'COMPLETED'], true)) {
            $this->database->prepare("UPDATE consignments SET status = 'DELIVERED' WHERE id = :id")
                ->execute(['id' => $journey['consignment_id']]);
        }
        if ($next === 'IN_TRANSIT') {
            $this->database->prepare("UPDATE consignments SET status = 'IN_TRANSIT' WHERE id = :id")
                ->execute(['id' => $journey['consignment_id']]);
        }

        (new AuditLog($this->database))->write(
            'TRUCK_JOURNEY_' . $next,
            'TruckJourney',
            $journeyId,
            $actor,
            $request,
            ['status' => $from],
            ['status' => $next],
            ['source' => 'truck-cargo-domain']
        );

        return $this->journey($journeyId, $actor);
    }

    /**
     * The manifest a responder needs, assembled from the live records.
     *
     * @return array<string,mixed>
     */
    public function manifest(string $journeyId, ?array $actor = null): array
    {
        $journey = $this->journeyRow($journeyId);
        if ($actor !== null) {
            $this->assertOperatorAccess($actor, (string) $journey['truck_operator_id']);
        }
        $truck = $this->truckRow((string) $journey['truck_id']);
        $vehicle = $this->vehicle((string) $truck['vehicle_id']);
        $trailer = $journey['trailer_id'] === null ? null : $this->trailerRow((string) $journey['trailer_id']);
        $consignment = $this->consignmentRow((string) $journey['consignment_id']);
        $assetId = $journey['tracked_asset_id'] === null ? null : (string) $journey['tracked_asset_id'];

        $items = $this->database->prepare('SELECT * FROM cargo_items WHERE consignment_id = :id ORDER BY created_at');
        $items->execute(['id' => $journey['consignment_id']]);
        $containers = $this->database->prepare(
            'SELECT c.container_number, c.container_type, c.seal_number
             FROM consignment_containers cc JOIN containers c ON c.id = cc.container_id
             WHERE cc.consignment_id = :id AND cc.released_at IS NULL'
        );
        $containers->execute(['id' => $journey['consignment_id']]);
        $occupants = $this->database->prepare(<<<'SQL'
            SELECT o.role, p.first_name, p.last_name, p.phone, d.license_number, d.license_class
            FROM truck_journey_occupants o
            JOIN persons p ON p.id = o.person_id
            LEFT JOIN truck_drivers d ON d.person_id = o.person_id
            WHERE o.truck_journey_id = :id ORDER BY o.role DESC
            SQL);
        $occupants->execute(['id' => $journeyId]);

        return [
            'journeyId' => $journeyId,
            'journeyCode' => $journey['journey_code'],
            'status' => $journey['status'],
            'truck' => [
                'truckNumber' => $truck['truck_number'],
                'registrationNumber' => $vehicle['registration_number'],
                'truckType' => $truck['truck_type'],
                'maximumPayloadKg' => $truck['maximum_payload_kg'] === null ? null : (float) $truck['maximum_payload_kg'],
            ],
            'trailer' => $trailer === null ? null : [
                'trailerNumber' => $trailer['trailer_number'],
                'trailerType' => $trailer['trailer_type'],
                'maxLoadKg' => $trailer['max_load_kg'] === null ? null : (float) $trailer['max_load_kg'],
            ],
            'crew' => array_map(static fn (array $row): array => [
                'role' => $row['role'],
                'name' => trim(((string) $row['first_name']) . ' ' . ((string) $row['last_name'])),
                'phone' => $row['phone'],
                'licenseNumber' => $row['license_number'],
                'licenseClass' => $row['license_class'],
            ], $occupants->fetchAll()),
            'cargo' => [
                'consignmentNumber' => $consignment['consignment_number'],
                'category' => $consignment['cargo_category'],
                'totalWeightKg' => (float) $consignment['total_weight_kg'],
                'declaredValue' => $consignment['declared_value'] === null ? null : (string) $consignment['declared_value'],
                'declaredCurrency' => $consignment['declared_currency'],
                'hazardous' => (bool) $consignment['hazardous'],
                'hazardClass' => $consignment['hazard_class'],
                'unNumber' => $consignment['un_number'],
                'temperatureControlled' => (bool) $consignment['temperature_controlled'],
                'items' => array_map(static fn (array $row): array => [
                    'description' => $row['description'],
                    'quantity' => $row['quantity'] === null ? null : (float) $row['quantity'],
                    'unit' => $row['unit'],
                    'weightKg' => $row['weight_kg'] === null ? null : (float) $row['weight_kg'],
                    'fragile' => (bool) $row['fragile'],
                ], $items->fetchAll()),
                'containers' => array_map(static fn (array $row): array => [
                    'containerNumber' => $row['container_number'],
                    'containerType' => $row['container_type'],
                    'sealNumber' => $row['seal_number'],
                ], $containers->fetchAll()),
            ],
            'route' => [
                'origin' => $journey['origin_text'],
                'destination' => $journey['destination_text'],
                'plannedDepartureAt' => $journey['planned_departure_at'],
                'startedAt' => $journey['started_at'],
            ],
            'rescueCoverage' => $this->coverage->forVehicle((string) $truck['vehicle_id']),
            'position' => $this->currentPosition($assetId),
        ];
    }

    /**
     * The operational dashboard for the domain.
     *
     * @param array<string,mixed> $filters
     *
     * @return array<string,mixed>
     */
    public function dashboard(array $filters = [], ?array $actor = null): array
    {
        $operatorId = $this->scopeOperatorId($actor, $filters);
        $scope = $operatorId === null ? '' : ' AND truck_operator_id = ' . $this->database->quote($operatorId);

        $metrics = [
            'fleet' => (int) $this->database->query('SELECT COUNT(*) FROM trucks WHERE status = \'ACTIVE\'' . $scope)->fetchColumn(),
            'inTransit' => (int) $this->database->query(
                "SELECT COUNT(*) FROM truck_journeys WHERE status = 'IN_TRANSIT'" . $scope
            )->fetchColumn(),
            'delayed' => (int) $this->database->query(
                "SELECT COUNT(*) FROM truck_journeys WHERE status = 'DELAYED'" . $scope
            )->fetchColumn(),
            'breakdowns' => (int) $this->database->query(
                "SELECT COUNT(*) FROM truck_journeys WHERE status = 'BREAKDOWN'" . $scope
            )->fetchColumn(),
            'openIncidents' => (int) $this->database->query(
                "SELECT COUNT(*) FROM rescue_incidents WHERE domain = 'TRUCK_CARGO' AND status NOT IN ('RESOLVED', 'CANCELLED')"
            )->fetchColumn(),
            'cargoInTransit' => (int) $this->database->query(
                "SELECT COUNT(*) FROM truck_journeys WHERE status IN ('IN_TRANSIT', 'DELAYED')" . $scope
            )->fetchColumn(),
            'cargoWeightInTransitKg' => (string) $this->database->query(
                "SELECT COALESCE(SUM(cargo_weight_kg), 0) FROM truck_journeys WHERE status IN ('IN_TRANSIT', 'DELAYED')" . $scope
            )->fetchColumn(),
            'coveredTrucks' => (int) $this->database->query(
                "SELECT COUNT(*) FROM trucks WHERE rescue_coverage_status = 'ACTIVE'" . $scope
            )->fetchColumn(),
            'activeDrivers' => (int) $this->database->query(
                "SELECT COUNT(DISTINCT o.person_id) FROM truck_journey_occupants o
                 JOIN truck_journeys j ON j.id = o.truck_journey_id
                 WHERE j.status IN ('IN_TRANSIT', 'PAUSED', 'DELAYED', 'INCIDENT', 'BREAKDOWN')" . str_replace('truck_operator_id', 'j.truck_operator_id', $scope)
            )->fetchColumn(),
        ];
        $metrics['trackingOnline'] = (int) $this->database->query(<<<SQL
            SELECT COUNT(*) FROM trucks t
            JOIN tracked_assets a ON a.vehicle_id = t.vehicle_id
            JOIN tracked_asset_positions p ON p.tracked_asset_id = a.id
            WHERE t.status = 'ACTIVE' AND p.recorded_at >= DATE_SUB(UTC_TIMESTAMP(6), INTERVAL 2 MINUTE)
            SQL)->fetchColumn();
        $metrics['trackingOffline'] = max(0, $metrics['fleet'] - $metrics['trackingOnline']);

        $cargoByCategory = $this->database->query(<<<'SQL'
            SELECT cat.label, COUNT(DISTINCT j.id) AS total
            FROM truck_journeys j
            JOIN consignments c ON c.id = j.consignment_id
            JOIN cargo_categories cat ON cat.code = c.cargo_category
            WHERE j.status IN ('IN_TRANSIT', 'DELAYED', 'ARRIVED')
            GROUP BY cat.code, cat.label ORDER BY total DESC LIMIT 10
            SQL)->fetchAll();

        return [
            'metrics' => $metrics,
            'cargoByCategory' => array_map(static fn (array $row): array => [
                'label' => (string) $row['label'],
                'total' => (int) $row['total'],
            ], $cargoByCategory),
            'message' => $metrics['fleet'] === 0 ? 'No data available.' : null,
        ];
    }

    /**
     * @return array<string,mixed>
     */
    public function operator(string $id, ?array $actor = null): array
    {
        $row = $this->operatorRow($id);
        if ($actor !== null) {
            $this->assertOperatorAccess($actor, $id);
        }
        $counts = $this->database->query(
            'SELECT COUNT(*) FROM trucks WHERE truck_operator_id = ' . $this->database->quote($id)
        )->fetchColumn();

        return [
            'id' => $id,
            'operatorNumber' => $row['operator_number'],
            'organizationId' => $row['organization_id'],
            'verificationStatus' => $row['verification_status'],
            'licenseNumber' => $row['license_number'],
            'fleetSize' => $row['fleet_size'] === null ? null : (int) $row['fleet_size'],
            'truckCount' => (int) $counts,
            'operatingCountry' => $row['operating_country'],
            'status' => $row['status'],
            'planId' => $row['service_plan_id'],
        ];
    }

    /**
     * @return array<string,mixed>
     */
    public function truck(string $id, ?array $actor = null): array
    {
        $row = $this->truckRow($id);
        if ($actor !== null) {
            $this->assertOperatorAccess($actor, (string) $row['truck_operator_id']);
        }
        $vehicle = $this->vehicle((string) $row['vehicle_id']);
        $assetId = $this->trackedAssetId((string) $row['vehicle_id']);

        return [
            'id' => $id,
            'truckNumber' => $row['truck_number'],
            'truckType' => $row['truck_type'],
            'registrationNumber' => $vehicle['registration_number'],
            'description' => trim(((string) $vehicle['make']) . ' ' . ((string) $vehicle['model'])),
            'axleConfiguration' => $row['axle_configuration'],
            'grossVehicleWeightKg' => $row['gross_vehicle_weight_kg'] === null ? null : (float) $row['gross_vehicle_weight_kg'],
            'maximumPayloadKg' => $row['maximum_payload_kg'] === null ? null : (float) $row['maximum_payload_kg'],
            'trailerRequired' => (bool) $row['trailer_required'],
            'hazardousGoodsApproved' => (bool) $row['hazardous_goods_approved'],
            'crossBorderEnabled' => (bool) $row['cross_border_enabled'],
            'rescueCoverage' => $this->coverage->forVehicle((string) $row['vehicle_id']),
            'trackingStatus' => $this->trackingStatus($assetId),
            'trackedAssetId' => $assetId,
            'currentTrailerId' => $this->currentTrailerId($id),
            'status' => $row['status'],
        ];
    }

    /**
     * @return array<string,mixed>
     */
    public function journey(string $id, ?array $actor = null): array
    {
        $row = $this->journeyRow($id);
        if ($actor !== null) {
            $this->assertOperatorAccess($actor, (string) $row['truck_operator_id']);
        }
        $truck = $this->truckRow((string) $row['truck_id']);

        return [
            'id' => $id,
            'journeyCode' => $row['journey_code'],
            'status' => $row['status'],
            'truckId' => $row['truck_id'],
            'trailerId' => $row['trailer_id'],
            'consignmentId' => $row['consignment_id'],
            'operatorId' => $row['truck_operator_id'],
            'origin' => $row['origin_text'],
            'destination' => $row['destination_text'],
            'cargoWeightKg' => $row['cargo_weight_kg'] === null ? null : (float) $row['cargo_weight_kg'],
            'cargoHazardous' => (bool) $row['cargo_hazardous'],
            'rescueCoverage' => $this->coverage->forVehicle((string) $truck['vehicle_id']),
            'position' => $this->currentPosition($row['tracked_asset_id'] === null ? null : (string) $row['tracked_asset_id']),
            'plannedDepartureAt' => $row['planned_departure_at'],
            'startedAt' => $row['started_at'],
            'completedAt' => $row['completed_at'],
        ];
    }

    /**
     * @return array<string,mixed>
     */
    public function consignment(string $id, ?array $actor = null): array
    {
        $row = $this->consignmentRow($id);
        $items = $this->database->prepare('SELECT * FROM cargo_items WHERE consignment_id = :id');
        $items->execute(['id' => $id]);

        return [
            'id' => $id,
            'consignmentNumber' => $row['consignment_number'],
            'cargoCategory' => $row['cargo_category'],
            'totalWeightKg' => (float) $row['total_weight_kg'],
            'declaredValue' => $row['declared_value'] === null ? null : (string) $row['declared_value'],
            'declaredCurrency' => $row['declared_currency'],
            'hazardous' => (bool) $row['hazardous'],
            'hazardClass' => $row['hazard_class'],
            'status' => $row['status'],
            'origin' => $row['origin_text'],
            'destination' => $row['destination_text'],
            'items' => array_map(static fn (array $item): array => [
                'description' => $item['description'],
                'weightKg' => $item['weight_kg'] === null ? null : (float) $item['weight_kg'],
                'quantity' => $item['quantity'] === null ? null : (float) $item['quantity'],
                'fragile' => (bool) $item['fragile'],
            ], $items->fetchAll()),
        ];
    }

    // ------------------------------------------------------------- internals

    /** A truck may not be loaded beyond its rated payload. */
    private function assertPayloadFits(array $truck, array $consignment): void
    {
        $maxPayload = $truck['maximum_payload_kg'] === null ? null : (float) $truck['maximum_payload_kg'];
        $weight = (float) $consignment['total_weight_kg'];
        if ($maxPayload !== null && $weight > $maxPayload) {
            throw new AuthException(sprintf(
                'This load is %.0f kg but the truck is rated for %.0f kg.',
                $weight,
                $maxPayload
            ), 422);
        }
        if ((bool) $consignment['hazardous'] && !(bool) $truck['hazardous_goods_approved']) {
            throw new AuthException('This truck is not approved to carry hazardous goods.', 422);
        }
    }

    private function currentTrailerId(string $truckId): ?string
    {
        $id = $this->database->query(
            'SELECT trailer_id FROM truck_trailer_assignments WHERE truck_id = ' . $this->database->quote($truckId)
            . ' AND released_at IS NULL LIMIT 1'
        )->fetchColumn();

        return is_string($id) ? $id : null;
    }

    private function driverPersonId(string $driverId): string
    {
        $personId = $this->database->query('SELECT person_id FROM truck_drivers WHERE id = ' . $this->database->quote($driverId))
            ->fetchColumn();
        if (!is_string($personId)) {
            throw new AuthException('Driver not found.', 404);
        }

        return $personId;
    }

    private function ensureTrackedAsset(string $vehicleId, string $operatorId): string
    {
        $existing = $this->trackedAssetId($vehicleId);
        if ($existing !== null) {
            return $existing;
        }
        $vehicle = $this->vehicle($vehicleId);
        $id = Uuid::v4();
        $this->database->prepare(<<<'SQL'
            INSERT INTO tracked_assets (id, asset_type, vehicle_id, asset_code, label, tracking_status, domain, status)
            VALUES (:id, 'TRUCK', :vehicle, :code, :label, 'NO_DEVICE', 'TRUCK_CARGO', 'ACTIVE')
            SQL)->execute([
            'id' => $id, 'vehicle' => $vehicleId, 'code' => $vehicle['registration_number'],
            'label' => trim(((string) $vehicle['make']) . ' ' . ((string) $vehicle['model']) . ' · ' . $vehicle['registration_number']),
        ]);

        return $id;
    }

    private function trackedAssetId(string $vehicleId): ?string
    {
        $id = $this->database->query(
            'SELECT id FROM tracked_assets WHERE vehicle_id = ' . $this->database->quote($vehicleId)
        )->fetchColumn();

        return is_string($id) ? $id : null;
    }

    /** @return array<string,mixed> */
    private function currentPosition(?string $assetId): array
    {
        $none = ['status' => 'NO_POSITION', 'latitude' => null, 'longitude' => null, 'recordedAt' => null, 'secondsAgo' => null];
        if ($assetId === null) {
            return $none;
        }
        $position = $this->database->query(
            'SELECT latitude, longitude, recorded_at FROM tracked_asset_positions WHERE tracked_asset_id = '
            . $this->database->quote($assetId)
        )->fetch();
        if (!is_array($position)) {
            return $none;
        }
        $secondsAgo = ServerClock::epoch($this->database) - ServerClock::parse((string) $position['recorded_at']);

        return [
            'status' => $secondsAgo <= 120 ? 'ONLINE' : 'OFFLINE',
            'latitude' => (float) $position['latitude'],
            'longitude' => (float) $position['longitude'],
            'recordedAt' => $position['recorded_at'],
            'secondsAgo' => $secondsAgo,
        ];
    }

    /** @return string NO_DEVICE|OFFLINE|ONLINE|UNKNOWN */
    private function trackingStatus(?string $assetId): string
    {
        if ($assetId === null) {
            return 'NO_DEVICE';
        }
        $assigned = $this->database->query(
            'SELECT COUNT(*) FROM tracking_device_assignments WHERE tracked_asset_id = '
            . $this->database->quote($assetId) . ' AND unassigned_at IS NULL'
        )->fetchColumn();
        if ((int) $assigned === 0) {
            return 'NO_DEVICE';
        }

        return $this->currentPosition($assetId)['status'] === 'ONLINE' ? 'ONLINE' : 'OFFLINE';
    }

    /**
     * Operator isolation: a truck operator sees only its own fleet, and a staff
     * account with no operator link is refused rather than shown everything.
     */
    private function assertOperatorAccess(?array $actor, string $operatorId): void
    {
        if ($actor === null) {
            return;
        }
        $role = (string) ($actor['role_code'] ?? '');
        if (in_array($role, ['SYSTEM_ADMIN', 'HQ_DISPATCHER', 'AUDITOR', 'FINANCE_MANAGER', 'RESCUE_OPERATOR'], true)) {
            return;
        }
        $scoped = $this->scopeOperatorId($actor, []);
        if ($scoped === null || $scoped !== $operatorId) {
            throw new AuthException('This fleet belongs to another operator.', 403);
        }
    }

    /**
     * The operator this actor is scoped to, if any.
     *
     * @param array<string,mixed> $filters
     */
    private function scopeOperatorId(?array $actor, array $filters): ?string
    {
        if (($filters['operatorId'] ?? '') !== '') {
            return (string) $filters['operatorId'];
        }
        if ($actor === null) {
            return null;
        }
        $role = (string) ($actor['role_code'] ?? '');
        if (in_array($role, ['SYSTEM_ADMIN', 'HQ_DISPATCHER', 'AUDITOR', 'FINANCE_MANAGER', 'RESCUE_OPERATOR'], true)) {
            return null;
        }
        $organizationId = is_string($actor['organization_id'] ?? null) ? $actor['organization_id'] : null;
        if ($organizationId === null) {
            return null;
        }
        $id = $this->database->query(
            'SELECT id FROM truck_operators WHERE organization_id = ' . $this->database->quote($organizationId) . ' LIMIT 1'
        )->fetchColumn();

        return is_string($id) ? $id : null;
    }

    private function createOrganization(array $input): string
    {
        $id = Uuid::v4();
        $this->database->prepare(<<<'SQL'
            INSERT INTO organizations (id, name, organization_type, country_code, region, city, phone, status)
            VALUES (:id, :name, 'TRANSPORT_OPERATOR', :country, :region, :city, :phone, 'ACTIVE')
            SQL)->execute([
            'id' => $id,
            'name' => $this->required($input, 'companyName', 'Company name'),
            'country' => $this->optional($input, 'country') ?? 'CD',
            'region' => $this->optional($input, 'region'),
            'city' => $this->optional($input, 'city'),
            'phone' => $this->optional($input, 'phone'),
        ]);

        return $id;
    }

    private function organizationExists(string $id): void
    {
        $statement = $this->database->prepare('SELECT COUNT(*) FROM organizations WHERE id = :id');
        $statement->execute(['id' => $id]);
        if ((int) $statement->fetchColumn() === 0) {
            throw new AuthException('Organization not found.', 404);
        }
    }

    private function assertPlanDomain(string $planId, string $domain): void
    {
        $statement = $this->database->prepare('SELECT domain FROM service_plans WHERE id = :id');
        $statement->execute(['id' => $planId]);
        $planDomain = $statement->fetchColumn();
        if (!is_string($planDomain)) {
            throw new AuthException('Service plan not found.', 404);
        }
        if ($planDomain !== $domain) {
            throw new AuthException("That plan belongs to the {$planDomain} domain.", 422);
        }
    }

    private function planId(string $code): ?string
    {
        $id = $this->database->query(
            "SELECT id FROM service_plans WHERE plan_code = " . $this->database->quote($code) . " AND status = 'ACTIVE'"
        )->fetchColumn();

        return is_string($id) ? $id : null;
    }

    /** @return array<string,mixed> */
    private function operatorRow(string $id): array
    {
        $statement = $this->database->prepare('SELECT * FROM truck_operators WHERE id = :id');
        $statement->execute(['id' => $id]);
        $row = $statement->fetch();
        if (!is_array($row)) {
            throw new AuthException('Truck operator not found.', 404);
        }

        return $row;
    }

    /** @return array<string,mixed> */
    private function truckRow(string $id): array
    {
        $statement = $this->database->prepare('SELECT * FROM trucks WHERE id = :id');
        $statement->execute(['id' => $id]);
        $row = $statement->fetch();
        if (!is_array($row)) {
            throw new AuthException('Truck not found.', 404);
        }

        return $row;
    }

    /** @return array<string,mixed> */
    private function trailerRow(string $id): array
    {
        $statement = $this->database->prepare('SELECT * FROM trailers WHERE id = :id');
        $statement->execute(['id' => $id]);
        $row = $statement->fetch();
        if (!is_array($row)) {
            throw new AuthException('Trailer not found.', 404);
        }

        return $row;
    }

    /** @return array<string,mixed> */
    private function journeyRow(string $id): array
    {
        $statement = $this->database->prepare('SELECT * FROM truck_journeys WHERE id = :id');
        $statement->execute(['id' => $id]);
        $row = $statement->fetch();
        if (!is_array($row)) {
            throw new AuthException('Truck journey not found.', 404);
        }

        return $row;
    }

    /** @return array<string,mixed> */
    private function consignmentRow(string $id): array
    {
        $statement = $this->database->prepare('SELECT * FROM consignments WHERE id = :id');
        $statement->execute(['id' => $id]);
        $row = $statement->fetch();
        if (!is_array($row)) {
            throw new AuthException('Consignment not found.', 404);
        }

        return $row;
    }

    /** @return array<string,mixed> */
    private function vehicle(string $id): array
    {
        $statement = $this->database->prepare('SELECT * FROM vehicles WHERE id = :id AND deleted_at IS NULL');
        $statement->execute(['id' => $id]);
        $row = $statement->fetch();
        if (!is_array($row)) {
            throw new AuthException('Vehicle not found.', 404);
        }

        return $row;
    }

    /** @return array<string,mixed> */
    private function person(string $id): array
    {
        $statement = $this->database->prepare('SELECT * FROM persons WHERE id = :id AND deleted_at IS NULL');
        $statement->execute(['id' => $id]);
        $row = $statement->fetch();
        if (!is_array($row)) {
            throw new AuthException('Person not found.', 404);
        }

        return $row;
    }

    private function weight(array $input, string $key): ?string
    {
        if (!isset($input[$key]) || $input[$key] === '' || !is_numeric($input[$key])) {
            return null;
        }
        $value = (float) $input[$key];
        if ($value <= 0) {
            throw new AuthException('Weights must be greater than zero.', 422);
        }

        return (string) round($value, 2);
    }

    private function operatorNumber(): string
    {
        for ($attempt = 0; $attempt < 5; $attempt++) {
            $number = 'TRO-' . gmdate('ymd') . '-' . strtoupper(bin2hex(random_bytes(3)));
            $exists = $this->database->prepare('SELECT COUNT(*) FROM truck_operators WHERE operator_number = :number');
            $exists->execute(['number' => $number]);
            if ((int) $exists->fetchColumn() === 0) {
                return $number;
            }
        }

        throw new AuthException('Could not allocate an operator number.', 500);
    }

    private function truckNumber(string $operatorId, mixed $requested): string
    {
        if (is_string($requested) && trim($requested) !== '') {
            return trim($requested);
        }
        for ($attempt = 0; $attempt < 5; $attempt++) {
            $number = 'TRK-' . strtoupper(bin2hex(random_bytes(3)));
            $exists = $this->database->prepare(
                'SELECT COUNT(*) FROM trucks WHERE truck_operator_id = :operator AND truck_number = :number'
            );
            $exists->execute(['operator' => $operatorId, 'number' => $number]);
            if ((int) $exists->fetchColumn() === 0) {
                return $number;
            }
        }

        throw new AuthException('Could not allocate a truck number.', 500);
    }

    private function trailerNumber(string $operatorId, mixed $requested): string
    {
        if (is_string($requested) && trim($requested) !== '') {
            return trim($requested);
        }
        for ($attempt = 0; $attempt < 5; $attempt++) {
            $number = 'TRL-' . strtoupper(bin2hex(random_bytes(3)));
            $exists = $this->database->prepare(
                'SELECT COUNT(*) FROM trailers WHERE truck_operator_id = :operator AND trailer_number = :number'
            );
            $exists->execute(['operator' => $operatorId, 'number' => $number]);
            if ((int) $exists->fetchColumn() === 0) {
                return $number;
            }
        }

        throw new AuthException('Could not allocate a trailer number.', 500);
    }

    private function driverNumber(string $operatorId): string
    {
        for ($attempt = 0; $attempt < 5; $attempt++) {
            $number = 'DRV-' . strtoupper(bin2hex(random_bytes(3)));
            $exists = $this->database->prepare(
                'SELECT COUNT(*) FROM truck_drivers WHERE truck_operator_id = :operator AND driver_number = :number'
            );
            $exists->execute(['operator' => $operatorId, 'number' => $number]);
            if ((int) $exists->fetchColumn() === 0) {
                return $number;
            }
        }

        throw new AuthException('Could not allocate a driver number.', 500);
    }

    private function consignmentNumber(): string
    {
        for ($attempt = 0; $attempt < 5; $attempt++) {
            $number = 'CN-' . gmdate('ymd') . '-' . strtoupper(bin2hex(random_bytes(3)));
            $exists = $this->database->prepare('SELECT COUNT(*) FROM consignments WHERE consignment_number = :number');
            $exists->execute(['number' => $number]);
            if ((int) $exists->fetchColumn() === 0) {
                return $number;
            }
        }

        throw new AuthException('Could not allocate a consignment number.', 500);
    }

    /** @param list<string>|null $allowed */
    private function choice(mixed $value, string $column, ?string $referenceTable, ?array $allowed = null): string
    {
        $choice = is_string($value) ? strtoupper(trim($value)) : '';
        if ($choice === '') {
            throw new AuthException("Choose a valid {$column}.", 422);
        }
        if ($allowed !== null) {
            if (!in_array($choice, $allowed, true)) {
                throw new AuthException("Choose a valid {$column}.", 422);
            }

            return $choice;
        }
        if ($referenceTable === null) {
            return $choice;
        }
        $statement = $this->database->prepare("SELECT code FROM {$referenceTable} WHERE code = :code");
        $statement->execute(['code' => $choice]);
        if ($statement->fetchColumn() === false) {
            throw new AuthException("Choose a valid {$column}.", 422);
        }

        return $choice;
    }

    private function required(array $input, string $key, string $label): string
    {
        $value = is_string($input[$key] ?? null) ? trim($input[$key]) : '';
        if ($value === '') {
            throw new AuthException("{$label} is required.", 422);
        }

        return $value;
    }

    private function optional(array $input, string $key): ?string
    {
        $value = $input[$key] ?? null;
        if (!is_string($value) || trim($value) === '') {
            return null;
        }

        return trim($value);
    }
}
