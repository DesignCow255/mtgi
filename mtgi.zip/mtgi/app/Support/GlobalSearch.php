<?php

declare(strict_types=1);

namespace Mamore\Support;

use Mamore\Auth\AuthException;
use Mamore\Core\AuditLog;
use PDO;

/**
 * Global operational search.
 *
 * One box resolves a rescue code, a VIP number, a plate, a truck number, a
 * consignment or a person - and every result is permission filtered in SQL, not
 * filtered afterwards in the browser. A role that may not see a domain simply
 * does not get that domain in the answer.
 */
final class GlobalSearch
{
    private const MIN_LENGTH = 2;
    private const LIMIT = 20;

    public function __construct(private readonly PDO $database) {}

    /**
     * @param list<string> $domains the domains this caller may see
     *
     * @return array<string,mixed>
     */
    public function search(string $query, array $domains, ?array $actor = null): array
    {
        $term = trim($query);
        if (mb_strlen($term) < self::MIN_LENGTH) {
            throw new AuthException('Enter at least two characters to search.', 422);
        }
        if ($domains === []) {
            return ['query' => $term, 'results' => [], 'count' => 0, 'message' => 'No searchable domains for this role.'];
        }

        $inDomains = implode(', ', array_fill(0, count($domains), '?'));
        $results = [];

        // A rescue code, read only in full for a role allowed to see codes.
        $codes = $this->database->prepare(<<<SQL
            SELECT 'RESCUE_CODE' AS kind, c.id, c.code AS reference, c.status,
                   COALESCE(s.membership_number, '') AS secondary
            FROM rescue_codes c
            LEFT JOIN subscribers s ON s.id = c.subscriber_id
            WHERE c.code LIKE ? AND c.domain IN ({$inDomains})
            LIMIT 5
            SQL);
        $codes->execute(array_merge([$this->like($term)], $domains));
        foreach ($codes->fetchAll() as $row) {
            $results[] = [
                'kind' => 'RESCUE_CODE',
                'id' => $row['id'],
                'reference' => $row['reference'],
                'secondary' => $row['secondary'],
                'status' => $row['status'],
                'domain' => 'VIP',
            ];
        }

        // Vehicles by registration, make or model.
        $vehicles = $this->database->prepare(<<<SQL
            SELECT v.id, v.registration_number, v.make, v.model, v.vehicle_type
            FROM vehicles v
            WHERE v.deleted_at IS NULL
              AND (v.registration_number LIKE ? OR v.make LIKE ? OR v.model LIKE ? OR v.vin LIKE ?)
              AND v.vehicle_type IN ('BUS', 'TRUCK', 'PRIVATE_CAR', 'RESCUE_VEHICLE', 'TRAILER', 'VAN')
            LIMIT 8
            SQL);
        $vehicles->execute([$this->like($term), $this->like($term), $this->like($term), $this->like($term)]);
        foreach ($vehicles->fetchAll() as $row) {
            $results[] = [
                'kind' => 'VEHICLE',
                'id' => $row['id'],
                'reference' => $row['registration_number'],
                'secondary' => trim(((string) $row['make']) . ' ' . ((string) $row['model'])),
                'status' => $row['vehicle_type'],
                'domain' => $this->vehicleDomain((string) $row['vehicle_type']),
            ];
        }

        if (in_array('TRUCK_CARGO', $domains, true)) {
            $trucks = $this->database->prepare(<<<'SQL'
                SELECT t.id, t.truck_number, t.truck_type, o.operator_number
                FROM trucks t JOIN truck_operators o ON o.id = t.truck_operator_id
                WHERE t.truck_number LIKE ? OR o.operator_number LIKE ?
                LIMIT 5
                SQL);
            $trucks->execute([$this->like($term), $this->like($term)]);
            foreach ($trucks->fetchAll() as $row) {
                $results[] = [
                    'kind' => 'TRUCK',
                    'id' => $row['id'],
                    'reference' => $row['truck_number'],
                    'secondary' => $row['operator_number'],
                    'status' => $row['truck_type'],
                    'domain' => 'TRUCK_CARGO',
                ];
            }

            $consignments = $this->database->prepare(<<<'SQL'
                SELECT id, consignment_number, cargo_category, status
                FROM consignments WHERE consignment_number LIKE ? LIMIT 5
                SQL);
            $consignments->execute([$this->like($term)]);
            foreach ($consignments->fetchAll() as $row) {
                $results[] = [
                    'kind' => 'CONSIGNMENT',
                    'id' => $row['id'],
                    'reference' => $row['consignment_number'],
                    'secondary' => $row['cargo_category'],
                    'status' => $row['status'],
                    'domain' => 'TRUCK_CARGO',
                ];
            }
        }

        if (in_array('SMART_BUS', $domains, true)) {
            $tickets = $this->database->prepare(<<<'SQL'
                SELECT b.id, b.booking_reference, b.passenger_name, t.trip_code
                FROM smartbus_bookings b JOIN smartbus_trips t ON t.id = b.trip_id
                WHERE b.booking_reference LIKE ? OR t.trip_code LIKE ?
                ORDER BY b.created_at DESC LIMIT 5
                SQL);
            $tickets->execute([$this->like($term), $this->like($term)]);
            foreach ($tickets->fetchAll() as $row) {
                $results[] = [
                    'kind' => 'BOOKING',
                    'id' => $row['id'],
                    'reference' => $row['booking_reference'],
                    'secondary' => $row['trip_code'],
                    'status' => null,
                    'domain' => 'SMART_BUS',
                ];
            }
        }

        if (in_array('VIP', $domains, true)) {
            $vips = $this->database->prepare(<<<'SQL'
                SELECT v.id, v.membership_number, p.first_name, p.last_name, v.status
                FROM vip_subscribers v JOIN persons p ON p.id = v.person_id
                WHERE v.membership_number LIKE ? OR p.phone LIKE ? LIMIT 5
                SQL);
            $vips->execute([$this->like($term), $this->like($term)]);
            foreach ($vips->fetchAll() as $row) {
                $results[] = [
                    'kind' => 'VIP',
                    'id' => $row['id'],
                    'reference' => $row['membership_number'],
                    'secondary' => trim(((string) $row['first_name']) . ' ' . ((string) $row['last_name'])),
                    'status' => $row['status'],
                    'domain' => 'VIP',
                ];
            }
        }

        $incidents = $this->database->prepare(<<<SQL
            SELECT i.id, i.incident_code, i.domain, i.status, i.severity
            FROM rescue_incidents i
            WHERE i.incident_code LIKE ? AND i.domain IN ({$inDomains})
            ORDER BY i.reported_at DESC LIMIT 5
            SQL);
        $incidents->execute(array_merge([$this->like($term)], $domains));
        foreach ($incidents->fetchAll() as $row) {
            $results[] = [
                'kind' => 'INCIDENT',
                'id' => $row['id'],
                'reference' => $row['incident_code'],
                'secondary' => $row['severity'],
                'status' => $row['status'],
                'domain' => $row['domain'],
            ];
        }

        $results = array_slice($results, 0, self::LIMIT);

        if ($actor !== null) {
            (new AuditLog($this->database))->write(
                'GLOBAL_SEARCH_PERFORMED',
                'Search',
                null,
                $actor,
                null,
                null,
                null,
                ['source' => 'global-search', 'resultCount' => count($results), 'domains' => $domains]
            );
        }

        return [
            'query' => $term,
            'results' => $results,
            'count' => count($results),
            'message' => $results === [] ? 'No matches.' : null,
        ];
    }

    /**
     * The domains a caller may see, derived from the permissions they hold.
     *
     * @param array<string,list<string>> $permissionCodesByCode
     *
     * @return list<string>
     */
    public function domainsFor(array $actor, array $permissionCodesByCode): array
    {
        $permissions = $permissionCodesByCode['all'] ?? [];
        $domains = [];
        foreach (['SMART_BUS', 'TRUCK_CARGO', 'PRIVATE_VEHICLE', 'VIP', 'RESCUE'] as $domain) {
            $required = match ($domain) {
                'SMART_BUS' => 'smartbus.manifest.view',
                'TRUCK_CARGO' => 'truck.view',
                'PRIVATE_VEHICLE' => 'private_vehicle.view',
                'VIP' => 'vip.view',
                'RESCUE' => 'tracking.global_view',
                default => null,
            };
            if ($required !== null && in_array($required, $permissions, true)) {
                $domains[] = $domain;
            }
        }

        return $domains;
    }

    private function like(string $term): string
    {
        return '%' . str_replace(['%', '_'], ['\%', '\_'], $term) . '%';
    }

    private function vehicleDomain(string $vehicleType): string
    {
        return match ($vehicleType) {
            'BUS' => 'SMART_BUS',
            'TRUCK' => 'TRUCK_CARGO',
            'PRIVATE_CAR' => 'PRIVATE_VEHICLE',
            'RESCUE_VEHICLE' => 'RESCUE',
            default => 'OTHER',
        };
    }
}
