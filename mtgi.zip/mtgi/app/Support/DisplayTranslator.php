<?php

declare(strict_types=1);

namespace Mamore\Support;

/**
 * Decides how a value from the database may be displayed.
 *
 * The brief is unusually specific about this, and it is right to be: blindly
 * running a translation service over query results is how you end up translating
 * a customer's name, a registration plate and a phone number. This class is the
 * single place that decision is made, so it cannot be forgotten on one screen.
 *
 * Category A — never translated: names, company names (absent an official
 *   localised form), plates, IDs, references, ticket and invoice numbers,
 *   phone numbers, emails, coordinates, raw addresses, numbers.
 * Category B — translated by key: statuses, categories, vehicle types, incident
 *   types, service types, permission display names, plan features, location types.
 * Category C — translatable admin content, via the content_translations table.
 *   The source row is never overwritten; a missing translation falls back to the
 *   source value, which keeps the interface readable in every language from day
 *   one rather than blank.
 * Category D — user free text, always rendered as authored. An optional
 *   translation may be shown beneath it, never instead of it.
 */
final class DisplayTranslator
{
    /**
     * Field names whose values are Category A and must pass through untouched.
     *
     * Deliberately generous. A name that slips through untranslated is a cosmetic
     * bug; a phone number or a plate that gets translated is a broken record.
     */
    private const NEVER_TRANSLATE = [
        'first_name', 'last_name', 'full_name', 'name', 'passenger_name',
        'subscriber_name', 'operator_name', 'driver_name', 'conductor_name',
        'email', 'phone', 'alt_phone', 'national_id',
        'plate', 'plate_number', 'registration', 'registration_plate',
        'vin', 'chassis_number', 'trailer_plate',
        'reference', 'code', 'ticket_code', 'trip_code', 'receipt_number',
        'invoice_number', 'membership_number', 'consignment_reference',
        'latitude', 'longitude', 'address', 'address_line', 'landmark',
        'phone_number', 'emergency_contact',
    ];

    public function __construct(private readonly \Mamore\Core\Translator $translator) {}

    /**
     * Whether a field's value may be translated at all.
     */
    public function isTranslatable(string $field): bool
    {
        $normalised = strtolower($field);

        foreach (self::NEVER_TRANSLATE as $blocked) {
            if ($normalised === $blocked || str_contains($normalised, $blocked)) {
                return false;
            }
        }

        return true;
    }

    /**
     * Display a value, choosing the strategy from the field name.
     *
     * Category B is detected by VALUE rather than by field name: a status is the
     * same value whether it arrived as `status`, `subscription_status` or
     * `payment_status`, and the column name varies per table. The catalogue
     * lookup is the test.
     */
    public function display(string $field, ?string $value): string
    {
        if ($value === null || $value === '') {
            return '';
        }

        // Category A always wins, even if the value happens to look like a code.
        if (!$this->isTranslatable($field)) {
            return $value;
        }

        // Category B: a controlled value that exists in the status catalogue.
        $key = 'status.' . strtoupper(str_replace([' ', '-'], '_', trim($value)));
        if ($this->translator->has($key)) {
            return $this->translator->t($key);
        }

        // Category C and D: authored content, rendered as authored.
        return $value;
    }

    /**
     * A status, resolving through the catalogue with a readable fallback.
     *
     * `$locale` is explicit because the Translator is shared per-request state.
     * Reading a second locale through a handle captured before a switch would
     * silently return the CURRENT locale instead, which is the kind of bug that
     * makes a French page show an English status.
     *
     * The fallback replaces underscores with spaces rather than showing the raw
     * code, so a status added to the backend after this catalogue was written
     * still reads as "PENDING REVIEW" instead of shouting a code at an operator.
     */
    public function status(?string $value, ?string $locale = null): string
    {
        $normalised = strtoupper(str_replace([' ', '-'], '_', trim((string) $value)));

        if ($normalised === '') {
            return '';
        }

        $key = 'status.' . $normalised;

        return $this->translator->has($key)
            ? $this->translator->t($key, [], $locale)
            : ucfirst(strtolower(str_replace('_', ' ', $normalised)));
    }

    /**
     * Numbers, Category A, are never "translated" into words.
     */
    public function number(float|int|string|null $value, int $decimals = 0): string
    {
        if ($value === null || $value === '') {
            return '0';
        }

        return number_format((float) $value, $decimals, '.', '');
    }
}
