<?php

declare(strict_types=1);

namespace Mamore\Support;

use Mamore\Finance\ExchangeRateService;

/**
 * The single money formatter.
 *
 * The audit found THREE independent formatters in the frontend -- app.js:206
 * `money()` which hard-suffixed "CDF" on every value regardless of its real
 * currency, subscriptions.js:13 `usd()`, and multi-domain.js:40 `asMoney()`,
 * which was also used to print CARGO WEIGHT IN KILOGRAMS. A financial screen
 * that cannot say which currency a number is in, and a weight that renders as
 * money, are the kind of defect that makes people stop trusting a number.
 *
 * This class is the one place a monetary value becomes text, and the rule is
 * simple: a converted figure ALWAYS carries its currency code. "$1,705,500.00"
 * with no code is a number nobody can act on.
 *
 * CONVERSION NEVER MUTATES A STORED AMOUNT. `convert()` takes a string and
 * returns a string; nothing here writes to payments, receipts, the ledger or
 * any allocation table. There is no code path from a display-currency choice to
 * a write, and tests/currency-integration.php proves it by hashing the finance
 * tables either side of a full round-trip.
 */
final class Money
{
    /**
     * Format an amount in the currency it is already denominated in.
     *
     * Retained unchanged: it is used by services, by the receipt print view and
     * by tests/fee-engine-characterization.php, and it is the correct behaviour
     * when no conversion was requested.
     */
    public static function format(string $amount, string $currency): string
    {
        $normalized = bcadd($amount, '0', 2);
        $negative = bccomp($normalized, '0', 2) < 0;
        $digits = $negative ? substr($normalized, 1) : $normalized;
        [$units, $cents] = array_pad(explode('.', $digits, 2), 2, '00');
        $grouped = number_format((float) $units, 0, '', ',');

        return ($negative ? '-' : '') . $currency . ' ' . $grouped . '.' . substr(str_pad($cents, 2, '0'), 0, 2);
    }

    /**
     * Convert USD to CDF and round UP to the nearest 100 CDF.
     *
     * Matches the TypeScript Money/CDF convention (ceil-to-100), which exists
     * because CDF has no practical minor unit in commerce: charging 1,000.01 CDF
     * is a rounding artefact nobody can pay.
     */
    public static function usdToCdfRounded(string $usd, string $rate): string
    {
        $product = bcmul($usd, $rate, 4);
        $ceiled = (int) ceil(((float) $product) / 100);

        return number_format($ceiled * 100, 2, '.', '');
    }

    /**
     * Round UP to the nearest 100 CDF, the settlement convention.
     */
    public static function ceilToCdfHundred(string $amount): string
    {
        $ceiled = (int) ceil((float) $amount / 100);

        return number_format($ceiled * 100, 2, '.', '');
    }

    /**
     * Convert for DISPLAY only.
     *
     * When no rate is available the ORIGINAL amount is returned in its ORIGINAL
     * currency and `converted` is false. This is the single most important
     * behaviour in the class: presenting a guess as a conversion is worse than
     * admitting the figure is not convertible right now, so the caller shows the
     * source value plus a notice instead.
     *
     * @return array{amount:string,currency:string,converted:bool,rate:?string,status:string}
     */
    public static function convert(
        string $amount,
        string $sourceCurrency,
        string $displayCurrency,
        ?ExchangeRateService $rates = null
    ): array {
        $source = strtoupper(trim($sourceCurrency));
        $display = strtoupper(trim($displayCurrency));
        $amount = bcadd($amount, '0', 2);

        if ($source === '' || $display === '' || $source === $display) {
            return ['amount' => $amount, 'currency' => $source, 'converted' => false, 'rate' => null, 'status' => 'identity'];
        }

        $rate = $rates?->getRate($source, $display);

        if ($rate === null || $rate['rate'] === null) {
            return [
                'amount' => $amount,
                'currency' => $source,
                'converted' => false,
                'rate' => null,
                'status' => $rate['status'] ?? 'unavailable',
            ];
        }

        return [
            'amount' => bcdiv(bcmul($amount, $rate['rate'], 12), '1', 2),
            'currency' => $display,
            'converted' => true,
            'rate' => $rate['rate'],
            'status' => $rate['status'],
        ];
    }

    /**
     * Format for display, converting when a rate exists.
     *
     * `cdfRounding` applies ceil-to-100 and is used only where a CDF amount is
     * actually going to be charged, never for a figure that is merely shown.
     */
    public static function display(
        string $amount,
        string $sourceCurrency,
        string $displayCurrency,
        ?ExchangeRateService $rates = null,
        bool $cdfRounding = false
    ): string {
        $converted = self::convert($amount, $sourceCurrency, $displayCurrency, $rates);

        if (!$converted['converted'] || !$cdfRounding || $converted['currency'] !== ExchangeRateService::CDF) {
            return self::format($converted['amount'], $converted['currency']);
        }

        return self::format(self::ceilToCdfHundred($converted['amount']), ExchangeRateService::CDF);
    }

    /**
     * A figure plus everything a reader needs to trust it.
     *
     * Carries the source amount and the rate used, so a tooltip can show
     * "USD 600.00 · converted at 2,842.50" rather than making the reader guess
     * where the number came from. An unconverted figure has no rate, and the
     * interface says so instead of implying one.
     *
     * @return array{amount:string,currency:string,converted:bool,rate:?string,status:string,sourceAmount:string,sourceCurrency:string}
     */
    public static function presentation(
        string $amount,
        string $sourceCurrency,
        string $displayCurrency,
        ?ExchangeRateService $rates = null
    ): array {
        return self::convert($amount, $sourceCurrency, $displayCurrency, $rates) + [
            'sourceAmount' => bcadd($amount, '0', 2),
            'sourceCurrency' => strtoupper(trim($sourceCurrency)),
        ];
    }
}



