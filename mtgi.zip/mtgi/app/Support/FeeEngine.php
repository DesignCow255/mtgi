<?php

declare(strict_types=1);

namespace Mamore\Support;

final class FeeEngine
{
    public const TRUCK_TOTAL = '600.00';
    public const PRIVATE_TOTAL = '80.00';

    /**
     * Canonical chargeable breakdown for the Truck Rescue Standby fee.
     *
     * GRO $430 + TAXABLE $170 = $600 charged to the subscriber.
     *
     * The DGI/PDC/UNALLOCATED amounts are SUBSETS of the $170 TAXABLE
     * container - they are reported for transparency but are NOT
     * additive on top of the total. Matches the TypeScript
     * FeeEngineService::chargeableBreakdown() semantics.
     *
     * @return list<array{key:string,name:string,amount:string}>
     */
    public static function truckBreakdown(): array
    {
        return [
            ['key' => 'GRO', 'name' => 'General Rescue Operations', 'amount' => '430.00'],
            ['key' => 'TAXABLE', 'name' => 'Taxable (DGI + PDC + Unallocated remainder)', 'amount' => '170.00'],
        ];
    }

    /**
     * Informational sub-allocation of the $170 TAXABLE container.
     * DGI $51 + Haut-Katanga PDC $15 + Lualaba PDC $15 + UNALLOCATED $89 = $170.
     * Never added to the customer total.
     *
     * @return list<array{key:string,name:string,amount:string}>
     */
    public static function truckTaxableSubBreakdown(): array
    {
        return [
            ['key' => 'DGI_TAX', 'name' => 'DGI Tax (Direction Generale des Impots) - subset of Taxable', 'amount' => '51.00'],
            ['key' => 'PDC_HAUT_KATANGA', 'name' => 'Haut-Katanga PDC (Provincial Direct Cost) - subset of Taxable', 'amount' => '15.00'],
            ['key' => 'PDC_LUALABA', 'name' => 'Lualaba PDC (Provincial Direct Cost) - subset of Taxable', 'amount' => '15.00'],
            ['key' => 'UNALLOCATED', 'name' => 'Unallocated remainder of Taxable (awaiting management allocation)', 'amount' => '89.00'],
        ];
    }

    /**
     * Canonical chargeable breakdown for the Private Vehicle Rescue fee.
     * Operating cost $40 + Taxable $40 = $80/month.
     *
     * @return list<array{key:string,name:string,amount:string}>
     */
    public static function privateBreakdown(): array
    {
        return [
            ['key' => 'OP_COST', 'name' => 'Operating Cost', 'amount' => '40.00'],
            ['key' => 'TAXABLE', 'name' => 'Taxable', 'amount' => '40.00'],
        ];
    }

    /**
     * Informational sub-allocation of the $40 private TAXABLE container.
     * DGI $12 + PDC $8 + PROFIT $20 = $40. Never additive to the total.
     *
     * @return list<array{key:string,name:string,amount:string}>
     */
    public static function privateTaxableSubBreakdown(): array
    {
        return [
            ['key' => 'DGI_TAX', 'name' => 'DGI Tax - subset of Taxable', 'amount' => '12.00'],
            ['key' => 'PDC_TAX', 'name' => 'PDC Tax - subset of Taxable', 'amount' => '8.00'],
            ['key' => 'PROFIT', 'name' => 'Profit - subset of Taxable', 'amount' => '20.00'],
        ];
    }

    /**
     * Canonical product catalog: the single PHP source of truth for fees.
     *
     * `app/Support/FeeEngine.php` and the seeded `rescue_products` /
     * `rescue_product_rules` rows must stay identical; the parity test
     * tests/fee-catalog-parity.php fails the suite if they drift.
     *
     * `role` distinguishes the CHARGEABLE lines that reconcile to the product
     * total from the SUBSET lines that merely sub-allocate a taxable container
     * (they are reported for transparency and are never additive).
     *
     * @return array<string, array{
     *     code:string, name:string, productType:string, vehicleType:string,
     *     billingFrequency:string, baseFee:string, totalFee:string, currency:string,
     *     provinces:list<string>,
     *     rules:list<array{key:string,name:string,componentType:string,category:string,role:string,ledgerAccount:string,amount:string,isTaxable:bool,province:?string}>
     * }>
     */
    public static function catalog(): array
    {
        return [
            'TRUCK_RESCUE' => [
                'code' => 'TRUCK_RESCUE',
                'name' => 'Truck Rescue Standby',
                'productType' => 'TRUCK_RESCUE',
                'vehicleType' => 'TRUCK',
                'billingFrequency' => 'ONE_TIME',
                'baseFee' => '430.00',
                'totalFee' => self::TRUCK_TOTAL,
                'currency' => 'USD',
                'provinces' => ['HAUT_KATANGA', 'LUALABA'],
                'rules' => [
                    ['key' => 'GRO', 'name' => 'General Rescue Operations', 'componentType' => 'GENERAL_RESCUE_OPERATIONS', 'category' => 'BASE_FEE', 'role' => 'CHARGEABLE', 'ledgerAccount' => 'GRO_REVENUE', 'amount' => '430.00', 'isTaxable' => false, 'province' => null],
                    ['key' => 'TAXABLE', 'name' => 'Taxable (container of DGI + PDC + unallocated remainder)', 'componentType' => 'TAXABLE', 'category' => 'TAXABLE', 'role' => 'CHARGEABLE', 'ledgerAccount' => 'TAX_REVENUE', 'amount' => '170.00', 'isTaxable' => true, 'province' => null],
                    ['key' => 'DGI_TAX', 'name' => 'DGI Tax (subset of Taxable)', 'componentType' => 'DGI_TAX', 'category' => 'TAX', 'role' => 'SUBSET', 'ledgerAccount' => 'TAX_REVENUE', 'amount' => '51.00', 'isTaxable' => true, 'province' => null],
                    ['key' => 'PDC_HAUT_KATANGA', 'name' => 'Haut-Katanga PDC (subset of Taxable)', 'componentType' => 'PDC_HAUT_KATANGA', 'category' => 'PDC', 'role' => 'SUBSET', 'ledgerAccount' => 'PDC_PAYABLE', 'amount' => '15.00', 'isTaxable' => false, 'province' => 'HAUT_KATANGA'],
                    ['key' => 'PDC_LUALABA', 'name' => 'Lualaba PDC (subset of Taxable)', 'componentType' => 'PDC_LUALABA', 'category' => 'PDC', 'role' => 'SUBSET', 'ledgerAccount' => 'PDC_PAYABLE', 'amount' => '15.00', 'isTaxable' => false, 'province' => 'LUALABA'],
                    ['key' => 'UNALLOCATED', 'name' => 'Unallocated remainder of Taxable (awaiting management allocation)', 'componentType' => 'UNALLOCATED', 'category' => 'UNALLOCATED', 'role' => 'SUBSET', 'ledgerAccount' => 'UNALLOCATED', 'amount' => '89.00', 'isTaxable' => false, 'province' => null],
                ],
            ],
            'PRIVATE_VEHICLE_RESCUE' => [
                'code' => 'PRIVATE_VEHICLE_RESCUE',
                'name' => 'Private Vehicle Rescue',
                'productType' => 'PRIVATE_VEHICLE_RESCUE',
                'vehicleType' => 'PRIVATE_VEHICLE',
                'billingFrequency' => 'MONTHLY',
                'baseFee' => '40.00',
                'totalFee' => self::PRIVATE_TOTAL,
                'currency' => 'USD',
                'provinces' => ['HAUT_KATANGA', 'LUALABA'],
                'rules' => [
                    ['key' => 'OP_COST', 'name' => 'Operating Cost', 'componentType' => 'OPERATING_COST', 'category' => 'OPERATING_COST', 'role' => 'CHARGEABLE', 'ledgerAccount' => 'OPERATING_COST', 'amount' => '40.00', 'isTaxable' => false, 'province' => null],
                    ['key' => 'TAXABLE', 'name' => 'Taxable (container of DGI + PDC + profit)', 'componentType' => 'TAXABLE', 'category' => 'TAXABLE', 'role' => 'CHARGEABLE', 'ledgerAccount' => 'TAX_REVENUE', 'amount' => '40.00', 'isTaxable' => true, 'province' => null],
                    ['key' => 'DGI_TAX', 'name' => 'DGI Tax (subset of Taxable)', 'componentType' => 'DGI_TAX', 'category' => 'TAX', 'role' => 'SUBSET', 'ledgerAccount' => 'TAX_REVENUE', 'amount' => '12.00', 'isTaxable' => true, 'province' => null],
                    ['key' => 'PDC_TAX', 'name' => 'PDC Tax (subset of Taxable)', 'componentType' => 'PDC_TAX', 'category' => 'PDC', 'role' => 'SUBSET', 'ledgerAccount' => 'PDC_PAYABLE', 'amount' => '8.00', 'isTaxable' => false, 'province' => null],
                    ['key' => 'PROFIT', 'name' => 'Profit (subset of Taxable)', 'componentType' => 'PROFIT', 'category' => 'PROFIT', 'role' => 'SUBSET', 'ledgerAccount' => 'PROFIT_REVENUE', 'amount' => '20.00', 'isTaxable' => false, 'province' => null],
                ],
            ],
        ];
    }

    /**
     * Resolve a user supplied product code to its canonical catalog key.
     * Accepts the canonical codes plus the short forms used in the UI
     * ("TRUCK", "PRIVATE", "PRIVATE_VEHICLE"). Returns null when unknown.
     */
    public static function resolveProduct(string $code): ?string
    {
        $normalized = strtoupper(trim($code));
        $aliases = [
            'TRUCK' => 'TRUCK_RESCUE',
            'TRUCK_RESCUE' => 'TRUCK_RESCUE',
            'PRIVATE' => 'PRIVATE_VEHICLE_RESCUE',
            'PRIVATE_VEHICLE' => 'PRIVATE_VEHICLE_RESCUE',
            'PRIVATE_VEHICLE_RESCUE' => 'PRIVATE_VEHICLE_RESCUE',
        ];
        $resolved = $aliases[$normalized] ?? null;

        return $resolved !== null && isset(self::catalog()[$resolved]) ? $resolved : null;
    }

    /**
     * Chargeable lines of a product: the lines that reconcile to the product
     * total and that are allocated against a payment.
     *
     * @return list<array{key:string,name:string,amount:string}>
     */
    public static function chargeableBreakdown(string $productCode): array
    {
        return array_map(
            static fn (array $rule): array => ['key' => $rule['key'], 'name' => $rule['name'], 'amount' => $rule['amount']],
            self::rules($productCode, 'CHARGEABLE')
        );
    }

    /**
     * Catalog rules of one product, optionally filtered by allocation role
     * (CHARGEABLE | SUBSET).
     *
     * @return list<array{key:string,name:string,componentType:string,category:string,role:string,ledgerAccount:string,amount:string,isTaxable:bool,province:?string}>
     */
    public static function rules(string $productCode, ?string $role = null): array
    {
        $product = self::catalog()[$productCode] ?? null;
        if ($product === null) {
            return [];
        }
        $rules = $product['rules'];
        if ($role === null) {
            return $rules;
        }

        return array_values(array_filter($rules, static fn (array $rule): bool => $rule['role'] === $role));
    }

    /** Catalog total for a product (0.00 when the product is unknown). */
    public static function totalFor(string $productCode): string
    {
        return self::catalog()[$productCode]['totalFee'] ?? '0.00';
    }

    /** Sum of the SUBSET lines; must equal the taxable container of the product. */
    public static function subsetTotal(string $productCode): string
    {
        return self::total(array_map(
            static fn (array $rule): array => ['amount' => $rule['amount']],
            self::rules($productCode, 'SUBSET')
        ));
    }

    /** Taxable container amount declared on the CHARGEABLE lines of a product. */
    public static function taxableContainer(string $productCode): string
    {
        $taxable = array_values(array_filter(
            self::rules($productCode, 'CHARGEABLE'),
            static fn (array $rule): bool => $rule['isTaxable'] === true
        ));

        return self::total(array_map(static fn (array $rule): array => ['amount' => $rule['amount']], $taxable));
    }

    /** Exact decimal sum of a breakdown (bcmath, scale 2). */
    public static function total(array $breakdown): string
    {
        $sum = '0.00';
        foreach ($breakdown as $row) {
            $sum = bcadd($sum, (string) $row['amount'], 2);
        }
        return $sum;
    }

    public static function reconciles(array $breakdown, string $expected): bool
    {
        return bccomp(self::total($breakdown), $expected, 2) === 0;
    }
}

