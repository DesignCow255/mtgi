<?php

declare(strict_types=1);

namespace Mamore\Core;

use Mamore\Auth\AuthException;
use PDO;
use Throwable;

/**
 * Append-only audit trail (risk register item 7).
 *
 * Every mutation funnels through write() so the row always carries the full
 * forensic set: actor, the actor's role FROZEN at write time (a later role
 * change must not rewrite history), session, action, entity + id, previous and
 * new data, IP, user agent, request id, metadata and the server timestamp.
 *
 * There is deliberately no update() and no delete(): audit rows are evidence.
 * The Router only exposes GET/POST, so no HTTP verb can reach an UPDATE or
 * DELETE against this table, and finance rows are never editable from the UI.
 */
final class AuditLog
{
    public function __construct(private readonly PDO $database) {}

    /**
     * Append one audit row.
     *
     * @param array<string,mixed>|null $actor    row as returned by AuthService::authenticate()
     * @param array<string,mixed>|null $previous state before the change
     * @param array<string,mixed>|null $new      state after the change
     * @param array<string,mixed>|null $metadata extra context (source, reason)
     *
     * @return string the request id, so one operation can be correlated
     */
    public function write(
        string $action,
        string $entityType,
        ?string $entityId,
        ?array $actor = null,
        ?Request $request = null,
        ?array $previous = null,
        ?array $new = null,
        ?array $metadata = null,
    ): string {
        $requestId = Uuid::v4();
        $actorId = is_string($actor['id'] ?? null) && $actor['id'] !== '' ? $actor['id'] : null;
        $actorRole = is_string($actor['role_code'] ?? null) && $actor['role_code'] !== '' ? $actor['role_code'] : null;
        $sessionId = is_string($actor['session_id'] ?? null) && $actor['session_id'] !== '' ? $actor['session_id'] : null;

        $this->database->prepare(<<<'SQL'
            INSERT INTO audit_logs
                (actor_user_id, actor_role, session_id, action, entity_type, entity_id, request_id,
                 ip_address, user_agent, previous_data, new_data, metadata)
            VALUES
                (:actor, :actorRole, :session, :action, :entityType, :entityId, :requestId,
                 :ip, :agent, :previous, :new, :metadata)
            SQL)->execute([
            'actor' => $actorId,
            'actorRole' => $actorRole,
            'session' => $sessionId,
            'action' => $action,
            'entityType' => $entityType,
            'entityId' => $entityId,
            'requestId' => $requestId,
            'ip' => $request?->ipAddress,
            'agent' => $this->truncate($request?->userAgent, 500),
            'previous' => $previous === null ? null : $this->encode($previous),
            'new' => $new === null ? null : $this->encode($new),
            'metadata' => $metadata === null ? null : $this->encode($metadata),
        ]);

        return $requestId;
    }

    /**
     * Read the trail. Filters: entityType, entityId, actorId, action,
     * from / to (Y-m-d or Y-m-d H:i:s), limit.
     *
     * @param array<string,mixed> $filters
     * @return list<array<string,mixed>>
     */
    public function list(array $filters = []): array
    {
        $where = [];
        $params = [];
        if (($filters['entityType'] ?? '') !== '') {
            $where[] = 'a.entity_type = :entityType';
            $params['entityType'] = (string) $filters['entityType'];
        }
        if (($filters['entityId'] ?? '') !== '') {
            $where[] = 'a.entity_id = :entityId';
            $params['entityId'] = (string) $filters['entityId'];
        }
        if (($filters['actorId'] ?? '') !== '') {
            $where[] = 'a.actor_user_id = :actorId';
            $params['actorId'] = (string) $filters['actorId'];
        }
        if (($filters['action'] ?? '') !== '') {
            $where[] = 'a.action = :action';
            $params['action'] = strtoupper((string) $filters['action']);
        }
        foreach (['from' => '>=', 'to' => '<='] as $key => $operator) {
            $value = trim((string) ($filters[$key] ?? ''));
            if ($value === '') {
                continue;
            }
            $where[] = "a.occurred_at {$operator} :{$key}";
            $params[$key] = $this->boundary($value, $key, $operator);
        }
        $limit = $this->pageSize($filters['limit'] ?? null);

        $sql = 'SELECT a.*, u.email AS actor_email FROM audit_logs a
                LEFT JOIN users u ON u.id = a.actor_user_id';
        if ($where !== []) {
            $sql .= ' WHERE ' . implode(' AND ', $where);
        }
        $sql .= ' ORDER BY a.occurred_at DESC, a.id DESC LIMIT ' . $limit;

        $statement = $this->database->prepare($sql);
        $statement->execute($params);

        return array_map([$this, 'hydrate'], $statement->fetchAll());
    }

    /** Total number of audit rows recorded for one entity (used in tests). */
    public function countFor(string $entityType, string $entityId): int
    {
        $statement = $this->database->prepare(
            'SELECT COUNT(*) FROM audit_logs WHERE entity_type = :entityType AND entity_id = :entityId'
        );
        $statement->execute(['entityType' => $entityType, 'entityId' => $entityId]);

        return (int) $statement->fetchColumn();
    }

    /** @return array<string,mixed> */
    private function hydrate(array $row): array
    {
        return [
            'id' => (int) $row['id'],
            'action' => $row['action'],
            'entityType' => $row['entity_type'],
            'entityId' => $row['entity_id'],
            'actorUserId' => $row['actor_user_id'],
            'actorRole' => $row['actor_role'],
            'actorEmail' => $row['actor_email'] ?? null,
            'sessionId' => $row['session_id'],
            'requestId' => $row['request_id'],
            'ipAddress' => $row['ip_address'],
            'userAgent' => $row['user_agent'],
            'previousData' => $this->decode($row['previous_data']),
            'newData' => $this->decode($row['new_data']),
            'metadata' => $this->decode($row['metadata']),
            'occurredAt' => $row['occurred_at'],
        ];
    }

    /**
     * Clamp the page size, refusing values that are not a number.
     *
     * (int) 'abc' is 0 and max(0, 1) is 1, so an unparseable limit used to
     * return a single row with no error at all. A forensic reader that quietly
     * answers the wrong question is worse than one that refuses to answer.
     */
    private function pageSize(mixed $value): int
    {
        if ($value === null || $value === '') {
            return 50;
        }
        if (!is_numeric($value)) {
            throw new AuthException("Filter 'limit' must be a number.", 422);
        }

        return min(max((int) $value, 1), 200);
    }

    /**
     * Resolve a timeline filter bound.
     *
     * A date-only upper bound covers the whole day: asking for "to = today"
     * must not silently mean "up to midnight this morning".
     *
     * occurred_at is TIMESTAMP(6), so an inclusive bound has to reach the last
     * microsecond of its final second. Ending at 23:59:59 dropped the final
     * 999999/1000th of the day - including any event recorded in that second -
     * which is exactly the kind of "the ledger lost the last event" bug an audit
     * reader must not have.
     */
    private function boundary(string $value, string $key, string $operator): string
    {
        $timezone = new \DateTimeZone('UTC');
        $inclusive = $operator === '<=';

        $day = $this->exactMoment('!Y-m-d', $value, $timezone);
        $moment = $day ?? $this->exactMoment('!Y-m-d H:i:s', $value, $timezone);
        if (!$moment instanceof \DateTimeImmutable) {
            throw new AuthException("Filter '{$key}' must be a date (YYYY-MM-DD) or timestamp (YYYY-MM-DD HH:MM:SS).", 422);
        }

        // A date-only bound covers the whole day: 00:00:00.000000 from the
        // start, 23:59:59.999999 at the end. An explicit timestamp is taken
        // literally, and either way an inclusive bound ends on the last
        // microsecond of its second, never on the second itself.
        if ($day instanceof \DateTimeImmutable) {
            $moment = $day->setTime($inclusive ? 23 : 0, $inclusive ? 59 : 0, $inclusive ? 59 : 0);
        }

        return $moment->setTime(
            (int) $moment->format('H'),
            (int) $moment->format('i'),
            (int) $moment->format('s'),
            $inclusive ? 999999 : 0
        )->format('Y-m-d H:i:s.u');
    }

    /**
     * Parse a filter bound only when it is exactly the requested format.
     *
     * createFromFormat() does not fail on every input it does not understand.
     * An out-of-range date comes back as a perfectly valid object that has
     * silently rolled over - '2026-13-45' becomes 2027-02-14 - so without the
     * round-trip check a typo becomes a filter for a completely different day
     * and the audit reader answers a question nobody asked.
     */
    private function exactMoment(string $format, string $value, \DateTimeZone $timezone): ?\DateTimeImmutable
    {
        $parsed = \DateTimeImmutable::createFromFormat($format, $value, $timezone);
        if (!$parsed instanceof \DateTimeImmutable) {
            return null;
        }

        // Compare without the leading "!": that prefix only resets unparsed
        // fields, and format() echoes it back as a literal character.
        $echo = ltrim($format, '!');

        return $parsed->format($echo) === $value ? $parsed : null;
    }

    /** @param array<string,mixed> $data */
    private function encode(array $data): string
    {
        try {
            return json_encode($data, JSON_THROW_ON_ERROR | JSON_UNESCAPED_SLASHES);
        } catch (Throwable $error) {
            // An audit row must never be lost because a payload had bad bytes.
            return json_encode(['unserialisable' => $error->getMessage()], JSON_THROW_ON_ERROR);
        }
    }

    private function decode(mixed $value): ?array
    {
        if (!is_string($value) || $value === '') {
            return null;
        }
        $decoded = json_decode($value, true);

        return is_array($decoded) ? $decoded : null;
    }

    private function truncate(?string $value, int $length): ?string
    {
        $value = $value === null ? '' : trim($value);

        return $value === '' ? null : mb_substr($value, 0, $length);
    }
}
