<?php

declare(strict_types=1);

namespace Mamore\Core;

use PDO;

final class Database
{
    private static ?PDO $connection = null;

    public static function connection(): PDO
    {
        if (self::$connection instanceof PDO) {
            return self::$connection;
        }

        $charset = Env::get('DB_CHARSET', 'utf8mb4');
        $dsn = sprintf(
            'mysql:host=%s;port=%s;dbname=%s;charset=%s',
            Env::get('DB_HOST', '127.0.0.1'),
            Env::get('DB_PORT', '3306'),
            Env::get('DB_DATABASE'),
            $charset
        );

        self::$connection = new PDO($dsn, Env::get('DB_USERNAME'), Env::get('DB_PASSWORD'), [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES => false,
        ]);
        // MySQL TIMESTAMP values are session-timezone aware. Keep the
        // persistence boundary in UTC so application and database host
        // timezones cannot make newly-issued sessions appear expired.
        self::$connection->exec("SET time_zone = '+00:00'");

        return self::$connection;
    }
}
