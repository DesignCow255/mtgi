<?php

declare(strict_types=1);

namespace Mamore\Core;

final class Application
{
    public function __construct(
        private readonly Router $router = new Router(),
    ) {
    }

    public function router(): Router
    {
        return $this->router;
    }

    public function handle(Request $request): array
    {
        return $this->router->dispatch(
            $request->method,
            $request->uri,
            $request->body,
            $request->headers,
            $request->ipAddress,
            $request->userAgent
        );
    }
}
