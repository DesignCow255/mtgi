<?php

declare(strict_types=1);

namespace Mamore\Core;

/**
 * Prepares the single-page shell for the mount point it is served from.
 *
 * app.html ships with web-root-absolute references ("/assets/app.css"), which
 * is correct when public/ is the document root but points outside the app when
 * it is served from a sub-directory such as /mtgi. Two things are therefore
 * rewritten on the way out:
 *
 *   - the asset references, which are re-rooted onto the mount point;
 *   - a <meta name="mamore-base"> tag the bundles read to prefix their own
 *     fetch() calls. It is a meta tag rather than an inline <script> because
 *     the CSP this app sends is script-src 'self' with no 'unsafe-inline', so
 *     an injected script block would be blocked.
 *
 * On a web-root install the base is empty and the document is returned
 * untouched, so the shell still boots exactly as before.
 */
final class AppShell
{
    public static function render(string $html): string
    {
        $base = Url::base();
        if ($base === '') {
            return self::applyTheme($html);
        }

        $html = str_replace(
            ['href="/', 'src="/'],
            ['href="' . $base . '/', 'src="' . $base . '/'],
            $html
        );

        $html = str_replace(
            '<head>',
            '<head>' . "\n    " . '<meta name="mamore-base" content="' . View::esc($base) . '">',
            $html
        );

        return self::applyTheme($html);
    }

    /**
     * Write the resolved theme onto <html> before the document is sent.
     *
     * The Content-Security-Policy this application sends is `script-src 'self'`
     * with no 'unsafe-inline', so the conventional "tiny inline script in <head>
     * that reads localStorage and sets a theme class" cannot be used: it would
     * be blocked. Deciding the theme on the server and shipping it as an
     * attribute of the very first element removes the possibility of a flash
     * instead of trying to hide one.
     *
     * @see Theme for the resolution order (explicit choice, then stored
     *      preference, then the operating system).
     */
    private static function applyTheme(string $html): string
    {
        $theme = (new Theme(new Request('GET', (string) ($_SERVER['REQUEST_URI'] ?? '/'))))->resolved();

        return preg_replace(
            '/<html\b(?![^>]*\bdata-theme=)/i',
            '<html data-theme="' . View::esc($theme) . '"',
            $html,
            1
        ) ?? $html;
    }
}
