<?php

declare(strict_types=1);

namespace Mamore\Core;

final class Request
{
    public function __construct(
        public readonly string $method,
        public readonly string $uri,
        public readonly array $body = [],
        public readonly array $headers = [],
        public readonly ?string $ipAddress = null,
        public readonly ?string $userAgent = null,
    ) {
    }

    public static function capture(): self
    {
        $raw = file_get_contents('php://input');
        $body = [];
        if (is_string($raw) && $raw !== '') {
            $decoded = json_decode($raw, true);
            $body = is_array($decoded) ? $decoded : [];
        }

        $headers = [];
        foreach ($_SERVER as $key => $value) {
            if (str_starts_with($key, 'HTTP_')) {
                $headers[strtolower(str_replace('_', '-', substr($key, 5)))] = (string) $value;
            }
        }

        // Some SAPIs (notably PHP-FPM/FastCGI behind Apache, which is how MAMP
        // runs this app) never expose the Authorization header as
        // HTTP_AUTHORIZATION, and getallheaders() omits it too. Apache's
        // mod_rewrite leaves it behind under the REDIRECT_ prefix instead, so
        // the bearer token would otherwise be invisible and every authenticated
        // request would be rejected. Normalise it onto the name the app looks
        // for, preferring whichever source actually carries a value.
        $authorization = '';
        foreach ([$headers['authorization'] ?? '', $_SERVER['REDIRECT_HTTP_AUTHORIZATION'] ?? '', $_SERVER['HTTP_AUTHORIZATION'] ?? ''] as $candidate) {
            if (is_string($candidate) && $candidate !== '') {
                $authorization = $candidate;
                break;
            }
        }
        $headers['authorization'] = $authorization;

        return new self(
            strtoupper($_SERVER['REQUEST_METHOD'] ?? 'GET'),
            // The router registers "/api/...", so the mount point the request
            // arrived through has to come off before the path is compared.
            Url::strip($_SERVER['REQUEST_URI'] ?? '/'),
            $body,
            $headers,
            $_SERVER['REMOTE_ADDR'] ?? null,
            $_SERVER['HTTP_USER_AGENT'] ?? null,
        );
    }

    public function bearerToken(): ?string
    {
        $authorization = $this->headers['authorization'] ?? '';
        return str_starts_with($authorization, 'Bearer ') ? substr($authorization, 7) : null;
    }
}
