<?php

declare(strict_types=1);

namespace Mamore\Core;

final class View
{
    public static function render(string $template, array $data = []): string
    {
        $file = dirname(__DIR__, 2) . '/resources/views/' . ltrim($template, '/');
        if (!is_file($file)) {
            return '<p>View not found.</p>';
        }
        extract($data, EXTR_SKIP);
        ob_start();
        require $file;
        return (string) ob_get_clean();
    }

    public static function esc(mixed $value): string
    {
        return htmlspecialchars((string) $value, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
    }
}
