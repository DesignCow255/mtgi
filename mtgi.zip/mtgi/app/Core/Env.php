<?php

declare(strict_types=1);

namespace Mamore\Core;

use RuntimeException;

final class Env
{
    public static function load(string $path): void
    {
        if (!is_file($path)) {
            return;
        }

        foreach (file($path, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES) ?: [] as $line) {
            $line = trim($line);
            if ($line === '' || str_starts_with($line, '#') || !str_contains($line, '=')) {
                continue;
            }

            [$key, $value] = array_map('trim', explode('=', $line, 2));
            $value = trim($value, "\"'");
            if ($key !== '' && getenv($key) === false) {
                putenv("{$key}={$value}");
                $_ENV[$key] = $value;
            }
        }
    }

    public static function get(string $key, ?string $default = null): string
    {
        $value = getenv($key);
        return $value === false ? (string) $default : $value;
    }

    public static function validateProduction(): void
    {
        if (self::get('APP_ENV', 'local') !== 'production') {
            return;
        }

        $required = ['APP_URL', 'DB_HOST', 'DB_DATABASE', 'DB_USERNAME', 'DB_PASSWORD'];
        $missing = array_values(array_filter($required, static fn (string $key): bool => self::get($key) === ''));
        if ($missing !== []) {
            throw new RuntimeException('Missing production environment variables: ' . implode(', ', $missing));
        }
    }
}
