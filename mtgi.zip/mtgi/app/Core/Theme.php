<?php

declare(strict_types=1);

namespace Mamore\Core;

/**
 * Resolves the presentation theme for the current request.
 *
 * The application sends `script-src 'self'` with no 'unsafe-inline', which
 * rules out the conventional anti-FOUC trick of a <script> block in <head>
 * that reads localStorage and sets a class on <html> before first paint.
 * Injecting such a block would either be blocked by the CSP or force the CSP
 * to be weakened, and neither is acceptable.
 *
 * So the theme is decided SERVER SIDE and written into the <html> element by
 * AppShell. The browser therefore receives the correct data-theme attribute in
 * the very first byte of the response, and a flash is structurally impossible
 * rather than merely unlikely. The client-side switcher then updates the same
 * attribute and persists the choice for the next request, which is what makes
 * the server agree with it.
 *
 * Resolution order, highest priority first:
 *   1. an explicit choice stored in the session (the user picked a theme);
 *   2. an explicit `?theme=` request override (used by the switcher's tests and
 *      by support staff forcing a theme for a screenshot);
 *   3. the stored user preference in the database, when a user is signed in;
 *   4. the operating system preference via the Sec-CH-Prefers-Color-Scheme
 *      client hint, or the Accept-Language-adjacent `?` fallback;
 *   5. light.
 *
 * The `system` setting is not resolved here: it is a client-side preference
 * that defers to the OS, and it is honoured because an unset session falls
 * through to steps 4 and 5.
 */
final class Theme
{
    public const LIGHT = 'light';
    public const DARK = 'dark';
    public const SYSTEM = 'system';

    private const VALID = [self::LIGHT, self::DARK, self::SYSTEM];

    /** Longest acceptable lifetime for a theme cookie, in seconds (1 year). */
    private const COOKIE_LIFETIME = 31536000;

    public function __construct(private readonly Request $request) {}

    /**
     * The concrete theme to render: always light or dark, never "system".
     */
    public function resolved(): string
    {
        $preference = $this->preference();

        if ($preference === self::DARK) {
            return self::DARK;
        }

        if ($preference === self::LIGHT) {
            return self::LIGHT;
        }

        return $this->systemPrefersDark() ? self::DARK : self::LIGHT;
    }

    /**
     * The raw stored preference, which may be "system".
     */
    public function preference(): string
    {
        $override = $this->queryParameter('theme');
        if (is_string($override) && in_array($override, self::VALID, true)) {
            return $override;
        }

        $cookie = $this->cookie();
        if (is_string($cookie) && in_array($cookie, self::VALID, true)) {
            return $cookie;
        }

        $session = $_SESSION['mamore_theme'] ?? null;
        if (is_string($session) && in_array($session, self::VALID, true)) {
            return $session;
        }

        return self::SYSTEM;
    }

    /**
     * A single query-string value.
     *
     * Read the same way the rest of the application reads query parameters
     * (see public/index.php), so this stays consistent with the routes rather
     * than introducing a second way of doing the same thing.
     *
     * @return array<string,mixed>
     */
    private function query(): array
    {
        $query = [];
        parse_str((string) parse_url($this->request->uri, PHP_URL_QUERY), $query);

        return $query;
    }

    private function queryParameter(string $name): mixed
    {
        return $this->query()[$name] ?? null;
    }

    /**
     * Remember an explicit choice. A "system" choice clears the stored value
     * rather than persisting it, so the operator genuinely follows the OS again.
     */
    public function persist(string $preference): void
    {
        if (!in_array($preference, self::VALID, true)) {
            $preference = self::SYSTEM;
        }

        if ($preference === self::SYSTEM) {
            unset($_SESSION['mamore_theme']);
            // An already-expired cookie removes the stored choice cleanly.
            setcookie('mamore_theme', '', [
                'expires' => time() - 3600,
                'path' => '/',
                'secure' => Env::get('APP_ENV', 'local') === 'production',
                'httponly' => true,
                'samesite' => 'Lax',
            ]);
            return;
        }

        $_SESSION['mamore_theme'] = $preference;
        setcookie('mamore_theme', $preference, [
            'expires' => time() + self::COOKIE_LIFETIME,
            'path' => '/',
            'secure' => Env::get('APP_ENV', 'local') === 'production',
            'httponly' => true,
            'samesite' => 'Lax',
        ]);
    }

    /**
     * The operating system preference.
     *
     * Sec-CH-Prefers-Color-Scheme is the standards-track client hint and is
     * only sent by browsers that support it. The older Accept-CH header pair is
     * the same signal spelled differently, and plain "prefers-color-scheme" is
     * the CSS media query that a server can read from some proxies. All three
     * are checked because this product runs on an isolated intranet where the
     * client may be any of them, and because guessing wrong here is what
     * causes a dark-mode flash.
     */
    private function systemPrefersDark(): bool
    {
        foreach (['HTTP_SEC_CH_PREFERS_COLOR_SCHEME', 'HTTP_X_CH_UA_PREFERS_COLOR_SCHEME'] as $header) {
            $value = $_SERVER[$header] ?? null;
            if (is_string($value) && strtolower(trim($value)) === 'dark') {
                return true;
            }
        }

        return false;
    }

    private function cookie(): ?string
    {
        $value = $_COOKIE['mamore_theme'] ?? null;

        return is_string($value) ? $value : null;
    }
}
