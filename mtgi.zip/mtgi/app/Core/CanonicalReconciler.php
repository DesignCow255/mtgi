<?php

declare(strict_types=1);

namespace Mamore\Core;

use PDO;

/**
 * Reconciles the canonical identity, vehicle, organization and location rows with
 * domain rows that were created after the migration ran.
 *
 * A migration can only backfill what exists at the moment it runs. Data written
 * afterwards - by the seeder, by an operator, by a legacy import - still needs a
 * canonical row, or a domain would quietly own a vehicle that the shared core
 * cannot see. Every statement here is idempotent (`WHERE NOT EXISTS`), so this
 * is safe to run repeatedly and safe to run on a large table in one pass.
 */
final class CanonicalReconciler
{
    public function __construct(private readonly PDO $database) {}

    /**
     * @return array{persons:int,organizations:int,vehicles:int,locations:int,links:int}
     */
    public function reconcile(): array
    {
        $result = [
            'persons' => $this->persons(),
            'mergedPersons' => $this->mergeDuplicatePersons(),
            'organizations' => $this->organizations(),
            'vehicles' => $this->vehicles(),
            'locations' => $this->locations(),
            'links' => $this->links(),
        ];

        return $result + [
            'duplicatePersons' => $this->duplicatePersonCount(),
            'vehicleConflicts' => $this->vehicleConflicts(),
        ];
    }

    /**
     * One canonical person per human.
     *
     * Identity is matched, not just id: a person that already exists with the
     * same email or phone is reused, because legacy data carries the same human
     * in two id spaces (an account and a membership). Creating a second row here
     * would be the exact fragmentation this core exists to remove.
     */
    private function persons(): int
    {
        // An account becomes a person unless that human is already known.
        $this->database->exec(<<<'SQL'
            INSERT INTO persons (id, first_name, last_name, email, phone, status, created_at, updated_at)
            SELECT u.id, u.first_name, u.last_name, u.email, u.phone, 'ACTIVE', u.created_at, u.updated_at
            FROM users u
            WHERE u.deleted_at IS NULL
              AND NOT EXISTS (SELECT 1 FROM persons p WHERE p.id = u.id)
              AND NOT EXISTS (
                    SELECT 1 FROM persons p
                    WHERE (u.email IS NOT NULL AND p.email = u.email)
                       OR (u.phone IS NOT NULL AND p.phone = u.phone))
            SQL);

        // An account joins an existing person when the identity matches.
        $this->database->exec(<<<'SQL'
            UPDATE users u
            JOIN persons p ON (u.email IS NOT NULL AND p.email = u.email) OR (u.phone IS NOT NULL AND p.phone = u.phone)
            SET u.person_id = p.id
            WHERE u.person_id IS NULL
            SQL);

        // A membership becomes a person only when no person matches by id, email or phone.
        $this->database->exec(<<<'SQL'
            INSERT INTO persons (id, first_name, last_name, email, phone, alternative_phone, national_id,
                                 passport_number, photo_url, status, created_at, updated_at)
            SELECT s.id, s.first_name, s.last_name, s.email, s.phone, s.alternative_phone, s.national_id,
                   s.passport_number, s.photo_url, 'ACTIVE', s.created_at, s.updated_at
            FROM subscribers s
            WHERE s.deleted_at IS NULL
              AND NOT EXISTS (SELECT 1 FROM persons p WHERE p.id = s.id)
              AND NOT EXISTS (
                    SELECT 1 FROM persons p
                    WHERE (s.email IS NOT NULL AND p.email = s.email)
                       OR (s.phone IS NOT NULL AND p.phone = s.phone)
                       OR (s.national_id IS NOT NULL AND s.national_id <> '' AND p.national_id = s.national_id))
            SQL);

        // Then every membership points at its canonical person: by id, by identity, or through the account.
        $this->database->exec(<<<'SQL'
            UPDATE subscribers s
            JOIN persons p ON p.id = s.id
            SET s.person_id = p.id
            WHERE s.person_id IS NULL
            SQL);
        $this->database->exec(<<<'SQL'
            UPDATE subscribers s
            JOIN persons p ON (s.email IS NOT NULL AND p.email = s.email) OR (s.phone IS NOT NULL AND p.phone = s.phone)
            SET s.person_id = p.id
            WHERE s.person_id IS NULL
            SQL);
        $this->database->exec(<<<'SQL'
            UPDATE subscribers s
            LEFT JOIN users u ON u.subscriber_id = s.id
            SET s.person_id = COALESCE(u.person_id, s.id)
            WHERE s.person_id IS NULL
              AND EXISTS (SELECT 1 FROM persons p WHERE p.id = COALESCE(u.person_id, s.id))
            SQL);

        return (int) $this->database->query('SELECT COUNT(*) FROM persons')->fetchColumn();
    }

    /**
     * Merge person rows that describe the same human.
     *
     * Legacy data carries one human in two id spaces, so reconciliation can end
     * up with two rows for one identity. References are repointed to the
     * surviving row before it is removed, so nothing is orphaned and no history
     * is rewritten - the duplicate is deleted, the canonical record is kept.
     *
     * @return int number of merged rows
     */
    private function mergeDuplicatePersons(): int
    {
        $duplicates = $this->database->query(<<<'SQL'
            SELECT p.id AS duplicate_id, k.id AS keeper_id
            FROM persons p
            JOIN persons k
              ON k.id <> p.id
             AND (
                 (p.email IS NOT NULL AND p.email <> '' AND k.email = p.email)
                 OR (p.phone IS NOT NULL AND p.phone <> '' AND k.phone = p.phone)
             )
            WHERE p.id > k.id
            SQL)->fetchAll();

        foreach ($duplicates as $pair) {
            $this->database->beginTransaction();
            try {
                $this->database->prepare('UPDATE users SET person_id = :keeper WHERE person_id = :duplicate')
                    ->execute(['keeper' => $pair['keeper_id'], 'duplicate' => $pair['duplicate_id']]);
                $this->database->prepare('UPDATE subscribers SET person_id = :keeper WHERE person_id = :duplicate')
                    ->execute(['keeper' => $pair['keeper_id'], 'duplicate' => $pair['duplicate_id']]);
                // Only merge the fields the keeper does not already have.
                // Read the duplicate's values first: an UPDATE cannot read its own
                // target table in a subquery.
                $read = $this->database->prepare(
                    'SELECT email, phone, national_id, passport_number FROM persons WHERE id = :id'
                );
                $read->execute(['id' => $pair['duplicate_id']]);
                $incoming = $read->fetch() ?: [];
                $this->database->prepare(<<<'SQL'
                    UPDATE persons SET
                        email = COALESCE(email, :email),
                        phone = COALESCE(phone, :phone),
                        national_id = COALESCE(national_id, :nationalId),
                        passport_number = COALESCE(passport_number, :passport)
                    WHERE id = :keeper
                    SQL)->execute([
                    'email' => $incoming['email'] ?? null,
                    'phone' => $incoming['phone'] ?? null,
                    'nationalId' => $incoming['national_id'] ?? null,
                    'passport' => $incoming['passport_number'] ?? null,
                    'keeper' => $pair['keeper_id'],
                ]);
                $this->database->prepare('DELETE FROM persons WHERE id = :id')->execute(['id' => $pair['duplicate_id']]);
                $this->database->commit();
            } catch (\Throwable $error) {
                if ($this->database->inTransaction()) {
                    $this->database->rollBack();
                }
                throw $error;
            }
        }

        return count($duplicates);
    }

    private function duplicatePersonCount(): int
    {
        return (int) $this->database->query(<<<'SQL'
            SELECT COUNT(*) FROM (
                SELECT p.email FROM persons p WHERE p.email IS NOT NULL AND p.email <> ''
                GROUP BY p.email HAVING COUNT(*) > 1
            ) d
            SQL)->fetchColumn();
    }

    /** One canonical organization per Smart Bus operator, and links for both. */
    private function organizations(): int
    {
        $this->database->exec(<<<'SQL'
            INSERT INTO organizations (id, name, organization_type, country_code, status, created_at)
            SELECT o.id, o.name, 'TRANSPORT_OPERATOR', 'CD', 'ACTIVE', o.created_at
            FROM smartbus_operators o
            WHERE NOT EXISTS (SELECT 1 FROM organizations g WHERE g.id = o.id)
            SQL);

        return $this->database->exec(
            'UPDATE smartbus_operators SET organization_id = id WHERE organization_id IS NULL'
        ) === false ? 0 : 1;
    }

    /**
     * One canonical vehicle per bus, rescue unit and subscriber vehicle.
     *
     * The rescue unit registration falls back to a derived value when the unit
     * code is already taken by another vehicle, so a shared code can never
     * abort a reconciliation.
     */
    private function vehicles(): int
    {
        $this->database->exec(<<<'SQL'
            INSERT INTO vehicles (id, vehicle_type, registration_number, country_of_registration, chassis_number,
                                  engine_number, make, model, year, tracking_enabled, status, created_at)
            SELECT v.id, 'BUS', v.registration_number, 'CD',
                   (SELECT sv.chassis_no FROM subscriber_vehicles sv WHERE sv.plate_number = v.registration_number ORDER BY sv.created_at LIMIT 1),
                   (SELECT sv.engine_no FROM subscriber_vehicles sv WHERE sv.plate_number = v.registration_number ORDER BY sv.created_at LIMIT 1),
                   v.make, v.model, v.year, v.gps_enabled, v.status, v.created_at
            FROM smartbus_vehicles v
            WHERE NOT EXISTS (SELECT 1 FROM vehicles c WHERE c.id = v.id)
              AND NOT EXISTS (SELECT 1 FROM vehicles c WHERE c.country_of_registration = 'CD' AND c.registration_number = v.registration_number)
            SQL);

        $this->database->exec(<<<'SQL'
            INSERT INTO vehicles (id, vehicle_type, registration_number, country_of_registration, make, model,
                                  tracking_enabled, status, created_at)
            SELECT u.id, 'RESCUE_VEHICLE',
                   CASE WHEN EXISTS (SELECT 1 FROM vehicles c WHERE c.registration_number = u.code)
                        THEN CONCAT('RU-', SUBSTRING(REPLACE(u.id, '-', ''), 1, 10))
                        ELSE COALESCE(NULLIF(u.code, ''), CONCAT('RU-', SUBSTRING(REPLACE(u.id, '-', ''), 1, 10))) END,
                   'CD', u.base_name, u.unit_type, TRUE, u.status, u.created_at
            FROM rescue_units u
            WHERE NOT EXISTS (SELECT 1 FROM vehicles c WHERE c.id = u.id)
            SQL);

        $this->database->exec(<<<'SQL'
            INSERT INTO vehicles (id, vehicle_type, registration_number, country_of_registration, chassis_number,
                                  engine_number, make, model, year, owner_person_id, status, created_at)
            SELECT sv.id, 'PRIVATE_CAR', sv.plate_number, 'CD', sv.chassis_no, sv.engine_no, sv.vehicle_make,
                   sv.vehicle_model, sv.vehicle_year, COALESCE(u.id, s.id), 'ACTIVE', sv.created_at
            FROM subscriber_vehicles sv
            JOIN subscribers s ON s.id = sv.subscriber_id
            LEFT JOIN users u ON u.subscriber_id = s.id
            WHERE NOT EXISTS (SELECT 1 FROM vehicles c WHERE c.id = sv.id)
              AND NOT EXISTS (SELECT 1 FROM vehicles c WHERE c.country_of_registration = 'CD' AND c.registration_number = sv.plate_number)
            SQL);

        return (int) $this->database->query('SELECT COUNT(*) FROM vehicles')->fetchColumn();
    }

    /** One canonical location per service location and station, originals kept. */
    private function locations(): int
    {
        $this->database->exec(<<<'SQL'
            INSERT INTO locations (id, location_type, name, country_code, region, city, address_text,
                                   latitude, longitude, contact_phone, status, created_at)
            SELECT s.id, s.location_type, s.name, 'CD', s.province, NULL, s.address_text,
                   s.latitude, s.longitude, s.contact_phone, s.status, s.created_at
            FROM service_locations s
            WHERE NOT EXISTS (SELECT 1 FROM locations l WHERE l.id = s.id)
            SQL);

        $this->database->exec(<<<'SQL'
            INSERT INTO locations (id, location_type, name, country_code, region, city, address_text,
                                   latitude, longitude, contact_phone, status, created_at)
            SELECT st.id, 'STATION', st.name, st.country_code, st.province, st.city, st.address_text,
                   st.latitude, st.longitude, st.contact_phone, st.status, st.created_at
            FROM smartbus_stations st
            WHERE NOT EXISTS (SELECT 1 FROM locations l WHERE l.id = st.id)
            SQL);

        $this->database->exec('UPDATE service_locations SET location_id = id WHERE location_id IS NULL');
        $this->database->exec('UPDATE smartbus_stations SET location_id = id WHERE location_id IS NULL');

        return (int) $this->database->query('SELECT COUNT(*) FROM locations')->fetchColumn();
    }

    /**
     * Domain rows that could not be given a canonical vehicle because another
     * vehicle already owns the same registration. These are a data-quality
     * problem for an operator to resolve, so they are counted and reported
     * rather than papered over with an invented registration.
     */
    private function vehicleConflicts(): int
    {
        return (int) $this->database->query(<<<'SQL'
            SELECT (
                (SELECT COUNT(*) FROM smartbus_vehicles v
                  WHERE NOT EXISTS (SELECT 1 FROM vehicles c WHERE c.id = v.id))
              + (SELECT COUNT(*) FROM subscriber_vehicles sv
                  WHERE NOT EXISTS (SELECT 1 FROM vehicles c WHERE c.id = sv.id))
              + (SELECT COUNT(*) FROM rescue_units u
                  WHERE NOT EXISTS (SELECT 1 FROM vehicles c WHERE c.id = u.id))
            ) AS conflicts
            SQL)->fetchColumn();
    }

    /** Point every domain row at its canonical vehicle. */
    private function links(): int
    {
        $count = 0;
        foreach (['smartbus_vehicles', 'rescue_units', 'subscriber_vehicles'] as $table) {
            $this->database->exec(
                "UPDATE {$table} SET vehicle_id = id WHERE vehicle_id IS NULL AND EXISTS (SELECT 1 FROM vehicles v WHERE v.id = {$table}.id)"
            );
            $count += (int) $this->database->query("SELECT COUNT(*) FROM {$table} WHERE vehicle_id IS NOT NULL")->fetchColumn();
        }

        return $count;
    }
}
