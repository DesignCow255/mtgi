<?php

declare(strict_types=1);

namespace Mamore\Core;

use Throwable;

final class ExceptionHandler
{
    public static function handle(Throwable $error): array
    {
        Logger::error($error->getMessage(), ['at' => $error->getFile() . ':' . $error->getLine()]);
        return Response::json(['error' => 'Unexpected server error.'], 500);
    }
}
