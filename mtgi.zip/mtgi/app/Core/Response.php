<?php

declare(strict_types=1);

namespace Mamore\Core;

final class Response
{
    public static function json(array $payload, int $status = 200): array
    {
        return ['status' => $status, 'headers' => ['Content-Type' => 'application/json; charset=utf-8'], 'body' => json_encode($payload, JSON_THROW_ON_ERROR)];
    }

    public static function html(string $body, int $status = 200): array
    {
        return ['status' => $status, 'headers' => ['Content-Type' => 'text/html; charset=utf-8'], 'body' => $body];
    }

    public static function emit(array $response): never
    {
        http_response_code($response['status']);
        header('X-Content-Type-Options: nosniff');
        header('Referrer-Policy: same-origin');
        header('X-Frame-Options: DENY');
        // object-src 'none' and frame-src 'self' are explicit rather than
        // inherited: default-src already covers them, but stating them means a
        // future edit to default-src cannot silently reopen plugin content or
        // third-party frames. Found by bin/preflight.php.
        header("Content-Security-Policy: default-src 'self'; script-src 'self'; style-src 'self'; img-src 'self' data:; connect-src 'self'; object-src 'none'; frame-src 'self'; base-uri 'none'; form-action 'self'; frame-ancestors 'none'");
        foreach ($response['headers'] as $name => $value) {
            header("{$name}: {$value}");
        }
        echo $response['body'];
        exit;
    }
}
