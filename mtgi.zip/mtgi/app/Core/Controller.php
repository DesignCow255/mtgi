<?php

declare(strict_types=1);

namespace Mamore\Core;

abstract class Controller
{
    protected function ok(array $data = [], int $status = 200): array
    {
        return Response::json($data, $status);
    }

    protected function fail(string $message, int $status = 400): array
    {
        return Response::json(['error' => $message], $status);
    }
}
