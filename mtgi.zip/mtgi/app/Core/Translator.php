<?php

declare(strict_types=1);

namespace Mamore\Core;

/**
 * The translation service.
 *
 * Before this existed the product had no localisation at all: `grep` for
 * lang|locale|i18n across app/ returned eleven hits, every one of them the
 * `preferred_language` COLUMN on vip_emergency_profiles. There was no catalogue,
 * no lookup and no fallback, so supporting French and Kiswahili would have meant
 * editing ~180 English literals in app.html plus every template literal in four
 * JS bundles, twice.
 *
 * The rules this enforces, from docs/ui-v2/I18N_ARCHITECTURE.md:
 *
 *  1. A missing key NEVER reaches a user. `t()` falls back to English, and only
 *     then, as a last resort, to the key itself -- which the test fails on.
 *     A raw `nav.rescue` in the sidebar would be worse than English.
 *  2. Fallback is always English, never a raw key.
 *  3. Missing keys are RECORDED, not displayed, so gaps surface in development
 *     instead of in front of an operator.
 *  4. Language is not currency. Separate preferences, separate fallbacks, and a
 *     French speaker reading TZS is a normal, supported case.
 *
 * Pluralisation is a method rather than a ternary, because French and Kiswahili
 * do not pluralise the way English does and a `n !== 1` rule would produce
 * subtly wrong forms that are hard to see and easy to ship.
 */
final class Translator
{
    private static ?self $instance = null;

    public const DEFAULT = 'en';
    public const FALLBACK = 'en';

    /** @var array<string, array<string, mixed>> */
    private array $catalogues = [];

    /** @var list<string> keys requested but not found, for the dev log and the test */
    private array $missing = [];

    private function __construct(
        private string $locale = self::DEFAULT,
        private string $directory = '',
    ) {
    }

    /**
     * The shared translator.
     *
     * Passing a locale here SETS the shared instance's locale rather than
     * returning a differently-configured one. That is deliberate and it is the
     * whole point: PHP has one request, one locale, and a second object holding a
     * different locale is the kind of state that produces a French page with an
     * English footer.
     *
     * Consequence worth knowing: `$a = instance('fr'); instance('en'); $a->t(...)`
     * reads ENGLISH, because $a and the singleton are the same object. Code that
     * needs to compare two locales must use `t($key, [], 'fr')`, whose locale is
     * an explicit argument rather than shared state.
     */
    public static function instance(?string $locale = null, ?string $directory = null): self
    {
        if (self::$instance === null) {
            $root = $directory ?? dirname(__DIR__, 2) . '/resources/lang';
            self::$instance = new self($locale ?? self::DEFAULT, $root);
        } elseif ($locale !== null) {
            self::$instance->setLocale($locale);
        }

        return self::$instance;
    }

    /** Drop the singleton. The tests switch locale repeatedly. */
    public static function reset(): void
    {
        self::$instance = null;
    }

    public function setLocale(string $locale): void
    {
        $this->locale = self::normalise($locale);
    }

    public function locale(): string
    {
        return $this->locale;
    }

    /** @return list<string> */
    public static function supported(): array
    {
        $root = dirname(__DIR__, 2) . '/resources/lang';
        $locales = [];

        foreach (is_dir($root) ? (scandir($root) ?: []) : [] as $entry) {
            if (str_starts_with($entry, '.')) {
                continue;
            }
            if (is_dir($root . '/' . $entry)) {
                $locales[] = $entry;
            }
        }

        sort($locales);

        return $locales;
    }

    public function has(string $key): bool
    {
        return $this->lookup($key) !== null;
    }

    /**
     * Translate a dot-keyed string.
     *
     * `{placeholder}` tokens are replaced positionally, which keeps substitution
     * locale-neutral: the grammar of a sentence containing a number belongs in
     * the catalogue, not in PHP string concatenation.
     *
     * @param array<string, string|int|float> $replace
     */
    public function t(string $key, array $replace = [], ?string $locale = null): string
    {
        $value = $this->lookup($key, $locale);

        if ($value === null) {
            $this->missing[] = $key;
            // Last resort, so a gap is visible rather than blank. The test fails
            // on any key that ever reaches this branch.
            return $key;
        }

        return self::interpolate((string) $value, $replace);
    }

    /**
     * Plural-aware translation.
     *
     * Each locale declares its own rule rather than inheriting an English one.
     * `one` is the singular form, `other` everything else. A locale needing a
     * distinct zero or "few" form adds keys rather than needing a signature
     * change, because the lookup is key-based, not numeric.
     */
    public function choice(string $key, int $count, array $replace = [], ?string $locale = null): string
    {
        $value = $this->lookup($key, $locale);

        if (!is_array($value)) {
            $this->missing[] = $key;

            return $key;
        }

        $form = $count === 1 ? 'one' : 'other';
        $line = $value[$form] ?? $value['other'] ?? $value['one'] ?? null;

        if (!is_string($line)) {
            $this->missing[] = $key . '.' . $form;

            return $key;
        }

        return self::interpolate(str_replace('{count}', (string) $count, $line), $replace);
    }

    /**
     * @param array<string, string|int|float> $replace
     */
    private static function interpolate(string $value, array $replace): string
    {
        foreach ($replace as $token => $replacement) {
            $value = str_replace('{' . $token . '}', (string) $replacement, $value);
        }

        return $value;
    }

    /**
     * The whole catalogue for a locale, flattened to dot-keys.
     *
     * This is what GET /api/i18n ships: the complete set for the ACTIVE locale
     * only, so the client never guesses and never ships English the user should
     * not be reading.
     *
     * @return array<string, string|array<string, string>>
     */
    public function catalogue(?string $locale = null): array
    {
        $target = self::normalise($locale ?? $this->locale);
        $resolved = $this->catalogueFor($target);

        // A partially translated locale is topped up from English, so the client
        // always receives a complete, renderable message set. This is what makes
        // adding a locale incrementally safe rather than all-or-nothing.
        if ($target !== self::FALLBACK) {
            $resolved += $this->catalogueFor(self::FALLBACK);
        }

        return $resolved;
    }

    /** @return array<string, mixed> */
    private function catalogueFor(string $locale): array
    {
        if (isset($this->catalogues[$locale])) {
            return $this->catalogues[$locale];
        }

        $messages = [];
        $directory = $this->directory . '/' . $locale;

        foreach (is_dir($directory) ? (glob($directory . '/*.php') ?: []) : [] as $file) {
            $group = basename($file, '.php');
            $loaded = require $file;
            if (!is_array($loaded)) {
                continue;
            }
            foreach ($loaded as $key => $value) {
                $messages[$group . '.' . $key] = $value;
            }
        }

        return $this->catalogues[$locale] = $messages;
    }

    /**
     * Find a key, trying the active locale then English.
     *
     * @return string|array<string, string>|null
     */
    private function lookup(string $key, ?string $locale = null): string|array|null
    {
        $order = $locale === null ? [$this->locale] : [self::normalise($locale)];
        if ($order[0] !== self::FALLBACK) {
            $order[] = self::FALLBACK;
        }

        foreach ($order as $candidate) {
            $messages = $this->catalogueFor($candidate);
            if (isset($messages[$key])) {
                return $messages[$key];
            }
        }

        return null;
    }

    /** @return list<string> */
    public function missing(): array
    {
        return array_values(array_unique($this->missing));
    }

    public static function normalise(?string $locale): string
    {
        $locale = strtolower(trim((string) $locale));
        // Accept "fr-FR", "fr_CA", "sw-KE" and reduce them to a catalogue key.
        foreach (['-', '_'] as $separator) {
            $position = strpos($locale, $separator);
            if ($position !== false) {
                $locale = substr($locale, 0, $position);
            }
        }

        return in_array($locale, self::supported(), true) ? $locale : self::DEFAULT;
    }

    /**
     * Resolve the locale for a request: explicit choice, then stored preference,
     * then the browser's Accept-Language, then English.
     */
    public function resolveForRequest(Request $request): string
    {
        $query = [];
        parse_str((string) parse_url($request->uri, PHP_URL_QUERY), $query);

        // Explicit choice, then the stored session, then the cookie. The cookie
        // is what makes the preference survive a session expiry and what lets the
        // server-rendered login screen be correct before any JS runs.
        foreach ([$query['lang'] ?? null, $_SESSION['mamore_locale'] ?? null, $_COOKIE['mamore_locale'] ?? null] as $candidate) {
            if (is_string($candidate) && in_array(self::normalise($candidate), self::supported(), true)) {
                $this->setLocale($candidate);

                return $this->locale;
            }
        }

        // Accept-Language is only consulted for a supported NON-default locale, so
        // a browser asking for "de" falls back to English explicitly rather than
        // accidentally inheriting a partial match.
        foreach (explode(',', $request->headers['accept-language'] ?? '') as $part) {
            $normalised = self::normalise(trim(explode(';', $part)[0]));
            if ($normalised !== self::DEFAULT) {
                $this->setLocale($normalised);

                return $this->locale;
            }
        }

        $this->setLocale(self::DEFAULT);

        return $this->locale;
    }
}
