<?php

declare(strict_types=1);

namespace Mamore\Core;

use PDO;
use RuntimeException;
use Throwable;

final class Migrator
{
    public function __construct(
        private readonly PDO $database,
        private readonly string $directory,
    ) {
    }

    /**
     * What has been applied and what is still pending.
     *
     * Read-only, so it is safe to call from a health endpoint on every request:
     * it takes no lock and changes nothing.
     *
     * @return array{applied:int,pending:int,last:?string,pendingFiles:list<string>,modified:list<string>}
     */
    public function status(): array
    {
        $this->ensureLedger();
        $applied = $this->appliedMigrations();
        $pending = [];
        $modified = [];

        foreach ($this->files() as $file) {
            $name = basename($file);
            $checksum = hash_file('sha256', $file);
            if (!isset($applied[$name])) {
                $pending[] = $name;
                continue;
            }
            if ($checksum !== false && !hash_equals($applied[$name], $checksum)) {
                $modified[] = $name;
            }
        }

        $statement = $this->database->query('SELECT migration FROM schema_migrations ORDER BY migration DESC LIMIT 1');
        $last = $statement === false ? false : $statement->fetchColumn();

        return [
            'applied' => count($applied),
            'pending' => count($pending),
            'pendingFiles' => $pending,
            'modified' => $modified,
            'last' => is_string($last) ? $last : null,
        ];
    }

    /** @return list<string> */
    public function migrate(): array
    {
        $this->ensureLedger();
        $this->acquireLock();

        try {
            $applied = $this->appliedMigrations();
            $completed = [];

            foreach ($this->files() as $file) {
                $name = basename($file);
                $checksum = hash_file('sha256', $file);
                if ($checksum === false) {
                    throw new RuntimeException("Cannot checksum migration: {$name}");
                }

                if (isset($applied[$name])) {
                    if (!hash_equals($applied[$name], $checksum)) {
                        throw new RuntimeException("Applied migration was modified: {$name}");
                    }
                    continue;
                }

                $sql = file_get_contents($file);
                if ($sql === false) {
                    throw new RuntimeException("Cannot read migration: {$name}");
                }

                $this->database->exec($sql);
                $statement = $this->database->prepare(
                    'INSERT INTO schema_migrations (migration, checksum) VALUES (:migration, :checksum)'
                );
                $statement->execute(['migration' => $name, 'checksum' => $checksum]);
                $completed[] = $name;
            }

            return $completed;
        } finally {
            $this->releaseLock();
        }
    }

    private function ensureLedger(): void
    {
        $this->database->exec(<<<'SQL'
            CREATE TABLE IF NOT EXISTS schema_migrations (
                migration VARCHAR(190) PRIMARY KEY,
                checksum CHAR(64) NOT NULL,
                applied_at TIMESTAMP(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
            SQL);
    }

    /** @return array<string, string> */
    private function appliedMigrations(): array
    {
        $rows = $this->database->query('SELECT migration, checksum FROM schema_migrations')->fetchAll();
        $applied = [];
        foreach ($rows as $row) {
            $applied[$row['migration']] = $row['checksum'];
        }
        return $applied;
    }

    /** @return list<string> */
    private function files(): array
    {
        $files = glob(rtrim($this->directory, '/') . '/*.sql') ?: [];
        sort($files, SORT_STRING);
        return array_values($files);
    }

    private function acquireLock(): void
    {
        $result = $this->database->query("SELECT GET_LOCK('mamore_schema_migrations', 10)")->fetchColumn();
        if ((int) $result !== 1) {
            throw new RuntimeException('Could not acquire the Mamore migration lock.');
        }
    }

    private function releaseLock(): void
    {
        try {
            $this->database->query("SELECT RELEASE_LOCK('mamore_schema_migrations')");
        } catch (Throwable) {
            // The database releases advisory locks when the connection closes.
        }
    }
}
