<?php

declare(strict_types=1);

namespace Mamore\Core;

final class RateLimiter
{
    /** @var array<string,list<int>> */
    private static array $hits = [];

    public static function allow(string $key, int $max, int $windowSeconds): bool
    {
        $now = time();
        $bucket = self::$hits[$key] ?? [];
        $bucket = array_values(array_filter($bucket, static fn (int $t): bool => $t > $now - $windowSeconds));
        if (count($bucket) >= $max) {
            self::$hits[$key] = $bucket;
            return false;
        }
        $bucket[] = $now;
        self::$hits[$key] = $bucket;
        return true;
    }
}
