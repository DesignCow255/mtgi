<?php

declare(strict_types=1);

namespace Mamore\Core;

use PDO;

/**
 * Decides which navigation the signed-in user is offered.
 *
 * Why this lives on the server rather than in the browser:
 *
 *  - The shell today only distinguishes staff from customer (`role === 'CUSTOMER'`),
 *    so a DRIVER or a CONDUCTOR is shown all eighteen staff entries for work they
 *    cannot do. Navigation is the first thing a user learns about a product, and
 *    offering 18 destinations to someone whose job is one of them teaches them
 *    that the interface does not know who they are.
 *  - The brief is explicit that permissions must never be enforced by hiding UI.
 *    This class does NOT enforce anything. Every route still calls
 *    AuthService::requirePermission() and still filters in SQL. What this decides
 *    is what is even *offered*, so the correct action is always the easy one.
 *    Hiding a control the server would reject is a usability decision; refusing
 *    an action is a security decision, and it stays in the service layer.
 *
 * Adding permissions to AuthService::publicUser() would have been the smaller
 * change, but it would ship the full permission vocabulary to the browser on
 * every login and make the client's filtering look authoritative. A dedicated
 * endpoint keeps the decision where the data is.
 *
 * The domain vocabulary deliberately reuses the same permission codes as
 * GlobalSearch::domainsFor(), so "which domains can I see" has exactly one
 * answer in this codebase.
 */
final class Navigation
{
    /**
     * Staff navigation groups, in display order. Adding a destination is one
     * entry here plus its panel in the shell.
     *
     * The Control Center is the first operational destination. It used to be
     * labelled "Rescue operations", which duplicated the rescue entry and was
     * simply the wrong name for a cross-domain board.
     *
     * @var list<array{key:string,labelKey:string,items:list<array{panel:string,key:string,icon:string,permission:?string}>}>
     */
    private const STAFF_GROUPS = [
        [
            'key' => 'overview',
            'labelKey' => 'navigation.group_overview',
            'items' => [
                ['panel' => 'overview', 'key' => 'home', 'icon' => 'gauge-high', 'permission' => null],
                ['panel' => 'operations', 'key' => 'control_center', 'icon' => 'tower-broadcast', 'permission' => 'incident.global_view'],
            ],
        ],
        [
            'key' => 'operations',
            'labelKey' => 'navigation.group_operations',
            'items' => [
                ['panel' => 'rescue', 'key' => 'rescue_operations', 'icon' => 'truck-medical', 'permission' => 'rescue.dispatch'],
                ['panel' => 'alerts', 'key' => 'panic_alerts', 'icon' => 'triangle-exclamation', 'permission' => 'alert.manage'],
                ['panel' => 'tracking', 'key' => 'live_tracking', 'icon' => 'location-crosshairs', 'permission' => 'tracking.view'],
            ],
        ],
        [
            'key' => 'mobility',
            'labelKey' => 'navigation.group_mobility',
            'items' => [
                ['panel' => 'mobility', 'key' => 'smart_bus', 'icon' => 'bus', 'permission' => 'smartbus.manage'],
                ['panel' => 'boarding', 'key' => 'boarding_manifest', 'icon' => 'ticket', 'permission' => 'smartbus.manifest.view'],
                ['panel' => 'command', 'key' => 'command_centre', 'icon' => 'headset', 'permission' => 'smartbus.pilot.view'],
                ['panel' => 'truckcargo', 'key' => 'truck_cargo', 'icon' => 'truck', 'permission' => 'truck.view'],
                ['panel' => 'privatevehicles', 'key' => 'private_vehicles', 'icon' => 'car-side', 'permission' => 'private_vehicle.view'],
            ],
        ],
        [
            'key' => 'services',
            'labelKey' => 'navigation.group_services',
            'items' => [
                ['panel' => 'vip', 'key' => 'vip_subscribers', 'icon' => 'trophy', 'permission' => 'vip.view'],
                ['panel' => 'subscriptions', 'key' => 'rescue_subscriptions', 'icon' => 'shield-heart', 'permission' => 'finance.manage'],
            ],
        ],
        [
            'key' => 'intelligence',
            'labelKey' => 'navigation.group_intelligence',
            'items' => [
                ['panel' => 'analytics', 'key' => 'analytics', 'icon' => 'chart-column', 'permission' => 'analytics.global_view'],
                ['panel' => 'finance', 'key' => 'finance', 'icon' => 'sack-dollar', 'permission' => 'finance.manage'],
                ['panel' => 'receipts', 'key' => 'receipts', 'icon' => 'receipt', 'permission' => 'finance.manage'],
            ],
        ],
        [
            'key' => 'administration',
            'labelKey' => 'navigation.group_administration',
            'items' => [
                ['panel' => 'users', 'key' => 'users', 'icon' => 'users', 'permission' => 'users.manage'],
                ['panel' => 'sessions', 'key' => 'security_sessions', 'icon' => 'shield-halved', 'permission' => null],
                ['panel' => 'notifications', 'key' => 'notifications', 'icon' => 'bell', 'permission' => null],
                ['panel' => 'audit', 'key' => 'audit_trail', 'icon' => 'clipboard-list', 'permission' => 'audit.view'],
            ],
        ],
    ];

    /** The customer portal is a different product, not a filtered staff menu. */
    private const CUSTOMER_ITEMS = [
        ['panel' => 'portal', 'key' => 'find_trip', 'icon' => 'route', 'permission' => null],
        ['panel' => 'mybookings', 'key' => 'my_bookings', 'icon' => 'ticket', 'permission' => null],
        ['panel' => 'membership', 'key' => 'my_rescue_cover', 'icon' => 'shield-heart', 'permission' => null],
        ['panel' => 'privatevehicles', 'key' => 'my_vehicles', 'icon' => 'car-side', 'permission' => null],
        ['panel' => 'sessions', 'key' => 'account_security', 'icon' => 'shield-halved', 'permission' => null],
        ['panel' => 'notifications', 'key' => 'notifications', 'icon' => 'bell', 'permission' => null],
    ];

    public function __construct(private readonly PDO $database) {}

    /**
     * @param array<string,mixed> $actor the authenticated user row
     *
     * @return array<string,mixed>
     */
    public function forUser(array $actor, ?Translator $translator = null): array
    {
        $permissions = $this->permissions($actor);
        $customer = ($actor['role_code'] ?? '') === 'CUSTOMER';
        $translator ??= Translator::instance();

        $groups = $customer
            ? [['key' => 'my-mamore', 'labelKey' => 'navigation.group_my_mamore', 'items' => self::CUSTOMER_ITEMS]]
            : self::STAFF_GROUPS;

        $result = [];
        $panels = [];

        foreach ($groups as $group) {
            $items = [];
            foreach ($group['items'] as $item) {
                if (!$this->allows($item['permission'], $permissions)) {
                    continue;
                }

                // Labels are resolved HERE, on the server, rather than shipped as
                // English for the browser to translate. The shell is served before
                // sign-in, so the client cannot know the locale at render time, and
                // /api/navigation is called after sign-in when the session locale
                // is known. This keeps one copy of the vocabulary.
                $label = $translator->t('navigation.' . $item['key']);

                $items[] = [
                    'panel' => $item['panel'],
                    'label' => $label,
                    'icon' => $item['icon'],
                ];
                $panels[$item['panel']] = $label;
            }

            // A group with nothing in it is omitted entirely rather than left as
            // an empty heading, which would advertise that something is missing.
            if ($items !== []) {
                $result[] = [
                    'key' => $group['key'],
                    'label' => $translator->t($group['labelKey']),
                    'items' => $items,
                ];
            }
        }

        return [
            'groups' => $result,
            'panels' => $panels,
            'domains' => $this->domains($permissions),
            'landing' => $customer ? 'portal' : 'overview',
            'locale' => $translator->locale(),
        ];
    }

    /**
     * The domains this caller may see, using the same permission codes as
     * GlobalSearch::domainsFor() so there is one answer, not two.
     *
     * @param list<string> $permissions
     *
     * @return list<string>
     */
    private function domains(array $permissions): array
    {
        $map = [
            'RESCUE' => 'tracking.global_view',
            'SMART_BUS' => 'smartbus.manifest.view',
            'TRUCK_CARGO' => 'truck.view',
            'PRIVATE_VEHICLE' => 'private_vehicle.view',
            'VIP' => 'vip.view',
        ];

        $domains = [];
        foreach ($map as $domain => $permission) {
            if (in_array($permission, $permissions, true)) {
                $domains[] = $domain;
            }
        }

        return $domains;
    }

    /**
     * @param list<string> $permissions
     */
    private function allows(?string $permission, array $permissions): bool
    {
        // A null permission means the destination is available to any signed-in
        // user of that kind (Home, Security & sessions, Notifications). It is not
        // a way to leak an admin surface: those always name a permission.
        return $permission === null || in_array($permission, $permissions, true);
    }

    /**
     * Every permission this role holds.
     *
     * @return list<string>
     */
    private function permissions(array $actor): array
    {
        $statement = $this->database->prepare(<<<'SQL'
            SELECT p.code
            FROM role_permissions rp
            JOIN permissions p ON p.id = rp.permission_id
            WHERE rp.role_id = :role_id
            SQL);
        $statement->execute(['role_id' => $actor['role_id']]);

        return array_map('strval', $statement->fetchAll(PDO::FETCH_COLUMN));
    }
}

