<?php

declare(strict_types=1);

namespace Mamore\Core;

/**
 * Mount-point aware URL helper.
 *
 * The application is not necessarily served from the web root. Under MAMP the
 * document root is /Applications/MAMP/htdocs, so the project is reached through
 * the "mtgi" sub-directory and every generated URL has to carry that prefix,
 * while every incoming request URI has to have it removed before the router
 * compares the path against its table (the routes are always registered as
 * "/api/...", never "/mtgi/api/...").
 *
 * The mount point is derived from SCRIPT_NAME, the path of the front controller
 * the request was actually served through, so the same build works unchanged
 * both at the web root (an empty base, e.g. `php -S ... -t public`) and from a
 * sub-directory (e.g. "/mtgi" behind MAMP) without any per-environment
 * configuration. APP_BASE_PATH overrides the detection for deployments where
 * the front controller is reached through a proxy that reports a misleading
 * SCRIPT_NAME.
 */
final class Url
{
    private static ?string $base = null;

    /** The mount point, either "" at the web root or "/sub-directory". */
    public static function base(): string
    {
        if (self::$base !== null) {
            return self::$base;
        }

        $configured = trim(Env::get('APP_BASE_PATH', ''));
        if ($configured !== '') {
            return self::$base = '/' . trim($configured, '/');
        }

        return self::$base = self::detect();
    }

    /**
     * Derive the mount point from the URL the front controller was reached at.
     *
     * SCRIPT_NAME is the request-side signal: it is the URL path of the script
     * being run, so its directory is the mount point ("/mtgi/index.php" ->
     * "/mtgi"). It is deliberately not trusted on its own, because PHP's
     * built-in server (php -S) reports SCRIPT_NAME as the *requested* path when
     * a router script is used: asking for /assets/app.css yields SCRIPT_NAME
     * "/assets/app.css", and a naive dirname() would infer a "/assets" base and
     * then strip it from the URI, breaking every static file.
     *
     * Such a bogus candidate is rejected by resolving it against the document
     * root and requiring that the resulting directory really is this project.
     * SCRIPT_FILENAME cannot be used instead: on Apache it names the file that
     * was executed, which for a sub-directory install is the project-root shim,
     * so its dirname is an absolute filesystem path rather than a URL prefix.
     */
    private static function detect(): string
    {
        $script = (string) ($_SERVER['SCRIPT_NAME'] ?? '');
        if ($script === '') {
            return '';
        }

        $directory = rtrim(str_replace('\\', '/', dirname($script)), '/');
        if ($directory === '.' || $directory === '/') {
            return '';
        }

        // "…/public" is this project's public/ directory, which is the document
        // root on a web-root install and not part of a mount point. SCRIPT_NAME
        // only contains that segment when the front controller was reached
        // through it, so strip it before the check below.
        if (preg_match('#/public$#', $directory) === 1) {
            $directory = substr($directory, 0, -strlen('/public'));
        }
        if ($directory === '') {
            return '';
        }

        // A mount point is a URL path, so resolve it against the document root
        // and confirm it really points at this project. This rejects the
        // built-in server's "the requested path is the script name" behaviour.
        $documentRoot = rtrim(str_replace('\\', '/', (string) ($_SERVER['DOCUMENT_ROOT'] ?? '')), '/');
        $resolved = $documentRoot === '' ? '' : realpath($documentRoot . $directory);

        if ($resolved === false || realpath(dirname(__DIR__, 2)) !== $resolved) {
            return '';
        }

        return $directory;
    }

    /**
     * Prefix an application path with the mount point.
     *
     * Only absolute paths are rewritten: a path that is already relative, or a
     * full URL, is returned untouched.
     */
    public static function to(string $path): string
    {
        $base = self::base();
        if ($base === '' || $path === '' || $path[0] !== '/') {
            return $path;
        }

        return $base . $path;
    }

    /**
     * Remove the mount point from an incoming request URI so the router sees the
     * path it was registered with. A URI outside the mount point is left alone
     * rather than mangled.
     */
    public static function strip(string $uri): string
    {
        $base = self::base();
        if ($base === '' || $uri === '') {
            return self::normalise($uri);
        }

        if ($uri === $base || $uri === $base . '/') {
            return '/';
        }

        return str_starts_with($uri, $base . '/')
            ? self::normalise(substr($uri, strlen($base)))
            : $uri;
    }

    /**
     * Collapse the front controller's own filename onto the site root.
     *
     * Apache serves "/" through index.php, so "/mtgi/" and "/mtgi/index.php" are
     * the same page; without this the latter is stripped to "/index.php", which
     * matches no route and 404s. This happens on any SAPI, not just a
     * sub-directory install.
     */
    private static function normalise(string $path): string
    {
        if ($path === '/index.php') {
            return '/';
        }

        return str_starts_with($path, '/index.php/')
            ? substr($path, strlen('/index.php'))
            : $path;
    }
}
