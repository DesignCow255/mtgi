<?php

declare(strict_types=1);

namespace Mamore\Core;

use PDO;

/**
 * The single source of "now" for time-critical logic.
 *
 * Stored timestamps are written by the database (UTC_TIMESTAMP(6)), so they must
 * also be *compared* against the database clock. Comparing them with PHP's
 * time() silently breaks whenever the application host and the database server
 * clocks disagree - and on this workstation they are three hours apart, which
 * would expire one-time codes early, close boarding windows at the wrong moment
 * and report every GPS feed as stale.
 *
 * The value is read once per process and cached; /ready reports the measured
 * skew so a misconfigured host is visible instead of mysterious.
 */
final class ServerClock
{
    private static ?int $epoch = null;
    private static ?int $skewSeconds = null;

    /** Unix timestamp according to the database server. */
    public static function epoch(PDO $database): int
    {
        if (self::$epoch === null) {
            $statement = $database->query('SELECT UNIX_TIMESTAMP(UTC_TIMESTAMP(6))');
            $value = $statement === false ? false : $statement->fetchColumn();
            self::$epoch = is_numeric($value) ? (int) $value : time();
        }

        return self::$epoch;
    }

    /** Seconds the PHP clock is ahead of the database clock. */
    public static function skewSeconds(PDO $database): int
    {
        if (self::$skewSeconds === null) {
            self::$skewSeconds = time() - self::epoch($database);
        }

        return self::$skewSeconds;
    }

    /**
     * Parse a MySQL TIMESTAMP(6) column into a Unix timestamp.
     *
     * strtotime() returns false for "2026-09-26 12:40:06.200633" because of the
     * fractional part, and false compared as 0 silently means "very old" - which
     * once made every live GPS feed report OFFLINE and every one-time code look
     * expired. Centralised here so no caller repeats it.
     */
    public static function parse(string $value): int
    {
        $timezone = new \DateTimeZone('UTC');
        foreach (['!Y-m-d H:i:s.u', '!Y-m-d H:i:s', '!Y-m-d\TH:i:sP', '!Y-m-d'] as $format) {
            $parsed = \DateTimeImmutable::createFromFormat($format, $value, $timezone);
            if ($parsed instanceof \DateTimeImmutable) {
                return $parsed->getTimestamp();
            }
        }
        try {
            return (new \DateTimeImmutable($value, $timezone))->getTimestamp();
        } catch (\Throwable) {
            return 0;
        }
    }

    /** Forget the cached values (used by tests and long-running processes). */
    public static function reset(): void
    {
        self::$epoch = null;
        self::$skewSeconds = null;
    }
}
