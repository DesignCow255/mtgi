<?php

declare(strict_types=1);

namespace Mamore\Core;

final class Cache
{
    /** @var array<string,array{value:mixed,expires:int}> */
    private static array $store = [];

    public static function remember(string $key, int $ttlSeconds, callable $producer): mixed
    {
        $now = time();
        if (isset(self::$store[$key]) && self::$store[$key]['expires'] > $now) {
            return self::$store[$key]['value'];
        }
        $value = $producer();
        self::$store[$key] = ['value' => $value, 'expires' => $now + $ttlSeconds];
        return $value;
    }
}
