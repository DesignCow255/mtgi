<?php

declare(strict_types=1);

namespace Mamore\Core;

final class Validator
{
    /** @return array<string,string> */
    public static function required(array $input, array $fields): array
    {
        $errors = [];
        foreach ($fields as $field) {
            if (!isset($input[$field]) || trim((string) $input[$field]) === '') {
                $errors[$field] = 'This field is required.';
            }
        }
        return $errors;
    }

    public static function email(?string $value): bool
    {
        return is_string($value) && filter_var($value, FILTER_VALIDATE_EMAIL) !== false;
    }
}
