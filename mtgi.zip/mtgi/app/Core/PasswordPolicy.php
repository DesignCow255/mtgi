<?php

declare(strict_types=1);

namespace Mamore\Core;

/**
 * The one password rule for the whole platform.
 *
 * Previously only the admin user creation path checked a length, so a password
 * set through the portal could be weaker than one set by an administrator.
 * Both entry points now share this policy: 12 characters minimum and at least
 * three of the four character classes.
 */
final class PasswordPolicy
{
    public const MIN_LENGTH = 12;

    /** @throws \Mamore\Auth\AuthException when the password is too weak */
    public static function assert(string $password, string $label = 'Password'): void
    {
        if (mb_strlen($password) < self::MIN_LENGTH) {
            throw new \Mamore\Auth\AuthException("{$label} must contain at least " . self::MIN_LENGTH . ' characters.', 422);
        }

        $classes = 0;
        $classes += preg_match('/[a-z]/', $password) === 1 ? 1 : 0;
        $classes += preg_match('/[A-Z]/', $password) === 1 ? 1 : 0;
        $classes += preg_match('/\d/', $password) === 1 ? 1 : 0;
        $classes += preg_match('/[^A-Za-z0-9]/', $password) === 1 ? 1 : 0;

        if ($classes < 3) {
            throw new \Mamore\Auth\AuthException(
                "{$label} must mix at least three of: lowercase, uppercase, digits, symbols.",
                422
            );
        }
    }

    public static function isStrong(string $password): bool
    {
        try {
            self::assert($password);
            return true;
        } catch (\Mamore\Auth\AuthException) {
            return false;
        }
    }
}
