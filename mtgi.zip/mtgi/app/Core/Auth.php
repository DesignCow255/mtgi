<?php

declare(strict_types=1);

namespace Mamore\Core;

use PDO;

final class Auth
{
    public function __construct(private readonly PDO $db)
    {
    }

    public function userFromSession(): ?array
    {
        Session::start();
        $userId = $_SESSION['user_id'] ?? null;
        if (!is_string($userId) || $userId === '') {
            return null;
        }
        $st = $this->db->prepare('SELECT u.*, r.code AS role_code FROM users u JOIN roles r ON r.id=u.role_id WHERE u.id=:id AND u.deleted_at IS NULL LIMIT 1');
        $st->execute(['id' => $userId]);
        $row = $st->fetch();
        return is_array($row) ? $row : null;
    }
}
