<?php

declare(strict_types=1);

namespace Mamore\Core;

final class Csrf
{
    public static function token(): string
    {
        Session::start();
        if (empty($_SESSION['csrf_token'])) {
            $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
        }
        return (string) $_SESSION['csrf_token'];
    }

    public static function check(?string $token): bool
    {
        Session::start();
        $expected = (string) ($_SESSION['csrf_token'] ?? '');
        if ($expected === '' || $token === null) {
            return false;
        }
        return hash_equals($expected, $token);
    }
}
