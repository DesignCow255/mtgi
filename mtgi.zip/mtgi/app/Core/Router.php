<?php

declare(strict_types=1);

namespace Mamore\Core;

final class Router
{
    /** @var array<string, callable(Request): array> */
    private array $routes = [];

    public function get(string $path, callable $handler): void
    {
        $this->routes['GET ' . $path] = $handler;
    }

    public function post(string $path, callable $handler): void
    {
        $this->routes['POST ' . $path] = $handler;
    }

    public function dispatch(
        string $method,
        string $uri,
        array $body = [],
        array $headers = [],
        ?string $ipAddress = null,
        ?string $userAgent = null,
    ): array
    {
        $path = parse_url($uri, PHP_URL_PATH) ?: '/';
        $handler = $this->routes[strtoupper($method) . ' ' . $path] ?? null;
        $request = new Request(strtoupper($method), $uri, $body, $headers, $ipAddress, $userAgent);
        return $handler ? $handler($request) : Response::json(['error' => 'Not found'], 404);
    }
}
