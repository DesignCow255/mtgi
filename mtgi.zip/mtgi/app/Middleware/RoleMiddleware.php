<?php

declare(strict_types=1);

namespace Mamore\Middleware;

use Mamore\Core\Response;

final class RoleMiddleware
{
    /** @param list<string> $roles */
    public static function check(?array $user, array $roles): ?array
    {
        if ($user === null) {
            return Response::json(['error' => 'Authentication required.'], 401);
        }
        if (!in_array($user['role_code'] ?? null, $roles, true)) {
            return Response::json(['error' => 'Forbidden.'], 403);
        }
        return null;
    }
}
