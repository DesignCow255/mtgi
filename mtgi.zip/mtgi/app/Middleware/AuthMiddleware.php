<?php

declare(strict_types=1);

namespace Mamore\Middleware;

use Mamore\Auth\AuthException;
use Mamore\Auth\AuthService;
use Mamore\Core\Request;
use Mamore\Core\Response;
use PDO;

final class AuthMiddleware
{
    public function __construct(private readonly PDO $db)
    {
    }

    public function handle(Request $request): array
    {
        try {
            $user = (new AuthService($this->db))->authenticate($request->bearerToken());
            return ['user' => $user];
        } catch (AuthException $e) {
            return Response::json(['error' => $e->getMessage()], $e->status);
        }
    }
}
