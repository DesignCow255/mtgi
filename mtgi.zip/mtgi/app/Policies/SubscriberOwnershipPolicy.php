<?php

declare(strict_types=1);

namespace Mamore\Policies;

final class SubscriberOwnershipPolicy
{
    public static function owns(array $user, string $ownerUserId): bool
    {
        if (($user['role_code'] ?? '') === 'SYSTEM_ADMIN') {
            return true;
        }
        return ($user['id'] ?? null) === $ownerUserId;
    }
}
