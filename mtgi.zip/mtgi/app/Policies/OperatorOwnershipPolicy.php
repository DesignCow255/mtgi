<?php

declare(strict_types=1);

namespace Mamore\Policies;

final class OperatorOwnershipPolicy
{
    public static function ownsTrip(array $user, array $trip, ?string $operatorId): bool
    {
        if (($user['role_code'] ?? '') === 'SYSTEM_ADMIN') {
            return true;
        }
        if ($operatorId === null || $operatorId === '') {
            return true;
        }
        return ($trip['operator_id'] ?? null) === $operatorId;
    }
}
