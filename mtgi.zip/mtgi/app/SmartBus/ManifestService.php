<?php

declare(strict_types=1);

namespace Mamore\SmartBus;

use Mamore\Auth\AuthException;
use Mamore\Core\AuditLog;
use Mamore\Core\RateLimiter;
use Mamore\Core\Request;
use Mamore\Policies\OperatorOwnershipPolicy;
use PDO;

/**
 * Passenger manifest, digital check-in and boarding (Features F, G, H).
 *
 * The manifest is a read model over smartbus_bookings - there is no second
 * passenger table. State moves forward only, inside a transaction, and every
 * transition is audited:
 *
 *   CONFIRMED -> CHECKED_IN -> BOARDED -> COMPLETED
 *        |             |           |
 *        +--------> NO_SHOW (before boarding)   CANCELLED
 *
 * Check-in validates the ticket, the trip, the seat, payment and cancellation in
 * one pass, so a scan cannot accept a ticket for the wrong bus, a cancelled
 * booking, or the same passenger twice.
 */
final class ManifestService
{
    /** Set by resolveBooking() when a historical unsigned ticket was accepted. */
    private bool $legacyTicketWarning = false;

    private const ALLOWED = [
        'CONFIRMED' => ['CHECKED_IN', 'NO_SHOW', 'CANCELLED'],
        'CHECKED_IN' => ['BOARDED', 'NO_SHOW'],
        'BOARDED' => ['COMPLETED', 'NO_SHOW'],
        'RESERVED' => ['CONFIRMED', 'CANCELLED'],
        'NO_SHOW' => ['BOARDED'],
        'COMPLETED' => [],
        'CANCELLED' => [],
        'REFUNDED' => [],
    ];

    public function __construct(private readonly PDO $database) {}

    /**
     * Manifest for a trip, with counts a conductor actually needs.
     *
     * @return array<string,mixed>
     */
    public function manifest(string $tripId, array $actor): array
    {
        $trip = $this->trip($tripId);
        $this->assertTripAccess($actor, $trip);

        $rows = $this->database->prepare(<<<'SQL'
            SELECT b.*, s.membership_number, s.first_name AS subscriber_first_name, s.last_name AS subscriber_last_name,
                   rc.code AS rescue_code, rc.status AS rescue_code_status
            FROM smartbus_bookings b
            LEFT JOIN subscribers s ON s.id = b.subscriber_id
            LEFT JOIN rescue_codes rc ON rc.id = b.rescue_code_id
            WHERE b.trip_id = :trip AND b.status <> 'CANCELLED' AND b.status <> 'REFUNDED'
            ORDER BY b.seat_number ASC
            SQL);
        $rows->execute(['trip' => $tripId]);
        $bookings = $rows->fetchAll();

        $counts = [
            'total' => 0, 'confirmed' => 0, 'reserved' => 0, 'checkedIn' => 0, 'boarded' => 0, 'noShow' => 0,
            'completed' => 0, 'cancelled' => 0, 'vip' => 0, 'rescueProtected' => 0, 'assistance' => 0,
        ];
        $passengers = [];
        foreach ($bookings as $row) {
            $state = $this->state($row);
            $counts['total']++;
            $bucket = lcfirst(str_replace(' ', '', ucwords(strtolower(str_replace('_', ' ', $state)))));
            $counts[$bucket] = ($counts[$bucket] ?? 0) + 1;
            $counts['vip'] += $row['vip_at_booking'] ? 1 : 0;
            $counts['rescueProtected'] += (float) $row['rescue_fee_usd'] > 0 ? 1 : 0;
            $counts['assistance'] += $row['special_assistance'] !== null ? 1 : 0;
            $passengers[] = [
                'bookingId' => $row['id'],
                'reference' => $row['booking_reference'],
                'passengerName' => $row['passenger_name'],
                'phone' => $row['passenger_phone'],
                'seatNumber' => (int) $row['seat_number'],
                'state' => $state,
                'checkInAt' => $row['check_in_at'],
                'boardedAt' => $row['boarded_at'],
                'paid' => $this->isPaid((string) $row['id']),
                'vip' => (bool) $row['vip_at_booking'],
                'rescueCoverage' => (float) $row['rescue_fee_usd'] > 0 ? 'ACTIVE' : 'INACTIVE',
                // Never the full code on a manifest: the seat and name already
                // identify the passenger, the code is for responders.
                'rescueCode' => $row['rescue_code'] === null ? null : RescueCodeService::maskCode((string) $row['rescue_code']),
                'hasRescueCode' => $row['rescue_code'] !== null,
                'membershipNumber' => $row['membership_number'],
                'specialAssistance' => $row['special_assistance'],
                'emergencyProfile' => $row['subscriber_id'] !== null,
            ];
        }

        $phase = BoardingWindow::phase($trip);
        $capacity = (int) $trip['capacity'];

        return [
            'tripId' => $tripId,
            'tripCode' => $trip['trip_code'],
            'route' => ['code' => $trip['route_code'], 'origin' => $trip['origin'], 'destination' => $trip['destination']],
            'departureAt' => $trip['departure_at'],
            'boarding' => BoardingWindow::present($trip),
            'counts' => $counts + [
                'capacity' => $capacity,
                'pending' => max(0, $counts['total'] - $counts['boarded']),
                'occupancy' => $capacity > 0 ? round($counts['total'] / $capacity, 2) : null,
            ],
            'passengers' => $passengers,
        ];
    }

    /**
     * Check a passenger in from a scanned or typed ticket.
     *
     * @return array<string,mixed>
     */
    public function checkIn(array $input, array $actor, Request $request): array
    {
        $tripId = $this->required($input, 'tripId', 'Trip');
        $trip = $this->trip($tripId);
        $this->assertTripAccess($actor, $trip);

        $payload = (string) ($input['qrPayload'] ?? '');
        $reference = (string) ($input['bookingReference'] ?? '');
        $seat = $input['seatNumber'] ?? null;

        $booking = $this->resolveBooking($tripId, $payload, $reference, $seat);
        $this->assertTripAcceptsBoarding($trip);

        $state = $this->state($booking);
        if ($state === 'CHECKED_IN' || $state === 'BOARDED' || $state === 'COMPLETED') {
            throw new AuthException('This passenger is already checked in.', 409);
        }
        if ($state === 'NO_SHOW') {
            throw new AuthException('This booking was marked as a no-show.', 409);
        }
        if (!$this->isPaid($booking['id'])) {
            throw new AuthException('This booking has no recorded payment.', 409);
        }
        if ($this->cancelled($booking['id'])) {
            throw new AuthException('This booking was cancelled or refunded.', 409);
        }

        $this->transition($booking, 'CHECKED_IN', $actor, $request, ['from' => $state]);
        if ($this->legacyTicketWarning) {
            (new AuditLog($this->database))->write(
                'LEGACY_TICKET_SCANNED',
                'Booking',
                $booking['id'],
                $actor,
                $request,
                null,
                null,
                ['source' => 'manifest-check-in', 'signed' => false]
            );
        }

        return ['booking' => $this->bookingSummary($this->booking($booking['id']))];
    }

    /**
     * Confirm boarding (or mark a no-show).
     *
     * @return array<string,mixed>
     */
    public function board(array $input, array $actor, Request $request): array
    {
        $bookingId = $this->required($input, 'bookingId', 'Booking');
        $action = strtoupper((string) ($input['action'] ?? 'BOARD'));
        if (!in_array($action, ['BOARD', 'NO_SHOW', 'COMPLETE'], true)) {
            throw new AuthException('Choose board, no-show or complete.', 422);
        }

        $booking = $this->booking($bookingId);
        $trip = $this->trip($booking['trip_id']);
        $this->assertTripAccess($actor, $trip);
        $this->assertTripAcceptsBoarding($trip);

        $target = match ($action) {
            'BOARD' => 'BOARDED',
            'NO_SHOW' => 'NO_SHOW',
            'COMPLETE' => 'COMPLETED',
        };
        $from = $this->state($booking);

        if ($target === 'BOARDED' && $from !== 'CHECKED_IN') {
            throw new AuthException('Check the passenger in before boarding them.', 409);
        }
        if ($target === 'COMPLETED' && $from !== 'BOARDED') {
            throw new AuthException('Only boarded passengers can complete the trip.', 409);
        }

        $this->transition($booking, $target, $actor, $request, ['from' => $from]);

        if ($target === 'BOARDED') {
            $this->openJourney($booking);
        }

        return ['booking' => $this->bookingSummary($this->booking($bookingId))];
    }

    // ------------------------------------------------------------- internals

    /**
     * Operator isolation, delegated to the existing policy.
     *
     * A BUS_OPERATOR must be linked to an operator; without that link the
     * policy cannot tell whose trip this is, so access is refused rather than
     * granted everywhere.
     */
    private function assertTripAccess(array $actor, array $trip): void
    {
        $operatorId = $actor['operator_id'] ?? null;
        if ($this->roleCode($actor) === 'BUS_OPERATOR' && !is_string($operatorId)) {
            throw new AuthException('Your account is not linked to an operator. Ask an administrator.', 403);
        }
        if (!OperatorOwnershipPolicy::ownsTrip($actor, $trip, is_string($operatorId) ? $operatorId : null)) {
            throw new AuthException('This trip belongs to another operator.', 403);
        }
    }

    /**
     * The role of the acting account.
     *
     * AuthService::authenticate() already returns role_code; this fallback keeps
     * the check honest for any caller that passes a bare user row.
     */
    private function roleCode(array $actor): string
    {
        $role = $actor['role_code'] ?? null;
        if (is_string($role) && $role !== '') {
            return $role;
        }
        $id = $actor['id'] ?? null;
        if (!is_string($id) || $id === '') {
            return '';
        }
        $statement = $this->database->prepare(
            'SELECT r.code FROM users u JOIN roles r ON r.id = u.role_id WHERE u.id = :id'
        );
        $statement->execute(['id' => $id]);
        $code = $statement->fetchColumn();

        return is_string($code) ? $code : '';
    }

    /** @return array<string,mixed> */
    private function trip(string $tripId): array
    {
        $statement = $this->database->prepare(<<<'SQL'
            SELECT t.*, r.code AS route_code, r.origin, r.destination, v.capacity, v.code AS vehicle_code,
                   v.registration_number, o.id AS operator_id, o.name AS operator_name
            FROM smartbus_trips t
            JOIN smartbus_routes r ON r.id = t.route_id
            JOIN smartbus_vehicles v ON v.id = t.vehicle_id
            JOIN smartbus_operators o ON o.id = v.operator_id
            WHERE t.id = :id
            SQL);
        $statement->execute(['id' => $tripId]);
        $trip = $statement->fetch();
        if (!is_array($trip)) {
            throw new AuthException('Trip not found.', 404);
        }

        return $trip;
    }

    /** @return array<string,mixed> */
    private function booking(string $bookingId): array
    {
        $statement = $this->database->prepare('SELECT * FROM smartbus_bookings WHERE id = :id');
        $statement->execute(['id' => $bookingId]);
        $booking = $statement->fetch();
        if (!is_array($booking)) {
            throw new AuthException('Booking not found.', 404);
        }

        return $booking;
    }

    private function state(array $booking): string
    {
        $manifest = (string) $booking['manifest_status'];
        if (in_array($manifest, array_keys(self::ALLOWED), true)) {
            return $manifest;
        }

        // A booking from before the migration carries only the legacy status.
        return (string) $booking['status'] === 'BOARDED' ? 'BOARDED' : 'CONFIRMED';
    }

    /**
     * Resolve a scanned ticket, a typed reference or a seat to exactly one
     * booking on this trip.
     *
     * @return array<string,mixed>
     */
    private function resolveBooking(string $tripId, string $payload, string $reference, mixed $seat): array
    {
        if ($payload !== '') {
            $verified = TicketSigner::verify($payload);
            if (!$verified['valid']) {
                throw new AuthException('This ticket could not be read. Ask for a reprint.', 422);
            }
            $reference = (string) $verified['reference'];
        }
        if ($reference === '') {
            throw new AuthException('Scan a ticket or enter a booking reference.', 422);
        }

        $statement = $this->database->prepare('SELECT * FROM smartbus_bookings WHERE booking_reference = :reference');
        $statement->execute(['reference' => $reference]);
        $booking = $statement->fetch();
        if (!is_array($booking)) {
            throw new AuthException('No booking matches that reference on this trip.', 404);
        }
        if ((string) $booking['trip_id'] !== $tripId) {
            // Same ticket, different bus: this is the mistake that must never
            // pass silently.
            throw new AuthException('This ticket belongs to a different trip.', 409);
        }
        if ($seat !== null && $seat !== '' && (int) $booking['seat_number'] !== (int) $seat) {
            throw new AuthException('The seat does not match this ticket.', 409);
        }
        if ($payload !== '') {
            $verified = TicketSigner::verify($payload);
            if ($verified['seatNumber'] !== null && $verified['seatNumber'] !== (int) $booking['seat_number']) {
                throw new AuthException('The ticket seat does not match the booking.', 409);
            }
            $this->legacyTicketWarning = !$verified['signed'];
        }

        return $booking;
    }

    /** A trip only boards while it is scheduled and before it leaves. */
    private function assertTripAcceptsBoarding(array $trip): void
    {
        if (in_array((string) $trip['status'], ['CANCELLED', 'COMPLETED', 'DEPARTED'], true) || $trip['departed_at'] !== null) {
            throw new AuthException('This trip is not accepting passengers.', 409);
        }
    }

    private function isPaid(string $bookingId): bool
    {
        $statement = $this->database->prepare(
            "SELECT COUNT(*) FROM finance_transactions WHERE smartbus_booking_id = :id AND status = 'RECONCILED'"
        );
        $statement->execute(['id' => $bookingId]);

        return (int) $statement->fetchColumn() > 0;
    }

    private function cancelled(string $bookingId): bool
    {
        $statement = $this->database->prepare('SELECT status FROM smartbus_bookings WHERE id = :id');
        $statement->execute(['id' => $bookingId]);

        return in_array((string) $statement->fetchColumn(), ['CANCELLED', 'REFUNDED'], true);
    }

    /** Move the manifest state forward, in a transaction, and audit it. */
    private function transition(array $booking, string $target, array $actor, Request $request, array $context): void
    {
        $from = $this->state($booking);
        $allowed = self::ALLOWED[$from] ?? [];
        if (!in_array($target, $allowed, true)) {
            throw new AuthException("A passenger cannot move from {$from} to {$target}.", 409);
        }

        $this->database->beginTransaction();
        try {
            $sql = match ($target) {
                'CHECKED_IN' => "UPDATE smartbus_bookings SET manifest_status = 'CHECKED_IN', check_in_at = UTC_TIMESTAMP(6) WHERE id = :id AND check_in_at IS NULL",
                'BOARDED' => "UPDATE smartbus_bookings SET manifest_status = 'BOARDED', boarded_at = UTC_TIMESTAMP(6), status = 'BOARDED' WHERE id = :id AND boarded_at IS NULL",
                'COMPLETED' => "UPDATE smartbus_bookings SET manifest_status = 'COMPLETED', completed_at = UTC_TIMESTAMP(6) WHERE id = :id",
                'NO_SHOW' => "UPDATE smartbus_bookings SET manifest_status = 'NO_SHOW', no_show_at = UTC_TIMESTAMP(6) WHERE id = :id AND no_show_at IS NULL",
                'CANCELLED' => "UPDATE smartbus_bookings SET manifest_status = 'CANCELLED', cancelled_at = UTC_TIMESTAMP(6) WHERE id = :id",
                default => 'UPDATE smartbus_bookings SET manifest_status = :state WHERE id = :id',
            };
            $affected = $this->database->prepare($sql);
            // Native prepared statements reject a bound parameter the SQL does
            // not use, so :state is only bound on the fallback statement.
            $affected->execute($target === 'CONFIRMED' ? ['id' => $booking['id'], 'state' => $target] : ['id' => $booking['id']]);
            if ($affected->rowCount() === 0) {
                throw new AuthException('This passenger was already updated by someone else.', 409);
            }
            $this->database->commit();
        } catch (\Throwable $error) {
            if ($this->database->inTransaction()) {
                $this->database->rollBack();
            }
            throw $error;
        }

        (new AuditLog($this->database))->write(
            match ($target) {
                'CHECKED_IN' => 'PASSENGER_CHECKED_IN',
                'BOARDED' => 'PASSENGER_BOARDED',
                'NO_SHOW' => 'PASSENGER_NO_SHOW',
                'COMPLETED' => 'PASSENGER_COMPLETED',
                default => 'PASSENGER_STATE_CHANGED',
            },
            'Booking',
            $booking['id'],
            $actor,
            $request,
            ['manifestStatus' => $from],
            ['manifestStatus' => $target],
            ['source' => 'manifest', 'tripId' => $booking['trip_id'], 'seatNumber' => (int) $booking['seat_number']] + $context
        );
    }

    /** A boarded passenger starts an active journey for the rescue chain. */
    private function openJourney(array $booking): void
    {
        $trip = $this->database->prepare(<<<'SQL'
            SELECT t.id AS trip_id, t.vehicle_id, t.route_id, v.operator_id
            FROM smartbus_trips t JOIN smartbus_vehicles v ON v.id = t.vehicle_id WHERE t.id = :id
            SQL);
        $trip->execute(['id' => $booking['trip_id']]);
        $tripRow = $trip->fetch();
        if (!is_array($tripRow)) {
            return;
        }

        $this->database->prepare(<<<'SQL'
            INSERT INTO active_journeys
                (id, trip_id, booking_id, user_id, subscriber_id, rescue_code_id, vehicle_id, operator_id, route_id,
                 seat_number, status, rescue_coverage_status, checked_in_at, boarded_at)
            VALUES
                (:id, :trip, :booking, :user, :subscriber, :code, :vehicle, :operator, :route, :seat, 'ACTIVE',
                 :coverage, :checkedIn, UTC_TIMESTAMP(6))
            ON DUPLICATE KEY UPDATE boarded_at = UTC_TIMESTAMP(6), status = 'ACTIVE'
            SQL)->execute([
            'id' => \Mamore\Core\Uuid::v4(),
            'trip' => $booking['trip_id'],
            'booking' => $booking['id'],
            'user' => $booking['user_id'],
            'subscriber' => $booking['subscriber_id'],
            'code' => $booking['rescue_code_id'],
            'vehicle' => $tripRow['vehicle_id'],
            'operator' => $tripRow['operator_id'],
            'route' => $tripRow['route_id'],
            'seat' => (int) $booking['seat_number'],
            'coverage' => (float) $booking['rescue_fee_usd'] > 0 ? 'ACTIVE' : 'INACTIVE',
            'checkedIn' => $booking['check_in_at'],
        ]);
    }

    /** @return array<string,mixed> */
    private function bookingSummary(array $booking): array
    {
        return [
            'id' => $booking['id'],
            'reference' => $booking['booking_reference'],
            'passengerName' => $booking['passenger_name'],
            'seatNumber' => (int) $booking['seat_number'],
            'tripId' => $booking['trip_id'],
            'manifestStatus' => $this->state($booking),
            'checkInAt' => $booking['check_in_at'],
            'boardedAt' => $booking['boarded_at'],
            'noShowAt' => $booking['no_show_at'],
            'completedAt' => $booking['completed_at'],
        ];
    }

    private function required(array $input, string $key, string $label): string
    {
        $value = is_string($input[$key] ?? null) ? trim($input[$key]) : '';
        if ($value === '') {
            throw new AuthException("{$label} is required.", 422);
        }

        return $value;
    }
}
