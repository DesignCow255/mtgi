<?php

declare(strict_types=1);

namespace Mamore\SmartBus;

use Mamore\Auth\AuthException;
use DateTimeImmutable;
use DateTimeZone;

/**
 * Boarding windows (Feature Group C).
 *
 * Departure is the single fact the existing model stores. Everything a passenger
 * needs around it - report by, boarding opens, boarding closes - is derived from
 * the operator's defaults, stored on the trip so it is auditable, and never
 * recalculated at read time. All values are UTC; comparisons use the server
 * clock, never the browser's.
 */
final class BoardingWindow
{
    public const PHASE_NOT_STARTED = 'REPORTING_OPEN';
    public const PHASE_BOARDING = 'BOARDING';
    public const PHASE_BOARDING_CLOSING = 'BOARDING_CLOSING';
    public const PHASE_BOARDING_CLOSED = 'BOARDING_CLOSED';
    public const PHASE_DEPARTED = 'DEPARTED';
    public const PHASE_FINISHED = 'FINISHED';
    public const PHASE_CANCELLED = 'CANCELLED';
    public const PHASE_UNKNOWN = 'UNKNOWN';

    /**
     * Derive the window timestamps for a trip.
     *
     * @param array<string,mixed> $operator row from smartbus_operators
     * @param array<string,mixed> $overrides per-trip overrides in minutes
     *
     * @return array{reporting_at:string,boarding_opens_at:string,boarding_closes_at:string}
     */
    public static function derive(string $departureAt, array $operator, array $overrides = []): array
    {
        $departure = self::parse($departureAt);

        $reportMinutes = self::minutes($overrides['reportingMinutesBefore'] ?? $operator['reporting_minutes_before_departure'] ?? 45);
        $openMinutes = self::minutes($overrides['boardingOpenMinutesBefore'] ?? $operator['boarding_open_minutes_before_departure'] ?? 20);
        $closeMinutes = self::minutes($overrides['boardingCloseMinutesBefore'] ?? $operator['boarding_close_minutes_before_departure'] ?? 10);

        // A window that closes before it opens is a data error, not a schedule:
        // ordering is enforced rather than silently producing nonsense.
        if ($closeMinutes >= $openMinutes) {
            $closeMinutes = max(1, $openMinutes - 1);
        }
        if ($openMinutes >= $reportMinutes) {
            $openMinutes = max(1, $reportMinutes - 1);
        }

        return [
            'reporting_at' => $departure->modify("-{$reportMinutes} minutes")->format('Y-m-d H:i:s.u'),
            'boarding_opens_at' => $departure->modify("-{$openMinutes} minutes")->format('Y-m-d H:i:s.u'),
            'boarding_closes_at' => $departure->modify("-{$closeMinutes} minutes")->format('Y-m-d H:i:s.u'),
        ];
    }

    /**
     * Server-side phase of a trip, plus a human message and a countdown.
     *
     * @param array<string,mixed> $trip row from smartbus_trips
     *
     * @return array<string,mixed>
     */
    public static function phase(array $trip, ?DateTimeImmutable $now = null): array
    {
        $now ??= new DateTimeImmutable('@' . time());
        $status = strtoupper((string) $trip['status']);

        if ($status === 'CANCELLED') {
            return self::describe(self::PHASE_CANCELLED, 'This trip was cancelled.', null, $trip);
        }
        if (in_array($status, ['DEPARTED', 'COMPLETED'], true) || $trip['departed_at'] !== null) {
            return self::describe(self::PHASE_DEPARTED, 'This bus has departed.', null, $trip);
        }

        $closesAt = $trip['boarding_closes_at'] ?? null;
        $opensAt = $trip['boarding_opens_at'] ?? null;
        $reportsAt = $trip['reporting_at'] ?? null;
        if ($closesAt === null || $opensAt === null || $reportsAt === null) {
            // Historical trip without stored windows: departure is all we know.
            return self::describe(self::PHASE_UNKNOWN, 'Boarding times are not set for this trip.', null, $trip);
        }

        $closes = self::parse((string) $closesAt);
        $opens = self::parse((string) $opensAt);
        $reports = self::parse((string) $reportsAt);
        $departure = self::parse((string) $trip['departure_at']);

        if ($now >= $closes) {
            return self::describe(self::PHASE_BOARDING_CLOSED, 'Boarding has closed. The bus is about to leave.', null, $trip);
        }
        if ($now >= $opens) {
            return self::describe(
                self::PHASE_BOARDING,
                'Boarding is now open.',
                $closes->getTimestamp() - $now->getTimestamp(),
                $trip
            );
        }
        if ($now >= $reports) {
            return self::describe(
                self::PHASE_BOARDING_CLOSING,
                'Reporting time reached. Boarding opens shortly.',
                $opens->getTimestamp() - $now->getTimestamp(),
                $trip
            );
        }

        return self::describe(
            self::PHASE_NOT_STARTED,
            'Report to the station before boarding opens.',
            $reports->getTimestamp() - $now->getTimestamp(),
            $trip
        );
    }

    /**
     * Present a trip's timings for a passenger card.
     *
     * @param array<string,mixed> $trip
     *
     * @return array<string,mixed>
     */
    public static function present(array $trip): array
    {
        $phase = self::phase($trip);

        return [
            'departureAt' => $trip['departure_at'],
            'reportingAt' => $trip['reporting_at'] ?? null,
            'boardingOpensAt' => $trip['boarding_opens_at'] ?? null,
            'boardingClosesAt' => $trip['boarding_closes_at'] ?? null,
            'phase' => $phase['phase'],
            'message' => $phase['message'],
            'secondsRemaining' => $phase['secondsRemaining'],
            'countdown' => self::countdown($phase['secondsRemaining']),
        ];
    }

    /** HH:MM:SS countdown, never negative. */
    public static function countdown(?int $seconds): ?string
    {
        if ($seconds === null || $seconds < 0) {
            return null;
        }
        $hours = intdiv($seconds, 3600);
        $minutes = intdiv($seconds % 3600, 60);

        return sprintf('%02d:%02d:%02d', $hours, $minutes, $seconds % 60);
    }

    /** @return array{phase:string,message:string,secondsRemaining:?int} */
    private static function describe(string $phase, string $message, ?int $remaining, array $trip): array
    {
        return [
            'phase' => $phase,
            'message' => $message,
            'secondsRemaining' => $remaining !== null && $remaining > 0 ? $remaining : null,
        ];
    }

    private static function minutes(mixed $value): int
    {
        if (!is_numeric($value)) {
            return 0;
        }

        return max(1, min((int) $value, 1440));
    }

    /**
     * MySQL TIMESTAMP(6) strings carry microseconds, which strtotime() cannot
     * parse (it returns false, and false compares as 0 - which previously made
     * every one-time code look expired).
     */
    private static function parse(string $value): DateTimeImmutable
    {
        $timezone = new DateTimeZone('UTC');
        foreach (['!Y-m-d H:i:s.u', '!Y-m-d H:i:s', '!Y-m-d\\TH:i:sP'] as $format) {
            $parsed = DateTimeImmutable::createFromFormat($format, $value, $timezone);
            if ($parsed instanceof DateTimeImmutable) {
                return $parsed;
            }
        }
        try {
            return new DateTimeImmutable($value, $timezone);
        } catch (\Throwable $error) {
            throw new AuthException('A trip timestamp could not be read.', 500);
        }
    }
}
