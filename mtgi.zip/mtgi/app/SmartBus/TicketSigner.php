<?php

declare(strict_types=1);

namespace Mamore\SmartBus;

use Mamore\Core\Config;
use Mamore\Core\Env;

/**
 * Signs and verifies the Smart Bus ticket payload.
 *
 * The historical payload is plaintext: MAMORE|<reference>|<trip_code>|SEAT-<n>.
 * Signed tickets append a fifth segment, HMAC-SHA256 over the first four, so a
 * scan cannot be forged or altered. Legacy payloads still verify, but they are
 * reported as unsigned so the caller can decide (check-in accepts them for
 * historical bookings, everything else warns).
 */
final class TicketSigner
{
    public const LEGACY_SEGMENTS = 4;
    public const SIGNED_SEGMENTS = 5;

    /** @return array{valid:bool,signed:bool,reference:?string,tripCode:?string,seatNumber:?int,reason:?string} */
    public static function verify(string $payload): array
    {
        $parts = explode('|', trim($payload));
        if (count($parts) < self::LEGACY_SEGMENTS) {
            return self::invalid('malformed_payload');
        }
        if ($parts[0] !== 'MAMORE') {
            return self::invalid('unknown_issuer');
        }

        $reference = $parts[1];
        $tripCode = $parts[2];
        $seat = str_starts_with($parts[3], 'SEAT-') ? (int) substr($parts[3], 5) : 0;
        if ($reference === '' || $tripCode === '' || $seat < 1) {
            return self::invalid('malformed_payload');
        }

        if (count($parts) === self::LEGACY_SEGMENTS) {
            return [
                'valid' => true, 'signed' => false, 'reference' => $reference,
                'tripCode' => $tripCode, 'seatNumber' => $seat, 'reason' => null,
            ];
        }
        if (count($parts) !== self::SIGNED_SEGMENTS) {
            return self::invalid('malformed_payload');
        }

        $expected = self::sign(implode('|', array_slice($parts, 0, self::LEGACY_SEGMENTS)));
        if (!hash_equals($expected, strtoupper($parts[4]))) {
            return self::invalid('bad_signature');
        }

        return [
            'valid' => true, 'signed' => true, 'reference' => $reference,
            'tripCode' => $tripCode, 'seatNumber' => $seat, 'reason' => null,
        ];
    }

    /** Build a signed payload for a new ticket. */
    public static function payload(string $reference, string $tripCode, int $seatNumber): string
    {
        $base = implode('|', ['MAMORE', $reference, $tripCode, 'SEAT-' . $seatNumber]);

        return $base . '|' . self::sign($base);
    }

    private static function sign(string $base): string
    {
        return strtoupper(substr(hash_hmac('sha256', $base, self::secret()), 0, 32));
    }

    private static function secret(): string
    {
        $configured = Env::get('TICKET_SIGNING_KEY', '');
        if ($configured !== '') {
            return $configured;
        }

        // Stable per-installation fallback so local development can verify its own
        // tickets; production must set TICKET_SIGNING_KEY explicitly.
        return Config::get('app.key', 'mamore-local-ticket-key');
    }

    /** @return array{valid:false,signed:bool,reference:null,tripCode:null,seatNumber:null,reason:string} */
    private static function invalid(string $reason): array
    {
        return [
            'valid' => false, 'signed' => false, 'reference' => null,
            'tripCode' => null, 'seatNumber' => null, 'reason' => $reason,
        ];
    }
}
