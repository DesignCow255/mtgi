<?php

declare(strict_types=1);

namespace Mamore\SmartBus;

use Mamore\Auth\AuthException;
use Mamore\Core\Uuid;
use PDO;
use PDOException;

final class SmartBusService
{
    public function __construct(private readonly PDO $database) {}

    public function board(): array
    {
        $trips = $this->database->query(<<<'SQL'
            SELECT t.*, r.code AS route_code, r.origin, r.destination, r.country_code, r.province,
                   v.code AS vehicle_code, v.capacity, v.make, v.model, v.registration_number,
                   v.has_air_conditioning, v.gps_enabled, v.verification_status AS vehicle_verification,
                   o.id AS operator_id, o.name AS operator_name, o.verification_status AS operator_verification,
                   (SELECT COUNT(*) FROM smartbus_bookings b WHERE b.trip_id = t.id AND b.status IN ('CONFIRMED','BOARDED')) AS booked_seats
            FROM smartbus_trips t JOIN smartbus_routes r ON r.id = t.route_id
            JOIN smartbus_vehicles v ON v.id = t.vehicle_id JOIN smartbus_operators o ON o.id = v.operator_id
            ORDER BY t.departure_at ASC LIMIT 50
            SQL)->fetchAll();
        foreach ($trips as &$trip) {
            $statement = $this->database->prepare("SELECT seat_number FROM smartbus_bookings WHERE trip_id = :id AND status IN ('CONFIRMED','BOARDED') ORDER BY seat_number");
            $statement->execute(['id' => $trip['id']]);
            $trip['occupied_seats'] = array_map('intval', $statement->fetchAll(PDO::FETCH_COLUMN));
        }
        unset($trip);
        return [
            'trips' => array_map([$this, 'trip'], $trips),
            'routes' => $this->database->query("SELECT id, code, origin, destination, base_fare_cdf, rescue_fee_usd FROM smartbus_routes WHERE status = 'ACTIVE' ORDER BY origin, destination")->fetchAll(),
            'vehicles' => $this->database->query("SELECT v.id, v.code, v.registration_number, v.capacity, o.name AS operator_name FROM smartbus_vehicles v JOIN smartbus_operators o ON o.id = v.operator_id WHERE v.status = 'ACTIVE' ORDER BY o.name, v.code")->fetchAll(),
            'operators' => $this->database->query("SELECT id, code, name FROM smartbus_operators WHERE status = 'ACTIVE' ORDER BY name")->fetchAll(),
        ];
    }

    public function schedule(array $input, array $actor): array
    {
        $routeId = $this->required($input, 'routeId', 'Route');
        $vehicleId = $this->required($input, 'vehicleId', 'Vehicle');
        $departure = $this->required($input, 'departureAt', 'Departure time');
        $rate = $this->positiveNumber($input['usdCdfRate'] ?? null, 'USD/CDF exchange rate');
        $route = $this->one('SELECT * FROM smartbus_routes WHERE id = :id AND status = \'ACTIVE\'', $routeId, 'Route');
        $vehicle = $this->one('SELECT * FROM smartbus_vehicles WHERE id = :id AND status = \'ACTIVE\'', $vehicleId, 'Vehicle');
        try { $date = new \DateTimeImmutable($departure); } catch (\Throwable) { throw new AuthException('Enter a valid departure date and time.', 422); }
        if ($date <= new \DateTimeImmutable('now')) throw new AuthException('Departure must be in the future.', 422);
        $id = Uuid::v4(); $code = 'TRP-' . gmdate('ymd') . '-' . strtoupper(bin2hex(random_bytes(3)));
        $departureUtc = $date->setTimezone(new \DateTimeZone('UTC'))->format('Y-m-d H:i:s.u');
        // The reporting and boarding windows are derived once, from the operator's
        // own defaults, and stored on the trip so they stay auditable and can be
        // overridden per trip. Nothing is recalculated at read time.
        $operator = $this->one('SELECT * FROM smartbus_operators WHERE id = :id', (string) $vehicle['operator_id'], 'Operator');
        $window = BoardingWindow::derive($departureUtc, $operator, array_filter([
            'reportingMinutesBefore' => $input['reportingMinutesBefore'] ?? null,
            'boardingOpenMinutesBefore' => $input['boardingOpenMinutesBefore'] ?? null,
            'boardingCloseMinutesBefore' => $input['boardingCloseMinutesBefore'] ?? null,
        ], static fn (mixed $value): bool => $value !== null && $value !== ''));
        $statement = $this->database->prepare(<<<'SQL'
            INSERT INTO smartbus_trips
                (id, trip_code, route_id, vehicle_id, departure_at, reporting_at, boarding_opens_at, boarding_closes_at,
                 fare_cdf, rescue_fee_usd, usd_cdf_rate, created_by_user_id)
            VALUES
                (:id, :code, :route, :vehicle, :departure, :reporting, :opens, :closes, :fare, :rescue_fee, :rate, :actor)
            SQL);
        $statement->execute(['id' => $id, 'code' => $code, 'route' => $routeId, 'vehicle' => $vehicleId, 'departure' => $departureUtc, 'reporting' => $window['reporting_at'], 'opens' => $window['boarding_opens_at'], 'closes' => $window['boarding_closes_at'], 'fare' => $route['base_fare_cdf'], 'rescue_fee' => $route['rescue_fee_usd'], 'rate' => $rate, 'actor' => $actor['id']]);
        return $this->findTrip($id);
    }

    public function book(array $input, array $actor): array
    {
        $tripId = $this->required($input, 'tripId', 'Trip');
        $name = $this->required($input, 'passengerName', 'Passenger name');
        $phone = $this->required($input, 'passengerPhone', 'Passenger phone');
        $seat = filter_var($input['seatNumber'] ?? null, FILTER_VALIDATE_INT);
        $this->database->beginTransaction();
        try {
            $trip = $this->one(<<<'SQL'
                SELECT t.*, v.capacity FROM smartbus_trips t JOIN smartbus_vehicles v ON v.id = t.vehicle_id
                WHERE t.id = :id FOR UPDATE
                SQL, $tripId, 'Trip');
            if (!in_array($trip['status'], ['SCHEDULED', 'BOARDING'], true)) throw new AuthException('This trip is not accepting bookings.', 409);
            if ($seat === false || $seat < 1 || $seat > (int) $trip['capacity']) throw new AuthException('Select a valid seat.', 422);
            $rescueCdf = round((float) $trip['rescue_fee_usd'] * (float) $trip['usd_cdf_rate'], 2);
            $total = (float) $trip['fare_cdf'] + $rescueCdf;
            $id = Uuid::v4(); $reference = 'MB-' . strtoupper(bin2hex(random_bytes(4)));
            $qr = implode('|', ['MAMORE', $reference, $trip['trip_code'], 'SEAT-' . $seat]);
            $statement = $this->database->prepare(<<<'SQL'
                INSERT INTO smartbus_bookings
                    (id, booking_reference, trip_id, seat_number, passenger_name, passenger_phone, fare_cdf, rescue_fee_usd, rescue_fee_cdf, total_cdf, qr_payload, created_by_user_id)
                VALUES (:id, :reference, :trip, :seat, :name, :phone, :fare, :rescue_usd, :rescue_cdf, :total, :qr, :actor)
                SQL);
            $statement->execute(['id' => $id, 'reference' => $reference, 'trip' => $tripId, 'seat' => $seat, 'name' => $name, 'phone' => $phone, 'fare' => $trip['fare_cdf'], 'rescue_usd' => $trip['rescue_fee_usd'], 'rescue_cdf' => $rescueCdf, 'total' => $total, 'qr' => $qr, 'actor' => $actor['id']]);
            $this->database->commit();
        } catch (PDOException $error) {
            $this->database->rollBack();
            if ((string) $error->getCode() === '23000') throw new AuthException('That seat has already been booked.', 409);
            throw $error;
        } catch (\Throwable $error) { $this->database->rollBack(); throw $error; }
        return ['id' => $id, 'reference' => $reference, 'tripCode' => $trip['trip_code'], 'seatNumber' => $seat, 'passengerName' => $name, 'fareCdf' => (float) $trip['fare_cdf'], 'rescueFeeUsd' => (float) $trip['rescue_fee_usd'], 'rescueFeeCdf' => $rescueCdf, 'totalCdf' => $total, 'qrPayload' => $qr, 'status' => 'CONFIRMED'];
    }

    private function findTrip(string $id): array
    {
        $statement = $this->database->prepare(<<<'SQL'
            SELECT t.*, r.code AS route_code, r.origin, r.destination, r.country_code, r.province,
                   v.code AS vehicle_code, v.capacity, v.make, v.model, v.registration_number,
                   v.has_air_conditioning, v.gps_enabled, v.verification_status AS vehicle_verification,
                   o.id AS operator_id, o.name AS operator_name, o.verification_status AS operator_verification, 0 AS booked_seats
            FROM smartbus_trips t JOIN smartbus_routes r ON r.id = t.route_id JOIN smartbus_vehicles v ON v.id = t.vehicle_id
            JOIN smartbus_operators o ON o.id = v.operator_id WHERE t.id = :id
            SQL);
        $statement->execute(['id' => $id]); $trip = $statement->fetch();
        if (!is_array($trip)) throw new AuthException('Trip not found.', 404);
        $trip['occupied_seats'] = [];
        return $this->trip($trip);
    }

    private function trip(array $row): array
    {
        return ['id' => $row['id'], 'code' => $row['trip_code'], 'routeCode' => $row['route_code'], 'origin' => $row['origin'], 'destination' => $row['destination'], 'vehicleCode' => $row['vehicle_code'], 'operatorName' => $row['operator_name'],
        'vehicle' => [
            'code' => $row['vehicle_code'], 'plate' => $row['registration_number'] ?? null,
            'make' => $row['make'] ?? null, 'model' => $row['model'] ?? null,
            'airConditioning' => (bool) ($row['has_air_conditioning'] ?? false),
            'gps' => (bool) ($row['gps_enabled'] ?? false),
            'verified' => ($row['vehicle_verification'] ?? 'PENDING') === 'VERIFIED',
        ],
        'operatorVerification' => $row['operator_verification'] ?? 'PENDING',
        'countryCode' => $row['country_code'] ?? null, 'province' => $row['province'] ?? null,
        // A badge is only shown when the backend proves it.
        'badges' => [
            'rescueProtected' => true,
            'liveGps' => (bool) ($row['gps_enabled'] ?? false),
            'verifiedOperator' => ($row['operator_verification'] ?? '') === 'VERIFIED',
            'verifiedBus' => ($row['vehicle_verification'] ?? '') === 'VERIFIED',
        ], 'capacity' => (int) $row['capacity'], 'bookedSeats' => (int) $row['booked_seats'], 'occupiedSeats' => $row['occupied_seats'], 'departureAt' => $row['departure_at'], 'reportingAt' => $row['reporting_at'] ?? null,
        'boardingOpensAt' => $row['boarding_opens_at'] ?? null, 'boardingClosesAt' => $row['boarding_closes_at'] ?? null,
        'boarding' => BoardingWindow::present($row), 'fareCdf' => (float) $row['fare_cdf'], 'rescueFeeUsd' => (float) $row['rescue_fee_usd'], 'usdCdfRate' => (float) $row['usd_cdf_rate'], 'status' => $row['status']];
    }

    private function one(string $sql, string $id, string $label): array { $statement = $this->database->prepare($sql); $statement->execute(['id' => $id]); $row = $statement->fetch(); if (!is_array($row)) throw new AuthException("{$label} not found.", 404); return $row; }
    private function required(array $input, string $key, string $label): string { $value = is_string($input[$key] ?? null) ? trim($input[$key]) : ''; if ($value === '') throw new AuthException("{$label} is required.", 422); return $value; }
    private function positiveNumber(mixed $value, string $label): float { if (!is_numeric($value) || (float) $value <= 0) throw new AuthException("Enter a valid {$label}.", 422); return (float) $value; }
}
