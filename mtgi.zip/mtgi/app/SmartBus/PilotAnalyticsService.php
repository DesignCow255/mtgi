<?php

declare(strict_types=1);

namespace Mamore\SmartBus;

use Mamore\Auth\AuthException;
use Mamore\Core\ServerClock;
use DateTimeImmutable;
use DateTimeZone;
use PDO;

/**
 * Smart Bus pilot command centre and executive analytics (Feature Groups Y, Z).
 *
 * Every figure is an aggregate over real tables. When a source has no rows the
 * answer is "No data available", never a zero that looks like a real result and
 * never a made-up trend. Filters are always bound as PDO parameters - never
 * interpolated into SQL text.
 */
final class PilotAnalyticsService
{
    public function __construct(private readonly PDO $database) {}

    /**
     * KPI header for the pilot dashboard.
     *
     * @param array<string,mixed> $filters
     * @return array<string,mixed>
     */
    public function summary(array $filters = []): array
    {
        $metrics = [
            'registeredPassengers' => $this->bookingMetric($filters, 'COUNT(DISTINCT b.passenger_phone)'),
            'activeSubscribers' => $this->bookingMetric($filters, 'COUNT(DISTINCT b.subscriber_id)', 'b.subscriber_id IS NOT NULL'),
            'vipPassengers' => $this->bookingMetric($filters, 'COUNT(*)', 'b.vip_at_booking = 1'),
            'bookings' => $this->bookingMetric($filters, 'COUNT(*)'),
            'ticketsIssued' => $this->bookingMetric($filters, 'COUNT(*)'),
            'checkedIn' => $this->bookingMetric($filters, 'COUNT(*)', 'b.check_in_at IS NOT NULL'),
            'boarded' => $this->bookingMetric($filters, 'COUNT(*)', "b.manifest_status = 'BOARDED'"),
            'noShows' => $this->bookingMetric($filters, 'COUNT(*)', "b.manifest_status = 'NO_SHOW'"),
            'rescueProtectedBookings' => $this->bookingMetric($filters, 'COUNT(*)', 'b.rescue_fee_usd > 0'),
            'trips' => $this->tripMetric($filters, 'COUNT(*)'),
            'liveTrips' => $this->tripMetric($filters, 'COUNT(*)', "t.status IN ('BOARDING', 'DEPARTED', 'DELAYED')"),
            'completedTrips' => $this->tripMetric($filters, 'COUNT(*)', "t.status = 'COMPLETED'"),
            'cancelledTrips' => $this->tripMetric($filters, 'COUNT(*)', "t.status = 'CANCELLED'"),
            'delayedTrips' => $this->tripMetric($filters, 'COUNT(*)', 't.delay_minutes > 0'),
        ];
        $metrics['operators'] = $this->scalar("SELECT COUNT(*) FROM smartbus_operators WHERE status = 'ACTIVE'");
        $metrics['verifiedOperators'] = $this->scalar("SELECT COUNT(*) FROM smartbus_operators WHERE status = 'ACTIVE' AND verification_status = 'VERIFIED'");
        $metrics['activeBuses'] = $this->scalar("SELECT COUNT(*) FROM smartbus_vehicles WHERE status = 'ACTIVE'");
        $metrics['gpsEnabledBuses'] = $this->scalar("SELECT COUNT(*) FROM smartbus_vehicles WHERE status = 'ACTIVE' AND gps_enabled = 1");
        $metrics['rescueCodesIssued'] = $this->scalar('SELECT COUNT(*) FROM rescue_codes');
        $metrics['rescueProtectedTrips'] = $this->bookingMetric($filters, 'COUNT(DISTINCT b.trip_id)', 'b.rescue_fee_usd > 0');
        $metrics['incidents'] = $this->scalar('SELECT COUNT(*) FROM rescue_incidents');
        $metrics['smartBusIncidents'] = $this->scalar('SELECT COUNT(*) FROM rescue_incidents WHERE smartbus_trip_id IS NOT NULL');

        $fares = $this->bookingSum($filters, 'COALESCE(SUM(b.fare_cdf), 0)');
        $rescueFees = $this->bookingSum($filters, 'COALESCE(SUM(b.rescue_fee_cdf), 0)');
        $paid = $this->bookingMetric(
            $filters,
            'COUNT(*)',
            "f.status = 'RECONCILED'",
            'JOIN finance_transactions f ON f.smartbus_booking_id = b.id'
        );
        $bookings = $metrics['bookings'];
        $occupancy = $this->occupancy($filters);

        return [
            'metrics' => $metrics,
            'revenue' => ['fareCdf' => $fares, 'rescueFeeCdf' => $rescueFees, 'totalCdf' => bcadd($fares, $rescueFees, 2)],
            'rates' => [
                // A zero denominator means "no data available", not 0%.
                'paymentSuccessRate' => $this->rate($paid, $bookings),
                'boardRate' => $this->rate($metrics['boarded'], $bookings),
                'noShowRate' => $this->rate($metrics['noShows'], $bookings),
                'gpsCoverageRate' => $this->rate($metrics['gpsEnabledBuses'], $metrics['activeBuses']),
                'digitalBookingRate' => $this->rate(
                    $this->bookingMetric($filters, 'COUNT(*)', 'b.user_id IS NOT NULL'),
                    $bookings
                ),
                'operatorVerificationRate' => $this->rate($metrics['verifiedOperators'], $metrics['operators']),
            ],
            'occupancy' => $occupancy,
            'emptyData' => $bookings === 0 && $metrics['trips'] === 0,
            'message' => $bookings === 0 && $metrics['trips'] === 0 ? 'No data available.' : null,
            'generatedAt' => gmdate('c', ServerClock::epoch($this->database)),
        ];
    }

    /**
     * The executive questions from Feature Group Z, each answered from real rows.
     *
     * @param array<string,mixed> $filters
     * @return array<string,mixed>
     */
    public function insights(array $filters = []): array
    {
        return [
            'busiestRoutes' => $this->report(
                'SELECT r.code, r.origin, r.destination, COUNT(b.id) AS passengers, COALESCE(SUM(b.fare_cdf), 0) AS revenue_cdf
                 FROM smartbus_bookings b
                 JOIN smartbus_trips t ON t.id = b.trip_id
                 JOIN smartbus_routes r ON r.id = t.route_id
                 WHERE b.status <> :cancelled ' . $this->tripFilterSql($filters) . '
                 GROUP BY r.id, r.code, r.origin, r.destination ORDER BY passengers DESC LIMIT 10',
                ['cancelled' => 'CANCELLED'] + $this->tripFilterParams($filters),
                'routesByPassengers'
            ),
            'operatorBookings' => $this->report(
                'SELECT o.name, COUNT(b.id) AS bookings
                 FROM smartbus_bookings b
                 JOIN smartbus_trips t ON t.id = b.trip_id
                 JOIN smartbus_vehicles v ON v.id = t.vehicle_id
                 JOIN smartbus_operators o ON o.id = v.operator_id
                 WHERE b.status <> :cancelled ' . $this->tripFilterSql($filters) . '
                 GROUP BY o.id, o.name ORDER BY bookings DESC LIMIT 10',
                ['cancelled' => 'CANCELLED'] + $this->tripFilterParams($filters),
                'operatorsByBookings'
            ),
            'poorOccupancy' => $this->report(
                'SELECT t.trip_code, v.capacity, COUNT(b.id) AS booked,
                        ROUND(COUNT(b.id) / NULLIF(v.capacity, 0), 2) AS occupancy
                 FROM smartbus_trips t
                 JOIN smartbus_vehicles v ON v.id = t.vehicle_id
                 LEFT JOIN smartbus_bookings b ON b.trip_id = t.id AND b.status <> :cancelled
                 WHERE 1 = 1 ' . $this->tripFilterSql($filters) . '
                 GROUP BY t.id, t.trip_code, v.capacity
                 HAVING booked > 0 AND occupancy < 0.4
                 ORDER BY occupancy ASC LIMIT 10',
                ['cancelled' => 'CANCELLED'] + $this->tripFilterParams($filters),
                'tripsUnderFortyPercentFull'
            ),
            'lateTrips' => $this->report(
                'SELECT t.trip_code, t.delay_minutes, r.origin, r.destination
                 FROM smartbus_trips t JOIN smartbus_routes r ON r.id = t.route_id
                 WHERE t.delay_minutes > 0 ' . $this->tripFilterSql($filters) . '
                 ORDER BY t.delay_minutes DESC LIMIT 10',
                $this->tripFilterParams($filters),
                'tripsWithDelay'
            ),
            'noShowHotspots' => $this->report(
                "SELECT r.code, r.origin, COUNT(b.id) AS no_shows
                 FROM smartbus_bookings b
                 JOIN smartbus_trips t ON t.id = b.trip_id
                 JOIN smartbus_routes r ON r.id = t.route_id
                 WHERE b.manifest_status = 'NO_SHOW' " . $this->tripFilterSql($filters) . '
                 GROUP BY r.id, r.code, r.origin ORDER BY no_shows DESC LIMIT 10',
                $this->tripFilterParams($filters),
                'routesWithMostNoShows'
            ),
            'incidentRateByRoute' => $this->report(
                'SELECT r.code, r.origin, COUNT(DISTINCT t.id) AS trips, COUNT(i.id) AS incidents,
                        ROUND(COUNT(i.id) / NULLIF(COUNT(DISTINCT t.id), 0), 3) AS incidents_per_trip
                 FROM smartbus_routes r
                 LEFT JOIN smartbus_trips t ON t.route_id = r.id
                 LEFT JOIN rescue_incidents i ON i.smartbus_trip_id = t.id
                 GROUP BY r.id, r.code, r.origin HAVING trips > 0 ORDER BY incidents_per_trip DESC LIMIT 10',
                [],
                'incidentRatePerRoute'
            ),
            'weakRescueCoverage' => $this->report(
                "SELECT r.code, r.origin, r.province,
                        (SELECT COUNT(*) FROM rescue_units u WHERE u.status = 'AVAILABLE'
                           AND (r.province IS NULL OR u.province = r.province)) AS available_units,
                        (SELECT COUNT(*) FROM service_locations l WHERE l.location_type = 'HOSPITAL'
                           AND l.status = 'ACTIVE' AND (r.province IS NULL OR l.province = r.province)) AS hospitals
                 FROM smartbus_routes r WHERE r.status = 'ACTIVE'
                 ORDER BY available_units ASC, hospitals ASC LIMIT 10",
                [],
                'routesByAvailableRescueAssets'
            ),
            'gpsHealth' => $this->report(
                "SELECT o.name AS operator, COUNT(v.id) AS buses, SUM(v.gps_enabled = 1) AS with_gps
                 FROM smartbus_operators o
                 JOIN smartbus_vehicles v ON v.operator_id = o.id AND v.status = 'ACTIVE'
                 GROUP BY o.id, o.name ORDER BY with_gps ASC LIMIT 10",
                [],
                'operatorsByGpsCoverage'
            ),
        ];
    }

    /**
     * Rescue response times, or "No data available" when there is nothing to
     * average. No synthetic default is substituted.
     *
     * @return array<string,mixed>
     */
    public function rescueResponse(): array
    {
        $row = $this->database->query(<<<'SQL'
            SELECT COUNT(*) AS incidents,
                   AVG(TIMESTAMPDIFF(MINUTE, reported_at, dispatched_at)) AS avg_dispatch_minutes,
                   AVG(TIMESTAMPDIFF(MINUTE, dispatched_at, arrived_at)) AS avg_arrive_minutes,
                   AVG(TIMESTAMPDIFF(MINUTE, reported_at, resolved_at)) AS avg_resolve_minutes
            FROM rescue_incidents
            WHERE reported_at >= DATE_SUB(UTC_DATE(), INTERVAL 30 DAY)
            SQL)->fetch() ?: [];

        $incidents = (int) ($row['incidents'] ?? 0);

        return [
            'window' => 'last 30 days',
            'incidents' => $incidents,
            'avgDispatchMinutes' => $this->roundOrNull($row['avg_dispatch_minutes'] ?? null),
            'avgArriveMinutes' => $this->roundOrNull($row['avg_arrive_minutes'] ?? null),
            'avgResolveMinutes' => $this->roundOrNull($row['avg_resolve_minutes'] ?? null),
            'message' => $incidents === 0 ? 'No data available.' : null,
        ];
    }

    // ------------------------------------------------------------- internals

    private function scalar(string $sql, array $params = []): int
    {
        $statement = $this->database->prepare($sql);
        $statement->execute($params);
        $value = $statement->fetchColumn();

        return is_numeric($value) ? (int) $value : 0;
    }

    /** @param array<string,mixed> $filters */
    private function tripMetric(array $filters, string $aggregate, string $extra = ''): int
    {
        $params = $this->tripFilterParams($filters);
        $where = $this->tripFilterSql($filters);
        if ($extra !== '') {
            $where = ($where === '' ? 'WHERE ' : $where . ' AND ') . $extra;
        }

        return $this->scalar('SELECT ' . $aggregate . ' FROM smartbus_trips t ' . $where, $params);
    }

    /**
     * @param array<string,mixed> $filters
     * @param string $join optional extra join (a table already joined to bookings)
     */
    private function bookingMetric(array $filters, string $aggregate, string $extra = '', string $join = ''): int
    {
        $params = $this->tripFilterParams($filters);
        $where = $this->tripFilterSql($filters);
        if ($extra !== '') {
            $where = ($where === '' ? 'WHERE ' : $where . ' AND ') . $extra;
        }
        $sql = 'SELECT ' . $aggregate . ' FROM smartbus_bookings b
                JOIN smartbus_trips t ON t.id = b.trip_id ' . $join . ' ' . $where;

        return $this->scalar($sql, $params);
    }

    /** @param array<string,mixed> $filters */
    private function bookingSum(array $filters, string $expression): string
    {
        $params = $this->tripFilterParams($filters);
        $statement = $this->database->prepare(
            'SELECT ' . $expression . ' FROM smartbus_bookings b JOIN smartbus_trips t ON t.id = b.trip_id '
            . $this->tripFilterSql($filters)
        );
        $statement->execute($params);
        $value = $statement->fetchColumn();

        return bcadd((string) $value, '0', 2);
    }

    /** @return array{rows:list<array<string,mixed>>,count:int,message:?string,chart:string} */
    private function report(string $sql, array $params, string $chart): array
    {
        try {
            $statement = $this->database->prepare($sql);
            $statement->execute($params);
            $rows = $statement->fetchAll();
        } catch (\Throwable) {
            return ['rows' => [], 'count' => 0, 'message' => 'No data available.', 'chart' => $chart];
        }

        return [
            'rows' => array_map([$this, 'castRow'], $rows),
            'count' => count($rows),
            'message' => $rows === [] ? 'No data available.' : null,
            'chart' => $chart,
        ];
    }

    /** @return array<string,mixed> */
    private function occupancy(array $filters): array
    {
        $params = $this->tripFilterParams($filters);
        $statement = $this->database->prepare(
            'SELECT COUNT(DISTINCT t.id) AS trips, COALESCE(SUM(v.capacity), 0) AS seats, COUNT(b.id) AS bookings
             FROM smartbus_trips t
             JOIN smartbus_vehicles v ON v.id = t.vehicle_id
             LEFT JOIN smartbus_bookings b ON b.trip_id = t.id AND b.status <> :cancelled '
            . $this->tripFilterSql($filters)
        );
        $params['cancelled'] = 'CANCELLED';
        $statement->execute($params);
        $row = $statement->fetch() ?: [];

        $trips = (int) ($row['trips'] ?? 0);
        $seats = (int) ($row['seats'] ?? 0);
        $booked = (int) ($row['bookings'] ?? 0);

        return [
            'trips' => $trips,
            'seatsOffered' => $seats,
            'seatsBooked' => $booked,
            'occupancyRate' => $this->rate($booked, $seats),
            'message' => $trips === 0 ? 'No data available.' : null,
        ];
    }

    /** @param array<string,mixed> $filters */
    private function tripFilterSql(array $filters): string
    {
        $clauses = [];
        foreach (['from' => '>=', 'to' => '<='] as $key => $operator) {
            if (($filters[$key] ?? '') !== '') {
                $clauses[] = 't.departure_at ' . $operator . ' :' . $key;
            }
        }
        if (($filters['operatorId'] ?? '') !== '') {
            $clauses[] = 't.vehicle_id IN (SELECT id FROM smartbus_vehicles WHERE operator_id = :operatorId)';
        }
        if (($filters['routeId'] ?? '') !== '') {
            $clauses[] = 't.route_id = :routeId';
        }
        if (($filters['status'] ?? '') !== '') {
            $clauses[] = 't.status = :status';
        }

        return $clauses === [] ? '' : 'WHERE ' . implode(' AND ', $clauses);
    }

    /** @param array<string,mixed> $filters @return array<string,mixed> */
    private function tripFilterParams(array $filters): array
    {
        $params = [];
        foreach (['from', 'to'] as $key) {
            if (($filters[$key] ?? '') !== '') {
                $params[$key] = $this->day((string) $filters[$key], $key === 'to');
            }
        }
        foreach (['operatorId', 'routeId'] as $key) {
            if (($filters[$key] ?? '') !== '') {
                $params[$key] = (string) $filters[$key];
            }
        }
        if (($filters['status'] ?? '') !== '') {
            $params['status'] = strtoupper((string) $filters['status']);
        }

        return $params;
    }

    private function rate(int $numerator, int $denominator): ?float
    {
        return $denominator > 0 ? round($numerator / $denominator, 3) : null;
    }

    private function roundOrNull(mixed $value): ?float
    {
        return $value === null ? null : round((float) $value, 1);
    }

    /** @param array<string,mixed> $row @return array<string,mixed> */
    private function castRow(array $row): array
    {
        foreach ($row as $key => $value) {
            if (is_string($value) && is_numeric($value) && !str_ends_with((string) $key, 'code') && !str_ends_with((string) $key, 'name')) {
                $row[$key] = str_contains($value, '.') ? (float) $value : (int) $value;
            }
        }

        return $row;
    }

    private function day(string $value, bool $endOfDay = false): string
    {
        $parsed = DateTimeImmutable::createFromFormat('!Y-m-d', $value, new DateTimeZone('UTC'));
        if (!$parsed instanceof DateTimeImmutable) {
            throw new AuthException('Filters must be dates (YYYY-MM-DD).', 422);
        }

        return $endOfDay ? $parsed->setTime(23, 59, 59)->format('Y-m-d H:i:s') : $parsed->format('Y-m-d 00:00:00');
    }
}
