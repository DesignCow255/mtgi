<?php

declare(strict_types=1);

namespace Mamore\SmartBus;

use Mamore\Auth\AuthException;
use Mamore\Core\AuditLog;
use Mamore\Core\ServerClock;
use Mamore\Core\Uuid;
use PDO;

/**
 * Trip notifications (Feature Groups M, N).
 *
 * A template catalogue plus a queue. No SMS, WhatsApp or email provider is
 * configured in this environment, so every message is QUEUED and the API
 * reports the provider as NOT_CONFIGURED. Nothing is ever reported as sent that
 * was not actually handed to a provider - a fake "delivered" tick is worse than
 * an honest queue.
 *
 * The schedule is derived from the trip's own timestamps, so reminders respect
 * reporting time, boarding open and boarding close rather than a fixed guess.
 */
final class TripNotificationService
{
    private const CHANNELS = ['EMAIL', 'SMS', 'WHATSAPP', 'IN_APP'];

    public function __construct(private readonly PDO $database) {}

    /**
     * Queue every notification a trip owes right now.
     *
     * Idempotent: a template that already has a QUEUED/SENT row for this trip and
     * event is skipped, so re-running this is safe.
     *
     * @return array<string,mixed>
     */
    public function scheduleForTrip(string $tripId, array $actor = []): array
    {
        $trip = $this->trip($tripId);
        $passengers = $this->passengers($tripId);
        $now = ServerClock::epoch($this->database);
        $plan = $this->plan($trip, $now);
        $queued = [];
        $skipped = [];

        foreach ($passengers as $passenger) {
            foreach ($plan as $slot) {
                $event = $slot['event'];
                $due = $this->due($trip, $slot);
                if ($due === null) {
                    continue;
                }
                if ($this->alreadyQueued((string) $passenger['id'], $event, $due)) {
                    $skipped[] = $event;
                    continue;
                }
                $context = $slot['context'] + [
                    'passengerName' => (string) $passenger['passenger_name'],
                    'seatNumber' => (string) $passenger['seat_number'],
                ];
                $this->queue($trip, $passenger, $slot['template'], $event, $due, $context);
                $queued[] = $event;
            }
        }

        if ($queued !== [] || $skipped !== []) {
            (new AuditLog($this->database))->write(
                'TRIP_NOTIFICATIONS_SCHEDULED',
                'Trip',
                $tripId,
                $actor === [] ? null : $actor,
                null,
                null,
                null,
                ['source' => 'trip-notifications', 'queued' => $queued, 'skipped' => $skipped]
            );
        }

        return [
            'tripId' => $tripId,
            'tripCode' => $trip['trip_code'],
            'queued' => $queued,
            'skippedAsAlreadyQueued' => $skipped,
            'provider' => $this->providerStatus(),
        ];
    }

    /** What a subscriber is told, and when, for one trip. */
    public function scheduleForBooking(string $bookingId): array
    {
        $statement = $this->database->prepare(<<<'SQL'
            SELECT b.*, t.trip_code, t.departure_at, t.reporting_at, t.boarding_opens_at, t.boarding_closes_at,
                   t.status AS trip_status, r.origin, r.destination, v.registration_number
            FROM smartbus_bookings b
            JOIN smartbus_trips t ON t.id = b.trip_id
            JOIN smartbus_routes r ON r.id = t.route_id
            JOIN smartbus_vehicles v ON v.id = t.vehicle_id
            WHERE b.id = :id
            SQL);
        $statement->execute(['id' => $bookingId]);
        $booking = $statement->fetch();
        if (!is_array($booking)) {
            throw new AuthException('Booking not found.', 404);
        }

        return [
            'bookingReference' => $booking['booking_reference'],
            'tripCode' => $booking['trip_code'],
            'route' => $booking['origin'] . ' → ' . $booking['destination'],
            'seatNumber' => (int) $booking['seat_number'],
            'board' => BoardingWindow::present($booking),
            'messages' => $this->preview($booking),
        ];
    }

    /**
     * The queue for a trip, with provider honesty.
     *
     * @return array<string,mixed>
     */
    public function outboxForTrip(string $tripId): array
    {
        $statement = $this->database->prepare(<<<'SQL'
            SELECT o.*, b.booking_reference, b.trip_id
            FROM message_outbox o
            JOIN smartbus_bookings b ON b.id = o.related_id
            WHERE o.related_type = 'BOOKING' AND b.trip_id = :trip
            ORDER BY b.seat_number ASC, o.scheduled_for ASC LIMIT 500
            SQL);
        $statement->execute(['trip' => $tripId]);

        return [
            'provider' => $this->providerStatus(),
            'messages' => array_map(static fn (array $row): array => [
                'eventCode' => $row['event_code'],
                'channel' => $row['channel'],
                'recipient' => $row['recipient_address'],
                'bookingReference' => $row['booking_reference'],
                'status' => $row['status'],
                'scheduledFor' => $row['scheduled_for'],
                'sentAt' => $row['sent_at'],
                'failureReason' => $row['failure_reason'],
            ], $statement->fetchAll()),
        ];
    }

    // ------------------------------------------------------------- internals

    /**
     * The reminder ladder from the brief, anchored on the trip's real times.
     *
     * @return list<array{event:string,template:string,context:array<string,string>}>
     */
    private function plan(array $trip, int $now): array
    {
        $departure = ServerClock::parse((string) $trip['departure_at']);
        $reporting = $trip['reporting_at'] === null ? $departure - 2700 : ServerClock::parse((string) $trip['reporting_at']);
        $opens = $trip['boarding_opens_at'] === null ? $departure - 1200 : ServerClock::parse((string) $trip['boarding_opens_at']);
        $closes = $trip['boarding_closes_at'] === null ? $departure - 600 : ServerClock::parse((string) $trip['boarding_closes_at']);
        $context = [
            'passengerName' => (string) $trip['passenger_name'],
            'tripCode' => (string) $trip['trip_code'],
            'route' => $trip['origin'] . ' → ' . $trip['destination'],
            'seatNumber' => (string) $trip['seat_number'],
            'reportingTime' => gmdate('H:i', $reporting),
            'boardingOpen' => gmdate('H:i', $opens),
            'boardingClose' => gmdate('H:i', $closes),
            'departureTime' => gmdate('H:i', $departure),
        ];

        return [
            ['event' => 'TRIP_REMINDER_24H', 'template' => 'TRIP_REMINDER', 'context' => $context, 'due' => $departure - 86400],
            ['event' => 'DEPARTURE_REMINDER_3H', 'template' => 'DEPARTURE_REMINDER', 'context' => $context, 'due' => $departure - 10800],
            ['event' => 'REPORTING_REMINDER_1H', 'template' => 'REPORTING_REMINDER', 'context' => $context, 'due' => $reporting - 3600],
            ['event' => 'REPORT_AT_STATION', 'template' => 'REPORT_AT_STATION', 'context' => $context, 'due' => $reporting],
            ['event' => 'BOARDING_OPEN', 'template' => 'BOARDING_OPEN', 'context' => $context, 'due' => $opens],
            ['event' => 'BOARDING_CLOSING_SOON', 'template' => 'BOARDING_CLOSING', 'context' => $context, 'due' => $closes - 900],
            ['event' => 'TRIP_STARTED', 'template' => 'TRIP_STARTED', 'context' => $context, 'due' => $departure],
        ];
    }

    /** @return int|null the scheduled epoch, or null when the slot is not yet due */
    private function due(array $trip, array $slot): ?int
    {
        $now = ServerClock::epoch($this->database);
        if (($slot['due'] ?? 0) > $now + 1) {
            return null;
        }
        if (in_array((string) $trip['trip_status'], ['COMPLETED', 'CANCELLED'], true)) {
            return null;
        }

        return max((int) $slot['due'], $now);
    }

    private function alreadyQueued(string $bookingId, string $event, int $due): bool
    {
        $statement = $this->database->prepare(<<<'SQL'
            SELECT COUNT(*) FROM message_outbox
            WHERE related_type = 'BOOKING' AND related_id = :booking AND event_code = :event
              AND status IN ('QUEUED', 'SENT') AND scheduled_for = :scheduled
            SQL);
        $statement->execute(['booking' => $bookingId, 'event' => $event, 'scheduled' => gmdate('Y-m-d H:i:s', $due)]);

        return (int) $statement->fetchColumn() > 0;
    }

    private function queue(array $trip, array $passenger, string $template, string $event, int $due, array $context): string
    {
        $scheduledFor = gmdate('Y-m-d H:i:s', $due);
        $channel = $this->channelFor($passenger);
        $this->database->prepare(<<<'SQL'
            INSERT INTO message_outbox
                (id, event_code, channel, recipient_user_id, recipient_address, related_type, related_id, payload,
                 status, scheduled_for)
            VALUES
                (:id, :event, :channel, :user, :address, 'BOOKING', :booking, :payload, 'QUEUED', :scheduled)
            SQL)->execute([
            'id' => Uuid::v4(),
            'event' => $event,
            'channel' => $channel,
            'user' => $passenger['user_id'] ?? null,
            'address' => $this->address($passenger, $channel),
            'booking' => $passenger['id'],
            'payload' => json_encode($context + ['template' => $template], JSON_THROW_ON_ERROR),
            'scheduled' => $scheduledFor,
        ]);

        // In-app copy goes to the existing notification centre, which is the one
        // channel that genuinely works in this environment.
        if ($channel === 'IN_APP' && is_string($passenger['user_id'] ?? null) && $passenger['user_id'] !== '') {
            $this->database->prepare(<<<'SQL'
                INSERT INTO user_notifications (user_id, notification_type, title, message, entity_type, entity_id)
                VALUES (:user, :type, :title, :message, 'Trip', :trip)
                SQL)->execute([
                'user' => $passenger['user_id'],
                'type' => $event,
                'title' => $event === 'BOARDING_OPEN' ? 'Boarding is now open' : $event,
                'message' => $context['route'] . ' · report by ' . $context['reportingTime'] . ' · seat ' . $context['seatNumber'],
                'trip' => $trip['id'],
            ]);
        }

        return $event;
    }

    private function channelFor(array $passenger): string
    {
        $phone = trim((string) ($passenger['passenger_phone'] ?? ''));
        $email = trim((string) ($passenger['user_email'] ?? ''));

        return $phone !== '' ? 'SMS' : ($email !== '' ? 'EMAIL' : 'IN_APP');
    }

    private function address(array $passenger, string $channel): ?string
    {
        $value = $channel === 'SMS' ? ($passenger['passenger_phone'] ?? null) : ($passenger['user_email'] ?? null);

        return is_string($value) && trim($value) !== '' ? mb_substr(trim($value), 0, 160) : null;
    }

    /**
     * Provider honesty: with no gateway configured, outbox rows stay QUEUED and
     * this reports the reason.
     *
     * @return array{configured:bool,status:string,note:string}
     */
    private function providerStatus(): array
    {
        $configured = trim((string) getenv('MESSAGE_PROVIDER')) !== '';

        return [
            'configured' => $configured,
            'status' => $configured ? 'AVAILABLE' : 'NOT_CONFIGURED',
            'note' => $configured
                ? 'Messages are queued for the configured provider.'
                : 'No SMS/WhatsApp/email provider is configured; messages are queued and will not be marked sent.',
        ];
    }

    /** @return list<array<string,string>> */
    private function preview(array $booking): array
    {
        $messages = [];
        foreach ($this->plan(['passenger_name' => $booking['passenger_name'], 'trip_code' => $booking['trip_code'],
            'origin' => $booking['origin'], 'destination' => $booking['destination'], 'seat_number' => $booking['seat_number'],
            'departure_at' => $booking['departure_at'], 'reporting_at' => $booking['reporting_at'],
            'boarding_opens_at' => $booking['boarding_opens_at'], 'boarding_closes_at' => $booking['boarding_closes_at'],
            'id' => $booking['id'], 'status' => $booking['trip_status'], 'user_id' => null,
            'passenger_phone' => null, 'user_email' => null], ServerClock::epoch($this->database)) as $slot) {
            $template = $this->database->prepare('SELECT body_template FROM message_templates WHERE event_code = :event AND channel = :channel');
            $template->execute(['event' => $slot['template'], 'channel' => 'IN_APP']);
            $body = $template->fetchColumn();
            $messages[] = [
                'event' => $slot['event'],
                'scheduledFor' => gmdate('Y-m-d H:i:s', (int) $slot['due']),
                'body' => is_string($body) ? $this->interpolate($body, $slot['context']) : null,
            ];
        }

        return $messages;
    }

    /** @param array<string,string> $context */
    private function interpolate(string $template, array $context): string
    {
        foreach ($context as $key => $value) {
            $template = str_replace('{{' . $key . '}}', $value, $template);
        }

        return $template;
    }

    /** @return array<string,mixed> */
    private function trip(string $tripId): array
    {
        $statement = $this->database->prepare(<<<'SQL'
            SELECT t.id, t.trip_code, t.departure_at, t.reporting_at, t.boarding_opens_at, t.boarding_closes_at, t.status,
                   r.origin, r.destination
            FROM smartbus_trips t
            JOIN smartbus_routes r ON r.id = t.route_id
            WHERE t.id = :id
            SQL);
        $statement->execute(['id' => $tripId]);
        $trip = $statement->fetch();
        if (!is_array($trip)) {
            throw new AuthException('Trip not found.', 404);
        }

        return $trip;
    }

    /**
     * Every passenger who should receive messages for this trip.
     *
     * @return list<array<string,mixed>>
     */
    private function passengers(string $tripId): array
    {
        $statement = $this->database->prepare(<<<'SQL'
            SELECT b.id, b.passenger_name, b.passenger_phone, b.seat_number, b.user_id, u.email AS user_email
            FROM smartbus_bookings b
            LEFT JOIN users u ON u.id = b.user_id
            WHERE b.trip_id = :trip AND b.status NOT IN ('CANCELLED', 'REFUNDED')
            ORDER BY b.seat_number ASC
            SQL);
        $statement->execute(['trip' => $tripId]);
        $passengers = $statement->fetchAll();
        if ($passengers === []) {
            throw new AuthException('No passenger is booked on this trip.', 404);
        }

        return $passengers;
    }
}
