<?php

declare(strict_types=1);

namespace Mamore\SmartBus;

use Mamore\Auth\AuthException;
use Mamore\Core\AuditLog;
use Mamore\Core\Request;
use Mamore\Core\ServerClock;
use Mamore\Policies\OperatorOwnershipPolicy;
use PDO;

/**
 * Journey safety status (Feature Group I) and the Control Center view of active
 * Smart Bus trips (Feature Group J).
 *
 * Every field is derived from a real source. When a source has nothing to say
 * the answer is UNKNOWN or OFFLINE - never a reassuring default. Nearest assets
 * come from the existing rescue_units and service_locations tables via a
 * haversine distance, not from a hard-coded list.
 */
final class JourneySafetyService
{
    private const GPS_FRESH_SECONDS = 120;
    private const LEVELS = ['NORMAL', 'WARNING', 'DEGRADED', 'CRITICAL', 'OFFLINE', 'UNKNOWN'];

    public function __construct(private readonly PDO $database) {}

    /**
     * Full safety status for one trip.
     *
     * @return array<string,mixed>
     */
    public function tripSafety(string $tripId, array $actor): array
    {
        $trip = $this->trip($tripId);
        $this->assertAccess($actor, $trip);

        $gps = $this->gps($tripId);
        $counts = $this->counts($tripId);
        $rescueReady = $this->rescueReadiness((string) $trip['province']);
        $coverage = $counts['total'] > 0 && $counts['rescueProtected'] === $counts['total'] ? 'ACTIVE' : 'PARTIAL';

        $components = [
            'gps' => $gps['status'],
            'bus' => $this->verification((string) $trip['verification_status'], 'UNKNOWN'),
            'driver' => $trip['driver_user_id'] === null ? 'UNKNOWN' : 'ASSIGNED',
            'manifest' => $counts['synced'] ? 'SYNCED' : 'DEGRADED',
            'rescueCoverage' => $coverage === 'ACTIVE' ? 'ACTIVE' : ($counts['total'] > 0 ? 'PARTIAL' : 'UNKNOWN'),
            'rescueResponse' => $rescueReady['status'],
            'routeStatus' => $this->routeStatus($trip),
        ];

        $status = $this->overall($components, $trip);
        $nearest = $this->nearestAssets($gps);

        return [
            'tripId' => $tripId,
            'tripCode' => $trip['trip_code'],
            'route' => ['origin' => $trip['origin'], 'destination' => $trip['destination'], 'code' => $trip['route_code']],
            'operatorName' => $trip['operator_name'],
            'vehicle' => ['code' => $trip['vehicle_code'], 'plate' => $trip['registration_number'], 'capacity' => (int) $trip['capacity']],
            'status' => $status,
            'components' => $components,
            'manifest' => $counts,
            'gps' => $gps,
            'nearest' => $nearest,
            'rescue' => $rescueReady,
            'incidentCount' => (int) $this->database->query(
                'SELECT COUNT(*) FROM rescue_incidents WHERE smartbus_trip_id = ' . $this->database->quote($tripId)
            )->fetchColumn(),
        ];
    }

    /**
     * Control Center board of active Smart Bus trips.
     *
     * @return list<array<string,mixed>>
     */
    public function liveTrips(array $actor): array
    {
        $trips = $this->database->query(<<<'SQL'
            SELECT t.id, t.trip_code, t.status, t.departure_at, t.delay_minutes,
                   r.code AS route_code, r.origin, r.destination,
                   v.code AS vehicle_code, v.registration_number, v.capacity, v.gps_enabled,
                   o.id AS operator_id, o.name AS operator_name
            FROM smartbus_trips t
            JOIN smartbus_routes r ON r.id = t.route_id
            JOIN smartbus_vehicles v ON v.id = t.vehicle_id
            JOIN smartbus_operators o ON o.id = v.operator_id
            WHERE t.status IN ('SCHEDULED', 'BOARDING', 'DEPARTED', 'DELAYED')
              AND t.departure_at BETWEEN DATE_SUB(UTC_TIMESTAMP(6), INTERVAL 1 DAY) AND DATE_ADD(UTC_TIMESTAMP(6), INTERVAL 2 DAY)
            ORDER BY t.departure_at ASC LIMIT 100
            SQL)->fetchAll();

        $board = [];
        foreach ($trips as $trip) {
            $gps = $this->gps((string) $trip['id']);
            $counts = $this->counts((string) $trip['id']);
            $board[] = [
                'tripId' => $trip['id'],
                'tripCode' => $trip['trip_code'],
                'operatorName' => $trip['operator_name'],
                'vehicleLabel' => $trip['operator_name'] . ' · ' . $trip['vehicle_code'],
                'route' => $trip['origin'] . ' → ' . $trip['destination'],
                'routeCode' => $trip['route_code'],
                'status' => $trip['status'],
                'delayMinutes' => (int) $trip['delay_minutes'],
                'departureAt' => $trip['departure_at'],
                'passengers' => $counts['total'],
                'boarded' => $counts['boarded'],
                'vipPassengers' => $counts['vip'],
                'rescueProtectedPassengers' => $counts['rescueProtected'],
                'gpsStatus' => $gps['status'],
                'gps' => $gps,
                'rescueCoverage' => $counts['rescueProtected'] > 0 ? 'ACTIVE' : 'NONE',
                'incidentCount' => (int) $this->database->query(
                    'SELECT COUNT(*) FROM rescue_incidents WHERE smartbus_trip_id = ' . $this->database->quote((string) $trip['id'])
                )->fetchColumn(),
                'nearest' => $this->nearestAssets($gps),
            ];
        }

        (new AuditLog($this->database))->write(
            'CONTROL_CENTER_LIVE_TRIPS_VIEWED',
            'SmartBus',
            null,
            $actor,
            null,
            null,
            null,
            ['source' => 'control-center', 'trips' => count($board)]
        );

        return $board;
    }

    /**
     * Journey safety for the passenger's own booking, and their active journey.
     *
     * @return array<string,mixed>
     */
    public function forPassenger(array $user): array
    {
        $statement = $this->database->prepare(<<<'SQL'
            SELECT b.id, b.trip_id FROM active_journeys aj
            JOIN smartbus_bookings b ON b.id = aj.booking_id
            WHERE aj.user_id = :user AND aj.status = 'ACTIVE'
            ORDER BY aj.created_at DESC LIMIT 1
            SQL);
        $statement->execute(['user' => $user['id']]);
        $row = $statement->fetch();
        if (!is_array($row)) {
            return ['active' => false, 'status' => BoardingWindow::PHASE_UNKNOWN, 'message' => 'You have no active journey.'];
        }

        $safety = $this->tripSafety((string) $row['trip_id'], $user);
        $safety['active'] = true;
        $safety['bookingId'] = $row['id'];

        return $safety;
    }

    // ------------------------------------------------------------- internals

    /** @return array<string,mixed> */
    private function trip(string $tripId): array
    {
        $statement = $this->database->prepare(<<<'SQL'
            SELECT t.*, r.code AS route_code, r.origin, r.destination, r.province,
                   v.code AS vehicle_code, v.registration_number, v.capacity, v.verification_status, v.gps_enabled,
                   o.id AS operator_id, o.name AS operator_name
            FROM smartbus_trips t
            JOIN smartbus_routes r ON r.id = t.route_id
            JOIN smartbus_vehicles v ON v.id = t.vehicle_id
            JOIN smartbus_operators o ON o.id = v.operator_id
            WHERE t.id = :id
            SQL);
        $statement->execute(['id' => $tripId]);
        $trip = $statement->fetch();
        if (!is_array($trip)) {
            throw new AuthException('Trip not found.', 404);
        }

        return $trip;
    }

    /**
     * Live position, derived from the existing tracking asset. No copy of the
     * coordinates is made here.
     *
     * @return array<string,mixed>
     */
    private function gps(string $tripId): array
    {
        $statement = $this->database->prepare(<<<'SQL'
            SELECT tp.latitude, tp.longitude, tp.speed_kph, tp.recorded_at
            FROM tracking_positions tp
            JOIN tracking_assets a ON a.id = tp.asset_id
            JOIN smartbus_trips t ON t.vehicle_id = a.reference_id
            WHERE a.asset_type = 'SMARTBUS_VEHICLE' AND t.id = :id
            ORDER BY tp.recorded_at DESC LIMIT 1
            SQL);
        $statement->execute(['id' => $tripId]);
        $position = $statement->fetch();
        if (!is_array($position)) {
            return ['status' => 'OFFLINE', 'latitude' => null, 'longitude' => null, 'recordedAt' => null, 'secondsAgo' => null];
        }

        $recordedAt = ServerClock::parse((string) $position['recorded_at']);
        $secondsAgo = ServerClock::epoch($this->database) - (int) $recordedAt;
        if ($secondsAgo > self::GPS_FRESH_SECONDS) {
            return [
                'status' => 'OFFLINE', 'latitude' => null, 'longitude' => null,
                'recordedAt' => $position['recorded_at'], 'secondsAgo' => $secondsAgo,
            ];
        }

        return [
            'status' => 'ONLINE',
            'latitude' => (float) $position['latitude'],
            'longitude' => (float) $position['longitude'],
            'speedKph' => $position['speed_kph'] === null ? null : (float) $position['speed_kph'],
            'recordedAt' => $position['recorded_at'],
            'secondsAgo' => $secondsAgo,
        ];
    }

    /** @return array<string,int|bool> */
    private function counts(string $tripId): array
    {
        $statement = $this->database->prepare(<<<'SQL'
            SELECT COUNT(*) AS total,
                   COALESCE(SUM(manifest_status = 'BOARDED'), 0) AS boarded,
                   COALESCE(SUM(manifest_status = 'CHECKED_IN'), 0) AS checked_in,
                   COALESCE(SUM(manifest_status = 'NO_SHOW'), 0) AS no_show,
                   COALESCE(SUM(vip_at_booking = 1), 0) AS vip,
                   COALESCE(SUM(rescue_fee_usd > 0), 0) AS rescue_protected,
                   COALESCE(SUM(special_assistance IS NOT NULL), 0) AS assistance
            FROM smartbus_bookings
            WHERE trip_id = :id AND status NOT IN ('CANCELLED', 'REFUNDED')
            SQL);
        $statement->execute(['id' => $tripId]);
        $row = $statement->fetch() ?: [];

        return [
            'total' => (int) ($row['total'] ?? 0),
            'boarded' => (int) ($row['boarded'] ?? 0),
            'checkedIn' => (int) ($row['checked_in'] ?? 0),
            'noShow' => (int) ($row['no_show'] ?? 0),
            'vip' => (int) ($row['vip'] ?? 0),
            'rescueProtected' => (int) ($row['rescue_protected'] ?? 0),
            'assistance' => (int) ($row['assistance'] ?? 0),
            'synced' => (int) ($row['total'] ?? 0) > 0,
        ];
    }

    /** @return array{status:string,nearestUnit:?array<string,mixed>,unitKm:?float} */
    private function rescueReadiness(string $province): array
    {
        $available = (int) $this->database->query(
            "SELECT COUNT(*) FROM rescue_units WHERE status = 'AVAILABLE'"
            . ($province === '' ? '' : " AND province = " . $this->database->quote($province))
        )->fetchColumn();

        if ($available === 0) {
            return ['status' => 'DEGRADED', 'nearestUnit' => null, 'unitKm' => null, 'availableUnits' => 0];
        }

        return ['status' => 'READY', 'nearestUnit' => null, 'unitKm' => null, 'availableUnits' => $available];
    }

    /**
     * Nearest rescue unit, hospital, garage and fuel station to the bus.
     *
     * @return array<string,mixed>
     */
    private function nearestAssets(array $gps): array
    {
        $empty = ['status' => 'UNKNOWN', 'name' => null, 'distanceKm' => null];
        if ($gps['status'] !== 'ONLINE') {
            return ['rescueUnit' => $empty, 'hospital' => $empty, 'garage' => $empty, 'fuelStation' => $empty, 'basis' => 'NO_POSITION'];
        }

        return [
            'rescueUnit' => $this->nearest('rescue_units', (float) $gps['latitude'], (float) $gps['longitude'], "status = 'AVAILABLE'", 'name AS label'),
            'hospital' => $this->nearest('service_locations', (float) $gps['latitude'], (float) $gps['longitude'], "location_type = 'HOSPITAL' AND status = 'ACTIVE'", 'name AS label'),
            'garage' => $this->nearest('service_locations', (float) $gps['latitude'], (float) $gps['longitude'], "location_type = 'GARAGE' AND status = 'ACTIVE'", 'name AS label'),
            'fuelStation' => $this->nearest('service_locations', (float) $gps['latitude'], (float) $gps['longitude'], "location_type = 'FUEL_STATION' AND status = 'ACTIVE'", 'name AS label'),
            'basis' => 'LIVE_POSITION',
        ];
    }

    /** @return array<string,mixed> */
    private function nearest(string $table, float $lat, float $lng, string $extraFilter, string $labelColumn): array
    {
        // Bounding box first, then haversine in SQL: the tables are small today
        // and this stays index-friendly without pulling coordinates into PHP.
        $statement = $this->database->prepare(<<<SQL
            SELECT {$labelColumn}, latitude, longitude,
                   6371 * 2 * ASIN(SQRT(
                       POWER(SIN(RADIANS(latitude - :latA) / 2), 2) +
                       COS(RADIANS(:latB)) * COS(RADIANS(latitude)) * POWER(SIN(RADIANS(longitude - :lngA) / 2), 2)
                   )) AS distance_km
            FROM {$table}
            WHERE latitude IS NOT NULL AND longitude IS NOT NULL AND {$extraFilter}
            ORDER BY distance_km ASC LIMIT 1
            SQL);
        // Each placeholder name appears once: native prepared statements reject a
        // repeated name, and interpolating the coordinates would be injection-prone.
        $statement->execute(['latA' => $lat, 'latB' => $lat, 'lngA' => $lng]);
        $row = $statement->fetch();
        if (!is_array($row)) {
            return ['status' => 'UNKNOWN', 'name' => null, 'distanceKm' => null];
        }

        return [
            'status' => 'AVAILABLE',
            'name' => $row['label'],
            'distanceKm' => round((float) $row['distance_km'], 1),
        ];
    }

    /** @param array<string,string> $components */
    private function overall(array $components, array $trip): string
    {
        $status = (string) $trip['status'];
        if ($status === 'CANCELLED') {
            return 'CRITICAL';
        }
        if ($components['gps'] === 'OFFLINE' && in_array($status, ['DEPARTED', 'DELAYED'], true)) {
            return 'CRITICAL';
        }
        if (in_array($components['rescueCoverage'], ['PARTIAL', 'UNKNOWN'], true)) {
            return 'WARNING';
        }
        if ($components['gps'] === 'OFFLINE') {
            return 'DEGRADED';
        }
        if ($components['bus'] !== 'VERIFIED' || $components['manifest'] === 'DEGRADED') {
            return 'DEGRADED';
        }
        if ((int) $trip['delay_minutes'] > 15) {
            return 'WARNING';
        }

        return 'NORMAL';
    }

    private function routeStatus(array $trip): string
    {
        if ((string) $trip['status'] === 'CANCELLED') {
            return 'CANCELLED';
        }
        if ((int) $trip['delay_minutes'] > 15) {
            return 'DELAYED';
        }
        if ((string) $trip['status'] === 'DEPARTED') {
            return 'ON_ROUTE';
        }

        return 'NORMAL';
    }

    private function verification(string $status, string $unknown): string
    {
        return match (strtoupper($status)) {
            'VERIFIED' => 'VERIFIED',
            'REJECTED', 'SUSPENDED' => 'UNVERIFIED',
            'PENDING' => $unknown,
            default => $unknown,
        };
    }

    private function assertAccess(array $actor, array $trip): void
    {
        $operatorId = $actor['operator_id'] ?? null;
        if (!OperatorOwnershipPolicy::ownsTrip($actor, $trip, is_string($operatorId) ? $operatorId : null)) {
            throw new AuthException('This trip belongs to another operator.', 403);
        }
    }
}
