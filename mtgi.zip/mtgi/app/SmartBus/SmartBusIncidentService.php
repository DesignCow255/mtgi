<?php

declare(strict_types=1);

namespace Mamore\SmartBus;

use Mamore\Auth\AuthException;
use Mamore\Core\AuditLog;
use Mamore\Core\Request;
use Mamore\Core\ServerClock;
use Mamore\Core\Uuid;
use Mamore\Policies\OperatorOwnershipPolicy;
use Mamore\Rescue\RescueService;
use PDO;

/**
 * Incidents raised from an active Smart Bus trip (Feature Group W).
 *
 * The responder should never re-type what the system already knows. Everything
 * the trip context proves - bus, operator, location, passenger and VIP counts,
 * nearest rescue unit - is attached to the incident record in the same
 * transaction, then handed to the existing RescueService so dispatch, the
 * Control Center and the notification path stay exactly as they were.
 */
final class SmartBusIncidentService
{
    public function __construct(private readonly PDO $database) {}

    /**
     * @return array<string,mixed>
     */
    public function create(array $input, array $actor, Request $request): array
    {
        $tripId = $this->required($input, 'tripId', 'Trip');
        $trip = $this->trip($tripId);
        $operatorId = $actor['operator_id'] ?? null;
        if (!OperatorOwnershipPolicy::ownsTrip($actor, $trip, is_string($operatorId) ? $operatorId : null)) {
            throw new AuthException('This trip belongs to another operator.', 403);
        }
        if (in_array((string) $trip['status'], ['COMPLETED', 'CANCELLED'], true)) {
            throw new AuthException('This trip has finished; report an incident without a trip.', 409);
        }

        $gps = $this->gps($tripId);
        $counts = $this->counts($tripId);
        $description = $this->required($input, 'description', 'What happened');
        $priority = $this->priority($input['priority'] ?? 'HIGH');

        $incidentId = Uuid::v4();
        $this->database->beginTransaction();
        try {
            $this->database->prepare(<<<'SQL'
                INSERT INTO rescue_incidents
                    (id, incident_code, source, caller_name, caller_phone, province, location_text, latitude, longitude,
                     description, priority, status, reported_by_user_id,
                     smartbus_trip_id, smartbus_vehicle_id, smartbus_operator_id,
                     passenger_count, vip_passenger_count, source_latitude, source_longitude)
                VALUES
                    (:id, :code, 'SMARTBUS_TRIP', :caller, :phone, :province, :location, :latitude, :longitude,
                     :description, :priority, 'REPORTED', :reporter,
                     :trip, :vehicle, :operator, :passengers, :vip, :sourceLat, :sourceLng)
                SQL)->execute([
                'id' => $incidentId,
                'code' => 'SBI-' . gmdate('ymd') . '-' . strtoupper(bin2hex(random_bytes(3))),
                'caller' => trim(((string) ($actor['first_name'] ?? '')) . ' ' . ((string) ($actor['last_name'] ?? ''))) ?: null,
                // rescue_incidents.caller_phone is NOT NULL and only 32 chars: a
                // bus-initiated incident may have no caller number at all, so an
                // empty value is recorded rather than an invented one (an email
                // does not fit the column).
                'phone' => $this->callerPhone($actor),
                'province' => (string) ($trip['province'] ?? 'HAUT_KATANGA'),
                'location' => $this->nullableString($input['location'] ?? null) ?? ($trip['origin'] . ' → ' . $trip['destination']),
                'latitude' => $gps['latitude'],
                'longitude' => $gps['longitude'],
                'description' => $description,
                'priority' => $priority,
                'reporter' => $actor['id'] ?? null,
                'trip' => $tripId,
                'vehicle' => $trip['vehicle_id'],
                'operator' => $trip['operator_id'],
                'passengers' => $counts['total'],
                'vip' => $counts['vip'],
                'sourceLat' => $gps['latitude'],
                'sourceLng' => $gps['longitude'],
            ]);
            $this->database->commit();
        } catch (\Throwable $error) {
            if ($this->database->inTransaction()) {
                $this->database->rollBack();
            }
            throw $error;
        }

        $incident = (new RescueService($this->database))->show($incidentId);

        (new AuditLog($this->database))->write(
            'SMARTBUS_INCIDENT_CREATED',
            'Incident',
            $incidentId,
            $actor,
            $request,
            null,
            [
                'incidentCode' => $incident['code'] ?? null,
                'priority' => $priority,
                'tripId' => $tripId,
                'passengers' => $counts['total'],
                'vipPassengers' => $counts['vip'],
                'gps' => $gps['status'],
            ],
            ['source' => 'smart-bus-incident', 'operatorName' => $trip['operator_name'], 'vehicleCode' => $trip['vehicle_code']]
        );

        return [
            'incident' => $incident,
            'context' => [
                'tripId' => $tripId,
                'tripCode' => $trip['trip_code'],
                'operatorName' => $trip['operator_name'],
                'vehicleCode' => $trip['vehicle_code'],
                'passengers' => $counts['total'],
                'vipPassengers' => $counts['vip'],
                'gps' => $gps,
            ],
        ];
    }

    /**
     * Incidents already linked to a trip, for the trip detail view.
     *
     * @return list<array<string,mixed>>
     */
    public function forTrip(string $tripId): array
    {
        $statement = $this->database->prepare(<<<'SQL'
            SELECT i.id, i.incident_code, i.priority, i.status, i.description, i.reported_at,
                   i.passenger_count, i.vip_passenger_count
            FROM rescue_incidents i WHERE i.smartbus_trip_id = :trip
            ORDER BY i.reported_at DESC LIMIT 50
            SQL);
        $statement->execute(['trip' => $tripId]);

        return array_map(static fn (array $row): array => [
            'id' => $row['id'],
            'incidentCode' => $row['incident_code'],
            'priority' => $row['priority'],
            'status' => $row['status'],
            'description' => $row['description'],
            'reportedAt' => $row['reported_at'],
            'passengerCount' => $row['passenger_count'] === null ? null : (int) $row['passenger_count'],
            'vipPassengerCount' => $row['vip_passenger_count'] === null ? null : (int) $row['vip_passenger_count'],
        ], $statement->fetchAll());
    }

    // ------------------------------------------------------------- internals

    /** @return array<string,mixed> */
    private function trip(string $tripId): array
    {
        $statement = $this->database->prepare(<<<'SQL'
            SELECT t.*, r.code AS route_code, r.origin, r.destination, r.province,
                   v.code AS vehicle_code, v.registration_number, o.id AS operator_id, o.name AS operator_name
            FROM smartbus_trips t
            JOIN smartbus_routes r ON r.id = t.route_id
            JOIN smartbus_vehicles v ON v.id = t.vehicle_id
            JOIN smartbus_operators o ON o.id = v.operator_id
            WHERE t.id = :id
            SQL);
        $statement->execute(['id' => $tripId]);
        $trip = $statement->fetch();
        if (!is_array($trip)) {
            throw new AuthException('Trip not found.', 404);
        }

        return $trip;
    }

    /** @return array<string,mixed> */
    private function gps(string $tripId): array
    {
        $statement = $this->database->prepare(<<<'SQL'
            SELECT tp.latitude, tp.longitude, tp.recorded_at
            FROM tracking_positions tp
            JOIN tracking_assets a ON a.id = tp.asset_id
            JOIN smartbus_trips t ON t.vehicle_id = a.reference_id
            WHERE a.asset_type = 'SMARTBUS_VEHICLE' AND t.id = :id
            ORDER BY tp.recorded_at DESC LIMIT 1
            SQL);
        $statement->execute(['id' => $tripId]);
        $position = $statement->fetch();
        if (!is_array($position) || (time() - (int) ServerClock::parse((string) $position['recorded_at'])) > 120) {
            return ['status' => 'OFFLINE', 'latitude' => null, 'longitude' => null];
        }

        return [
            'status' => 'ONLINE',
            'latitude' => (float) $position['latitude'],
            'longitude' => (float) $position['longitude'],
        ];
    }

    /** @return array<string,int> */
    private function counts(string $tripId): array
    {
        $statement = $this->database->prepare(<<<'SQL'
            SELECT COUNT(*) AS total, COALESCE(SUM(vip_at_booking = 1), 0) AS vip
            FROM smartbus_bookings WHERE trip_id = :id AND status NOT IN ('CANCELLED', 'REFUNDED')
            SQL);
        $statement->execute(['id' => $tripId]);
        $row = $statement->fetch() ?: [];

        return ['total' => (int) ($row['total'] ?? 0), 'vip' => (int) ($row['vip'] ?? 0)];
    }

    private function priority(mixed $value): string
    {
        $priority = is_string($value) ? strtoupper(trim($value)) : 'HIGH';
        if (!in_array($priority, ['CRITICAL', 'HIGH', 'MEDIUM', 'LOW'], true)) {
            throw new AuthException('Select a valid priority.', 422);
        }

        return $priority;
    }

    /** Never a made-up number: the real phone, or an empty value. */
    private function callerPhone(array $actor): string
    {
        $phone = $this->nullableString($actor['phone'] ?? null);

        return $phone === null ? '' : substr($phone, 0, 32);
    }

    private function required(array $input, string $key, string $label): string
    {
        $value = is_string($input[$key] ?? null) ? trim($input[$key]) : '';
        if ($value === '') {
            throw new AuthException("{$label} is required.", 422);
        }

        return $value;
    }

    private function nullableString(mixed $value): ?string
    {
        if (!is_string($value)) {
            return null;
        }
        $trimmed = trim($value);

        return $trimmed === '' ? null : $trimmed;
    }
}
