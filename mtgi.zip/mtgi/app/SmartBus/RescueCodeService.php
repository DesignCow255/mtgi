<?php

declare(strict_types=1);

namespace Mamore\SmartBus;

use Mamore\Auth\AuthException;
use Mamore\Core\AuditLog;
use Mamore\Core\RateLimiter;
use Mamore\Core\Request;
use Mamore\Core\ServerClock;
use Mamore\Core\Uuid;
use PDO;

/**
 * Mamore Rescue Codes (Feature Group A).
 *
 * A rescue code is a human-readable, high-entropy handle on a subscriber's
 * rescue entitlement: MRC-<country>-<yy>-<6 chars>. It is not a primary key, it
 * never encodes a database id, and it is checked before it is trusted.
 *
 * Three access modes, each audited in rescue_code_access_log:
 *   PUBLIC_VERIFY   - validity + coverage only. No subscriber detail ever.
 *   CONTROL_CENTER - full profile, contacts, journey, GPS, nearest assets.
 *   PORTAL_SELF     - the subscriber reading their own code.
 */
final class RescueCodeService
{
    public const MODE_PUBLIC = 'PUBLIC_VERIFY';
    public const MODE_CONTROL_CENTER = 'CONTROL_CENTER';
    public const MODE_PORTAL_SELF = 'PORTAL_SELF';

    private const PUBLIC_LIMIT = [20, 300];
    private const LOOKUP_LIMIT = [60, 300];
    private const UNAMBIGUOUS = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789'; // no I, O, 0, 1

    public function __construct(private readonly PDO $database) {}

    /**
     * Issue a code for a subscriber that holds an active subscription.
     *
     * @return array<string,mixed>
     */
    public function issue(array $input, ?array $actor = null, ?Request $request = null): array
    {
        $subscriberId = $this->required($input, 'subscriberId', 'Subscriber');
        $subscriber = $this->subscriber($subscriberId);
        $subscription = $this->activeSubscription($subscriberId, $input['subscriptionId'] ?? null);
        if ($subscription === null) {
            // A rescue code is a promise of cover, so it may only exist while
            // that cover is live.
            throw new AuthException('A rescue code requires an active Mamore subscription.', 422);
        }
        $expiresAt = $this->nullableString($input['expiresAt'] ?? null);

        $this->database->beginTransaction();
        try {
            $existing = $this->activeCodeForSubscriber($subscriberId);
            if ($existing !== null) {
                $this->database->rollBack();
                throw new AuthException('This subscriber already holds an active rescue code.', 409);
            }

            $code = $this->generateCode($this->countryForProvince((string) ($subscription['province'] ?? '')));
            $id = Uuid::v4();
            $this->database->prepare(<<<'SQL'
                INSERT INTO rescue_codes
                    (id, code, country_code, subscriber_id, user_id, subscription_id, status, expires_at, created_by_user_id)
                VALUES
                    (:id, :code, :country, :subscriber, :user, :subscription, 'ACTIVE', :expires, :actor)
                SQL)->execute([
                'id' => $id,
                'code' => $code,
                'country' => $subscription['country_code'] ?? 'CD',
                'subscriber' => $subscriberId,
                'user' => $subscriber['user_id'] ?? null,
                'subscription' => $subscription['id'] ?? null,
                'expires' => $expiresAt,
                'actor' => $actor['id'] ?? null,
            ]);
            $this->database->commit();
        } catch (\Throwable $error) {
            if ($this->database->inTransaction()) {
                $this->database->rollBack();
            }
            throw $error;
        }

        $this->audit('RESCUE_CODE_ISSUED', $id, $actor, $request, null, ['subscriberId' => $subscriberId, 'expiresAt' => $expiresAt]);

        return $this->present($this->find($id), reveal: true);
    }

    /**
     * Public verification. Deliberately returns almost nothing: whether the code
     * exists, whether coverage is live, and how to reach Mamore. A stranger who
     * guesses a code learns no identity at all.
     *
     * @return array<string,mixed>
     */
    public function verifyPublic(string $code, Request $request): array
    {
        $this->throttle('rescue-code-public', self::PUBLIC_LIMIT, $request);

        $normalized = $this->normalize($code);
        $row = $normalized === '' ? null : $this->findByCode($normalized);
        $valid = $row !== null && $this->isLive($row);
        $coverage = $valid ? $this->coverageStatus($row) : 'UNKNOWN';

        $this->logAccess($row, $normalized, self::MODE_PUBLIC, null, $request, $valid, 'VALIDITY_ONLY', 'Public verification of a rescue code.');
        (new AuditLog($this->database))->write(
            'RESCUE_CODE_VERIFIED',
            'RescueCode',
            $row['id'] ?? null,
            null,
            $request,
            null,
            null,
            ['source' => 'rescue-code-public', 'valid' => $valid, 'coverageStatus' => $coverage]
        );

        return [
            'valid' => $valid,
            'status' => $row === null ? 'NOT_FOUND' : (string) $row['status'],
            'coverageStatus' => $coverage,
            'identityConfirmation' => $valid ? $this->maskIdentity($row) : null,
            'mamoreEmergencyContact' => '+243 000 000 000',
            'instructions' => $valid
                ? 'Present this code to Mamore staff or a rescue responder. They can confirm coverage with this reference.'
                : 'This code is not recognised. Contact Mamore HQ with your membership number.',
        ];
    }

    /**
     * Control Center lookup: the responder view. Requires the caller to already
     * hold smartbus.rescue_code.verify, and every access is recorded with the
     * reason the responder gave.
     *
     * @return array<string,mixed>
     */
    public function lookup(string $code, array $actor, Request $request): array
    {
        $this->throttle('rescue-code-lookup', self::LOOKUP_LIMIT, $request);

        $normalized = $this->normalize($code);
        $row = $normalized === '' ? null : $this->findByCode($normalized);
        $valid = $row !== null && $this->isLive($row);
        $reason = $this->required(['reason' => $request->body['reason'] ?? ''], 'reason', 'Access reason');

        $this->logAccess($row, $normalized, self::MODE_CONTROL_CENTER, $actor, $request, $valid, $valid ? 'JOURNEY' : 'VALIDITY_ONLY', $reason);
        (new AuditLog($this->database))->write(
            'RESCUE_CODE_LOOKED_UP',
            'RescueCode',
            $row['id'] ?? null,
            $actor,
            $request,
            null,
            null,
            ['source' => 'rescue-code-control-center', 'valid' => $valid, 'reason' => $reason, 'detail' => $valid ? 'JOURNEY' : 'VALIDITY_ONLY']
        );

        if (!$valid) {
            // Same shape whether unknown or dead, so probing learns nothing.
            return ['valid' => false, 'status' => $row === null ? 'NOT_FOUND' : (string) $row['status'], 'detail' => 'VALIDITY_ONLY'];
        }

        return ['valid' => true, 'detail' => 'JOURNEY', 'rescueCode' => $this->present($row, reveal: true), 'subscriber' => $this->subscriberDetail($row), 'journey' => $this->journey($row)];
    }

    /** The subscriber reading their own code. */
    public function forSubscriber(array $user): array
    {
        $statement = $this->database->prepare(
            'SELECT c.* FROM rescue_codes c JOIN subscribers s ON s.id = c.subscriber_id
             WHERE c.user_id = :user ORDER BY c.issued_at DESC LIMIT 1'
        );
        $statement->execute(['user' => $user['id']]);
        $row = $statement->fetch();
        if (!is_array($row)) {
            return ['code' => null, 'status' => 'NOT_ISSUED', 'message' => 'No rescue code has been issued for this account yet.'];
        }

        return $this->present($row, reveal: true);
    }

    /** Revoke a code, with a mandatory reason. */
    public function revoke(array $input, array $actor, Request $request): array
    {
        $id = $this->required($input, 'rescueCodeId', 'Rescue code');
        $reason = $this->required($input, 'reason', 'Revocation reason');
        $row = $this->find($id);
        if ($row['status'] === 'REVOKED') {
            return $this->present($row, reveal: true);
        }

        $this->database->prepare(
            "UPDATE rescue_codes SET status = 'REVOKED', revoked_at = UTC_TIMESTAMP(6), revocation_reason = :reason WHERE id = :id"
        )->execute(['reason' => $reason, 'id' => $id]);
        $this->audit('RESCUE_CODE_REVOKED', $id, $actor, $request, ['status' => $row['status']], ['status' => 'REVOKED'], ['reason' => $reason]);

        return $this->present($this->find($id), reveal: true);
    }

    /**
     * Regenerate under control: the old code is revoked, the new one is linked
     * to it, and the generation counter increments.
     */
    public function regenerate(array $input, array $actor, Request $request): array
    {
        $id = $this->required($input, 'rescueCodeId', 'Rescue code');
        $reason = $this->required($input, 'reason', 'Regeneration reason');
        $row = $this->find($id);
        if ($row['status'] === 'REVOKED') {
            throw new AuthException('This code was revoked; issue a new code instead.', 409);
        }

        $newId = Uuid::v4();
        $code = $this->generateCode((string) $row['country_code']);
        $this->database->beginTransaction();
        try {
            $this->database->prepare(
                "UPDATE rescue_codes SET status = 'REVOKED', revoked_at = UTC_TIMESTAMP(6), revocation_reason = :reason WHERE id = :id"
            )->execute(['reason' => 'Regenerated: ' . $reason, 'id' => $id]);
            $this->database->prepare(<<<'SQL'
                INSERT INTO rescue_codes
                    (id, code, country_code, subscriber_id, user_id, subscription_id, status, expires_at,
                     regeneration_of, generation, created_by_user_id)
                VALUES
                    (:id, :code, :country, :subscriber, :user, :subscription, 'ACTIVE', :expires, :previous, :generation, :actor)
                SQL)->execute([
                'id' => $newId,
                'code' => $code,
                'country' => $row['country_code'],
                'subscriber' => $row['subscriber_id'],
                'user' => $row['user_id'],
                'subscription' => $row['subscription_id'],
                'expires' => $row['expires_at'],
                'previous' => $id,
                'generation' => ((int) $row['generation']) + 1,
                'actor' => $actor['id'] ?? null,
            ]);
            $this->database->commit();
        } catch (\Throwable $error) {
            if ($this->database->inTransaction()) {
                $this->database->rollBack();
            }
            throw $error;
        }

        $this->audit('RESCUE_CODE_REGENERATED', $newId, $actor, $request, ['previousCodeId' => $id], ['generation' => ((int) $row['generation']) + 1], ['reason' => $reason]);

        return $this->present($this->find($newId), reveal: true);
    }

    // ------------------------------------------------------------- internals

    private function generateCode(string $country): string
    {
        $prefix = 'MRC-' . strtoupper(substr($country, 0, 2)) . '-' . gmdate('y') . '-';
        for ($attempt = 0; $attempt < 5; $attempt++) {
            $code = $prefix;
            for ($index = 0; $index < 6; $index++) {
                $code .= self::UNAMBIGUOUS[random_int(0, strlen(self::UNAMBIGUOUS) - 1)];
            }
            $exists = $this->database->prepare('SELECT COUNT(*) FROM rescue_codes WHERE code = :code');
            $exists->execute(['code' => $code]);
            if ((int) $exists->fetchColumn() === 0) {
                return $code;
            }
        }
        throw new AuthException('Could not allocate a rescue code. Try again.', 500);
    }

    private function normalize(string $code): string
    {
        return strtoupper(trim(preg_replace('/[^A-Za-z0-9-]/', '', $code) ?? ''));
    }

    /** @return array<string,mixed>|null */
    private function findByCode(string $code): ?array
    {
        $statement = $this->database->prepare('SELECT * FROM rescue_codes WHERE code = :code');
        $statement->execute(['code' => $code]);
        $row = $statement->fetch();

        return is_array($row) ? $row : null;
    }

    /** @return array<string,mixed> */
    private function find(string $id): array
    {
        $statement = $this->database->prepare('SELECT * FROM rescue_codes WHERE id = :id');
        $statement->execute(['id' => $id]);
        $row = $statement->fetch();
        if (!is_array($row)) {
            throw new AuthException('Rescue code not found.', 404);
        }

        return $row;
    }

    /** @return array<string,mixed>|null */
    private function activeCodeForSubscriber(string $subscriberId): ?array
    {
        $statement = $this->database->prepare(
            "SELECT * FROM rescue_codes WHERE subscriber_id = :subscriber AND status = 'ACTIVE' LIMIT 1"
        );
        $statement->execute(['subscriber' => $subscriberId]);
        $row = $statement->fetch();

        return is_array($row) ? $row : null;
    }

    /** @return array<string,mixed> */
    private function subscriber(string $subscriberId): array
    {
        $statement = $this->database->prepare(
            'SELECT s.*, (SELECT u.id FROM users u WHERE u.subscriber_id = s.id LIMIT 1) AS user_id
             FROM subscribers s WHERE s.id = :id AND s.deleted_at IS NULL'
        );
        $statement->execute(['id' => $subscriberId]);
        $row = $statement->fetch();
        if (!is_array($row)) {
            throw new AuthException('Subscriber not found.', 404);
        }

        return $row;
    }

    /**
     * A rescue code is only issued against live cover. An expired or cancelled
     * subscription cannot produce one.
     *
     * @return array<string,mixed>|null
     */
    private function activeSubscription(string $subscriberId, mixed $requestedId = null): ?array
    {
        $sql = "SELECT s.* FROM subscriptions s
                JOIN subscribers sub ON sub.id = s.subscriber_id
                WHERE s.subscriber_id = :subscriber
                  AND s.status IN ('ACTIVE', 'RENEWED')
                  AND (s.grace_end_date IS NULL OR s.grace_end_date >= UTC_DATE())";
        $params = ['subscriber' => $subscriberId];
        if (is_string($requestedId) && $requestedId !== '') {
            $sql .= ' AND s.id = :subscription';
            $params['subscription'] = $requestedId;
        }
        $sql .= ' ORDER BY s.expiry_date DESC LIMIT 1';

        $statement = $this->database->prepare($sql);
        $statement->execute($params);
        $row = $statement->fetch();

        return is_array($row) ? $row : null;
    }

    private function isLive(array $row): bool
    {
        if ((string) $row['status'] !== 'ACTIVE') {
            return false;
        }

        return $row['expires_at'] === null || strtotime((string) $row['expires_at']) >= ServerClock::epoch($this->database);
    }

    private function coverageStatus(array $row): string
    {
        $statement = $this->database->prepare(
            'SELECT status, grace_end_date, expiry_date FROM subscriptions WHERE id = :id'
        );
        $statement->execute(['id' => $row['subscription_id']]);
        $subscription = $statement->fetch();
        if (!is_array($subscription)) {
            return 'INACTIVE';
        }
        if (!in_array((string) $subscription['status'], ['ACTIVE', 'RENEWED'], true)) {
            return 'EXPIRED';
        }
        $grace = $subscription['grace_end_date'] ?: $subscription['expiry_date'];

        return $grace !== null && strtotime((string) $grace) < time() ? 'EXPIRED' : 'ACTIVE';
    }

    /** Minimal identity hint: proves possession without disclosing the person. */
    private function maskIdentity(array $row): array
    {
        $statement = $this->database->prepare(
            'SELECT first_name, last_name, membership_number FROM subscribers WHERE id = :id'
        );
        $statement->execute(['id' => $row['subscriber_id']]);
        $subscriber = $statement->fetch();
        if (!is_array($subscriber)) {
            return [];
        }
        $initial = mb_substr((string) ($subscriber['first_name'] ?? ''), 0, 1);

        return [
            'initial' => strtoupper($initial) . '.',
            'membershipSuffix' => substr((string) $subscriber['membership_number'], -4),
        ];
    }

    /** @return array<string,mixed> */
    private function subscriberDetail(array $row): array
    {
        $statement = $this->database->prepare(<<<'SQL'
            SELECT s.*, u.email AS user_email, u.phone AS user_phone
            FROM subscribers s LEFT JOIN users u ON u.subscriber_id = s.id
            WHERE s.id = :id
            SQL);
        $statement->execute(['id' => $row['subscriber_id']]);
        $subscriber = $statement->fetch();
        if (!is_array($subscriber)) {
            throw new AuthException('Subscriber not found.', 404);
        }

        $contacts = $this->database->prepare(
            "SELECT vehicle_make, vehicle_model, plate_number FROM subscriber_vehicles WHERE subscriber_id = :id ORDER BY created_at"
        );
        $contacts->execute(['id' => $row['subscriber_id']]);

        return [
            'membershipNumber' => $subscriber['membership_number'],
            'name' => trim(((string) ($subscriber['first_name'] ?? '')) . ' ' . ((string) ($subscriber['last_name'] ?? ''))),
            'company' => $subscriber['company_name'],
            'email' => $subscriber['email'] ?? $subscriber['user_email'] ?? null,
            'phone' => $subscriber['phone'] ?? $subscriber['user_phone'] ?? null,
            'nationalId' => $subscriber['national_id'],
            'emergencyContact' => $subscriber['emergency_contact'],
            'emergencyPhone' => $subscriber['emergency_phone'],
            'gps' => [
                'latitude' => $subscriber['gps_latitude'] === null ? null : (float) $subscriber['gps_latitude'],
                'longitude' => $subscriber['gps_longitude'] === null ? null : (float) $subscriber['gps_longitude'],
            ],
            'vehicles' => array_map(static fn (array $vehicle): array => [
                'plateNumber' => $vehicle['plate_number'],
                'description' => trim(((string) ($vehicle['vehicle_make'] ?? '')) . ' ' . ((string) ($vehicle['vehicle_model'] ?? ''))),
            ], $contacts->fetchAll()),
        ];
    }

    /** The journey this code is relevant to right now, if any. */
    private function journey(array $row): ?array
    {
        $statement = $this->database->prepare(<<<'SQL'
            SELECT aj.*, t.trip_code, t.status AS trip_status, t.departure_at,
                   r.origin, r.destination, v.code AS vehicle_code, v.registration_number,
                   o.name AS operator_name, b.booking_reference, b.seat_number, b.passenger_name,
                   ta.latitude, ta.longitude, ta.recorded_at, ta.speed_kph
            FROM active_journeys aj
            JOIN smartbus_trips t ON t.id = aj.trip_id
            JOIN smartbus_routes r ON r.id = aj.route_id
            JOIN smartbus_vehicles v ON v.id = aj.vehicle_id
            JOIN smartbus_operators o ON o.id = aj.operator_id
            JOIN smartbus_bookings b ON b.id = aj.booking_id
            LEFT JOIN tracking_assets asset
                   ON asset.asset_type = 'SMARTBUS_VEHICLE' AND asset.reference_id = aj.vehicle_id
            LEFT JOIN tracking_positions ta ON ta.id = (
                   SELECT tp.id FROM tracking_positions tp WHERE tp.asset_id = asset.id ORDER BY tp.recorded_at DESC LIMIT 1
            )
            WHERE aj.subscriber_id = :subscriber AND aj.status = 'ACTIVE'
            ORDER BY aj.created_at DESC LIMIT 1
            SQL);
        $statement->execute(['subscriber' => $row['subscriber_id']]);
        $journey = $statement->fetch();
        if (!is_array($journey)) {
            return null;
        }

        $gpsFresh = $journey['recorded_at'] !== null
            && strtotime((string) $journey['recorded_at']) >= time() - 120;

        return [
            'tripCode' => $journey['trip_code'],
            'tripStatus' => $journey['trip_status'],
            'origin' => $journey['origin'],
            'destination' => $journey['destination'],
            'departureAt' => $journey['departure_at'],
            'bookingReference' => $journey['booking_reference'],
            'seatNumber' => (int) $journey['seat_number'],
            'passengerName' => $journey['passenger_name'],
            'vehicle' => ['code' => $journey['vehicle_code'], 'plate' => $journey['registration_number']],
            'operatorName' => $journey['operator_name'],
            'rescueCoverageStatus' => $journey['rescue_coverage_status'],
            'gps' => $gpsFresh
                ? [
                    'status' => 'ONLINE',
                    'latitude' => (float) $journey['latitude'],
                    'longitude' => (float) $journey['longitude'],
                    'speedKph' => $journey['speed_kph'] === null ? null : (float) $journey['speed_kph'],
                    'recordedAt' => $journey['recorded_at'],
                ]
                : ['status' => 'OFFLINE', 'latitude' => null, 'longitude' => null, 'recordedAt' => $journey['recorded_at']],
        ];
    }

    /**
     * @return array<string,mixed>
     */
    private function present(array $row, bool $reveal): array
    {
        return [
            'id' => $row['id'],
            'code' => $reveal ? $row['code'] : $this->maskCode((string) $row['code']),
            'status' => $this->isLive($row) ? 'ACTIVE' : (string) $row['status'],
            'countryCode' => $row['country_code'],
            'generation' => (int) $row['generation'],
            'issuedAt' => $row['issued_at'],
            'expiresAt' => $row['expires_at'],
            'revokedAt' => $row['revoked_at'],
            'revocationReason' => $row['revocation_reason'],
            'coverageStatus' => $this->isLive($row) ? $this->coverageStatus($row) : 'INACTIVE',
        ];
    }

    /** MRC-CD-26-AB12CD -> MRC-••-AB12CD */
    public static function maskCode(string $code): string
    {
        $parts = explode('-', $code);
        if (count($parts) !== 4) {
            return str_repeat('•', strlen($code));
        }

        return $parts[0] . '-••-' . $parts[2] . '-' . $parts[3];
    }

    private function logAccess(
        ?array $row,
        string $codeEntered,
        string $mode,
        ?array $actor,
        Request $request,
        bool $granted,
        string $detailLevel,
        string $reason
    ): void {
        $this->database->prepare(<<<'SQL'
            INSERT INTO rescue_code_access_log
                (rescue_code_id, code_entered, access_mode, actor_user_id, session_id, actor_role, reason,
                 ip_address, user_agent, granted, detail_level)
            VALUES
                (:codeId, :entered, :mode, :actor, :session, :role, :reason, :ip, :agent, :granted, :detail)
            SQL)->execute([
            'codeId' => $row['id'] ?? null,
            'entered' => substr($codeEntered, 0, 32),
            'mode' => $mode,
            'actor' => $actor['id'] ?? null,
            'session' => is_string($actor['session_id'] ?? null) ? $actor['session_id'] : null,
            'role' => is_string($actor['role_code'] ?? null) ? $actor['role_code'] : null,
            'reason' => $reason,
            'ip' => $request->ipAddress,
            'agent' => $request->userAgent === null ? null : mb_substr($request->userAgent, 0, 500),
            'granted' => $granted ? 1 : 0,
            'detail' => $detailLevel,
        ]);
    }

    private function audit(
        string $action,
        ?string $entityId,
        ?array $actor,
        ?Request $request,
        ?array $previous,
        ?array $new,
        ?array $metadata = null
    ): void {
        (new AuditLog($this->database))->write(
            $action,
            'RescueCode',
            $entityId,
            $actor,
            $request,
            $previous,
            $new,
            array_merge(['source' => 'rescue-code-service'], $metadata ?? [])
        );
    }

    /** @param array{0:int,1:int} $limit */
    private function throttle(string $bucket, array $limit, Request $request): void
    {
        if (!RateLimiter::allow($bucket . ':' . ($request->ipAddress ?? 'cli'), $limit[0], $limit[1])) {
            throw new AuthException('Too many attempts. Please try again later.', 429);
        }
    }

    private function required(array $input, string $key, string $label): string
    {
        $value = is_string($input[$key] ?? null) ? trim($input[$key]) : '';
        if ($value === '') {
            throw new AuthException("{$label} is required.", 422);
        }

        return $value;
    }

    /**
     * Country for a coverage province.
     *
     * The rescue code embeds the country, and coverage is what a code is really
     * about, so it is derived from the province the subscription is sold in.
     * Tanzania regions are already listed so a second market needs no schema
     * change; an unmapped province falls back to the DRC, which is the only
     * market currently sold.
     */
    private function countryForProvince(string $province): string
    {
        $map = [
            'HAUT_KATANGA' => 'CD', 'LUALABA' => 'CD',
            'DAR_ES_SALAAM' => 'TZ', 'DODOMA' => 'TZ', 'ARUSHA' => 'TZ',
            'KILIMANJARO' => 'TZ', 'MARECHERI' => 'TZ', 'MWANZA' => 'TZ',
        ];
        $normalized = strtoupper(trim($province));

        return $map[$normalized] ?? 'CD';
    }

    private function nullableString(mixed $value): ?string
    {
        if (!is_string($value)) {
            return null;
        }
        $trimmed = trim($value);

        return $trimmed === '' ? null : $trimmed;
    }
}
