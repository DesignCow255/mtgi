<?php

declare(strict_types=1);

return [
    'name' => 'Mamore',
    'env' => getenv('APP_ENV') ?: 'local',
    'url' => getenv('APP_URL') ?: 'http://localhost:8080',
    'timezone' => getenv('APP_TIMEZONE') ?: 'Africa/Lubumbashi',
    'db' => [
        'host' => getenv('DB_HOST') ?: '127.0.0.1',
        'port' => getenv('DB_PORT') ?: '3306',
        'database' => getenv('DB_DATABASE') ?: 'mamore',
        'username' => getenv('DB_USERNAME') ?: 'mamore',
        'charset' => getenv('DB_CHARSET') ?: 'utf8mb4',
    ],
];
